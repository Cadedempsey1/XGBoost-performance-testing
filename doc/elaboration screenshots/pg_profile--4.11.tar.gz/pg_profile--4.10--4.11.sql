\echo Use "ALTER EXTENSION pg_profile UPDATE" to load this file. \quit
DROP FUNCTION collect_obj_stats;
DROP FUNCTION get_report_context;
DROP FUNCTION import_data;
DROP FUNCTION import_section_data_profile;
DROP FUNCTION import_section_data_subsample;
DROP FUNCTION init_sample;
DROP FUNCTION sample_dbobj_delta;
DROP FUNCTION take_sample(integer, boolean);
DROP FUNCTION take_sample(name, boolean);
DROP FUNCTION take_sample_subset(integer, integer);
DROP FUNCTION top_tables;
DROP FUNCTION top_toasts;
DROP FUNCTION take_subsample(integer, jsonb);
DROP FUNCTION export_data;
DROP FUNCTION set_server_setting;
CREATE FUNCTION set_server_setting(IN server name,
  IN setting text,
  IN value   text = NULL)
RETURNS integer SET search_path=@extschema@ AS $$
DECLARE
    upd_rows integer;
    etext    text := '';
    edetail  text := '';
    econtext text := '';
    collect_node jsonb;
BEGIN
    IF set_server_setting.setting IN (
        'collect_pg_stat_statements',
        'collect_pg_wait_sampling',
        'collect_objects',
        'collect_vacuum_stats',
        'collect_relations',
        'collect_functions'
      )
    THEN
        BEGIN
            PERFORM set_server_setting.value::boolean;
        EXCEPTION
            WHEN OTHERS THEN
                BEGIN
                    GET STACKED DIAGNOSTICS etext = MESSAGE_TEXT,
                        edetail = PG_EXCEPTION_DETAIL,
                        econtext = PG_EXCEPTION_CONTEXT;
                    RAISE 'Value for collection conditions should be boolean: %',
                        etext
                        USING DETAIL = edetail;
                END;
        END;
        SELECT
          COALESCE(srv_settings #> ARRAY['collect'], '{}'::jsonb)
            INTO collect_node
        FROM servers
        WHERE server_name = server;

        collect_node := jsonb_set(
                          collect_node,
                          ARRAY[substr(set_server_setting.setting, 9)],
                          to_jsonb(set_server_setting.value::boolean)
        );

        UPDATE servers SET srv_settings =
          jsonb_set(
            COALESCE(srv_settings, '{}'::jsonb),
            ARRAY['collect'],
            collect_node
          )
          WHERE server_name = server;
        GET DIAGNOSTICS upd_rows = ROW_COUNT;
        RETURN upd_rows;
    ELSE
        RAISE 'Unsupported setting';
    END IF;
END;
$$ LANGUAGE plpgsql;
CREATE FUNCTION export_data(IN server_name name = NULL, IN min_sample_id integer = NULL,
  IN max_sample_id integer = NULL, IN obfuscate_queries boolean = FALSE,
  IN hide_connstr boolean = FALSE)
RETURNS TABLE(
    section_id  bigint,
    row_data    json
) SET search_path=@extschema@ AS $$
DECLARE
  section_counter   bigint = 0;
  ext_version       text = NULL;
  tables_list       json = NULL;
  sserver_id        integer = NULL;
  r_result          RECORD;
BEGIN
  /*
    Exported table will contain rows of extension tables, packed in JSON
    Each row will have a section ID, defining a table in most cases
    First sections contains metadata - extension name and version, tables list
  */
  -- Extension info
  IF (SELECT count(*) = 1 FROM pg_catalog.pg_extension WHERE extname = 'pg_profile') THEN
    SELECT extversion INTO STRICT r_result FROM pg_catalog.pg_extension WHERE extname = 'pg_profile';
    ext_version := r_result.extversion;
  ELSE
    RAISE 'Export is not supported for manual installed version';
  END IF;
  RETURN QUERY EXECUTE $q$SELECT $3, row_to_json(s)
    FROM (SELECT $1 AS extension,
              $2 AS version,
              $3 + 1 AS tab_list_section
    ) s$q$
    USING 'pg_profile', ext_version, section_counter;
  section_counter := section_counter + 1;
  -- tables list
  EXECUTE $q$
    WITH RECURSIVE exp_tables (reloid, relname, inc_rels) AS (
      -- start with all independent tables
        SELECT rel.oid, rel.relname, array_agg(rel.oid) OVER()
          FROM pg_depend dep
            JOIN pg_extension ext ON (dep.refobjid = ext.oid)
            JOIN pg_class rel ON (rel.oid = dep.objid AND rel.relkind IN ('r','p'))
            LEFT OUTER JOIN fkdeps con ON (con.reloid = dep.objid)
          WHERE ext.extname = $1 AND rel.relname NOT IN
              ('import_queries', 'import_queries_version_order',
              'report', 'report_static', 'report_struct', 'last_stat_activity')
            AND NOT rel.relispartition
            AND con.reloid IS NULL
      UNION
      -- and add all tables that have resolved dependencies by previously added tables
          SELECT con.reloid as reloid, con.relname, recurse.inc_rels||array_agg(con.reloid) OVER()
          FROM
            fkdeps con JOIN
            exp_tables recurse ON
              (array_append(recurse.inc_rels,con.reloid) @> con.reldeps AND
              NOT ARRAY[con.reloid] <@ recurse.inc_rels)
    ),
    fkdeps (reloid, relname, reldeps) AS (
      -- tables with their foreign key dependencies
      SELECT rel.oid as reloid, rel.relname, array_agg(con.confrelid), array_agg(rel.oid) OVER()
      FROM pg_depend dep
        JOIN pg_extension ext ON (dep.refobjid = ext.oid)
        JOIN pg_class rel ON (rel.oid = dep.objid AND rel.relkind IN ('r','p'))
        JOIN pg_constraint con ON (con.conrelid = dep.objid AND con.contype = 'f')
      WHERE ext.extname = $1 AND rel.relname NOT IN
        ('import_queries', 'import_queries_version_order',
        'report', 'report_static', 'report_struct', 'last_stat_activity')
        AND NOT rel.relispartition
      GROUP BY rel.oid, rel.relname
    )
    SELECT json_agg(row_to_json(tl)) FROM
    (SELECT row_number() OVER() + $2 AS section_id, relname FROM exp_tables) tl ;
  $q$ INTO tables_list
  USING 'pg_profile', section_counter;
  section_id := section_counter;
  row_data := tables_list;
  RETURN NEXT;
  section_counter := section_counter + 1;
  -- Server selection
  IF export_data.server_name IS NOT NULL THEN
    sserver_id := get_server_by_name(export_data.server_name);
  END IF;
  -- Tables data
  FOR r_result IN
    SELECT json_array_elements(tables_list)->>'relname' as relname
  LOOP
    -- Tables select conditions
    CASE
      WHEN r_result.relname != 'sample_settings'
        AND (r_result.relname LIKE 'sample%' OR r_result.relname LIKE 'last%') THEN
        RETURN QUERY EXECUTE format(
            $q$SELECT $1,row_to_json(dt) FROM
              (SELECT * FROM %I WHERE ($2 IS NULL OR $2 = server_id) AND
                ($3 IS NULL OR sample_id >= $3) AND
                ($4 IS NULL OR sample_id <= $4)) dt$q$,
            r_result.relname
          )
        USING
          section_counter,
          sserver_id,
          min_sample_id,
          max_sample_id;
      WHEN r_result.relname = 'bl_samples' THEN
        RETURN QUERY EXECUTE format(
            $q$
            SELECT $1,row_to_json(dt) FROM (
              SELECT *
              FROM %I b
                JOIN (
                  SELECT bl_id
                  FROM bl_samples
                    WHERE ($2 IS NULL OR $2 = server_id)
                  GROUP BY bl_id
                  HAVING
                    ($3 IS NULL OR min(sample_id) >= $3) AND
                    ($4 IS NULL OR max(sample_id) <= $4)
                ) bl_smp USING (bl_id)
              WHERE ($2 IS NULL OR $2 = server_id)
              ) dt$q$,
            r_result.relname
          )
        USING
          section_counter,
          sserver_id,
          min_sample_id,
          max_sample_id;
      WHEN r_result.relname = 'baselines' THEN
        RETURN QUERY EXECUTE format(
            $q$
            SELECT $1,row_to_json(dt) FROM (
              SELECT b.*
              FROM %I b
              JOIN bl_samples bs USING(server_id, bl_id)
                WHERE ($2 IS NULL OR $2 = server_id)
              GROUP BY b.server_id, b.bl_id, b.bl_name, b.keep_until
              HAVING
                ($3 IS NULL OR min(sample_id) >= $3) AND
                ($4 IS NULL OR max(sample_id) <= $4)
              ) dt$q$,
            r_result.relname
          )
        USING
          section_counter,
          sserver_id,
          min_sample_id,
          max_sample_id;
      WHEN r_result.relname = 'stmt_list' THEN
        RETURN QUERY EXECUTE format(
            $sql$SELECT $1,row_to_json(dt) FROM
              (SELECT rows.server_id, rows.queryid_md5,
                CASE $5
                  WHEN TRUE THEN
                    encode(sha224(convert_to(rows.query, 'UTF8')), 'base64')
                    || ', Query length: '|| length(rows.query)::text
                  ELSE rows.query
                END AS query,
                last_sample_id
               FROM %I AS rows WHERE (server_id,queryid_md5) IN
                (SELECT server_id, queryid_md5 FROM sample_statements WHERE
                  ($2 IS NULL OR $2 = server_id) AND
                ($3 IS NULL OR sample_id >= $3) AND
                ($4 IS NULL OR sample_id <= $4))) dt$sql$,
            r_result.relname
          )
        USING
          section_counter,
          sserver_id,
          min_sample_id,
          max_sample_id,
          obfuscate_queries;
      WHEN r_result.relname = 'act_query' THEN
        RETURN QUERY EXECUTE format(
            $sql$SELECT $1,row_to_json(dt) FROM
              (SELECT rows.server_id, rows.act_query_md5,
                CASE $5
                  WHEN TRUE THEN
                    encode(sha224(convert_to(rows.act_query, 'UTF8')), 'base64')
                    || ', Query length: '|| length(rows.act_query)::text
                  ELSE rows.act_query
                END AS act_query,
                last_sample_id
               FROM %I AS rows WHERE (server_id, act_query_md5) IN
                (SELECT server_id, act_query_md5 FROM sample_act_statement WHERE
                  ($2 IS NULL OR $2 = server_id) AND
                ($3 IS NULL OR sample_id >= $3) AND
                ($4 IS NULL OR sample_id <= $4))) dt$sql$,
            r_result.relname
          )
        USING
          section_counter,
          sserver_id,
          min_sample_id,
          max_sample_id,
          obfuscate_queries;
      WHEN r_result.relname = 'servers' THEN
        RETURN QUERY EXECUTE format(
            $sql$SELECT $1,row_to_json(dt) FROM
              (SELECT
                rows.server_id,
                rows.server_name,
                rows.server_description,
                rows.server_created,
                rows.db_exclude,
                rows.enabled,
                CASE $3 OR $4
                  WHEN TRUE THEN
                    NULL
                  ELSE rows.connstr
                END AS connstr,
                rows.max_sample_age,
                rows.last_sample_id,
                rows.size_smp_wnd_start,
                rows.size_smp_wnd_dur,
                rows.size_smp_interval,
                rows.srv_settings
               FROM %I AS rows WHERE $2 IS NULL OR server_id = $2) dt$sql$,
            r_result.relname
          )
        USING
          section_counter,
          sserver_id,
          obfuscate_queries,
          hide_connstr;
      ELSE
        RETURN QUERY EXECUTE format(
            $q$SELECT $1,row_to_json(dt) FROM (SELECT * FROM %I WHERE $2 IS NULL OR $2 = server_id) dt$q$,
            r_result.relname
          )
        USING section_counter, sserver_id;
    END CASE;
    section_counter := section_counter + 1;
  END LOOP;
  RETURN;
END;
$$ LANGUAGE plpgsql;
COMMENT ON FUNCTION export_data(IN server_name name, IN min_sample_id integer,
  IN max_sample_id integer, IN obfuscate_queries boolean,
  IN hide_connstr boolean) IS 'Export collected data as a table';
CREATE FUNCTION import_data(data regclass, server_name_prefix text = NULL) RETURNS bigint
SET search_path=@extschema@ AS $$
DECLARE
  import_meta     jsonb;
  tables_list     jsonb;
  servers_list    jsonb; -- import servers list
  tmp_srv_map     jsonb = '{}'; -- import server_id to local server_id mapping
  dump_versions   text[];

  new_server_id   integer = null;
  s_id            integer;
  sserver_id      integer;
  import_stage    integer;
  tot_processed   bigint = 0;
  func_processed  bigint = 0;
  c_datarows      refcursor;

  servers_sect_id   integer = NULL;
  settings_sect_id  integer = NULL;

  r_result        RECORD;
BEGIN
  -- Get import metadata
  EXECUTE format('SELECT row_data::jsonb FROM %s WHERE section_id = 0',data)
  INTO STRICT import_meta;

  -- Check dump compatibility
  IF (SELECT count(*) < 1 FROM import_queries_version_order
      WHERE (extension, version) =
        (import_meta ->> 'extension', import_meta ->> 'version'))
  THEN
    RAISE 'Unsupported extension version: %', (import_meta ->> 'extension')||' '||(import_meta ->> 'version');
  END IF;

  -- Get import tables list
  EXECUTE format('SELECT row_data::jsonb FROM %s WHERE section_id = $1',data)
  USING (import_meta ->> 'tab_list_section')::integer
  INTO STRICT tables_list;

  -- Get vital section identifiers
  FOR r_result IN (
    SELECT
      section_id,
      relname
    FROM
      jsonb_to_recordset(tables_list) as tbllist(section_id integer, relname text)
    WHERE
      relname IN ('servers', 'sample_settings')
  ) LOOP
    CASE r_result.relname
      WHEN 'servers' THEN servers_sect_id := r_result.section_id;
      WHEN 'sample_settings' THEN settings_sect_id := r_result.section_id;
    END CASE;
  END LOOP;

  -- Servers processing
  -- Get import servers list
  EXECUTE format($q$SELECT
      jsonb_agg(srvjs.row_data::jsonb)
    FROM
      %1$s srvjs
    WHERE
      srvjs.section_id = $1$q$,
    data)
  USING servers_sect_id
  INTO STRICT servers_list;

  /*
   * Performing importing to local servers matching. We need to consider several cases:
   * - creation dates and system identifiers matched - we have a match
   * - creation dates and system identifiers don't match, but names matched - conflict as we can't create a new server
   * - nothing matched - a new local server is to be created
   * By the way, we'll populate tmp_srv_map table, containing
   * a mapping between local and importing servers to use on data load.
   */
  FOR r_result IN EXECUTE format($q$SELECT
      COALESCE($3,'')||
        imp_srv.server_name       imp_server_name,
      ls.server_name              local_server_name,
      imp_srv.server_created      imp_server_created,
      ls.server_created           local_server_created,
      d.row_data->>'reset_val'    imp_system_identifier,
      ls.system_identifier        local_system_identifier,
      imp_srv.server_id           imp_server_id,
      ls.server_id                local_server_id,
      imp_srv.server_description  imp_server_description,
      imp_srv.db_exclude          imp_server_db_exclude,
      imp_srv.connstr             imp_server_connstr,
      imp_srv.max_sample_age      imp_server_max_sample_age,
      imp_srv.last_sample_id      imp_server_last_sample_id,
      imp_srv.size_smp_wnd_start  imp_size_smp_wnd_start,
      imp_srv.size_smp_wnd_dur    imp_size_smp_wnd_dur,
      imp_srv.size_smp_interval   imp_size_smp_interval,
      imp_srv.srv_settings        imp_srv_settings
    FROM
      jsonb_to_recordset($1) as
        imp_srv(
          server_id           integer,
          server_name         name,
          server_description  text,
          server_created      timestamp with time zone,
          db_exclude          name[],
          enabled             boolean,
          connstr             text,
          max_sample_age      integer,
          last_sample_id      integer,
          size_smp_wnd_start  time with time zone,
          size_smp_wnd_dur    interval hour to second,
          size_smp_interval   interval day to minute,
          srv_settings        jsonb
        )
      JOIN %s d ON
        (d.section_id = $2 AND d.row_data->>'name' = 'system_identifier'
          AND (d.row_data->>'server_id')::integer = imp_srv.server_id)
      LEFT OUTER JOIN (
        SELECT
          srv.server_id,
          srv.server_name,
          srv.server_created,
          set.reset_val as system_identifier
        FROM servers srv
          LEFT OUTER JOIN sample_settings set ON (set.server_id = srv.server_id AND set.name = 'system_identifier')
        ) ls ON
        ((imp_srv.server_created = ls.server_created AND d.row_data->>'reset_val' = ls.system_identifier)
          OR COALESCE($3,'')||imp_srv.server_name = ls.server_name)
    $q$,
    data)
  USING
    servers_list,
    settings_sect_id,
    server_name_prefix
  LOOP
    IF r_result.imp_server_created = r_result.local_server_created AND
      r_result.imp_system_identifier = r_result.local_system_identifier
    THEN
      /* use this local server when matched by server creation time and system identifier */
      tmp_srv_map := jsonb_set(
        tmp_srv_map,
        ARRAY[r_result.imp_server_id::text],
        to_jsonb(r_result.local_server_id)
      );
      /* Update local server if new last_sample_id is greatest*/
      UPDATE servers
      SET
        (
          db_exclude,
          connstr,
          max_sample_age,
          last_sample_id,
          size_smp_wnd_start,
          size_smp_wnd_dur,
          size_smp_interval,
          srv_settings
        ) = (
          r_result.imp_server_db_exclude,
          r_result.imp_server_connstr,
          r_result.imp_server_max_sample_age,
          r_result.imp_server_last_sample_id,
          r_result.imp_size_smp_wnd_start,
          r_result.imp_size_smp_wnd_dur,
          r_result.imp_size_smp_interval,
          r_result.imp_srv_settings
        )
      WHERE server_id = r_result.local_server_id
        AND last_sample_id < r_result.imp_server_last_sample_id;
    ELSIF r_result.imp_server_name = r_result.local_server_name
    THEN
      /* Names matched, but identifiers does not - we have a conflict */
      RAISE 'Local server "%" creation date or system identifier does not match imported one (try renaming local server)',
        r_result.local_server_name;
    ELSIF r_result.local_server_name IS NULL
    THEN
      /* No match at all - we are creating a new server */
      INSERT INTO servers AS srv (
        server_name,
        server_description,
        server_created,
        db_exclude,
        enabled,
        connstr,
        max_sample_age,
        last_sample_id,
        size_smp_wnd_start,
        size_smp_wnd_dur,
        size_smp_interval,
        srv_settings)
      VALUES (
        r_result.imp_server_name,
        r_result.imp_server_description,
        r_result.imp_server_created,
        r_result.imp_server_db_exclude,
        FALSE,
        r_result.imp_server_connstr,
        r_result.imp_server_max_sample_age,
        r_result.imp_server_last_sample_id,
        r_result.imp_size_smp_wnd_start,
        r_result.imp_size_smp_wnd_dur,
        r_result.imp_size_smp_interval,
        r_result.imp_srv_settings
      )
      RETURNING server_id INTO new_server_id;
      tmp_srv_map := jsonb_set(
        tmp_srv_map,
        ARRAY[r_result.imp_server_id::text],
        to_jsonb(new_server_id)
      );
      PERFORM create_server_partitions(new_server_id);
    ELSE
      /* This shouldn't ever happen */
      RAISE 'Import and local servers matching exception';
    END IF;
  END LOOP;

  /* Version history array for checking during import
  *  This array should be ordered oldest version last, thus first
  *  entry will be the current version
  */
  WITH RECURSIVE versions AS (
      SELECT
        import_meta ->> 'extension' AS extension,
        import_meta ->> 'version' AS version,
        1 AS lvl
    UNION
      SELECT vo.parent_extension, vo.parent_version, v.lvl + 1 AS lvl
      FROM versions v JOIN import_queries_version_order vo ON
        (vo.extension, vo.version) = (v.extension, v.version)
  )
  SELECT array_agg(version || ':' || extension ORDER BY lvl DESC) INTO dump_versions
  FROM versions
  WHERE extension IS NOT NULL;

  /* Import tables data */

  CREATE TEMP TABLE import_sections_map (
       map_key text PRIMARY KEY,
       map_value jsonb
  );

  SET CONSTRAINTS ALL DEFERRED;
  import_stage := 0;
  WHILE import_stage < 3 LOOP
    FOR r_result IN (
      SELECT
        section_id,
        relname
      FROM
        jsonb_to_recordset(tables_list) AS tab_list(section_id integer, relname text)
    )
    LOOP
      CASE import_stage
        WHEN 0 THEN CONTINUE WHEN r_result.relname LIKE 'last_%';
        WHEN 1 THEN CONTINUE WHEN r_result.relname NOT LIKE 'last_%' OR
          r_result.relname = 'last_stat_kcache';
        WHEN 2 THEN CONTINUE WHEN r_result.relname != 'last_stat_kcache';
      END CASE;

      OPEN c_datarows FOR EXECUTE
        format('SELECT row_data FROM %s WHERE section_id = $1', data)
      USING r_result.section_id;
        RAISE NOTICE 'Started processing table %', r_result.relname;
        func_processed = 0;

        SELECT rows_processed, COALESCE(new_import_meta, import_meta)
          INTO func_processed, import_meta
        FROM import_section_data_profile(
          c_datarows,
          r_result.relname,
          tmp_srv_map,
          import_meta,
          dump_versions);
        -- try subsample import
        IF func_processed = -1 THEN
          SELECT rows_processed, COALESCE(new_import_meta, import_meta)
          INTO func_processed, import_meta
          FROM import_section_data_subsample(
            c_datarows,
            r_result.relname,
            tmp_srv_map,
            import_meta,
            dump_versions);
        END IF;

        IF func_processed = -1 THEN
          RAISE 'No import method for table %', r_result.relname;
        END IF;

        IF func_processed > 0 THEN
          RAISE NOTICE 'Analyzing table %', r_result.relname;
          EXECUTE format('ANALYZE %I', r_result.relname);
        END IF;

        RAISE NOTICE 'Finished processing %',
          format('table %s (%s rows)',r_result.relname, func_processed);
        tot_processed := tot_processed + func_processed;
        /*
        * In case of pgpro_pwr extension we should call two functions in series
        * First would be pg_profile function and if it will fail to process a table
        * the coursor is to be directed to pgpro_pwr import function
        */
      CLOSE c_datarows;
    END LOOP; -- over dump tables
    import_stage := import_stage + 1;
  END LOOP; -- over import stages

  DROP TABLE import_sections_map;

  -- Finalize import
  FOR r_result IN (SELECT * FROM jsonb_each(tmp_srv_map)) LOOP
    sserver_id := r_result.value;
    SELECT max(sample_id) INTO s_id FROM samples WHERE server_id = sserver_id;

    -- Updating dictionary tables setting last_sample_id
    UPDATE tablespaces_list utl SET last_sample_id = s_id - 1
    FROM tablespaces_list tl LEFT JOIN sample_stat_tablespaces cur
      ON (cur.server_id, cur.sample_id, cur.tablespaceid) =
        (sserver_id, s_id, tl.tablespaceid)
    WHERE
      tl.last_sample_id IS NULL AND
      (utl.server_id, utl.tablespaceid) = (sserver_id, tl.tablespaceid) AND
      tl.server_id = sserver_id AND cur.server_id IS NULL;

    UPDATE funcs_list ufl SET last_sample_id = s_id - 1
    FROM funcs_list fl LEFT JOIN sample_stat_user_functions cur
      ON (cur.server_id, cur.sample_id, cur.datid, cur.funcid) =
        (sserver_id, s_id, fl.datid, fl.funcid)
    WHERE
      fl.last_sample_id IS NULL AND
      fl.server_id = sserver_id AND cur.server_id IS NULL AND
      (ufl.server_id, ufl.datid, ufl.funcid) =
      (sserver_id, fl.datid, fl.funcid);

    UPDATE indexes_list uil SET last_sample_id = s_id - 1
    FROM indexes_list il LEFT JOIN sample_stat_indexes cur
      ON (cur.server_id, cur.sample_id, cur.datid, cur.indexrelid) =
        (sserver_id, s_id, il.datid, il.indexrelid)
    WHERE
      il.last_sample_id IS NULL AND
      il.server_id = sserver_id AND cur.server_id IS NULL AND
      (uil.server_id, uil.datid, uil.indexrelid) =
      (sserver_id, il.datid, il.indexrelid);

    UPDATE tables_list utl SET last_sample_id = s_id - 1
    FROM tables_list tl LEFT JOIN sample_stat_tables cur
      ON (cur.server_id, cur.sample_id, cur.datid, cur.relid) =
        (sserver_id, s_id, tl.datid, tl.relid)
    WHERE
      tl.last_sample_id IS NULL AND
      tl.server_id = sserver_id AND cur.server_id IS NULL AND
      (utl.server_id, utl.datid, utl.relid) =
      (sserver_id, tl.datid, tl.relid);

    UPDATE stmt_list slu SET last_sample_id = s_id - 1
    FROM sample_statements ss RIGHT JOIN stmt_list sl
      ON (ss.server_id, ss.sample_id, ss.queryid_md5) =
        (sserver_id, s_id, sl.queryid_md5)
    WHERE
      sl.server_id = sserver_id AND
      sl.last_sample_id IS NULL AND
      ss.server_id IS NULL AND
      (slu.server_id, slu.queryid_md5) = (sserver_id, sl.queryid_md5);

    UPDATE roles_list rlu SET last_sample_id = s_id - 1
    FROM
        sample_statements ss
      RIGHT JOIN roles_list rl
      ON (ss.server_id, ss.sample_id, ss.userid) =
        (sserver_id, s_id, rl.userid)
    WHERE
      rl.server_id = sserver_id AND
      rl.last_sample_id IS NULL AND
      ss.server_id IS NULL AND
      (rlu.server_id, rlu.userid) = (sserver_id, rl.userid);

    -- Cleanup last_ tables
    DELETE FROM last_stat_activity WHERE server_id = sserver_id AND sample_id != s_id;
    DELETE FROM last_stat_activity_count WHERE server_id = sserver_id AND sample_id != s_id;
    DELETE FROM last_stat_archiver WHERE server_id = sserver_id AND sample_id != s_id;
    DELETE FROM last_stat_cluster WHERE server_id = sserver_id AND sample_id != s_id;
    DELETE FROM last_stat_database WHERE server_id = sserver_id AND sample_id != s_id;
    DELETE FROM last_stat_indexes WHERE server_id=sserver_id AND sample_id != s_id;
    DELETE FROM last_stat_io WHERE server_id = sserver_id AND sample_id != s_id;
    DELETE FROM last_stat_kcache WHERE server_id = sserver_id AND sample_id != s_id;
    DELETE FROM last_stat_slru WHERE server_id = sserver_id AND sample_id != s_id;
    DELETE FROM last_stat_statements WHERE server_id = sserver_id AND sample_id != s_id;
    DELETE FROM last_stat_tables WHERE server_id=sserver_id AND sample_id != s_id;
    DELETE FROM last_stat_tablespaces WHERE server_id = sserver_id AND sample_id != s_id;
    DELETE FROM last_stat_user_functions WHERE server_id=sserver_id AND sample_id != s_id;
    DELETE FROM last_stat_wal WHERE server_id = sserver_id AND sample_id != s_id;
    DELETE FROM last_extension_versions WHERE server_id = sserver_id AND sample_id != s_id;
  END LOOP; --over import servers
  SET CONSTRAINTS ALL IMMEDIATE;
  RETURN tot_processed;
END;
$$ LANGUAGE plpgsql;
COMMENT ON FUNCTION import_data(regclass, text) IS
  'Import sample data from table, exported by export_data function';
CREATE FUNCTION import_section_data_profile(IN data refcursor, IN imp_table_name name, IN srv_map jsonb,
  IN import_meta jsonb, IN versions_array text[],
  OUT rows_processed bigint, OUT new_import_meta jsonb)
SET search_path=@extschema@ AS $$
DECLARE
  datarow          record;
  rowcnt           bigint = 0;
  row_proc         bigint = 0;
BEGIN
  new_import_meta := import_meta;
  CASE imp_table_name
    WHEN 'servers' THEN NULL; -- skip already imported servers table
    -- skip obsolete tables from old versions
    WHEN 'sample_stat_tables_failures' THEN NULL;
    WHEN 'sample_stat_indexes_failures' THEN NULL;
    WHEN 'samples' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO samples(server_id, sample_id, sample_time)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.sample_time
        FROM json_to_record(datarow.row_data) AS dr(
            server_id       integer,
            sample_id       integer,
            sample_time     timestamp(0) with time zone
          )
        JOIN
          servers s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer) =
            (s_ctl.server_id)
        ON CONFLICT ON CONSTRAINT pk_samples DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'baselines' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO baselines(server_id, bl_id, bl_name, keep_until)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.bl_id,
          dr.bl_name,
          dr.keep_until
        FROM json_to_record(datarow.row_data) AS dr(
            server_id    integer,
            bl_id        integer,
            bl_name      character varying(25),
            keep_until   timestamp (0) with time zone
          )
        JOIN
          servers s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer) =
            (s_ctl.server_id)
        ;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_settings' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_settings(server_id,first_seen,setting_scope,name,setting,
          reset_val,boot_val,unit,sourcefile,sourceline,pending_restart)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.first_seen,
          dr.setting_scope,
          dr.name,
          dr.setting,
          dr.reset_val,
          dr.boot_val,
          dr.unit,
          dr.sourcefile,
          dr.sourceline,
          dr.pending_restart
        FROM json_to_record(datarow.row_data) AS dr(
            server_id        integer,
            first_seen       timestamp(0) with time zone,
            setting_scope    smallint,
            name             text,
            setting          text,
            reset_val        text,
            boot_val         text,
            unit             text,
            sourcefile       text,
            sourceline       integer,
            pending_restart  boolean
          )
        JOIN
          servers s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer) =
            (s_ctl.server_id)
        ON CONFLICT ON CONSTRAINT pk_sample_settings DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'bl_samples' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO bl_samples(server_id, sample_id, bl_id)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.bl_id
        FROM json_to_record(datarow.row_data) AS dr(
            server_id       integer,
            sample_id       integer,
            bl_id           integer
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_stat_cluster' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_stat_cluster(server_id,sample_id,checkpoints_timed,
          checkpoints_req,checkpoints_done,checkpoint_write_time,checkpoint_sync_time,buffers_checkpoint,
          slru_checkpoint,buffers_clean,maxwritten_clean,buffers_backend,buffers_backend_fsync,
          buffers_alloc,stats_reset,wal_size,wal_lsn,in_recovery)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.checkpoints_timed,
          dr.checkpoints_req,
          dr.checkpoints_done,
          dr.checkpoint_write_time,
          dr.checkpoint_sync_time,
          dr.buffers_checkpoint,
          dr.slru_checkpoint,
          dr.buffers_clean,
          dr.maxwritten_clean,
          dr.buffers_backend,
          dr.buffers_backend_fsync,
          dr.buffers_alloc,
          dr.stats_reset,
          dr.wal_size,
          dr.wal_lsn,
          dr.in_recovery
        FROM json_to_record(datarow.row_data) AS dr(
            server_id              integer,
            sample_id              integer,
            checkpoints_timed      bigint,
            checkpoints_req        bigint,
            checkpoints_done       bigint,
            checkpoint_write_time  double precision,
            checkpoint_sync_time   double precision,
            buffers_checkpoint     bigint,
            slru_checkpoint        bigint,
            buffers_clean          bigint,
            maxwritten_clean       bigint,
            buffers_backend        bigint,
            buffers_backend_fsync  bigint,
            buffers_alloc          bigint,
            stats_reset            timestamp with time zone,
            wal_size               bigint,
            wal_lsn                pg_lsn,
            in_recovery            boolean
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_stat_cluster DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_stat_database' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_stat_database(server_id, sample_id, datid,datname,
          xact_commit, xact_rollback, blks_read, blks_hit, tup_returned, tup_fetched,
          tup_inserted, tup_updated, tup_deleted, conflicts, temp_files, temp_bytes,
          deadlocks, checksum_failures, checksum_last_failure, blk_read_time,
          blk_write_time, stats_reset, datsize,
          datsize_delta, datistemplate, session_time, active_time,
          idle_in_transaction_time, sessions, sessions_abandoned, sessions_fatal,
          sessions_killed, parallel_workers_to_launch, parallel_workers_launched)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.datid,
          dr.datname,
          dr.xact_commit,
          dr.xact_rollback,
          dr.blks_read,
          dr.blks_hit,
          dr.tup_returned,
          dr.tup_fetched,
          dr.tup_inserted,
          dr.tup_updated,
          dr.tup_deleted,
          dr.conflicts,
          dr.temp_files,
          dr.temp_bytes,
          dr.deadlocks,
          dr.checksum_failures,
          dr.checksum_last_failure,
          dr.blk_read_time,
          dr.blk_write_time,
          dr.stats_reset,
          dr.datsize,
          dr.datsize_delta,
          dr.datistemplate,
          dr.session_time,
          dr.active_time,
          dr.idle_in_transaction_time,
          dr.sessions,
          dr.sessions_abandoned,
          dr.sessions_fatal,
          dr.sessions_killed,
          dr.parallel_workers_to_launch,
          dr.parallel_workers_launched
        FROM json_to_record(datarow.row_data) AS dr(
          server_id       integer,
          sample_id       integer,
          datid           oid,
          datname         name,
          xact_commit     bigint,
          xact_rollback   bigint,
          blks_read       bigint,
          blks_hit        bigint,
          tup_returned    bigint,
          tup_fetched     bigint,
          tup_inserted    bigint,
          tup_updated     bigint,
          tup_deleted     bigint,
          conflicts       bigint,
          temp_files      bigint,
          temp_bytes      bigint,
          deadlocks       bigint,
          blk_read_time   double precision,
          blk_write_time  double precision,
          stats_reset     timestamp with time zone,
          datsize         bigint,
          datsize_delta   bigint,
          datistemplate   boolean,
          session_time    double precision,
          active_time     double precision,
          idle_in_transaction_time  double precision,
          sessions        bigint,
          sessions_abandoned  bigint,
          sessions_fatal      bigint,
          sessions_killed     bigint,
          parallel_workers_to_launch  bigint,
          parallel_workers_launched   bigint,
          checksum_failures   bigint,
          checksum_last_failure timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_stat_database DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_stat_wal' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_stat_wal(server_id,sample_id,wal_records,
          wal_fpi,wal_bytes,wal_buffers_full,wal_write,wal_sync,
          wal_write_time,wal_sync_time,stats_reset)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.wal_records,
          dr.wal_fpi,
          dr.wal_bytes,
          dr.wal_buffers_full,
          dr.wal_write,
          dr.wal_sync,
          dr.wal_write_time,
          dr.wal_sync_time,
          dr.stats_reset
        FROM json_to_record(datarow.row_data) AS dr(
            server_id           integer,
            sample_id           integer,
            wal_records         bigint,
            wal_fpi             bigint,
            wal_bytes           numeric,
            wal_buffers_full    bigint,
            wal_write           bigint,
            wal_sync            bigint,
            wal_write_time      double precision,
            wal_sync_time       double precision,
            stats_reset         timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_stat_wal DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_stat_archiver' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_stat_archiver(server_id,sample_id,archived_count,last_archived_wal,
          last_archived_time,failed_count,last_failed_wal,last_failed_time,
          stats_reset)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.archived_count,
          dr.last_archived_wal,
          dr.last_archived_time,
          dr.failed_count,
          dr.last_failed_wal,
          dr.last_failed_time,
          dr.stats_reset
        FROM json_to_record(datarow.row_data) AS dr(
            server_id           integer,
            sample_id           integer,
            archived_count      bigint,
            last_archived_wal   text,
            last_archived_time  timestamp with time zone,
            failed_count        bigint,
            last_failed_wal     text,
            last_failed_time    timestamp with time zone,
            stats_reset         timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_stat_archiver DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_stat_io' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_stat_io(server_id,sample_id,backend_type,object,context,reads,
          read_bytes,read_time,writes,write_bytes,write_time,writebacks,writeback_time,extends,
          extend_bytes,extend_time,op_bytes,hits,evictions,reuses,fsyncs,fsync_time,stats_reset)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.backend_type,
          dr.object,
          dr.context,
          dr.reads,
          dr.read_bytes,
          dr.read_time,
          dr.writes,
          dr.write_bytes,
          dr.write_time,
          dr.writebacks,
          dr.writeback_time,
          dr.extends,
          dr.extend_bytes,
          dr.extend_time,
          dr.op_bytes,
          dr.hits,
          dr.evictions,
          dr.reuses,
          dr.fsyncs,
          dr.fsync_time,
          dr.stats_reset
        FROM json_to_record(datarow.row_data) AS dr(
            server_id                   integer,
            sample_id                   integer,
            backend_type                text,
            object                      text,
            context                     text,
            reads                       bigint,
            read_bytes                  numeric,
            read_time                   double precision,
            writes                      bigint,
            write_bytes                 numeric,
            write_time                  double precision,
            writebacks                  bigint,
            writeback_time              double precision,
            extends                     bigint,
            extend_bytes                numeric,
            extend_time                 double precision,
            op_bytes                    bigint,
            hits                        bigint,
            evictions                   bigint,
            reuses                      bigint,
            fsyncs                      bigint,
            fsync_time                  double precision,
            stats_reset                 timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_stat_io DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_stat_slru' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_stat_slru(server_id,sample_id,name,blks_zeroed,
          blks_hit,blks_read,blks_written,blks_exists,flushes,truncates,
          stats_reset)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.name,
          dr.blks_zeroed,
          dr.blks_hit,
          dr.blks_read,
          dr.blks_written,
          dr.blks_exists,
          dr.flushes,
          dr.truncates,
          dr.stats_reset
        FROM json_to_record(datarow.row_data) AS dr(
            server_id      integer,
            sample_id      integer,
            name           text,
            blks_zeroed    bigint,
            blks_hit       bigint,
            blks_read      bigint,
            blks_written   bigint,
            blks_exists    bigint,
            flushes        bigint,
            truncates      bigint,
            stats_reset    timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_stat_slru DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'roles_list' THEN
      CASE
        WHEN array_position(versions_array, '0.3.5:pg_profile') >= 1 THEN
          LOOP
            FETCH data INTO datarow;
            EXIT WHEN NOT FOUND;
            INSERT INTO roles_list(server_id,last_sample_id,userid,username)
            SELECT
              (srv_map ->> dr.server_id::text)::integer,
              s.sample_id,
              dr.userid,
              dr.username
            FROM json_to_record(datarow.row_data) AS dr(
                server_id      integer,
                last_sample_id integer,
                userid         oid,
                username       name
              ) LEFT JOIN samples s ON (s.server_id, s.sample_id) =
                ((srv_map ->> dr.server_id::text)::integer, dr.last_sample_id)
            ON CONFLICT ON CONSTRAINT pk_roles_list DO
              UPDATE SET (last_sample_id, username) =
                (EXCLUDED.last_sample_id, EXCLUDED.username)
              WHERE (roles_list.last_sample_id, roles_list.username) IS DISTINCT FROM
                (EXCLUDED.last_sample_id, EXCLUDED.username);
            GET DIAGNOSTICS row_proc = ROW_COUNT;
            rowcnt := rowcnt + row_proc;
            IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
          END LOOP; -- over data rows
        ELSE
          RAISE '%', format('[import %s]: Unsupported extension version: %s %s',
            imp_table_name, import_meta ->> 'extension', import_meta ->> 'version');
      END CASE; -- over import versions
    WHEN 'tables_list' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        /* In case of old import (before 4.5) we should collect relid - reltoastrelid
        * binding here. We'll need it in further insert into sample_stat_tables
        */
        IF datarow.row_data #> ARRAY['reltoastrelid'] IS NOT NULL THEN
          INSERT INTO import_sections_map (map_key, map_value)
          VALUES (
            format('%s.%s',
              datarow.row_data #>> ARRAY['server_id'],
              datarow.row_data #>> ARRAY['relid']
            ),
            jsonb_build_object('reltoastrelid',
              datarow.row_data #> ARRAY['reltoastrelid']
            )
          ) ON CONFLICT DO NOTHING;
        END IF;
        INSERT INTO tables_list(server_id,last_sample_id,datid,relid,relkind,
          schemaname,relname)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          s.sample_id,
          dr.datid,
          dr.relid,
          dr.relkind,
          dr.schemaname,
          dr.relname
        FROM json_to_record(datarow.row_data) AS dr(
            server_id      integer,
            last_sample_id integer,
            datid          oid,
            relid          oid,
            relkind        character(1),
            schemaname     name,
            relname        name
          ) LEFT JOIN samples s ON (s.server_id, s.sample_id) =
            ((srv_map ->> dr.server_id::text)::integer, dr.last_sample_id)
          ON CONFLICT ON CONSTRAINT pk_tables_list DO
          UPDATE SET (last_sample_id, schemaname, relname) =
            (EXCLUDED.last_sample_id, EXCLUDED.schemaname, EXCLUDED.relname)
          WHERE (tables_list.last_sample_id, tables_list.schemaname, tables_list.relname)
            IS DISTINCT FROM
            (EXCLUDED.last_sample_id, EXCLUDED.schemaname, EXCLUDED.relname);
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
      -- Return collected relations mapping
      IF (SELECT count(*) > 0 FROM import_sections_map) THEN
        SELECT jsonb_set(new_import_meta, '{relations_map}',
          jsonb_object_agg(map_key, map_value))
          INTO new_import_meta
        FROM
          import_sections_map;
        TRUNCATE import_sections_map;
      END IF;
    WHEN 'stmt_list' THEN
      CASE
        WHEN array_position(versions_array, '0.3.2:pg_profile') >= 1 THEN
          LOOP
            FETCH data INTO datarow;
            EXIT WHEN NOT FOUND;
            INSERT INTO stmt_list(server_id, last_sample_id, queryid_md5, query)
            SELECT
              (srv_map ->> dr.server_id::text)::integer,
              s.sample_id,
              dr.queryid_md5,
              dr.query
            FROM json_to_record(datarow.row_data) AS dr (
                server_id      integer,
                last_sample_id integer,
                queryid_md5    character(32),
                query          text
              )
              LEFT JOIN samples s ON (s.server_id, s.sample_id) =
                ((srv_map ->> dr.server_id::text)::integer, dr.last_sample_id)
            ON CONFLICT ON CONSTRAINT pk_stmt_list
              DO NOTHING;
            GET DIAGNOSTICS row_proc = ROW_COUNT;
            rowcnt := rowcnt + row_proc;
            IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
              RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
            END IF;
          END LOOP; -- over data rows
        WHEN array_position(versions_array, '0.3.1:pg_profile') >= 1 THEN
          LOOP
            FETCH data INTO datarow;
            EXIT WHEN NOT FOUND;
            INSERT INTO import_sections_map (map_key, map_value)
            VALUES (
              format('%s.%s',
                datarow.row_data->>'queryid_md5',
                datarow.row_data->>'server_id'
              ),
              to_jsonb(left(encode(sha224(convert_to(
                datarow.row_data->>'query',
                'UTF8')
              ), 'base64'), 32))
            ) ON CONFLICT DO NOTHING;
            INSERT INTO stmt_list(server_id, last_sample_id, queryid_md5, query)
            SELECT
              (srv_map ->> dr.server_id::text)::integer,
              NULL,
              left(encode(sha224(convert_to(dr.query ,'UTF8')), 'base64'), 32),
              dr.query
            FROM json_to_record(datarow.row_data) AS dr (
                server_id      integer,
                query          text
              )
            ON CONFLICT ON CONSTRAINT pk_stmt_list
              DO NOTHING;
            GET DIAGNOSTICS row_proc = ROW_COUNT;
            rowcnt := rowcnt + row_proc;
            IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
              RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
            END IF;
          END LOOP; -- over data rows
          -- Return queryid mapping
          IF (SELECT count(*) > 0 FROM import_sections_map) THEN
            SELECT jsonb_set(new_import_meta, '{queryid_map}',
              jsonb_object_agg(map_key, map_value))
              INTO new_import_meta
            FROM
              import_sections_map;
            TRUNCATE import_sections_map;
          END IF;
        ELSE
          RAISE '%', format('[import %s]: Unsupported extension version: %s %s',
            imp_table_name, import_meta ->> 'extension', import_meta ->> 'version');
      END CASE; -- over import versions
    WHEN 'funcs_list' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO funcs_list(server_id, last_sample_id,datid,funcid,schemaname,
          funcname,funcargs)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          s.sample_id,
          dr.datid,
          dr.funcid,
          dr.schemaname,
          dr.funcname,
          dr.funcargs
        FROM json_to_record(datarow.row_data) AS dr(
            server_id      integer,
            last_sample_id integer,
            datid          oid,
            funcid         oid,
            schemaname     name,
            funcname       name,
            funcargs       text
          )
          LEFT JOIN samples s ON (s.server_id, s.sample_id) =
            ((srv_map ->> dr.server_id::text)::integer, dr.last_sample_id)
        ON CONFLICT ON CONSTRAINT pk_funcs_list DO
        UPDATE SET (last_sample_id, schemaname, funcname, funcargs) =
          (EXCLUDED.last_sample_id, EXCLUDED.schemaname, EXCLUDED.funcname, EXCLUDED.funcargs)
        WHERE (funcs_list.last_sample_id, funcs_list.schemaname, funcs_list.funcname,
          funcs_list.funcargs) IS DISTINCT FROM
          (EXCLUDED.last_sample_id, EXCLUDED.schemaname, EXCLUDED.funcname, EXCLUDED.funcargs);
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_timings' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_timings(server_id, sample_id, event, exec_point, event_ts)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.event,
          dr.exec_point,
          dr.event_ts
        FROM json_to_record(datarow.row_data) AS dr(
            server_id      integer,
            sample_id      integer,
            event          text,
            exec_point     text,
            event_ts       timestamp
          )
         JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_timings
          DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'tablespaces_list' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO tablespaces_list(server_id, last_sample_id,
          tablespaceid, tablespacename, tablespacepath)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          s.sample_id,
          dr.tablespaceid,
          dr.tablespacename,
          dr.tablespacepath
        FROM json_to_record(datarow.row_data) AS dr(
            server_id      integer,
            last_sample_id integer,
            tablespaceid   oid,
            tablespacename name,
            tablespacepath text
          )
          LEFT JOIN samples s ON (s.server_id, s.sample_id) =
            ((srv_map ->> dr.server_id::text)::integer, dr.last_sample_id)
        ON CONFLICT ON CONSTRAINT pk_tablespace_list DO
        UPDATE SET (last_sample_id, tablespacename, tablespacepath) =
          (EXCLUDED.last_sample_id, EXCLUDED.tablespacename, EXCLUDED.tablespacepath)
        WHERE (tablespaces_list.last_sample_id, tablespaces_list.tablespacename,
            tablespaces_list.tablespacepath) IS DISTINCT FROM
          (EXCLUDED.last_sample_id, EXCLUDED.tablespacename, EXCLUDED.tablespacepath);
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_stat_tablespaces' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_stat_tablespaces(server_id, sample_id,
          tablespaceid, size, size_delta)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.tablespaceid,
          dr.size,
          dr.size_delta
        FROM json_to_record(datarow.row_data) AS dr(
            server_id     integer,
            sample_id     integer,
            tablespaceid  oid,
            size          bigint,
            size_delta    bigint
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_stat_tablespaces
          DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'wait_sampling_total' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO wait_sampling_total(server_id, sample_id, sample_wevnt_id,
          event_type, event, tot_waited, stmt_waited)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.sample_wevnt_id,
          dr.event_type,
          dr.event,
          dr.tot_waited,
          dr.stmt_waited
        FROM json_to_record(datarow.row_data) AS dr(
            server_id           integer,
            sample_id           integer,
            sample_wevnt_id     integer,
            event_type          text,
            event               text,
            tot_waited          bigint,
            stmt_waited         bigint
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_weid
          DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'indexes_list' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO indexes_list(server_id, last_sample_id, datid, indexrelid, relid,
          schemaname, indexrelname)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          s.sample_id,
          dr.datid,
          dr.indexrelid,
          dr.relid,
          dr.schemaname,
          dr.indexrelname
        FROM json_to_record(datarow.row_data) AS dr(
            server_id      integer,
            last_sample_id integer,
            datid          oid,
            indexrelid     oid,
            relid          oid,
            schemaname     name,
            indexrelname   name
          )
          LEFT JOIN samples s ON (s.server_id, s.sample_id) =
            ((srv_map ->> dr.server_id::text)::integer, dr.last_sample_id)
        ON CONFLICT ON CONSTRAINT pk_indexes_list DO
        UPDATE SET (last_sample_id, schemaname, indexrelname) =
          (EXCLUDED.last_sample_id, EXCLUDED.schemaname, EXCLUDED.indexrelname)
        WHERE (indexes_list.last_sample_id, indexes_list.schemaname, indexes_list.indexrelname)
          IS DISTINCT FROM
          (EXCLUDED.last_sample_id, EXCLUDED.schemaname, EXCLUDED.indexrelname);
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_statements' THEN
      CASE -- Import version selector
        WHEN array_position(versions_array, '4.7:pg_profile') >= 1 THEN
          LOOP
            FETCH data INTO datarow;
            EXIT WHEN NOT FOUND;
            INSERT INTO sample_statements(server_id, sample_id, userid, datid, queryid, queryid_md5,
              plans, total_plan_time, min_plan_time, max_plan_time, mean_plan_time,
              sum_plan_time_sq, calls, total_exec_time, min_exec_time, max_exec_time,
              mean_exec_time, sum_exec_time_sq, rows, shared_blks_hit, shared_blks_read,
              shared_blks_dirtied, shared_blks_written, local_blks_hit, local_blks_read,
              local_blks_dirtied, local_blks_written, temp_blks_read, temp_blks_written,
              shared_blk_read_time, shared_blk_write_time, wal_records, wal_fpi, wal_bytes,
              wal_buffers_full, toplevel , jit_functions, jit_generation_time, jit_inlining_count,
              jit_inlining_time, jit_optimization_count, jit_optimization_time,
              jit_emission_count, jit_emission_time, temp_blk_read_time, temp_blk_write_time,
              local_blk_read_time, local_blk_write_time, jit_deform_count, jit_deform_time,
              parallel_workers_to_launch, parallel_workers_launched, stats_since, minmax_stats_since)
            SELECT
              (srv_map ->> dr.server_id::text)::integer,
              dr.sample_id,
              dr.userid,
              dr.datid,
              dr.queryid,
              dr.queryid_md5,
              dr.plans,
              dr.total_plan_time,
              dr.min_plan_time,
              dr.max_plan_time,
              dr.mean_plan_time,
              dr.sum_plan_time_sq,
              dr.calls,
              dr.total_exec_time,
              dr.min_exec_time,
              dr.max_exec_time,
              dr.mean_exec_time,
              dr.sum_exec_time_sq,
              dr.rows,
              dr.shared_blks_hit,
              dr.shared_blks_read,
              dr.shared_blks_dirtied,
              dr.shared_blks_written,
              dr.local_blks_hit,
              dr.local_blks_read,
              dr.local_blks_dirtied,
              dr.local_blks_written,
              dr.temp_blks_read,
              dr.temp_blks_written,
              dr.shared_blk_read_time,
              dr.shared_blk_write_time,
              dr.wal_records,
              dr.wal_fpi,
              dr.wal_bytes,
              dr.wal_buffers_full,
              COALESCE(dr.toplevel, true),
              dr.jit_functions,
              dr.jit_generation_time,
              dr.jit_inlining_count,
              dr.jit_inlining_time,
              dr.jit_optimization_count,
              dr.jit_optimization_time,
              dr.jit_emission_count,
              dr.jit_emission_time,
              dr.temp_blk_read_time,
              dr.temp_blk_write_time,
              dr.local_blk_read_time,
              dr.local_blk_write_time,
              dr.jit_deform_count,
              dr.jit_deform_time,
              dr.parallel_workers_to_launch,
              dr.parallel_workers_launched,
              dr.stats_since,
              dr.minmax_stats_since
            FROM json_to_record(datarow.row_data) AS dr(
              server_id            integer,
              sample_id            integer,
              userid               oid,
              datid                oid,
              queryid              bigint,
              queryid_md5          character(32),
              plans                bigint,
              total_plan_time      double precision,
              min_plan_time        double precision,
              max_plan_time        double precision,
              mean_plan_time       double precision,
              sum_plan_time_sq     numeric,
              calls                bigint,
              total_exec_time      double precision,
              min_exec_time        double precision,
              max_exec_time        double precision,
              mean_exec_time       double precision,
              sum_exec_time_sq     numeric,
              rows                 bigint,
              shared_blks_hit      bigint,
              shared_blks_read     bigint,
              shared_blks_dirtied  bigint,
              shared_blks_written  bigint,
              local_blks_hit       bigint,
              local_blks_read      bigint,
              local_blks_dirtied   bigint,
              local_blks_written   bigint,
              temp_blks_read       bigint,
              temp_blks_written    bigint,
              shared_blk_read_time  double precision,
              shared_blk_write_time double precision,
              wal_records          bigint,
              wal_fpi              bigint,
              wal_bytes            numeric,
              wal_buffers_full     bigint,
              toplevel             boolean,
              jit_functions        bigint,
              jit_generation_time  double precision,
              jit_inlining_count   bigint,
              jit_inlining_time    double precision,
              jit_optimization_count  bigint,
              jit_optimization_time   double precision,
              jit_emission_count   bigint,
              jit_emission_time    double precision,
              temp_blk_read_time   double precision,
              temp_blk_write_time  double precision,
              local_blk_read_time  double precision,
              local_blk_write_time double precision,
              jit_deform_count     bigint,
              jit_deform_time      double precision,
              parallel_workers_to_launch  bigint,
              parallel_workers_launched   bigint,
              stats_since          timestamp with time zone,
              minmax_stats_since   timestamp with time zone
              )
            JOIN
              samples s_ctl ON
                ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
                (s_ctl.server_id, s_ctl.sample_id)
            ON CONFLICT ON CONSTRAINT pk_sample_statements_n DO NOTHING;
            GET DIAGNOSTICS row_proc = ROW_COUNT;
            rowcnt := rowcnt + row_proc;
            IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
              RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
            END IF;
          END LOOP; -- over data rows
        WHEN array_position(versions_array, '4.0:pg_profile') >= 1 THEN
          LOOP
            FETCH data INTO datarow;
            EXIT WHEN NOT FOUND;
            INSERT INTO sample_statements(server_id, sample_id, userid, datid, queryid, queryid_md5,
              plans, total_plan_time, min_plan_time, max_plan_time, mean_plan_time,
              sum_plan_time_sq, calls, total_exec_time, min_exec_time, max_exec_time,
              mean_exec_time, sum_exec_time_sq, rows, shared_blks_hit, shared_blks_read,
              shared_blks_dirtied, shared_blks_written, local_blks_hit, local_blks_read,
              local_blks_dirtied, local_blks_written, temp_blks_read, temp_blks_written,
              shared_blk_read_time, shared_blk_write_time, wal_records, wal_fpi, wal_bytes,
              toplevel , jit_functions, jit_generation_time, jit_inlining_count,
              jit_inlining_time, jit_optimization_count, jit_optimization_time,
              jit_emission_count, jit_emission_time, temp_blk_read_time, temp_blk_write_time)
            SELECT
              (srv_map ->> dr.server_id::text)::integer,
              dr.sample_id,
              dr.userid,
              dr.datid,
              dr.queryid,
              dr.queryid_md5,
              dr.plans,
              dr.total_plan_time,
              dr.min_plan_time,
              dr.max_plan_time,
              dr.mean_plan_time,
              CASE
                WHEN dr.plans = 0 THEN 0
                WHEN dr.plans = 1 THEN
                  pow(dr.total_plan_time::numeric, 2)
                ELSE
                  pow(dr.stddev_plan_time::numeric, 2) * dr.plans +
                  pow(dr.mean_plan_time::numeric, 2) * dr.plans
              END AS sum_plan_time_sq,
              dr.calls,
              dr.total_exec_time,
              dr.min_exec_time,
              dr.max_exec_time,
              dr.mean_exec_time,
              CASE
                WHEN dr.calls = 0 THEN 0
                WHEN dr.calls = 1 THEN
                  pow(dr.total_exec_time::numeric, 2)
                ELSE
                  pow(dr.stddev_exec_time::numeric, 2) * dr.calls +
                  pow(dr.mean_exec_time::numeric, 2) * dr.calls
              END AS sum_exec_time_sq,
              dr.rows,
              dr.shared_blks_hit,
              dr.shared_blks_read,
              dr.shared_blks_dirtied,
              dr.shared_blks_written,
              dr.local_blks_hit,
              dr.local_blks_read,
              dr.local_blks_dirtied,
              dr.local_blks_written,
              dr.temp_blks_read,
              dr.temp_blks_written,
              dr.blk_read_time as shared_blk_read_time,
              dr.blk_write_time as shared_blk_write_time,
              dr.wal_records,
              dr.wal_fpi,
              dr.wal_bytes,
              COALESCE(dr.toplevel, true),
              dr.jit_functions,
              dr.jit_generation_time,
              dr.jit_inlining_count,
              dr.jit_inlining_time,
              dr.jit_optimization_count,
              dr.jit_optimization_time,
              dr.jit_emission_count,
              dr.jit_emission_time,
              dr.temp_blk_read_time,
              dr.temp_blk_write_time
            FROM json_to_record(datarow.row_data) AS dr(
              server_id            integer,
              sample_id            integer,
              userid               oid,
              datid                oid,
              queryid              bigint,
              queryid_md5          character(32),
              plans                bigint,
              total_plan_time      double precision,
              min_plan_time        double precision,
              max_plan_time        double precision,
              mean_plan_time       double precision,
              stddev_plan_time     double precision,
              calls                bigint,
              total_exec_time      double precision,
              min_exec_time        double precision,
              max_exec_time        double precision,
              mean_exec_time       double precision,
              stddev_exec_time     double precision,
              rows                 bigint,
              shared_blks_hit      bigint,
              shared_blks_read     bigint,
              shared_blks_dirtied  bigint,
              shared_blks_written  bigint,
              local_blks_hit       bigint,
              local_blks_read      bigint,
              local_blks_dirtied   bigint,
              local_blks_written   bigint,
              temp_blks_read       bigint,
              temp_blks_written    bigint,
              blk_read_time        double precision,
              blk_write_time       double precision,
              wal_records          bigint,
              wal_fpi              bigint,
              wal_bytes            numeric,
              toplevel             boolean,
              jit_functions        bigint,
              jit_generation_time  double precision,
              jit_inlining_count   bigint,
              jit_inlining_time    double precision,
              jit_optimization_count  bigint,
              jit_optimization_time   double precision,
              jit_emission_count   bigint,
              jit_emission_time    double precision,
              temp_blk_read_time   double precision,
              temp_blk_write_time  double precision
              )
            JOIN
              samples s_ctl ON
                ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
                (s_ctl.server_id, s_ctl.sample_id)
            ON CONFLICT ON CONSTRAINT pk_sample_statements_n DO NOTHING;
            GET DIAGNOSTICS row_proc = ROW_COUNT;
            rowcnt := rowcnt + row_proc;
            IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
              RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
            END IF;
          END LOOP; -- over data rows
        WHEN array_position(versions_array, '0.3.1:pg_profile') IS NOT NULL THEN
          LOOP
            FETCH data INTO datarow;
            EXIT WHEN NOT FOUND;

            INSERT INTO roles_list (server_id,userid,username)
            SELECT
              (srv_map ->> dr.server_id::text)::integer,
              dr.userid,
              '_unknown_'
            FROM json_to_record(datarow.row_data) AS dr(
                  server_id            integer,
                  userid               oid
              )
              JOIN
                servers s_ctl ON
                  ((srv_map ->> dr.server_id::text)::integer) =
                  (s_ctl.server_id)
            ON CONFLICT ON CONSTRAINT pk_roles_list DO
              UPDATE SET (last_sample_id, username) =
                (EXCLUDED.last_sample_id, EXCLUDED.username);

            INSERT INTO sample_statements(server_id, sample_id, userid, datid, queryid, queryid_md5,
              plans, total_plan_time, min_plan_time, max_plan_time, mean_plan_time,
              sum_plan_time_sq, calls, total_exec_time, min_exec_time, max_exec_time,
              mean_exec_time, sum_exec_time_sq, rows, shared_blks_hit, shared_blks_read,
              shared_blks_dirtied, shared_blks_written, local_blks_hit, local_blks_read,
              local_blks_dirtied, local_blks_written, temp_blks_read, temp_blks_written,
              shared_blk_read_time, shared_blk_write_time, wal_records, wal_fpi, wal_bytes,
              toplevel , jit_functions, jit_generation_time, jit_inlining_count,
              jit_inlining_time, jit_optimization_count, jit_optimization_time,
              jit_emission_count, jit_emission_time, temp_blk_read_time, temp_blk_write_time)
            SELECT
              (srv_map ->> dr.server_id::text)::integer,
              dr.sample_id,
              dr.userid,
              dr.datid,
              dr.queryid,
              CASE WHEN starts_with(versions_array[1], '0.3.1:') THEN
                import_meta #>> ARRAY[
                   'queryid_map',
                   format('%s.%s', dr.queryid_md5, dr.server_id::text)
                ]
              ELSE
                dr.queryid_md5
              END,
              dr.plans,
              dr.total_plan_time,
              dr.min_plan_time,
              dr.max_plan_time,
              dr.mean_plan_time,
              CASE
                WHEN dr.plans = 0 THEN 0
                WHEN dr.plans = 1 THEN
                  pow(dr.total_plan_time::numeric, 2)
                ELSE
                  pow(dr.stddev_plan_time::numeric, 2) * dr.plans +
                  pow(dr.mean_plan_time::numeric, 2) * dr.plans
              END AS sum_plan_time_sq,
              dr.calls,
              dr.total_exec_time,
              dr.min_exec_time,
              dr.max_exec_time,
              dr.mean_exec_time,
              CASE
                WHEN dr.calls = 0 THEN 0
                WHEN dr.calls = 1 THEN
                  pow(dr.total_exec_time::numeric, 2)
                ELSE
                  pow(dr.stddev_exec_time::numeric, 2) * dr.calls +
                  pow(dr.mean_exec_time::numeric, 2) * dr.calls
              END AS sum_exec_time_sq,
              dr.rows,
              dr.shared_blks_hit,
              dr.shared_blks_read,
              dr.shared_blks_dirtied,
              dr.shared_blks_written,
              dr.local_blks_hit,
              dr.local_blks_read,
              dr.local_blks_dirtied,
              dr.local_blks_written,
              dr.temp_blks_read,
              dr.temp_blks_written,
              dr.blk_read_time,
              dr.blk_write_time,
              dr.wal_records,
              dr.wal_fpi,
              dr.wal_bytes,
              COALESCE(dr.toplevel, true),
              dr.jit_functions,
              dr.jit_generation_time,
              dr.jit_inlining_count,
              dr.jit_inlining_time,
              dr.jit_optimization_count,
              dr.jit_optimization_time,
              dr.jit_emission_count,
              dr.jit_emission_time,
              dr.temp_blk_read_time,
              dr.temp_blk_write_time
            FROM json_to_record(datarow.row_data) AS dr(
              server_id            integer,
              sample_id            integer,
              userid               oid,
              datid                oid,
              queryid              bigint,
              queryid_md5          character(32),
              plans                bigint,
              total_plan_time      double precision,
              min_plan_time        double precision,
              max_plan_time        double precision,
              mean_plan_time       double precision,
              stddev_plan_time     double precision,
              calls                bigint,
              total_exec_time      double precision,
              min_exec_time        double precision,
              max_exec_time        double precision,
              mean_exec_time       double precision,
              stddev_exec_time     double precision,
              rows                 bigint,
              shared_blks_hit      bigint,
              shared_blks_read     bigint,
              shared_blks_dirtied  bigint,
              shared_blks_written  bigint,
              local_blks_hit       bigint,
              local_blks_read      bigint,
              local_blks_dirtied   bigint,
              local_blks_written   bigint,
              temp_blks_read       bigint,
              temp_blks_written    bigint,
              blk_read_time        double precision,
              blk_write_time       double precision,
              wal_records          bigint,
              wal_fpi              bigint,
              wal_bytes            numeric,
              toplevel             boolean,
              jit_functions        bigint,
              jit_generation_time  double precision,
              jit_inlining_count   bigint,
              jit_inlining_time    double precision,
              jit_optimization_count  bigint,
              jit_optimization_time   double precision,
              jit_emission_count   bigint,
              jit_emission_time    double precision,
              temp_blk_read_time   double precision,
              temp_blk_write_time  double precision
              )
            JOIN
              samples s_ctl ON
                ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
                (s_ctl.server_id, s_ctl.sample_id)
            ON CONFLICT ON CONSTRAINT pk_sample_statements_n DO NOTHING;
            GET DIAGNOSTICS row_proc = ROW_COUNT;
            rowcnt := rowcnt + row_proc;
            IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
              RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
            END IF;
          END LOOP; -- over data rows
        ELSE
          RAISE '%', format('[import %s]: Unsupported extension version: %s %s',
            imp_table_name, import_meta ->> 'extension', import_meta ->> 'version');
      END CASE; -- over import versions
    WHEN 'sample_statements_total' THEN
      CASE -- Import version selector
        WHEN array_position(versions_array, '4.7:pg_profile') >= 1 THEN
          LOOP
            FETCH data INTO datarow;
            EXIT WHEN NOT FOUND;
            INSERT INTO sample_statements_total(server_id, sample_id, datid, plans, total_plan_time,
              calls, total_exec_time, rows, shared_blks_hit, shared_blks_read, shared_blks_dirtied,
              shared_blks_written, local_blks_hit, local_blks_read, local_blks_dirtied,
              local_blks_written, temp_blks_read, temp_blks_written, shared_blk_read_time,
              shared_blk_write_time, wal_records, wal_fpi, wal_bytes, wal_buffers_full, statements, jit_functions,
              jit_generation_time, jit_inlining_count, jit_inlining_time, jit_optimization_count,
              jit_optimization_time, jit_emission_count, jit_emission_time, temp_blk_read_time,
              temp_blk_write_time, mean_max_plan_time, mean_max_exec_time, mean_min_plan_time,
              mean_min_exec_time, local_blk_read_time, local_blk_write_time, jit_deform_count,
              jit_deform_time)
            SELECT
              (srv_map ->> dr.server_id::text)::integer,
              dr.sample_id,
              dr.datid,
              dr.plans,
              dr.total_plan_time,
              dr.calls,
              dr.total_exec_time,
              dr.rows,
              dr.shared_blks_hit,
              dr.shared_blks_read,
              dr.shared_blks_dirtied,
              dr.shared_blks_written,
              dr.local_blks_hit,
              dr.local_blks_read,
              dr.local_blks_dirtied,
              dr.local_blks_written,
              dr.temp_blks_read,
              dr.temp_blks_written,
              dr.shared_blk_read_time,
              dr.shared_blk_write_time,
              dr.wal_records,
              dr.wal_fpi,
              dr.wal_bytes,
              dr.wal_buffers_full,
              dr.statements,
              dr.jit_functions,
              dr.jit_generation_time,
              dr.jit_inlining_count,
              dr.jit_inlining_time,
              dr.jit_optimization_count,
              dr.jit_optimization_time,
              dr.jit_emission_count,
              dr.jit_emission_time,
              dr.temp_blk_read_time,
              dr.temp_blk_write_time,
              dr.mean_max_plan_time,
              dr.mean_max_exec_time,
              dr.mean_min_plan_time,
              dr.mean_min_exec_time,
              dr.local_blk_read_time,
              dr.local_blk_write_time,
              dr.jit_deform_count,
              dr.jit_deform_time
            FROM json_to_record(datarow.row_data) AS dr(
                server_id            integer,
                sample_id            integer,
                datid                oid,
                plans                bigint,
                total_plan_time      double precision,
                calls                bigint,
                total_exec_time      double precision,
                rows                 bigint,
                shared_blks_hit      bigint,
                shared_blks_read     bigint,
                shared_blks_dirtied  bigint,
                shared_blks_written  bigint,
                local_blks_hit       bigint,
                local_blks_read      bigint,
                local_blks_dirtied   bigint,
                local_blks_written   bigint,
                temp_blks_read       bigint,
                temp_blks_written    bigint,
                shared_blk_read_time  double precision,
                shared_blk_write_time double precision,
                wal_records          bigint,
                wal_fpi              bigint,
                wal_bytes            numeric,
                wal_buffers_full     bigint,
                statements           bigint,
                jit_functions        bigint,
                jit_generation_time  double precision,
                jit_inlining_count   bigint,
                jit_inlining_time    double precision,
                jit_optimization_count  bigint,
                jit_optimization_time   double precision,
                jit_emission_count   bigint,
                jit_emission_time    double precision,
                temp_blk_read_time   double precision,
                temp_blk_write_time  double precision,
                mean_max_plan_time  double precision,
                mean_max_exec_time  double precision,
                mean_min_plan_time  double precision,
                mean_min_exec_time  double precision,
                local_blk_read_time double precision,
                local_blk_write_time  double precision,
                jit_deform_count    bigint,
                jit_deform_time     double precision
              )
            JOIN
              samples s_ctl ON
                ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
                (s_ctl.server_id, s_ctl.sample_id)
            ON CONFLICT ON CONSTRAINT pk_sample_statements_total DO NOTHING;
            GET DIAGNOSTICS row_proc = ROW_COUNT;
            rowcnt := rowcnt + row_proc;
            IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
              RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
            END IF;
          END LOOP; -- over data rows
        WHEN array_position(versions_array, '0.3.1:pg_profile') IS NOT NULL THEN
          LOOP
            FETCH data INTO datarow;
            EXIT WHEN NOT FOUND;
            INSERT INTO sample_statements_total(server_id, sample_id, datid, plans, total_plan_time,
              calls, total_exec_time, rows, shared_blks_hit, shared_blks_read, shared_blks_dirtied,
              shared_blks_written, local_blks_hit, local_blks_read, local_blks_dirtied,
              local_blks_written, temp_blks_read, temp_blks_written, shared_blk_read_time,
              shared_blk_write_time, wal_records, wal_fpi, wal_bytes, wal_buffers_full, statements, jit_functions,
              jit_generation_time, jit_inlining_count, jit_inlining_time, jit_optimization_count,
              jit_optimization_time, jit_emission_count, jit_emission_time, temp_blk_read_time,
              temp_blk_write_time, mean_max_plan_time, mean_max_exec_time, mean_min_plan_time,
              mean_min_exec_time)
            SELECT
              (srv_map ->> dr.server_id::text)::integer,
              dr.sample_id,
              dr.datid,
              dr.plans,
              dr.total_plan_time,
              dr.calls,
              dr.total_exec_time,
              dr.rows,
              dr.shared_blks_hit,
              dr.shared_blks_read,
              dr.shared_blks_dirtied,
              dr.shared_blks_written,
              dr.local_blks_hit,
              dr.local_blks_read,
              dr.local_blks_dirtied,
              dr.local_blks_written,
              dr.temp_blks_read,
              dr.temp_blks_written,
              dr.blk_read_time as shared_blk_read_time,
              dr.blk_write_time as shared_blk_write_time,
              dr.wal_records,
              dr.wal_fpi,
              dr.wal_bytes,
              dr.wal_buffers_full,
              dr.statements,
              dr.jit_functions,
              dr.jit_generation_time,
              dr.jit_inlining_count,
              dr.jit_inlining_time,
              dr.jit_optimization_count,
              dr.jit_optimization_time,
              dr.jit_emission_count,
              dr.jit_emission_time,
              dr.temp_blk_read_time,
              dr.temp_blk_write_time,
              dr.mean_max_plan_time,
              dr.mean_max_exec_time,
              dr.mean_min_plan_time,
              dr.mean_min_exec_time
            FROM json_to_record(datarow.row_data) AS dr(
                server_id            integer,
                sample_id            integer,
                datid                oid,
                plans                bigint,
                total_plan_time      double precision,
                calls                bigint,
                total_exec_time      double precision,
                rows                 bigint,
                shared_blks_hit      bigint,
                shared_blks_read     bigint,
                shared_blks_dirtied  bigint,
                shared_blks_written  bigint,
                local_blks_hit       bigint,
                local_blks_read      bigint,
                local_blks_dirtied   bigint,
                local_blks_written   bigint,
                temp_blks_read       bigint,
                temp_blks_written    bigint,
                blk_read_time        double precision,
                blk_write_time       double precision,
                wal_records          bigint,
                wal_fpi              bigint,
                wal_bytes            numeric,
                wal_buffers_full     bigint,
                statements           bigint,
                jit_functions        bigint,
                jit_generation_time  double precision,
                jit_inlining_count   bigint,
                jit_inlining_time    double precision,
                jit_optimization_count  bigint,
                jit_optimization_time   double precision,
                jit_emission_count   bigint,
                jit_emission_time    double precision,
                temp_blk_read_time   double precision,
                temp_blk_write_time  double precision,
                mean_max_plan_time  double precision,
                mean_max_exec_time  double precision,
                mean_min_plan_time  double precision,
                mean_min_exec_time  double precision
              )
            JOIN
              samples s_ctl ON
                ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
                (s_ctl.server_id, s_ctl.sample_id)
            ON CONFLICT ON CONSTRAINT pk_sample_statements_total DO NOTHING;
            GET DIAGNOSTICS row_proc = ROW_COUNT;
            rowcnt := rowcnt + row_proc;
            IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
              RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
            END IF;
          END LOOP; -- over data rows
        ELSE
          RAISE '%', format('[import %s]: Unsupported extension version: %s %s',
            imp_table_name, import_meta ->> 'extension', import_meta ->> 'version');
      END CASE; -- over import versions
    WHEN 'sample_kcache_total' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_kcache_total(server_id, sample_id, datid, plan_user_time,
          plan_system_time, plan_minflts, plan_majflts, plan_nswaps, plan_reads, plan_writes,
          plan_msgsnds, plan_msgrcvs, plan_nsignals, plan_nvcsws, plan_nivcsws,
          exec_user_time, exec_system_time, exec_minflts, exec_majflts, exec_nswaps,
          exec_reads, exec_writes, exec_msgsnds, exec_msgrcvs, exec_nsignals, exec_nvcsws,
          exec_nivcsws, statements)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.datid,
          dr.plan_user_time,
          dr.plan_system_time,
          dr.plan_minflts,
          dr.plan_majflts,
          dr.plan_nswaps,
          dr.plan_reads,
          dr.plan_writes,
          dr.plan_msgsnds,
          dr.plan_msgrcvs,
          dr.plan_nsignals,
          dr.plan_nvcsws,
          dr.plan_nivcsws,
          dr.exec_user_time,
          dr.exec_system_time,
          dr.exec_minflts,
          dr.exec_majflts,
          dr.exec_nswaps,
          dr.exec_reads,
          dr.exec_writes,
          dr.exec_msgsnds,
          dr.exec_msgrcvs,
          dr.exec_nsignals,
          dr.exec_nvcsws,
          dr.exec_nivcsws,
          dr.statements
        FROM json_to_record(datarow.row_data) AS dr(
            server_id         integer,
            sample_id         integer,
            datid             oid,
            plan_user_time    double precision,
            plan_system_time  double precision,
            plan_minflts      bigint,
            plan_majflts      bigint,
            plan_nswaps       bigint,
            plan_reads        bigint,
            plan_writes       bigint,
            plan_msgsnds      bigint,
            plan_msgrcvs      bigint,
            plan_nsignals     bigint,
            plan_nvcsws       bigint,
            plan_nivcsws      bigint,
            exec_user_time    double precision,
            exec_system_time  double precision,
            exec_minflts      bigint,
            exec_majflts      bigint,
            exec_nswaps       bigint,
            exec_reads        bigint,
            exec_writes       bigint,
            exec_msgsnds      bigint,
            exec_msgrcvs      bigint,
            exec_nsignals     bigint,
            exec_nvcsws       bigint,
            exec_nivcsws      bigint,
            statements        bigint
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_kcache_total DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_stat_user_functions' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_stat_user_functions(server_id, sample_id, datid, funcid,
          calls, total_time, self_time, trg_fn)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.datid,
          dr.funcid,
          dr.calls,
          dr.total_time,
          dr.self_time,
          dr.trg_fn
        FROM json_to_record(datarow.row_data) AS dr(
            server_id   integer,
            sample_id   integer,
            datid       oid,
            funcid      oid,
            calls       bigint,
            total_time  double precision,
            self_time   double precision,
            trg_fn      boolean
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_stat_user_functions DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_stat_user_func_total' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_stat_user_func_total(server_id, sample_id, datid, calls,
          total_time, trg_fn)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.datid,
          dr.calls,
          dr.total_time,
          dr.trg_fn
        FROM json_to_record(datarow.row_data) AS dr(
            server_id   integer,
            sample_id   integer,
            datid       oid,
            calls       bigint,
            total_time  double precision,
            trg_fn      boolean
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_stat_user_func_total DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_stat_tables' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_stat_tables(server_id,sample_id,
          datid,relid,reltoastrelid,tablespaceid,seq_scan,
          seq_tup_read,idx_scan,idx_tup_fetch,n_tup_ins,n_tup_upd,n_tup_del,n_tup_hot_upd,
          n_live_tup,n_dead_tup,n_mod_since_analyze,n_ins_since_vacuum,last_vacuum,
          last_autovacuum,last_analyze,last_autoanalyze,vacuum_count,autovacuum_count,
          analyze_count,autoanalyze_count,total_vacuum_time,total_autovacuum_time,
          total_analyze_time,total_autoanalyze_time,heap_blks_read,heap_blks_hit,idx_blks_read,
          idx_blks_hit,toast_blks_read,toast_blks_hit,tidx_blks_read,tidx_blks_hit,
          relsize,relsize_diff,relpages_bytes,relpages_bytes_diff,last_seq_scan,
          last_idx_scan,n_tup_newpage_upd)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.datid,
          dr.relid,
          COALESCE(
            dr.reltoastrelid,
            (import_meta #>> ARRAY[
                'relations_map',
                format('%s.%s', dr.server_id::text, dr.relid::text),
                'reltoastrelid'
              ]
            )::oid
          ) AS reltoastrelid,
          dr.tablespaceid,
          dr.seq_scan,
          dr.seq_tup_read,
          dr.idx_scan,
          dr.idx_tup_fetch,
          dr.n_tup_ins,
          dr.n_tup_upd,
          dr.n_tup_del,
          dr.n_tup_hot_upd,
          dr.n_live_tup,
          dr.n_dead_tup,
          dr.n_mod_since_analyze,
          dr.n_ins_since_vacuum,
          dr.last_vacuum,
          dr.last_autovacuum,
          dr.last_analyze,
          dr.last_autoanalyze,
          dr.vacuum_count,
          dr.autovacuum_count,
          dr.analyze_count,
          dr.autoanalyze_count,
          dr.total_vacuum_time,
          dr.total_autovacuum_time,
          dr.total_analyze_time,
          dr.total_autoanalyze_time,
          dr.heap_blks_read,
          dr.heap_blks_hit,
          dr.idx_blks_read,
          dr.idx_blks_hit,
          dr.toast_blks_read,
          dr.toast_blks_hit,
          dr.tidx_blks_read,
          dr.tidx_blks_hit,
          dr.relsize,
          dr.relsize_diff,
          dr.relpages_bytes,
          dr.relpages_bytes_diff,
          dr.last_seq_scan,
          dr.last_idx_scan,
          dr.n_tup_newpage_upd
        FROM json_to_record(datarow.row_data) AS dr(
          server_id            integer,
          sample_id            integer,
          datid                oid,
          relid                oid,
          reltoastrelid        oid,
          tablespaceid         oid,
          seq_scan             bigint,
          seq_tup_read         bigint,
          idx_scan             bigint,
          idx_tup_fetch        bigint,
          n_tup_ins            bigint,
          n_tup_upd            bigint,
          n_tup_del            bigint,
          n_tup_hot_upd        bigint,
          n_live_tup           bigint,
          n_dead_tup           bigint,
          n_mod_since_analyze  bigint,
          n_ins_since_vacuum   bigint,
          last_vacuum          timestamp with time zone,
          last_autovacuum      timestamp with time zone,
          last_analyze         timestamp with time zone,
          last_autoanalyze     timestamp with time zone,
          vacuum_count         bigint,
          autovacuum_count     bigint,
          analyze_count        bigint,
          autoanalyze_count    bigint,
          total_vacuum_time       double precision,
          total_autovacuum_time   double precision,
          total_analyze_time      double precision,
          total_autoanalyze_time  double precision,
          heap_blks_read       bigint,
          heap_blks_hit        bigint,
          idx_blks_read        bigint,
          idx_blks_hit         bigint,
          toast_blks_read      bigint,
          toast_blks_hit       bigint,
          tidx_blks_read       bigint,
          tidx_blks_hit        bigint,
          relsize              bigint,
          relsize_diff         bigint,
          relpages_bytes       bigint,
          relpages_bytes_diff  bigint,
          last_seq_scan        timestamp with time zone,
          last_idx_scan        timestamp with time zone,
          n_tup_newpage_upd    bigint
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_stat_tables DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
      /*
       Before v 4.5 it was possible to collect a heap statistics without toast statistics
       and it didn't cause any conflicts. Now sample_stat_tables references itself for a
       toast statistics. Setting a reltoastrelid field from old tables_list will cause a
       constraint violation. So, we should remove toasts references from samples without
       toast statistics collected.
      */
      IF array_position(versions_array, '4.5:pg_profile') IS NULL THEN
        ANALYZE sample_stat_tables;
        RAISE NOTICE 'Cleanup possible missing toast statistics from sample_stat_tables ...';
        UPDATE sample_stat_tables usst
        SET reltoastrelid = NULL
        FROM sample_stat_tables h LEFT JOIN sample_stat_tables t ON
          (t.server_id, t.sample_id, t.datid, t.relid) =
          (h.server_id, h.sample_id, h.datid, h.reltoastrelid)
        WHERE (usst.server_id, usst.sample_id, usst.datid, usst.relid) =
          (h.server_id, h.sample_id, h.datid, h.relid)
          AND t.relid IS NULL;
      END IF;
    WHEN 'sample_stat_tables_total' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_stat_tables_total(server_id,sample_id,datid,tablespaceid,relkind,
          seq_scan,seq_tup_read,idx_scan,idx_tup_fetch,n_tup_ins,n_tup_upd,n_tup_del,
          n_tup_hot_upd,vacuum_count,autovacuum_count,analyze_count,autoanalyze_count,
          total_vacuum_time,total_autovacuum_time,total_analyze_time,total_autoanalyze_time,
          heap_blks_read,heap_blks_hit,idx_blks_read,idx_blks_hit,toast_blks_read,
          toast_blks_hit,tidx_blks_read,tidx_blks_hit,relsize_diff,n_tup_newpage_upd)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.datid,
          dr.tablespaceid,
          dr.relkind,
          dr.seq_scan,
          dr.seq_tup_read,
          dr.idx_scan,
          dr.idx_tup_fetch,
          dr.n_tup_ins,
          dr.n_tup_upd,
          dr.n_tup_del,
          dr.n_tup_hot_upd,
          dr.vacuum_count,
          dr.autovacuum_count,
          dr.analyze_count,
          dr.autoanalyze_count,
          dr.total_vacuum_time,
          dr.total_autovacuum_time,
          dr.total_analyze_time,
          dr.total_autoanalyze_time,
          dr.heap_blks_read,
          dr.heap_blks_hit,
          dr.idx_blks_read,
          dr.idx_blks_hit,
          dr.toast_blks_read,
          dr.toast_blks_hit,
          dr.tidx_blks_read,
          dr.tidx_blks_hit,
          dr.relsize_diff,
          dr.n_tup_newpage_upd
        FROM json_to_record(datarow.row_data) AS dr(
          server_id          integer,
          sample_id          integer,
          datid              oid,
          tablespaceid       oid,
          relkind            character(1),
          seq_scan           bigint,
          seq_tup_read       bigint,
          idx_scan           bigint,
          idx_tup_fetch      bigint,
          n_tup_ins          bigint,
          n_tup_upd          bigint,
          n_tup_del          bigint,
          n_tup_hot_upd      bigint,
          vacuum_count       bigint,
          autovacuum_count   bigint,
          analyze_count      bigint,
          autoanalyze_count  bigint,
          total_vacuum_time       double precision,
          total_autovacuum_time   double precision,
          total_analyze_time      double precision,
          total_autoanalyze_time  double precision,
          heap_blks_read     bigint,
          heap_blks_hit      bigint,
          idx_blks_read      bigint,
          idx_blks_hit       bigint,
          toast_blks_read    bigint,
          toast_blks_hit     bigint,
          tidx_blks_read     bigint,
          tidx_blks_hit      bigint,
          relsize_diff       bigint,
          n_tup_newpage_upd  bigint
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_stat_tables_tot DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_stat_indexes' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_stat_indexes(server_id,sample_id,datid,indexrelid,tablespaceid,
          idx_scan,idx_tup_read,idx_tup_fetch,idx_blks_read,idx_blks_hit,relsize,
          relsize_diff,indisunique,relpages_bytes,relpages_bytes_diff,last_idx_scan)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.datid,
          dr.indexrelid,
          dr.tablespaceid,
          dr.idx_scan,
          dr.idx_tup_read,
          dr.idx_tup_fetch,
          dr.idx_blks_read,
          dr.idx_blks_hit,
          dr.relsize,
          dr.relsize_diff,
          dr.indisunique,
          dr.relpages_bytes,
          dr.relpages_bytes_diff,
          dr.last_idx_scan
        FROM json_to_record(datarow.row_data) AS dr(
          server_id      integer,
          sample_id      integer,
          datid          oid,
          indexrelid     oid,
          tablespaceid   oid,
          idx_scan       bigint,
          idx_tup_read   bigint,
          idx_tup_fetch  bigint,
          idx_blks_read  bigint,
          idx_blks_hit   bigint,
          relsize        bigint,
          relsize_diff   bigint,
          indisunique    boolean,
          relpages_bytes bigint,
          relpages_bytes_diff bigint,
          last_idx_scan  timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_stat_indexes DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_stat_indexes_total' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_stat_indexes_total (server_id,sample_id,datid,tablespaceid,idx_scan,
          idx_tup_read,idx_tup_fetch,idx_blks_read,idx_blks_hit,relsize_diff)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.datid,
          dr.tablespaceid,
          dr.idx_scan,
          dr.idx_tup_read,
          dr.idx_tup_fetch,
          dr.idx_blks_read,
          dr.idx_blks_hit,
          dr.relsize_diff
        FROM json_to_record(datarow.row_data) AS dr(
          server_id      integer,
          sample_id      integer,
          datid          oid,
          tablespaceid   oid,
          idx_scan       bigint,
          idx_tup_read   bigint,
          idx_tup_fetch  bigint,
          idx_blks_read  bigint,
          idx_blks_hit   bigint,
          relsize_diff   bigint
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_stat_indexes_tot DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_kcache' THEN
      CASE -- Import version selector
        WHEN array_position(versions_array, '0.3.2:pg_profile') >= 1 THEN
          LOOP
            FETCH data INTO datarow;
            EXIT WHEN NOT FOUND;
            INSERT INTO sample_kcache(server_id,sample_id,userid,datid,queryid,queryid_md5,
              plan_user_time,plan_system_time,plan_minflts,plan_majflts,
              plan_nswaps,plan_reads,plan_writes,plan_msgsnds,plan_msgrcvs,plan_nsignals,
              plan_nvcsws,plan_nivcsws,exec_user_time,exec_system_time,exec_minflts,
              exec_majflts,exec_nswaps,exec_reads,exec_writes,exec_msgsnds,exec_msgrcvs,
              exec_nsignals,exec_nvcsws,exec_nivcsws,toplevel,stats_since)
            SELECT
              (srv_map ->> dr.server_id::text)::integer,
              dr.sample_id,
              dr.userid,
              dr.datid,
              dr.queryid,
              dr.queryid_md5,
              dr.plan_user_time,
              dr.plan_system_time,
              dr.plan_minflts,
              dr.plan_majflts,
              dr.plan_nswaps,
              dr.plan_reads,
              dr.plan_writes,
              dr.plan_msgsnds,
              dr.plan_msgrcvs,
              dr.plan_nsignals,
              dr.plan_nvcsws,
              dr.plan_nivcsws,
              dr.exec_user_time,
              dr.exec_system_time,
              dr.exec_minflts,
              dr.exec_majflts,
              dr.exec_nswaps,
              dr.exec_reads,
              dr.exec_writes,
              dr.exec_msgsnds,
              dr.exec_msgrcvs,
              dr.exec_nsignals,
              dr.exec_nvcsws,
              dr.exec_nivcsws,
              coalesce(dr.toplevel, true),
              dr.stats_since
            FROM json_to_record(datarow.row_data) AS dr(
              server_id         integer,
              sample_id         integer,
              userid            oid,
              datid             oid,
              queryid           bigint,
              queryid_md5       character(32),
              plan_user_time    double precision,
              plan_system_time  double precision,
              plan_minflts      bigint,
              plan_majflts      bigint,
              plan_nswaps       bigint,
              plan_reads        bigint,
              plan_writes       bigint,
              plan_msgsnds      bigint,
              plan_msgrcvs      bigint,
              plan_nsignals     bigint,
              plan_nvcsws       bigint,
              plan_nivcsws      bigint,
              exec_user_time    double precision,
              exec_system_time  double precision,
              exec_minflts      bigint,
              exec_majflts      bigint,
              exec_nswaps       bigint,
              exec_reads        bigint,
              exec_writes       bigint,
              exec_msgsnds      bigint,
              exec_msgrcvs      bigint,
              exec_nsignals     bigint,
              exec_nvcsws       bigint,
              exec_nivcsws      bigint,
              toplevel          boolean,
              stats_since       timestamp with time zone
              )
            JOIN
              samples s_ctl ON
                ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
                (s_ctl.server_id, s_ctl.sample_id)
            ON CONFLICT ON CONSTRAINT pk_sample_kcache_n DO NOTHING;
            GET DIAGNOSTICS row_proc = ROW_COUNT;
            rowcnt := rowcnt + row_proc;
            IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
          END LOOP; -- over data rows
        WHEN array_position(versions_array, '0.3.1:pg_profile') >= 1 THEN
          LOOP
            FETCH data INTO datarow;
            EXIT WHEN NOT FOUND;
            INSERT INTO sample_kcache(server_id,sample_id,userid,datid,queryid,queryid_md5,
              plan_user_time,plan_system_time,plan_minflts,plan_majflts,
              plan_nswaps,plan_reads,plan_writes,plan_msgsnds,plan_msgrcvs,plan_nsignals,
              plan_nvcsws,plan_nivcsws,exec_user_time,exec_system_time,exec_minflts,
              exec_majflts,exec_nswaps,exec_reads,exec_writes,exec_msgsnds,exec_msgrcvs,
              exec_nsignals,exec_nvcsws,exec_nivcsws,toplevel,stats_since)
            SELECT
              (srv_map ->> dr.server_id::text)::integer,
              dr.sample_id,
              dr.userid,
              dr.datid,
              dr.queryid,
              CASE WHEN starts_with(versions_array[1], '0.3.1:') THEN
                import_meta #>> ARRAY[
                   'queryid_map',
                   format('%s.%s', dr.queryid_md5, dr.server_id::text)
                ]
              ELSE
                dr.queryid_md5
              END,
              dr.plan_user_time,
              dr.plan_system_time,
              dr.plan_minflts,
              dr.plan_majflts,
              dr.plan_nswaps,
              dr.plan_reads,
              dr.plan_writes,
              dr.plan_msgsnds,
              dr.plan_msgrcvs,
              dr.plan_nsignals,
              dr.plan_nvcsws,
              dr.plan_nivcsws,
              dr.exec_user_time,
              dr.exec_system_time,
              dr.exec_minflts,
              dr.exec_majflts,
              dr.exec_nswaps,
              dr.exec_reads,
              dr.exec_writes,
              dr.exec_msgsnds,
              dr.exec_msgrcvs,
              dr.exec_nsignals,
              dr.exec_nvcsws,
              dr.exec_nivcsws,
              coalesce(dr.toplevel, true),
              dr.stats_since
            FROM json_to_record(datarow.row_data) AS dr(
              server_id         integer,
              sample_id         integer,
              userid            oid,
              datid             oid,
              queryid           bigint,
              queryid_md5       character(32),
              plan_user_time    double precision,
              plan_system_time  double precision,
              plan_minflts      bigint,
              plan_majflts      bigint,
              plan_nswaps       bigint,
              plan_reads        bigint,
              plan_writes       bigint,
              plan_msgsnds      bigint,
              plan_msgrcvs      bigint,
              plan_nsignals     bigint,
              plan_nvcsws       bigint,
              plan_nivcsws      bigint,
              exec_user_time    double precision,
              exec_system_time  double precision,
              exec_minflts      bigint,
              exec_majflts      bigint,
              exec_nswaps       bigint,
              exec_reads        bigint,
              exec_writes       bigint,
              exec_msgsnds      bigint,
              exec_msgrcvs      bigint,
              exec_nsignals     bigint,
              exec_nvcsws       bigint,
              exec_nivcsws      bigint,
              toplevel          boolean,
              stats_since    timestamp with time zone
              )
            JOIN
              samples s_ctl ON
                ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
                (s_ctl.server_id, s_ctl.sample_id)
            ON CONFLICT ON CONSTRAINT pk_sample_kcache_n DO NOTHING;
            GET DIAGNOSTICS row_proc = ROW_COUNT;
            rowcnt := rowcnt + row_proc;
            IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
          END LOOP; -- over data rows
        ELSE
          RAISE '%', format('[import %s]: Unsupported extension version: %s %s',
            imp_table_name, import_meta ->> 'extension', import_meta ->> 'version');
      END CASE; -- over import versions
    WHEN 'last_stat_database' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO last_stat_database (server_id,sample_id,datid,datname,xact_commit,
          xact_rollback,blks_read,blks_hit,tup_returned,tup_fetched,tup_inserted,
          tup_updated,tup_deleted,conflicts,temp_files,temp_bytes,deadlocks,
          checksum_failures,checksum_last_failure,
          blk_read_time,blk_write_time,stats_reset,datsize,datsize_delta,datistemplate,
          session_time,active_time,
          idle_in_transaction_time,sessions,sessions_abandoned,sessions_fatal,
          sessions_killed,parallel_workers_to_launch,parallel_workers_launched)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.datid,
          dr.datname,
          dr.xact_commit,
          dr.xact_rollback,
          dr.blks_read,
          dr.blks_hit,
          dr.tup_returned,
          dr.tup_fetched,
          dr.tup_inserted,
          dr.tup_updated,
          dr.tup_deleted,
          dr.conflicts,
          dr.temp_files,
          dr.temp_bytes,
          dr.deadlocks,
          dr.checksum_failures,
          dr.checksum_last_failure,
          dr.blk_read_time,
          dr.blk_write_time,
          dr.stats_reset,
          dr.datsize,
          dr.datsize_delta,
          dr.datistemplate,
          dr.session_time,
          dr.active_time,
          dr.idle_in_transaction_time,
          dr.sessions,
          dr.sessions_abandoned,
          dr.sessions_fatal,
          dr.sessions_killed,
          dr.parallel_workers_to_launch,
          dr.parallel_workers_launched
        FROM json_to_record(datarow.row_data) AS dr(
          server_id       integer,
          sample_id       integer,
          datid           oid,
          datname         name,
          xact_commit     bigint,
          xact_rollback   bigint,
          blks_read       bigint,
          blks_hit        bigint,
          tup_returned    bigint,
          tup_fetched     bigint,
          tup_inserted    bigint,
          tup_updated     bigint,
          tup_deleted     bigint,
          conflicts       bigint,
          temp_files      bigint,
          temp_bytes      bigint,
          deadlocks       bigint,
          blk_read_time   double precision,
          blk_write_time  double precision,
          stats_reset     timestamp with time zone,
          datsize         bigint,
          datsize_delta   bigint,
          datistemplate   boolean,
          session_time    double precision,
          active_time     double precision,
          idle_in_transaction_time  double precision,
          sessions        bigint,
          sessions_abandoned  bigint,
          sessions_fatal      bigint,
          sessions_killed     bigint,
          parallel_workers_to_launch  bigint,
          parallel_workers_launched   bigint,
          checksum_failures   bigint,
          checksum_last_failure timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'last_stat_tablespaces' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO last_stat_tablespaces (server_id,sample_id,tablespaceid,tablespacename,
          tablespacepath,size,size_delta)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.tablespaceid,
          dr.tablespacename,
          dr.tablespacepath,
          dr.size,
          dr.size_delta
        FROM json_to_record(datarow.row_data) AS dr(
          server_id       integer,
          sample_id       integer,
          tablespaceid    oid,
          tablespacename  name,
          tablespacepath  text,
          size            bigint,
          size_delta      bigint
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'last_stat_cluster' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO last_stat_cluster (server_id,sample_id,checkpoints_timed,
          checkpoints_req,checkpoints_done,checkpoint_write_time,checkpoint_sync_time,
          buffers_checkpoint,slru_checkpoint,buffers_clean,maxwritten_clean,buffers_backend,
          buffers_backend_fsync,buffers_alloc,stats_reset,wal_size)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.checkpoints_timed,
          dr.checkpoints_req,
          dr.checkpoints_done,
          dr.checkpoint_write_time,
          dr.checkpoint_sync_time,
          dr.buffers_checkpoint,
          dr.slru_checkpoint,
          dr.buffers_clean,
          dr.maxwritten_clean,
          dr.buffers_backend,
          dr.buffers_backend_fsync,
          dr.buffers_alloc,
          dr.stats_reset,
          dr.wal_size
        FROM json_to_record(datarow.row_data) AS dr(
          server_id              integer,
          sample_id              integer,
          checkpoints_timed      bigint,
          checkpoints_req        bigint,
          checkpoints_done       bigint,
          checkpoint_write_time  double precision,
          checkpoint_sync_time   double precision,
          buffers_checkpoint     bigint,
          slru_checkpoint        bigint,
          buffers_clean          bigint,
          maxwritten_clean       bigint,
          buffers_backend        bigint,
          buffers_backend_fsync  bigint,
          buffers_alloc          bigint,
          stats_reset            timestamp with time zone,
          wal_size               bigint
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'last_stat_archiver' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO last_stat_archiver (server_id,sample_id,archived_count,last_archived_wal,
          last_archived_time,failed_count,last_failed_wal,last_failed_time,stats_reset)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.archived_count,
          dr.last_archived_wal,
          dr.last_archived_time,
          dr.failed_count,
          dr.last_failed_wal,
          dr.last_failed_time,
          dr.stats_reset
        FROM json_to_record(datarow.row_data) AS dr(
          server_id           integer,
          sample_id           integer,
          archived_count      bigint,
          last_archived_wal   text,
          last_archived_time  timestamp with time zone,
          failed_count        bigint,
          last_failed_wal     text,
          last_failed_time    timestamp with time zone,
          stats_reset         timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'last_stat_tables' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO last_stat_tables (server_id,sample_id,datid,relid,schemaname,relname,
          seq_scan,seq_tup_read,idx_scan,idx_tup_fetch,n_tup_ins,n_tup_upd,n_tup_del,
          n_tup_hot_upd,n_live_tup,n_dead_tup,n_mod_since_analyze,n_ins_since_vacuum,
          last_vacuum,last_autovacuum,last_analyze,last_autoanalyze,vacuum_count,
          autovacuum_count,analyze_count,autoanalyze_count,total_vacuum_time,total_autovacuum_time,
          total_analyze_time,total_autoanalyze_time,heap_blks_read,heap_blks_hit,
          idx_blks_read,idx_blks_hit,toast_blks_read,toast_blks_hit,tidx_blks_read,
          tidx_blks_hit,relsize,relsize_diff,tablespaceid,reltoastrelid,relkind,in_sample,
          relpages_bytes,relpages_bytes_diff,last_seq_scan,last_idx_scan,n_tup_newpage_upd,
          reloptions)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.datid,
          dr.relid,
          dr.schemaname,
          dr.relname,
          dr.seq_scan,
          dr.seq_tup_read,
          dr.idx_scan,
          dr.idx_tup_fetch,
          dr.n_tup_ins,
          dr.n_tup_upd,
          dr.n_tup_del,
          dr.n_tup_hot_upd,
          dr.n_live_tup,
          dr.n_dead_tup,
          dr.n_mod_since_analyze,
          dr.n_ins_since_vacuum,
          dr.last_vacuum,
          dr.last_autovacuum,
          dr.last_analyze,
          dr.last_autoanalyze,
          dr.vacuum_count,
          dr.autovacuum_count,
          dr.analyze_count,
          dr.autoanalyze_count,
          dr.total_vacuum_time,
          dr.total_autovacuum_time,
          dr.total_analyze_time,
          dr.total_autoanalyze_time,
          dr.heap_blks_read,
          dr.heap_blks_hit,
          dr.idx_blks_read,
          dr.idx_blks_hit,
          dr.toast_blks_read,
          dr.toast_blks_hit,
          dr.tidx_blks_read,
          dr.tidx_blks_hit,
          dr.relsize,
          dr.relsize_diff,
          dr.tablespaceid,
          dr.reltoastrelid,
          dr.relkind,
          COALESCE(dr.in_sample, false),
          dr.relpages_bytes,
          dr.relpages_bytes_diff,
          dr.last_seq_scan,
          dr.last_idx_scan,
          dr.n_tup_newpage_upd,
          dr.reloptions
        FROM json_to_record(datarow.row_data) AS dr(
          server_id            integer,
          sample_id            integer,
          datid                oid,
          relid                oid,
          schemaname           name,
          relname              name,
          seq_scan             bigint,
          seq_tup_read         bigint,
          idx_scan             bigint,
          idx_tup_fetch        bigint,
          n_tup_ins            bigint,
          n_tup_upd            bigint,
          n_tup_del            bigint,
          n_tup_hot_upd        bigint,
          n_live_tup           bigint,
          n_dead_tup           bigint,
          n_mod_since_analyze  bigint,
          n_ins_since_vacuum   bigint,
          last_vacuum          timestamp with time zone,
          last_autovacuum      timestamp with time zone,
          last_analyze         timestamp with time zone,
          last_autoanalyze     timestamp with time zone,
          total_vacuum_time       double precision,
          total_autovacuum_time   double precision,
          total_analyze_time      double precision,
          total_autoanalyze_time  double precision,
          vacuum_count         bigint,
          autovacuum_count     bigint,
          analyze_count        bigint,
          autoanalyze_count    bigint,
          heap_blks_read       bigint,
          heap_blks_hit        bigint,
          idx_blks_read        bigint,
          idx_blks_hit         bigint,
          toast_blks_read      bigint,
          toast_blks_hit       bigint,
          tidx_blks_read       bigint,
          tidx_blks_hit        bigint,
          relsize              bigint,
          relsize_diff         bigint,
          tablespaceid         oid,
          reltoastrelid        oid,
          relkind              character(1),
          in_sample            boolean,
          relpages_bytes       bigint,
          relpages_bytes_diff  bigint,
          last_seq_scan        timestamp with time zone,
          last_idx_scan        timestamp with time zone,
          n_tup_newpage_upd    bigint,
          reloptions           jsonb
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'last_stat_indexes' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO last_stat_indexes (server_id,sample_id,datid,relid,indexrelid,
          schemaname,relname,indexrelname,idx_scan,idx_tup_read,idx_tup_fetch,
          idx_blks_read,idx_blks_hit,relsize,relsize_diff,tablespaceid,indisunique,
          in_sample,relpages_bytes,relpages_bytes_diff,last_idx_scan,reloptions)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.datid,
          dr.relid,
          dr.indexrelid,
          dr.schemaname,
          dr.relname,
          dr.indexrelname,
          dr.idx_scan,
          dr.idx_tup_read,
          dr.idx_tup_fetch,
          dr.idx_blks_read,
          dr.idx_blks_hit,
          dr.relsize,
          dr.relsize_diff,
          dr.tablespaceid,
          dr.indisunique,
          COALESCE(dr.in_sample, false),
          dr.relpages_bytes,
          dr.relpages_bytes_diff,
          dr.last_idx_scan,
          dr.reloptions
        FROM json_to_record(datarow.row_data) AS dr(
          server_id      integer,
          sample_id      integer,
          datid          oid,
          relid          oid,
          indexrelid     oid,
          schemaname     name,
          relname        name,
          indexrelname   name,
          idx_scan       bigint,
          idx_tup_read   bigint,
          idx_tup_fetch  bigint,
          idx_blks_read  bigint,
          idx_blks_hit   bigint,
          relsize        bigint,
          relsize_diff   bigint,
          tablespaceid   oid,
          indisunique    boolean,
          in_sample      boolean,
          relpages_bytes bigint,
          relpages_bytes_diff bigint,
          last_idx_scan  timestamp with time zone,
          reloptions     jsonb
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'last_stat_user_functions' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO last_stat_user_functions (server_id,sample_id,datid,funcid,schemaname,
          funcname,funcargs,calls,total_time,self_time,trg_fn,in_sample)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.datid,
          dr.funcid,
          dr.schemaname,
          dr.funcname,
          dr.funcargs,
          dr.calls,
          dr.total_time,
          dr.self_time,
          dr.trg_fn,
          COALESCE(dr.in_sample, false)
        FROM json_to_record(datarow.row_data) AS dr(
          server_id   integer,
          sample_id   integer,
          datid       oid,
          funcid      oid,
          schemaname  name,
          funcname    name,
          funcargs    text,
          calls       bigint,
          total_time  double precision,
          self_time   double precision,
          trg_fn      boolean,
          in_sample   boolean
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'last_stat_wal' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO last_stat_wal (server_id,sample_id,wal_records,
          wal_fpi,wal_bytes,wal_buffers_full,wal_write,wal_sync,
          wal_write_time,wal_sync_time,stats_reset)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.wal_records,
          dr.wal_fpi,
          dr.wal_bytes,
          dr.wal_buffers_full,
          dr.wal_write,
          dr.wal_sync,
          dr.wal_write_time,
          dr.wal_sync_time,
          dr.stats_reset
        FROM json_to_record(datarow.row_data) AS dr(
          server_id           integer,
          sample_id           integer,
          wal_records         bigint,
          wal_fpi             bigint,
          wal_bytes           numeric,
          wal_buffers_full    bigint,
          wal_write           bigint,
          wal_sync            bigint,
          wal_write_time      double precision,
          wal_sync_time       double precision,
          stats_reset         timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'last_stat_kcache' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO last_stat_kcache (server_id,sample_id,userid,datid,toplevel,queryid,
          plan_user_time,plan_system_time,plan_minflts,plan_majflts,
          plan_nswaps,plan_reads,plan_writes,plan_msgsnds,plan_msgrcvs,plan_nsignals,
          plan_nvcsws,plan_nivcsws,exec_user_time,exec_system_time,exec_minflts,
          exec_majflts,exec_nswaps,exec_reads,exec_writes,exec_msgsnds,exec_msgrcvs,
          exec_nsignals,exec_nvcsws,exec_nivcsws,stats_since
        )
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.userid,
          dr.datid,
          dr.toplevel,
          dr.queryid,
          dr.plan_user_time,
          dr.plan_system_time,
          dr.plan_minflts,
          dr.plan_majflts,
          dr.plan_nswaps,
          dr.plan_reads,
          dr.plan_writes,
          dr.plan_msgsnds,
          dr.plan_msgrcvs,
          dr.plan_nsignals,
          dr.plan_nvcsws,
          dr.plan_nivcsws,
          dr.exec_user_time,
          dr.exec_system_time,
          dr.exec_minflts,
          dr.exec_majflts,
          dr.exec_nswaps,
          dr.exec_reads,
          dr.exec_writes,
          dr.exec_msgsnds,
          dr.exec_msgrcvs,
          dr.exec_nsignals,
          dr.exec_nvcsws,
          dr.exec_nivcsws,
          dr.stats_since
        FROM json_to_record(datarow.row_data) AS dr(
          server_id         integer,
          sample_id         integer,
          userid            oid,
          datid             oid,
          toplevel          boolean,
          queryid           bigint,
          plan_user_time    double precision,
          plan_system_time  double precision,
          plan_minflts      bigint,
          plan_majflts      bigint,
          plan_nswaps       bigint,
          plan_reads        bigint,
          plan_writes       bigint,
          plan_msgsnds      bigint,
          plan_msgrcvs      bigint,
          plan_nsignals     bigint,
          plan_nvcsws       bigint,
          plan_nivcsws      bigint,
          exec_user_time    double precision,
          exec_system_time  double precision,
          exec_minflts      bigint,
          exec_majflts      bigint,
          exec_nswaps       bigint,
          exec_reads        bigint,
          exec_writes       bigint,
          exec_msgsnds      bigint,
          exec_msgrcvs      bigint,
          exec_nsignals     bigint,
          exec_nvcsws       bigint,
          exec_nivcsws      bigint,
          stats_since       timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'last_stat_statements' THEN
      CASE -- Import version selector
        WHEN array_position(versions_array, '4.7:pg_profile') >= 1 THEN
          LOOP
            FETCH data INTO datarow;
            EXIT WHEN NOT FOUND;
            INSERT INTO last_stat_statements (server_id, sample_id, userid, username, datid, queryid,
              queryid_md5, plans, total_plan_time, min_plan_time, max_plan_time, mean_plan_time,
              stddev_plan_time, calls, total_exec_time, min_exec_time, max_exec_time,
              mean_exec_time, stddev_exec_time, rows, shared_blks_hit, shared_blks_read,
              shared_blks_dirtied, shared_blks_written, local_blks_hit, local_blks_read,
              local_blks_dirtied, local_blks_written, temp_blks_read, temp_blks_written,
              shared_blk_read_time, shared_blk_write_time, wal_records, wal_fpi, wal_bytes, wal_buffers_full,
              toplevel, in_sample, jit_functions, jit_generation_time, jit_inlining_count,
              jit_inlining_time, jit_optimization_count, jit_optimization_time,
              jit_emission_count, jit_emission_time, temp_blk_read_time, temp_blk_write_time,
              local_blk_read_time, local_blk_write_time, jit_deform_count, jit_deform_time,
              parallel_workers_to_launch, parallel_workers_launched, stats_since, minmax_stats_since
              )
            SELECT
              (srv_map ->> dr.server_id::text)::integer,
              dr.sample_id,
              dr.userid,
              dr.username,
              dr.datid,
              dr.queryid,
              dr.queryid_md5,
              dr.plans,
              dr.total_plan_time,
              dr.min_plan_time,
              dr.max_plan_time,
              dr.mean_plan_time,
              dr.stddev_plan_time,
              dr.calls,
              dr.total_exec_time,
              dr.min_exec_time,
              dr.max_exec_time,
              dr.mean_exec_time,
              dr.stddev_exec_time,
              dr.rows,
              dr.shared_blks_hit,
              dr.shared_blks_read,
              dr.shared_blks_dirtied,
              dr.shared_blks_written,
              dr.local_blks_hit,
              dr.local_blks_read,
              dr.local_blks_dirtied,
              dr.local_blks_written,
              dr.temp_blks_read,
              dr.temp_blks_written,
              dr.blk_read_time,
              dr.blk_write_time,
              dr.wal_records,
              dr.wal_fpi,
              dr.wal_bytes,
              dr.wal_buffers_full,
              dr.toplevel,
              dr.in_sample,
              dr.jit_functions,
              dr.jit_generation_time,
              dr.jit_inlining_count,
              dr.jit_inlining_time,
              dr.jit_optimization_count,
              dr.jit_optimization_time,
              dr.jit_emission_count,
              dr.jit_emission_time,
              dr.temp_blk_read_time,
              dr.temp_blk_write_time,
              dr.local_blk_read_time,
              dr.local_blk_write_time,
              dr.jit_deform_count,
              dr.jit_deform_time,
              dr.parallel_workers_to_launch,
              dr.parallel_workers_launched,
              dr.stats_since,
              dr.minmax_stats_since
            FROM json_to_record(datarow.row_data) AS dr(
              server_id            integer,
              sample_id            integer,
              userid               oid,
              username             name,
              datid                oid,
              queryid              bigint,
              queryid_md5          character(32),
              plans                bigint,
              total_plan_time      double precision,
              min_plan_time        double precision,
              max_plan_time        double precision,
              mean_plan_time       double precision,
              stddev_plan_time     double precision,
              calls                bigint,
              total_exec_time      double precision,
              min_exec_time        double precision,
              max_exec_time        double precision,
              mean_exec_time       double precision,
              stddev_exec_time     double precision,
              rows                 bigint,
              shared_blks_hit      bigint,
              shared_blks_read     bigint,
              shared_blks_dirtied  bigint,
              shared_blks_written  bigint,
              local_blks_hit       bigint,
              local_blks_read      bigint,
              local_blks_dirtied   bigint,
              local_blks_written   bigint,
              temp_blks_read       bigint,
              temp_blks_written    bigint,
              blk_read_time        double precision,
              blk_write_time       double precision,
              wal_records          bigint,
              wal_fpi              bigint,
              wal_bytes            numeric,
              wal_buffers_full     bigint,
              toplevel             boolean,
              in_sample            boolean,
              jit_functions        bigint,
              jit_generation_time  double precision,
              jit_inlining_count   bigint,
              jit_inlining_time    double precision,
              jit_optimization_count  bigint,
              jit_optimization_time   double precision,
              jit_emission_count   bigint,
              jit_emission_time    double precision,
              temp_blk_read_time   double precision,
              temp_blk_write_time  double precision,
              local_blk_read_time  double precision,
              local_blk_write_time double precision,
              jit_deform_count     bigint,
              jit_deform_time      double precision,
              parallel_workers_to_launch  bigint,
              parallel_workers_launched   bigint,
              stats_since          timestamp with time zone,
              minmax_stats_since   timestamp with time zone
              )
            JOIN
              samples s_ctl ON
                ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
                (s_ctl.server_id, s_ctl.sample_id)
            ON CONFLICT DO NOTHING;
            GET DIAGNOSTICS row_proc = ROW_COUNT;
            rowcnt := rowcnt + row_proc;
            IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
              RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
            END IF;
          END LOOP; -- over data rows
        WHEN array_position(versions_array, '0.3.1:pg_profile') IS NOT NULL THEN
          LOOP
            FETCH data INTO datarow;
            EXIT WHEN NOT FOUND;
            INSERT INTO last_stat_statements (server_id, sample_id, userid, username, datid, queryid,
              queryid_md5, plans, total_plan_time, min_plan_time, max_plan_time, mean_plan_time,
              stddev_plan_time, calls, total_exec_time, min_exec_time, max_exec_time,
              mean_exec_time, stddev_exec_time, rows, shared_blks_hit, shared_blks_read,
              shared_blks_dirtied, shared_blks_written, local_blks_hit, local_blks_read,
              local_blks_dirtied, local_blks_written, temp_blks_read, temp_blks_written,
              shared_blk_read_time, shared_blk_write_time, wal_records, wal_fpi, wal_bytes,
              toplevel, in_sample, jit_functions, jit_generation_time, jit_inlining_count,
              jit_inlining_time, jit_optimization_count, jit_optimization_time,
              jit_emission_count, jit_emission_time, temp_blk_read_time, temp_blk_write_time
              )
            SELECT
              (srv_map ->> dr.server_id::text)::integer,
              dr.sample_id,
              dr.userid,
              dr.username,
              dr.datid,
              dr.queryid,
              dr.queryid_md5,
              dr.plans,
              dr.total_plan_time,
              dr.min_plan_time,
              dr.max_plan_time,
              dr.mean_plan_time,
              dr.stddev_plan_time,
              dr.calls,
              dr.total_exec_time,
              dr.min_exec_time,
              dr.max_exec_time,
              dr.mean_exec_time,
              dr.stddev_exec_time,
              dr.rows,
              dr.shared_blks_hit,
              dr.shared_blks_read,
              dr.shared_blks_dirtied,
              dr.shared_blks_written,
              dr.local_blks_hit,
              dr.local_blks_read,
              dr.local_blks_dirtied,
              dr.local_blks_written,
              dr.temp_blks_read,
              dr.temp_blks_written,
              dr.blk_read_time,
              dr.blk_write_time,
              dr.wal_records,
              dr.wal_fpi,
              dr.wal_bytes,
              dr.toplevel,
              dr.in_sample,
              dr.jit_functions,
              dr.jit_generation_time,
              dr.jit_inlining_count,
              dr.jit_inlining_time,
              dr.jit_optimization_count,
              dr.jit_optimization_time,
              dr.jit_emission_count,
              dr.jit_emission_time,
              dr.temp_blk_read_time,
              dr.temp_blk_write_time
            FROM json_to_record(datarow.row_data) AS dr(
              server_id            integer,
              sample_id            integer,
              userid               oid,
              username             name,
              datid                oid,
              queryid              bigint,
              queryid_md5          character(32),
              plans                bigint,
              total_plan_time      double precision,
              min_plan_time        double precision,
              max_plan_time        double precision,
              mean_plan_time       double precision,
              stddev_plan_time     double precision,
              calls                bigint,
              total_exec_time      double precision,
              min_exec_time        double precision,
              max_exec_time        double precision,
              mean_exec_time       double precision,
              stddev_exec_time     double precision,
              rows                 bigint,
              shared_blks_hit      bigint,
              shared_blks_read     bigint,
              shared_blks_dirtied  bigint,
              shared_blks_written  bigint,
              local_blks_hit       bigint,
              local_blks_read      bigint,
              local_blks_dirtied   bigint,
              local_blks_written   bigint,
              temp_blks_read       bigint,
              temp_blks_written    bigint,
              blk_read_time        double precision,
              blk_write_time       double precision,
              wal_records          bigint,
              wal_fpi              bigint,
              wal_bytes            numeric,
              toplevel             boolean,
              in_sample            boolean,
              jit_functions        bigint,
              jit_generation_time  double precision,
              jit_inlining_count   bigint,
              jit_inlining_time    double precision,
              jit_optimization_count  bigint,
              jit_optimization_time   double precision,
              jit_emission_count   bigint,
              jit_emission_time    double precision,
              temp_blk_read_time   double precision,
              temp_blk_write_time  double precision
              )
            JOIN
              samples s_ctl ON
                ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
                (s_ctl.server_id, s_ctl.sample_id)
            ON CONFLICT DO NOTHING;
            GET DIAGNOSTICS row_proc = ROW_COUNT;
            rowcnt := rowcnt + row_proc;
            IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
              RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
            END IF;
          END LOOP; -- over data rows
        ELSE
          RAISE '%', format('[import %s]: Unsupported extension version: %s %s',
            imp_table_name, import_meta ->> 'extension', import_meta ->> 'version');
      END CASE; -- over import versions
    WHEN 'last_stat_io' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO last_stat_io (server_id,sample_id,backend_type,object,context,reads,
          read_bytes,read_time,writes,write_bytes,write_time,writebacks,writeback_time,extends,
          extend_bytes,extend_time,op_bytes,hits,evictions,reuses,fsyncs,fsync_time,stats_reset
          )
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.backend_type,
          dr.object,
          dr.context,
          dr.reads,
          dr.read_bytes,
          dr.read_time,
          dr.writes,
          dr.write_bytes,
          dr.write_time,
          dr.writebacks,
          dr.writeback_time,
          dr.extends,
          dr.extend_bytes,
          dr.extend_time,
          dr.op_bytes,
          dr.hits,
          dr.evictions,
          dr.reuses,
          dr.fsyncs,
          dr.fsync_time,
          dr.stats_reset
        FROM json_to_record(datarow.row_data) AS dr(
          server_id         integer,
          sample_id         integer,
          backend_type      text,
          object            text,
          context           text,
          reads             bigint,
          read_bytes        numeric,
          read_time         double precision,
          writes            bigint,
          write_bytes       numeric,
          write_time        double precision,
          writebacks        bigint,
          writeback_time    double precision,
          extends           bigint,
          extend_bytes      numeric,
          extend_time       double precision,
          op_bytes          bigint,
          hits              bigint,
          evictions         bigint,
          reuses            bigint,
          fsyncs            bigint,
          fsync_time        double precision,
          stats_reset       timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'last_stat_slru' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO last_stat_slru (server_id,sample_id,name,blks_zeroed,
          blks_hit,blks_read,blks_written,blks_exists,flushes,truncates,
          stats_reset
          )
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.name,
          dr.blks_zeroed,
          dr.blks_hit,
          dr.blks_read,
          dr.blks_written,
          dr.blks_exists,
          dr.flushes,
          dr.truncates,
          dr.stats_reset
        FROM json_to_record(datarow.row_data) AS dr(
          server_id      integer,
          sample_id      integer,
          name           text,
          blks_zeroed    bigint,
          blks_hit       bigint,
          blks_read      bigint,
          blks_written   bigint,
          blks_exists    bigint,
          flushes        bigint,
          truncates      bigint,
          stats_reset    timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'extension_versions' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO extension_versions(server_id,datid,extname,first_seen,last_sample_id,extversion)
        SELECT
          (srv_map ->> dr.server_id::text)::integer AS server_id,
          dr.datid,
          dr.extname,
          dr.first_seen,
          dr.last_sample_id,
          dr.extversion
        FROM json_to_record(datarow.row_data) AS dr(
            server_id        integer,
            datid            oid,
            extname          name,
            first_seen       timestamp(0) with time zone,
            last_sample_id   integer,
            extversion       text
          )
        JOIN
          servers s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer) =
            (s_ctl.server_id)
        ON CONFLICT ON CONSTRAINT pk_extension_versions DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'last_extension_versions' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO last_extension_versions(server_id, datid, sample_id, extname, extversion)
        SELECT
          (srv_map ->> dr.server_id::text)::integer AS server_id,
          dr.datid,
          dr.sample_id,
          dr.extname,
          dr.extversion
        FROM json_to_record(datarow.row_data) AS dr(
            server_id        integer,
            datid            oid,
            sample_id        integer,
            extname          name,
            extversion       text
          )
        JOIN
          servers s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer) =
            (s_ctl.server_id)
        ON CONFLICT ON CONSTRAINT pk_last_extension_versions DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'table_storage_parameters' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO table_storage_parameters(server_id,datid,relid,first_seen,last_sample_id,reloptions)
        SELECT
          (srv_map ->> dr.server_id::text)::integer AS server_id,
          dr.datid,
          dr.relid,
          dr.first_seen,
          dr.last_sample_id,
          dr.reloptions
        FROM json_to_record(datarow.row_data) AS dr(
            server_id        integer,
            datid            oid,
            relid            oid,
            first_seen       timestamp(0) with time zone,
            last_sample_id   integer,
            reloptions       jsonb
          )
        JOIN
          servers s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer) =
            (s_ctl.server_id)
        ON CONFLICT ON CONSTRAINT pk_table_storage_parameters DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'index_storage_parameters' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO index_storage_parameters(server_id,datid,relid,indexrelid,first_seen,last_sample_id,reloptions)
        SELECT
          (srv_map ->> dr.server_id::text)::integer AS server_id,
          dr.datid,
          dr.relid,
          dr.indexrelid,
          dr.first_seen,
          dr.last_sample_id,
          dr.reloptions
        FROM json_to_record(datarow.row_data) AS dr(
            server_id        integer,
            datid            oid,
            relid            oid,
            indexrelid       oid,
            first_seen       timestamp(0) with time zone,
            last_sample_id   integer,
            reloptions       jsonb
          )
        JOIN
          servers s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer) =
            (s_ctl.server_id)
        ON CONFLICT ON CONSTRAINT pk_index_storage_parameters DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    ELSE
      rows_processed := -1;
      RETURN; -- table not found
  END CASE; -- over table name
  rows_processed := rowcnt;
  RETURN;
END;
$$ LANGUAGE plpgsql;
CREATE FUNCTION import_section_data_subsample(IN data refcursor, IN imp_table_name name, IN srv_map jsonb,
  IN import_meta jsonb, IN versions_array text[],
  OUT rows_processed bigint, OUT new_import_meta jsonb)
SET search_path=@extschema@ AS $$
DECLARE
  datarow          record;
  rowcnt           bigint = 0;
  row_proc         bigint = 0;
BEGIN
  new_import_meta := import_meta;
  CASE imp_table_name
    WHEN 'last_stat_activity_count' THEN NULL; -- skip table without PK
    WHEN 'server_subsample' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO server_subsample(server_id, subsample_enabled, min_query_dur,
          min_xact_dur, min_xact_age, min_idle_xact_dur)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.subsample_enabled,
          dr.min_query_dur,
          dr.min_xact_dur,
          dr.min_xact_age,
          dr.min_idle_xact_dur
        FROM json_to_record(datarow.row_data) AS dr(
            server_id           integer,
            subsample_enabled   boolean,
            min_query_dur       interval hour to second,
            min_xact_dur        interval hour to second,
            min_xact_age        bigint,
            min_idle_xact_dur   interval hour to second
          )
        JOIN
          servers s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer) =
            (s_ctl.server_id)
        ON CONFLICT ON CONSTRAINT pk_server_subsample DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_act_backend' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_act_backend(server_id, sample_id, pid,
          backend_start, datid, datname, usesysid, usename,
          client_addr, client_hostname, client_port, backend_type,
          backend_last_ts)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.pid,
          dr.backend_start,
          dr.datid,
          dr.datname,
          dr.usesysid,
          dr.usename,
          dr.client_addr,
          dr.client_hostname,
          dr.client_port,
          dr.backend_type,
          dr.backend_last_ts
        FROM json_to_record(datarow.row_data) AS dr(
            server_id         integer,
            sample_id         integer,
            pid               integer,
            backend_start     timestamp with time zone,
            datid             oid,
            datname           name,
            usesysid          oid,
            usename           name,
            application_name  text,
            client_addr       inet,
            client_hostname   text,
            client_port       integer,
            backend_type      text,
            backend_last_ts   timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_backends DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_act_xact' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_act_xact(server_id, sample_id, pid, backend_start, xact_start,
          backend_xid, xact_last_ts)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.pid,
          dr.backend_start,
          dr.xact_start,
          dr.backend_xid,
          dr.xact_last_ts
        FROM json_to_record(datarow.row_data) AS dr(
            server_id         integer,
            sample_id         integer,
            pid               integer,
            backend_start     timestamp with time zone,
            xact_start        timestamp with time zone,
            backend_xid       text,
            xact_last_ts      timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_xact DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_act_backend_state' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_act_backend_state(server_id, sample_id,
          pid, backend_start, application_name, state_code,
          state_change, state_last_ts, xact_start, backend_xmin,
          backend_xmin_age, query_start)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.pid,
          dr.backend_start,
          dr.application_name,
          dr.state_code,
          dr.state_change,
          dr.state_last_ts,
          dr.xact_start,
          dr.backend_xmin,
          dr.backend_xmin_age,
          dr.query_start
        FROM json_to_record(datarow.row_data) AS dr(
            server_id         integer,
            sample_id         integer,
            pid               integer,
            backend_start     timestamp with time zone,
            application_name  text,
            state_code        integer,
            state_change      timestamp with time zone,
            state_last_ts     timestamp with time zone,
            xact_start        timestamp with time zone,
            backend_xmin      text,
            backend_xmin_age  bigint,
            query_start       timestamp with time zone
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_bk_state DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'act_query' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO act_query(server_id, act_query_md5, act_query, last_sample_id)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.act_query_md5,
          dr.act_query,
          s.sample_id
        FROM json_to_record(datarow.row_data) AS dr(
            server_id      integer,
            act_query_md5  char(32),
            act_query      text,
            last_sample_id integer
          )
          LEFT JOIN samples s ON (s.server_id, s.sample_id) =
            ((srv_map ->> dr.server_id::text)::integer, dr.last_sample_id)
        ON CONFLICT ON CONSTRAINT pk_act_query DO
          NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_act_statement' THEN
      IF array_position(versions_array, '4.7:pg_profile') >= 1 THEN
        /*
         V4.6 released with little bit incorrect schema, so, we will
         process it later. Here is V4.7+ import
        */
        LOOP
          FETCH data INTO datarow;
          EXIT WHEN NOT FOUND;

          INSERT INTO sample_act_statement(server_id, sample_id, pid,
            leader_pid, query_start, query_id, act_query_md5,
            stmt_last_ts, xact_start)
          SELECT
            (srv_map ->> dr.server_id::text)::integer,
            dr.sample_id,
            dr.pid,
            dr.leader_pid,
            dr.query_start,
            dr.query_id,
            dr.act_query_md5,
            dr.stmt_last_ts,
            dr.xact_start
          FROM json_to_record(datarow.row_data) AS dr(
              server_id         integer,
              sample_id         integer,
              pid               integer,
              leader_pid        integer,
              state_change      timestamp with time zone,
              query_start       timestamp with time zone,
              query_id          bigint,
              act_query_md5     char(32),
              stmt_last_ts      timestamp with time zone,
              xact_start        timestamp with time zone
            )
          JOIN
            samples s_ctl ON
              ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
              (s_ctl.server_id, s_ctl.sample_id)
          ON CONFLICT ON CONSTRAINT pk_sample_act_stmt DO NOTHING;
          GET DIAGNOSTICS row_proc = ROW_COUNT;
          rowcnt := rowcnt + row_proc;
          IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
            RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
          END IF;
        END LOOP; -- over data rows
      ELSE
        /* V4.6 import special case
          We should update sample_act_backend_state table with
          query_start field obtained from the sample_act_statement
          data row. By the way we should get xact_start from
          sample_act_backend_state and finally insert the data in
          sample_act_statement table
        */
        LOOP
          FETCH data INTO datarow;
          EXIT WHEN NOT FOUND;

          WITH u AS (
            UPDATE sample_act_backend_state usabs
              SET query_start = dr.query_start
            FROM json_to_record(datarow.row_data) AS dr(
                server_id         integer,
                sample_id         integer,
                pid               integer,
                leader_pid        integer,
                state_change      timestamp with time zone,
                query_start       timestamp with time zone,
                query_id          bigint,
                act_query_md5     char(32),
                stmt_last_ts      timestamp with time zone
              )
            WHERE
              (usabs.server_id, usabs.sample_id, usabs.pid, usabs.state_change) =
              ((srv_map ->> dr.server_id::text)::integer, dr.sample_id, dr.pid, dr.state_change)
            RETURNING usabs.server_id, usabs.sample_id, usabs.pid, dr.leader_pid,
              dr.query_start, dr.query_id, dr.act_query_md5, dr.stmt_last_ts,
              usabs.xact_start
          )
          INSERT INTO sample_act_statement(server_id, sample_id, pid,
            leader_pid, query_start, query_id, act_query_md5,
            stmt_last_ts, xact_start)
          SELECT
            u.server_id,
            u.sample_id,
            u.pid,
            u.leader_pid,
            u.query_start,
            u.query_id,
            u.act_query_md5,
            u.stmt_last_ts,
            u.xact_start
          FROM u
          ON CONFLICT ON CONSTRAINT pk_sample_act_stmt DO NOTHING;
          GET DIAGNOSTICS row_proc = ROW_COUNT;
          rowcnt := rowcnt + row_proc;
          IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
            RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
          END IF;
        END LOOP; -- over data rows
      END IF;
    WHEN 'last_stat_activity' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO last_stat_activity(server_id, sample_id,
          subsample_ts, datid, datname, pid, leader_pid, usesysid,
          usename, application_name, client_addr, client_hostname,
          client_port, backend_start, xact_start, query_start,
          state_change, state, backend_xid, backend_xmin, query_id,
          query, backend_type, backend_xmin_age
        )
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.subsample_ts,
          dr.datid,
          dr.datname,
          dr.pid,
          dr.leader_pid,
          dr.usesysid,
          dr.usename,
          dr.application_name,
          dr.client_addr,
          dr.client_hostname,
          dr.client_port,
          dr.backend_start,
          dr.xact_start,
          dr.query_start,
          dr.state_change,
          dr.state,
          dr.backend_xid,
          dr.backend_xmin,
          dr.query_id,
          dr.query,
          dr.backend_type,
          dr.backend_xmin_age
        FROM json_to_record(datarow.row_data) AS dr(
            server_id         integer,
            sample_id         integer,
            subsample_ts      timestamp with time zone,
            datid             oid,
            datname           name,
            pid               integer,
            leader_pid        integer,
            usesysid          oid,
            usename           name,
            application_name  text,
            client_addr       inet,
            client_hostname   text,
            client_port       integer,
            backend_start     timestamp with time zone,
            xact_start        timestamp with time zone,
            query_start       timestamp with time zone,
            state_change      timestamp with time zone,
            state             text,
            backend_xid       text,
            backend_xmin      text,
            query_id          bigint,
            query             text,
            backend_type      text,
            backend_xmin_age  bigint
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'session_attr' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO session_attr(server_id, sess_attr_id,
          backend_type, datid, datname, usesysid, usename,
          application_name, client_addr, last_sample_id)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sess_attr_id,
          dr.backend_type,
          dr.datid,
          dr.datname,
          dr.usesysid,
          dr.usename,
          dr.application_name,
          dr.client_addr,
          dr.last_sample_id
        FROM json_to_record(datarow.row_data) AS dr(
            server_id         integer,
            sess_attr_id      integer,
            backend_type      text,
            datid             oid,
            datname           name,
            usesysid          oid,
            usename           name,
            application_name  text,
            client_addr       inet,
            last_sample_id    integer
          )
        JOIN
          servers s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer) =
            (s_ctl.server_id)
        ON CONFLICT ON CONSTRAINT pk_subsample_sa DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'sample_stat_activity_cnt' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO sample_stat_activity_cnt(server_id, sample_id,
          subsample_ts, sess_attr_id, total, active, idle, idle_t,
          idle_ta, state_null, lwlock, lock, bufferpin, activity,
          extension, client, ipc, timeout, io)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.subsample_ts,
          dr.sess_attr_id,
          dr.total,
          dr.active,
          dr.idle,
          dr.idle_t,
          dr.idle_ta,
          dr.state_null,
          dr.lwlock,
          dr.lock,
          dr.bufferpin,
          dr.activity,
          dr.extension,
          dr.client,
          dr.ipc,
          dr.timeout,
          dr.io
        FROM json_to_record(datarow.row_data) AS dr(
            server_id         integer,
            sample_id         integer,
            subsample_ts      timestamp with time zone,
            sess_attr_id      integer,
            total             integer,
            active            integer,
            idle              integer,
            idle_t            integer,
            idle_ta           integer,
            state_null        integer,
            lwlock            integer,
            lock              integer,
            bufferpin         integer,
            activity          integer,
            extension         integer,
            client            integer,
            ipc               integer,
            timeout           integer,
            io                integer
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT ON CONSTRAINT pk_sample_stat_activity_cnt DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    WHEN 'last_stat_activity_count' THEN
      LOOP
        FETCH data INTO datarow;
        EXIT WHEN NOT FOUND;
        INSERT INTO last_stat_activity_count(server_id, sample_id,
          subsample_ts, backend_type, datid, datname, usesysid,
          usename, application_name, client_addr, total, active, idle,
          idle_t, idle_ta, state_null, lwlock, lock, bufferpin,
          activity, extension, client, ipc, timeout, io)
        SELECT
          (srv_map ->> dr.server_id::text)::integer,
          dr.sample_id,
          dr.subsample_ts,
          dr.backend_type,
          dr.datid,
          dr.datname,
          dr.usesysid,
          dr.usename,
          dr.application_name,
          dr.client_addr,
          dr.total,
          dr.active,
          dr.idle,
          dr.idle_t,
          dr.idle_ta,
          dr.state_null,
          dr.lwlock,
          dr.lock,
          dr.bufferpin,
          dr.activity,
          dr.extension,
          dr.client,
          dr.ipc,
          dr.timeout,
          dr.io
        FROM json_to_record(datarow.row_data) AS dr(
            server_id         integer,
            sample_id         integer,
            subsample_ts      timestamp with time zone,
            backend_type      text,
            datid             oid,
            datname           name,
            usesysid          oid,
            usename           name,
            application_name  text,
            client_addr       inet,
            total             integer,
            active            integer,
            idle              integer,
            idle_t            integer,
            idle_ta           integer,
            state_null        integer,
            lwlock            integer,
            lock              integer,
            bufferpin         integer,
            activity          integer,
            extension         integer,
            client            integer,
            ipc               integer,
            timeout           integer,
            io                integer
          )
        JOIN
          samples s_ctl ON
            ((srv_map ->> dr.server_id::text)::integer, dr.sample_id) =
            (s_ctl.server_id, s_ctl.sample_id)
        ON CONFLICT DO NOTHING;
        GET DIAGNOSTICS row_proc = ROW_COUNT;
        rowcnt := rowcnt + row_proc;
        IF (rowcnt > 0 AND rowcnt % 1000 = 0) THEN
          RAISE NOTICE '%', format('Table %s processed: %s rows', imp_table_name, rowcnt);
        END IF;
      END LOOP; -- over data rows
    ELSE
      rows_processed := -1;
      RETURN; -- table not found
  END CASE; -- over table name
  rows_processed := rowcnt;
  RETURN;
END;
$$ LANGUAGE plpgsql;
CREATE FUNCTION log_sample_timings(server_properties jsonb, sampling_event text, exec_point text)
    RETURNS jsonb SET search_path=@extschema@
AS $function$
BEGIN
    IF (server_properties #>> '{collect_timings}')::boolean THEN
        server_properties :=
            jsonb_set(
                server_properties,
                '{timings}',
                coalesce(server_properties -> 'timings', '[]'::jsonb) ||
                    jsonb_build_object(
                        'sampling_event', sampling_event,
                        'exec_point', exec_point,
                        'event_tm', clock_timestamp()));
    END IF;
    return server_properties;
END;
$function$ LANGUAGE plpgsql immutable;
COMMENT ON FUNCTION log_sample_timings(server_properties jsonb, sampling_event text, exec_point text) IS
  'log event to sample_timings';
CREATE FUNCTION get_sp_setting(IN server_properties jsonb, IN setting_name text, out reset_val text, out unit text, out pending_restart boolean
) RETURNS record SET search_path=@extschema@ AS $$
SELECT x.reset_val,
       x.unit,
       x.pending_restart
  FROM jsonb_to_recordset(server_properties #> '{settings}')
    AS x (name text, reset_val text, unit text, pending_restart boolean)
 WHERE x.name = setting_name;
$$ LANGUAGE sql IMMUTABLE;
CREATE FUNCTION calculate_archiver_stats(IN sserver_id integer, IN ssample_id integer
) RETURNS void AS $$
-- Calc stat archiver diff
INSERT INTO sample_stat_archiver(
  server_id,
  sample_id,
  archived_count,
  last_archived_wal,
  last_archived_time,
  failed_count,
  last_failed_wal,
  last_failed_time,
  stats_reset
)
SELECT
    cur.server_id,
    cur.sample_id,
    cur.archived_count - COALESCE(lst.archived_count,0),
    cur.last_archived_wal,
    cur.last_archived_time,
    cur.failed_count - COALESCE(lst.failed_count,0),
    cur.last_failed_wal,
    cur.last_failed_time,
    cur.stats_reset
FROM last_stat_archiver cur
LEFT OUTER JOIN last_stat_archiver lst ON
  (lst.server_id, lst.sample_id) =
  (cur.server_id, cur.sample_id - 1)
  AND cur.stats_reset IS NOT DISTINCT FROM lst.stats_reset
WHERE cur.sample_id = ssample_id AND cur.server_id = sserver_id;

DELETE FROM last_stat_archiver WHERE server_id = sserver_id AND sample_id != ssample_id;
$$ LANGUAGE sql;
CREATE FUNCTION calculate_cluster_stats(IN sserver_id integer, IN ssample_id integer
) RETURNS void AS $$
-- Calc stat cluster diff
INSERT INTO sample_stat_cluster(
  server_id,
  sample_id,
  checkpoints_timed,
  checkpoints_req,
  checkpoints_done,
  checkpoint_write_time,
  checkpoint_sync_time,
  buffers_checkpoint,
  slru_checkpoint,
  buffers_clean,
  maxwritten_clean,
  buffers_backend,
  buffers_backend_fsync,
  buffers_alloc,
  stats_reset,
  wal_size,
  wal_lsn,
  in_recovery,
  restartpoints_timed,
  restartpoints_req,
  restartpoints_done,
  checkpoint_stats_reset
)
SELECT
    cur.server_id,
    cur.sample_id,
    cur.checkpoints_timed - COALESCE(lstc.checkpoints_timed,0),
    cur.checkpoints_req - COALESCE(lstc.checkpoints_req,0),
    cur.checkpoints_done - COALESCE(lstc.checkpoints_done,0),
    cur.checkpoint_write_time - COALESCE(lstc.checkpoint_write_time,0),
    cur.checkpoint_sync_time - COALESCE(lstc.checkpoint_sync_time,0),
    cur.buffers_checkpoint - COALESCE(lstc.buffers_checkpoint,0),
    cur.slru_checkpoint - COALESCE(lstc.slru_checkpoint,0),
    cur.buffers_clean - COALESCE(lstb.buffers_clean,0),
    cur.maxwritten_clean - COALESCE(lstb.maxwritten_clean,0),
    cur.buffers_backend - COALESCE(lstb.buffers_backend,0),
    cur.buffers_backend_fsync - COALESCE(lstb.buffers_backend_fsync,0),
    cur.buffers_alloc - COALESCE(lstb.buffers_alloc,0),
    cur.stats_reset,
    cur.wal_size - COALESCE(lstb.wal_size,0),
    /* We will overwrite this value in case of stats reset
     * (see below)
     */
    cur.wal_lsn,
    cur.in_recovery,
    cur.restartpoints_timed - COALESCE(lstc.restartpoints_timed,0),
    cur.restartpoints_timed - COALESCE(lstc.restartpoints_timed,0),
    cur.restartpoints_timed - COALESCE(lstc.restartpoints_timed,0),
    cur.checkpoint_stats_reset
FROM last_stat_cluster cur
  LEFT OUTER JOIN last_stat_cluster lstb ON
    (lstb.server_id, lstb.sample_id) =
    (sserver_id, ssample_id - 1)
    AND cur.stats_reset IS NOT DISTINCT FROM lstb.stats_reset
  LEFT OUTER JOIN last_stat_cluster lstc ON
    (lstc.server_id, lstc.sample_id) =
    (sserver_id, ssample_id - 1)
    AND cur.checkpoint_stats_reset IS NOT DISTINCT FROM lstc.checkpoint_stats_reset
WHERE
  (cur.server_id, cur.sample_id) = (sserver_id, ssample_id);

/* wal_size is calculated since 0 to current value when stats reset happened
 * so, we need to update it
 */
UPDATE sample_stat_cluster ssc
SET wal_size = cur.wal_size - lst.wal_size
FROM last_stat_cluster cur
  JOIN last_stat_cluster lst ON
    (lst.server_id, lst.sample_id) =
    (sserver_id, ssample_id - 1)
WHERE
  (ssc.server_id, ssc.sample_id) = (sserver_id, ssample_id) AND
  (cur.server_id, cur.sample_id) = (sserver_id, ssample_id) AND
  cur.stats_reset IS DISTINCT FROM lst.stats_reset;

DELETE FROM last_stat_cluster WHERE server_id = sserver_id AND sample_id != ssample_id;
$$ LANGUAGE sql;
CREATE FUNCTION calculate_database_stats(IN sserver_id integer, IN ssample_id integer
) RETURNS void AS $$
-- Calc stat_database diff
INSERT INTO sample_stat_database(
  server_id,
  sample_id,
  datid,
  datname,
  xact_commit,
  xact_rollback,
  blks_read,
  blks_hit,
  tup_returned,
  tup_fetched,
  tup_inserted,
  tup_updated,
  tup_deleted,
  conflicts,
  temp_files,
  temp_bytes,
  deadlocks,
  checksum_failures,
  checksum_last_failure,
  blk_read_time,
  blk_write_time,
  session_time,
  active_time,
  idle_in_transaction_time,
  sessions,
  sessions_abandoned,
  sessions_fatal,
  sessions_killed,
  parallel_workers_to_launch,
  parallel_workers_launched,
  stats_reset,
  datsize,
  datsize_delta,
  datistemplate
)
SELECT
    cur.server_id,
    cur.sample_id,
    cur.datid,
    cur.datname,
    cur.xact_commit - COALESCE(lst.xact_commit,0),
    cur.xact_rollback - COALESCE(lst.xact_rollback,0),
    cur.blks_read - COALESCE(lst.blks_read,0),
    cur.blks_hit - COALESCE(lst.blks_hit,0),
    cur.tup_returned - COALESCE(lst.tup_returned,0),
    cur.tup_fetched - COALESCE(lst.tup_fetched,0),
    cur.tup_inserted - COALESCE(lst.tup_inserted,0),
    cur.tup_updated - COALESCE(lst.tup_updated,0),
    cur.tup_deleted - COALESCE(lst.tup_deleted,0),
    cur.conflicts - COALESCE(lst.conflicts,0),
    cur.temp_files - COALESCE(lst.temp_files,0),
    cur.temp_bytes - COALESCE(lst.temp_bytes,0),
    cur.deadlocks - COALESCE(lst.deadlocks,0),
    cur.checksum_failures - COALESCE(lst.checksum_failures,0),
    cur.checksum_last_failure,
    cur.blk_read_time - COALESCE(lst.blk_read_time,0),
    cur.blk_write_time - COALESCE(lst.blk_write_time,0),
    cur.session_time - COALESCE(lst.session_time,0),
    cur.active_time - COALESCE(lst.active_time,0),
    cur.idle_in_transaction_time - COALESCE(lst.idle_in_transaction_time,0),
    cur.sessions - COALESCE(lst.sessions,0),
    cur.sessions_abandoned - COALESCE(lst.sessions_abandoned,0),
    cur.sessions_fatal - COALESCE(lst.sessions_fatal,0),
    cur.sessions_killed - COALESCE(lst.sessions_killed,0),
    cur.parallel_workers_to_launch - COALESCE(lst.parallel_workers_to_launch,0),
    cur.parallel_workers_launched - COALESCE(lst.parallel_workers_launched,0),
    cur.stats_reset,
    cur.datsize as datsize,
    cur.datsize - COALESCE(lst.datsize,0) as datsize_delta,
    cur.datistemplate
FROM last_stat_database cur
  LEFT OUTER JOIN last_stat_database lst ON
    (lst.server_id, lst.sample_id, lst.datid, lst.datname) =
    (sserver_id, ssample_id - 1, cur.datid, cur.datname)
    AND lst.stats_reset IS NOT DISTINCT FROM cur.stats_reset
WHERE
  (cur.server_id, cur.sample_id) = (sserver_id, ssample_id);

/*
* In case of statistics reset full database size, and checksum checksum_failures
* is incorrectly considered as increment by previous query.
* So, we need to update it with correct value
*/
UPDATE sample_stat_database sdb
SET
  datsize_delta = cur.datsize - lst.datsize,
  checksum_failures = cur.checksum_failures - lst.checksum_failures,
  checksum_last_failure = cur.checksum_last_failure
FROM
  last_stat_database cur
  JOIN last_stat_database lst ON
    (lst.server_id, lst.sample_id, lst.datid, lst.datname) =
    (sserver_id, ssample_id - 1, cur.datid, cur.datname)
WHERE cur.stats_reset IS DISTINCT FROM lst.stats_reset AND
  (cur.server_id, cur.sample_id) = (sserver_id, ssample_id) AND
  (sdb.server_id, sdb.sample_id, sdb.datid, sdb.datname) =
  (cur.server_id, cur.sample_id, cur.datid, cur.datname);
$$ LANGUAGE sql;
CREATE FUNCTION calculate_io_stats(IN sserver_id integer, IN ssample_id integer
) RETURNS void AS $$
-- Calc I/O stat diff
INSERT INTO sample_stat_io(
    server_id,
    sample_id,
    backend_type,
    object,
    context,
    reads,
    read_bytes,
    read_time,
    writes,
    write_bytes,
    write_time,
    writebacks,
    writeback_time,
    extends,
    extend_bytes,
    extend_time,
    op_bytes,
    hits,
    evictions,
    reuses,
    fsyncs,
    fsync_time,
    stats_reset
)
SELECT
    cur.server_id,
    cur.sample_id,
    cur.backend_type,
    cur.object,
    cur.context,
    cur.reads - COALESCE(lst.reads, 0),
    cur.read_bytes - COALESCE(lst.read_bytes, 0),
    cur.read_time - COALESCE(lst.read_time, 0),
    cur.writes - COALESCE(lst.writes, 0),
    cur.write_bytes - COALESCE(lst.write_bytes, 0),
    cur.write_time - COALESCE(lst.write_time, 0),
    cur.writebacks - COALESCE(lst.writebacks, 0),
    cur.writeback_time - COALESCE(lst.writeback_time, 0),
    cur.extends - COALESCE(lst.extends, 0),
    cur.extend_bytes - COALESCE(lst.extend_bytes, 0),
    cur.extend_time - COALESCE(lst.extend_time, 0),
    cur.op_bytes,
    cur.hits - COALESCE(lst.hits, 0),
    cur.evictions - COALESCE(lst.evictions, 0),
    cur.reuses - COALESCE(lst.reuses, 0),
    cur.fsyncs - COALESCE(lst.fsyncs, 0),
    cur.fsync_time - COALESCE(lst.fsync_time, 0),
    cur.stats_reset
FROM last_stat_io cur
LEFT OUTER JOIN last_stat_io lst ON
  (lst.server_id, lst.sample_id, lst.backend_type, lst.object, lst.context) =
  (sserver_id, ssample_id - 1, cur.backend_type, cur.object, cur.context)
  AND (cur.op_bytes,cur.stats_reset) IS NOT DISTINCT FROM (lst.op_bytes,lst.stats_reset)
WHERE
  (cur.server_id, cur.sample_id) = (sserver_id, ssample_id) AND
  GREATEST(
    cur.reads - COALESCE(lst.reads, 0),
    cur.writes - COALESCE(lst.writes, 0),
    cur.writebacks - COALESCE(lst.writebacks, 0),
    cur.extends - COALESCE(lst.extends, 0),
    cur.hits - COALESCE(lst.hits, 0),
    cur.evictions - COALESCE(lst.evictions, 0),
    cur.reuses - COALESCE(lst.reuses, 0),
    cur.fsyncs - COALESCE(lst.fsyncs, 0)
  ) > 0;

DELETE FROM last_stat_io WHERE server_id = sserver_id AND sample_id != ssample_id;
$$ LANGUAGE sql;
CREATE FUNCTION calculate_slru_stats(IN sserver_id integer, IN ssample_id integer
) RETURNS void AS $$
-- Calc SLRU stat diff
INSERT INTO sample_stat_slru(
    server_id,
    sample_id,
    name,
    blks_zeroed,
    blks_hit,
    blks_read,
    blks_written,
    blks_exists,
    flushes,
    truncates,
    stats_reset
)
SELECT
    cur.server_id,
    cur.sample_id,
    cur.name,
    cur.blks_zeroed - COALESCE(lst.blks_zeroed, 0),
    cur.blks_hit - COALESCE(lst.blks_hit, 0),
    cur.blks_read - COALESCE(lst.blks_read, 0),
    cur.blks_written - COALESCE(lst.blks_written, 0),
    cur.blks_exists - COALESCE(lst.blks_exists, 0),
    cur.flushes - COALESCE(lst.flushes, 0),
    cur.truncates - COALESCE(lst.truncates, 0),
    cur.stats_reset
FROM last_stat_slru cur
LEFT OUTER JOIN last_stat_slru lst ON
  (lst.server_id, lst.sample_id, lst.name) =
  (sserver_id, ssample_id - 1, cur.name)
  AND cur.stats_reset IS NOT DISTINCT FROM lst.stats_reset
WHERE
  (cur.server_id, cur.sample_id) = (sserver_id, ssample_id) AND
  GREATEST(
    cur.blks_zeroed - COALESCE(lst.blks_zeroed, 0),
    cur.blks_hit - COALESCE(lst.blks_hit, 0),
    cur.blks_read - COALESCE(lst.blks_read, 0),
    cur.blks_written - COALESCE(lst.blks_written, 0),
    cur.blks_exists - COALESCE(lst.blks_exists, 0),
    cur.flushes - COALESCE(lst.flushes, 0),
    cur.truncates - COALESCE(lst.truncates, 0)
  ) > 0;

DELETE FROM last_stat_slru WHERE server_id = sserver_id AND sample_id != ssample_id;
$$ LANGUAGE sql;
CREATE FUNCTION calculate_tablespace_stats(IN sserver_id integer, IN ssample_id integer
) RETURNS void as $$
INSERT INTO tablespaces_list AS itl (
    server_id,
    last_sample_id,
    tablespaceid,
    tablespacename,
    tablespacepath
  )
SELECT
  cur.server_id,
  NULL,
  cur.tablespaceid,
  cur.tablespacename,
  cur.tablespacepath
FROM
  last_stat_tablespaces cur
WHERE
  (cur.server_id, cur.sample_id) = (sserver_id, ssample_id)
ON CONFLICT ON CONSTRAINT pk_tablespace_list DO
UPDATE SET
    (last_sample_id, tablespacename, tablespacepath) =
    (EXCLUDED.last_sample_id, EXCLUDED.tablespacename, EXCLUDED.tablespacepath)
  WHERE
    (itl.last_sample_id, itl.tablespacename, itl.tablespacepath) IS DISTINCT FROM
    (EXCLUDED.last_sample_id, EXCLUDED.tablespacename, EXCLUDED.tablespacepath);

-- Calculate diffs for tablespaces
INSERT INTO sample_stat_tablespaces(
  server_id,
  sample_id,
  tablespaceid,
  size,
  size_delta
)
SELECT
  cur.server_id as server_id,
  cur.sample_id as sample_id,
  cur.tablespaceid as tablespaceid,
  cur.size as size,
  cur.size - COALESCE(lst.size, 0) AS size_delta
FROM last_stat_tablespaces cur
  LEFT OUTER JOIN last_stat_tablespaces lst ON
    (lst.server_id, lst.sample_id, cur.tablespaceid) =
    (sserver_id, ssample_id - 1, lst.tablespaceid)
WHERE (cur.server_id, cur.sample_id) = (sserver_id, ssample_id);
$$ LANGUAGE sql;
CREATE FUNCTION calculate_wal_stats(IN sserver_id integer, IN ssample_id integer
) RETURNS void AS $$
-- Calc WAL stat diff
INSERT INTO sample_stat_wal(
  server_id,
  sample_id,
  wal_records,
  wal_fpi,
  wal_bytes,
  wal_buffers_full,
  wal_write,
  wal_sync,
  wal_write_time,
  wal_sync_time,
  stats_reset
)
SELECT
    cur.server_id,
    cur.sample_id,
    cur.wal_records - COALESCE(lst.wal_records,0),
    cur.wal_fpi - COALESCE(lst.wal_fpi,0),
    cur.wal_bytes - COALESCE(lst.wal_bytes,0),
    cur.wal_buffers_full - COALESCE(lst.wal_buffers_full,0),
    cur.wal_write - COALESCE(lst.wal_write,0),
    cur.wal_sync - COALESCE(lst.wal_sync,0),
    cur.wal_write_time - COALESCE(lst.wal_write_time,0),
    cur.wal_sync_time - COALESCE(lst.wal_sync_time,0),
    cur.stats_reset
FROM last_stat_wal cur
LEFT OUTER JOIN last_stat_wal lst ON
  (lst.server_id, lst.sample_id) = (sserver_id, ssample_id - 1)
  AND cur.stats_reset IS NOT DISTINCT FROM lst.stats_reset
WHERE (cur.server_id, cur.sample_id) = (sserver_id, ssample_id);

DELETE FROM last_stat_wal WHERE server_id = sserver_id AND sample_id != ssample_id;
$$ LANGUAGE sql;
CREATE FUNCTION collect_database_stats(IN server_properties jsonb, IN sserver_id integer, IN ssample_id integer
) RETURNS jsonb AS $$
declare
    server_query text;
    pg_version int := (get_sp_setting(server_properties, 'server_version_num')).reset_val::integer;
begin
    server_properties := log_sample_timings(server_properties, 'collect database stats', 'start');
    -- Construct pg_stat_database query
    CASE
      WHEN pg_version >= 180000 THEN
        server_query := 'SELECT '
            'dbs.datid, '
            'dbs.datname, '
            'dbs.xact_commit, '
            'dbs.xact_rollback, '
            'dbs.blks_read, '
            'dbs.blks_hit, '
            'dbs.tup_returned, '
            'dbs.tup_fetched, '
            'dbs.tup_inserted, '
            'dbs.tup_updated, '
            'dbs.tup_deleted, '
            'dbs.conflicts, '
            'dbs.temp_files, '
            'dbs.temp_bytes, '
            'dbs.deadlocks, '
            'dbs.checksum_failures, '
            'dbs.checksum_last_failure, '
            'dbs.blk_read_time, '
            'dbs.blk_write_time, '
            'dbs.session_time, '
            'dbs.active_time, '
            'dbs.idle_in_transaction_time, '
            'dbs.sessions, '
            'dbs.sessions_abandoned, '
            'dbs.sessions_fatal, '
            'dbs.sessions_killed, '
            'dbs.parallel_workers_to_launch, '
            'dbs.parallel_workers_launched, '
            'dbs.stats_reset, '
            'pg_database_size(dbs.datid) as datsize, '
            '0 as datsize_delta, '
            'db.datistemplate, '
            'db.dattablespace, '
            'db.datallowconn '
          'FROM pg_catalog.pg_stat_database dbs '
          'JOIN pg_catalog.pg_database db ON (dbs.datid = db.oid) '
          'WHERE dbs.datname IS NOT NULL';
      WHEN pg_version >= 140000 THEN
        server_query := 'SELECT '
            'dbs.datid, '
            'dbs.datname, '
            'dbs.xact_commit, '
            'dbs.xact_rollback, '
            'dbs.blks_read, '
            'dbs.blks_hit, '
            'dbs.tup_returned, '
            'dbs.tup_fetched, '
            'dbs.tup_inserted, '
            'dbs.tup_updated, '
            'dbs.tup_deleted, '
            'dbs.conflicts, '
            'dbs.temp_files, '
            'dbs.temp_bytes, '
            'dbs.deadlocks, '
            'dbs.checksum_failures, '
            'dbs.checksum_last_failure, '
            'dbs.blk_read_time, '
            'dbs.blk_write_time, '
            'dbs.session_time, '
            'dbs.active_time, '
            'dbs.idle_in_transaction_time, '
            'dbs.sessions, '
            'dbs.sessions_abandoned, '
            'dbs.sessions_fatal, '
            'dbs.sessions_killed, '
            'NULL as parallel_workers_to_launch, '
            'NULL as parallel_workers_launched, '
            'dbs.stats_reset, '
            'pg_database_size(dbs.datid) as datsize, '
            '0 as datsize_delta, '
            'db.datistemplate, '
            'db.dattablespace, '
            'db.datallowconn '
          'FROM pg_catalog.pg_stat_database dbs '
          'JOIN pg_catalog.pg_database db ON (dbs.datid = db.oid) '
          'WHERE dbs.datname IS NOT NULL';
      WHEN pg_version >= 120000 THEN
        server_query := 'SELECT '
            'dbs.datid, '
            'dbs.datname, '
            'dbs.xact_commit, '
            'dbs.xact_rollback, '
            'dbs.blks_read, '
            'dbs.blks_hit, '
            'dbs.tup_returned, '
            'dbs.tup_fetched, '
            'dbs.tup_inserted, '
            'dbs.tup_updated, '
            'dbs.tup_deleted, '
            'dbs.conflicts, '
            'dbs.temp_files, '
            'dbs.temp_bytes, '
            'dbs.deadlocks, '
            'dbs.checksum_failures, '
            'dbs.checksum_last_failure, '
            'dbs.blk_read_time, '
            'dbs.blk_write_time, '
            'NULL as session_time, '
            'NULL as active_time, '
            'NULL as idle_in_transaction_time, '
            'NULL as sessions, '
            'NULL as sessions_abandoned, '
            'NULL as sessions_fatal, '
            'NULL as sessions_killed, '
            'NULL as parallel_workers_to_launch, '
            'NULL as parallel_workers_launched, '
            'dbs.stats_reset, '
            'pg_database_size(dbs.datid) as datsize, '
            '0 as datsize_delta, '
            'db.datistemplate, '
            'db.dattablespace, '
            'db.datallowconn '
          'FROM pg_catalog.pg_stat_database dbs '
          'JOIN pg_catalog.pg_database db ON (dbs.datid = db.oid) '
          'WHERE dbs.datname IS NOT NULL';
      WHEN pg_version < 120000 THEN
        server_query := 'SELECT '
            'dbs.datid, '
            'dbs.datname, '
            'dbs.xact_commit, '
            'dbs.xact_rollback, '
            'dbs.blks_read, '
            'dbs.blks_hit, '
            'dbs.tup_returned, '
            'dbs.tup_fetched, '
            'dbs.tup_inserted, '
            'dbs.tup_updated, '
            'dbs.tup_deleted, '
            'dbs.conflicts, '
            'dbs.temp_files, '
            'dbs.temp_bytes, '
            'dbs.deadlocks, '
            'NULL as checksum_failures, '
            'NULL as checksum_last_failure, '
            'dbs.blk_read_time, '
            'dbs.blk_write_time, '
            'NULL as session_time, '
            'NULL as active_time, '
            'NULL as idle_in_transaction_time, '
            'NULL as sessions, '
            'NULL as sessions_abandoned, '
            'NULL as sessions_fatal, '
            'NULL as sessions_killed, '
            'NULL as parallel_workers_to_launch, '
            'NULL as parallel_workers_launched, '
            'dbs.stats_reset, '
            'pg_database_size(dbs.datid) as datsize, '
            '0 as datsize_delta, '
            'db.datistemplate, '
            'db.dattablespace, '
            'db.datallowconn '
          'FROM pg_catalog.pg_stat_database dbs '
          'JOIN pg_catalog.pg_database db ON (dbs.datid = db.oid) '
          'WHERE dbs.datname IS NOT NULL';
    END CASE;

    -- pg_stat_database data
    INSERT INTO last_stat_database (
        server_id,
        sample_id,
        datid,
        datname,
        xact_commit,
        xact_rollback,
        blks_read,
        blks_hit,
        tup_returned,
        tup_fetched,
        tup_inserted,
        tup_updated,
        tup_deleted,
        conflicts,
        temp_files,
        temp_bytes,
        deadlocks,
        checksum_failures,
        checksum_last_failure,
        blk_read_time,
        blk_write_time,
        session_time,
        active_time,
        idle_in_transaction_time,
        sessions,
        sessions_abandoned,
        sessions_fatal,
        sessions_killed,
        parallel_workers_to_launch,
        parallel_workers_launched,
        stats_reset,
        datsize,
        datsize_delta,
        datistemplate,
        dattablespace,
        datallowconn)
    SELECT
        sserver_id,
        ssample_id,
        datid,
        datname,
        xact_commit AS xact_commit,
        xact_rollback AS xact_rollback,
        blks_read AS blks_read,
        blks_hit AS blks_hit,
        tup_returned AS tup_returned,
        tup_fetched AS tup_fetched,
        tup_inserted AS tup_inserted,
        tup_updated AS tup_updated,
        tup_deleted AS tup_deleted,
        conflicts AS conflicts,
        temp_files AS temp_files,
        temp_bytes AS temp_bytes,
        deadlocks AS deadlocks,
        checksum_failures as checksum_failures,
        checksum_last_failure as checksum_failures,
        blk_read_time AS blk_read_time,
        blk_write_time AS blk_write_time,
        session_time AS session_time,
        active_time AS active_time,
        idle_in_transaction_time AS idle_in_transaction_time,
        sessions AS sessions,
        sessions_abandoned AS sessions_abandoned,
        sessions_fatal AS sessions_fatal,
        sessions_killed AS sessions_killed,
        parallel_workers_to_launch as parallel_workers_to_launch,
        parallel_workers_launched as parallel_workers_launched,
        stats_reset,
        datsize AS datsize,
        datsize_delta AS datsize_delta,
        datistemplate AS datistemplate,
        dattablespace AS dattablespace,
        datallowconn AS datallowconn
    FROM dblink('server_connection',server_query) AS rs (
        datid oid,
        datname name,
        xact_commit bigint,
        xact_rollback bigint,
        blks_read bigint,
        blks_hit bigint,
        tup_returned bigint,
        tup_fetched bigint,
        tup_inserted bigint,
        tup_updated bigint,
        tup_deleted bigint,
        conflicts bigint,
        temp_files bigint,
        temp_bytes bigint,
        deadlocks bigint,
        checksum_failures bigint,
        checksum_last_failure timestamp with time zone,
        blk_read_time double precision,
        blk_write_time double precision,
        session_time double precision,
        active_time double precision,
        idle_in_transaction_time double precision,
        sessions bigint,
        sessions_abandoned bigint,
        sessions_fatal bigint,
        sessions_killed bigint,
        parallel_workers_to_launch bigint,
        parallel_workers_launched bigint,
        stats_reset timestamp with time zone,
        datsize bigint,
        datsize_delta bigint,
        datistemplate boolean,
        dattablespace oid,
        datallowconn boolean
        );

    EXECUTE format('ANALYZE last_stat_database_srv%1$s',
      sserver_id);
    server_properties := log_sample_timings(server_properties, 'collect database stats', 'end');
    return server_properties;
end;
$$ LANGUAGE plpgsql;
CREATE FUNCTION collect_obj_stats(IN properties jsonb, IN sserver_id integer, IN s_id integer,
  IN skip_sizes boolean
) RETURNS jsonb SET search_path=@extschema@ AS $$
DECLARE
    --Cursor over databases
    c_dblist CURSOR FOR
    SELECT
      datid,
      datname,
      dattablespace AS tablespaceid
    FROM last_stat_database ldb
      JOIN servers n ON
        (n.server_id = sserver_id AND array_position(n.db_exclude,ldb.datname) IS NULL)
    WHERE
      NOT ldb.datistemplate AND ldb.datallowconn AND
      (ldb.server_id, ldb.sample_id) = (sserver_id, s_id);

    qres        record;
    db_connstr  text;
    t_query     text;
    analyze_list  text[] := array[]::text[];
    analyze_obj   text;
    result      jsonb := collect_obj_stats.properties;
    pg_version int := (get_sp_setting(properties, 'server_version_num')).reset_val::integer;
BEGIN
    -- Adding dblink extension schema to search_path if it does not already there
    IF (SELECT count(*) = 0 FROM pg_catalog.pg_extension WHERE extname = 'dblink') THEN
      RAISE 'dblink extension must be installed';
    END IF;
    SELECT extnamespace::regnamespace AS dblink_schema INTO STRICT qres FROM pg_catalog.pg_extension WHERE extname = 'dblink';
    IF NOT string_to_array(current_setting('search_path'),', ') @> ARRAY[qres.dblink_schema::text] THEN
      EXECUTE 'SET LOCAL search_path TO ' || current_setting('search_path')||','|| qres.dblink_schema;
    END IF;

    -- Disconnecting existing connection
    IF dblink_get_connections() @> ARRAY['server_db_connection'] THEN
        PERFORM dblink_disconnect('server_db_connection');
    END IF;

    -- Load new data from statistic views of all cluster databases
    FOR qres IN c_dblist LOOP
      db_connstr := concat_ws(' ',properties #>> '{properties,server_connstr}',
        format($o$dbname='%s'$o$,replace(qres.datname,$o$'$o$,$o$\'$o$)) --'
      );
      PERFORM dblink_connect('server_db_connection',db_connstr);
      -- Transaction
      PERFORM dblink('server_db_connection','BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY');
      -- Setting application name
      PERFORM dblink('server_db_connection','SET application_name=''pg_profile''');
      -- Conditionally set lock_timeout
      IF (
        SELECT lock_timeout_unset
        FROM dblink('server_db_connection',
          $sql$SELECT current_setting('lock_timeout')::interval = '0s'::interval$sql$)
          AS probe(lock_timeout_unset boolean)
        )
      THEN
        -- Setting lock_timout prevents hanging of take_sample() call due to DDL in long transaction
        PERFORM dblink('server_db_connection',
          format('SET lock_timeout TO %L',
            COALESCE(properties #>> '{properties,lock_timeout_effective}','3s')
          )
        );
      END IF;
      -- Reset search_path for security reasons
      PERFORM dblink('server_db_connection','SET search_path=''''');

      result := log_sample_timings(result, format('db:%s get extensions version',qres.datname), 'start');

      t_query := 'SELECT '
        'extname,'
        'extversion '
        'FROM pg_extension';

      INSERT INTO last_extension_versions (
        server_id,
        datid,
        sample_id,
        extname,
        extversion
      )
      SELECT
        sserver_id as server_id,
        qres.datid,
        s_id as sample_id,
        dbl.extname,
        dbl.extversion
      FROM dblink('server_db_connection', t_query)
      AS dbl (
         extname    name,
         extversion text
      );

      result := log_sample_timings(result, format('db:%s get extensions version',qres.datname), 'end');
      result := log_sample_timings(result, format('db:%s collect tables stats',qres.datname), 'start');

      -- Generate Table stats query
      CASE
        WHEN pg_version < 130000 THEN
          t_query :=
          'WITH ixstat AS ( '
            'SELECT '
              'indrelid, '
              'sum(pg_catalog.pg_stat_get_blocks_fetched(indexrelid) -'
                  'pg_catalog.pg_stat_get_blocks_hit(indexrelid))::bigint '
                  'AS idx_blks_read,'
              'sum(pg_stat_get_blocks_hit(indexrelid))::bigint '
                  'AS idx_blks_hit '
            'FROM '
              'pg_catalog.pg_index '
            'GROUP BY indrelid'
          ') '
          'SELECT '
            'st.relid,'
            'st.schemaname,'
            'st.relname,'
            'st.seq_scan,'
            'st.seq_tup_read,'
            'st.idx_scan,'
            'st.idx_tup_fetch,'
            'st.n_tup_ins,'
            'st.n_tup_upd,'
            'st.n_tup_del,'
            'st.n_tup_hot_upd,'
            'st.n_live_tup,'
            'st.n_dead_tup,'
            'st.n_mod_since_analyze,'
            'NULL as n_ins_since_vacuum,'
            'st.last_vacuum,'
            'st.last_autovacuum,'
            'st.last_analyze,'
            'st.last_autoanalyze,'
            'st.vacuum_count,'
            'st.autovacuum_count,'
            'st.analyze_count,'
            'st.autoanalyze_count,'
            'NULL as total_vacuum_time,'
            'NULL as total_autovacuum_time,'
            'NULL as total_analyze_time,'
            'NULL as total_autoanalyze_time,'
            'pg_catalog.pg_stat_get_blocks_fetched(class.oid) -
                    pg_catalog.pg_stat_get_blocks_hit(class.oid),'
            'pg_catalog.pg_stat_get_blocks_hit(class.oid),'
            'I.idx_blks_read,'
            'I.idx_blks_hit,'
            'pg_catalog.pg_stat_get_blocks_fetched(class.reltoastrelid) - '
                'pg_catalog.pg_stat_get_blocks_hit(class.reltoastrelid) '
                'AS toast_blks_read,'
            'pg_catalog.pg_stat_get_blocks_hit(class.reltoastrelid) '
                'AS toast_blks_hit,'
            'X.idx_blks_read AS tidx_blks_read,'
            'X.idx_blks_hit AS tidx_blks_hit,'
            -- Size of all forks without TOAST
            '{relation_size} relsize,'
            '0 relsize_diff,'
            'class.reltablespace AS tablespaceid,'
            'class.reltoastrelid,'
            'class.relkind,'
            'class.relpages::bigint * current_setting(''block_size'')::bigint AS relpages_bytes,'
            '0 AS relpages_bytes_diff,'
            'NULL AS last_seq_scan,'
            'NULL AS last_idx_scan,'
            'NULL AS n_tup_newpage_upd,'
            'to_jsonb(class.reloptions) '
          'FROM pg_catalog.pg_stat_all_tables st '
          'JOIN pg_catalog.pg_class class ON (st.relid = class.oid) '
          'LEFT JOIN ixstat I ON I.indrelid = class.oid '
          'LEFT JOIN ixstat X ON I.indrelid = class.reltoastrelid '
          -- is relation or its dependant is locked
          '{lock_join}'
          ;

        WHEN pg_version < 150000 THEN
          t_query :=
          'WITH ixstat AS ( '
            'SELECT '
              'indrelid, '
              'sum(pg_catalog.pg_stat_get_blocks_fetched(indexrelid) -'
                  'pg_catalog.pg_stat_get_blocks_hit(indexrelid))::bigint '
                  'AS idx_blks_read,'
              'sum(pg_stat_get_blocks_hit(indexrelid))::bigint '
                  'AS idx_blks_hit '
            'FROM '
              'pg_catalog.pg_index '
            'GROUP BY indrelid'
          ') '
          'SELECT '
            'st.relid,'
            'st.schemaname,'
            'st.relname,'
            'st.seq_scan,'
            'st.seq_tup_read,'
            'st.idx_scan,'
            'st.idx_tup_fetch,'
            'st.n_tup_ins,'
            'st.n_tup_upd,'
            'st.n_tup_del,'
            'st.n_tup_hot_upd,'
            'st.n_live_tup,'
            'st.n_dead_tup,'
            'st.n_mod_since_analyze,'
            'st.n_ins_since_vacuum,'
            'st.last_vacuum,'
            'st.last_autovacuum,'
            'st.last_analyze,'
            'st.last_autoanalyze,'
            'st.vacuum_count,'
            'st.autovacuum_count,'
            'st.analyze_count,'
            'st.autoanalyze_count,'
            'NULL as total_vacuum_time,'
            'NULL as total_autovacuum_time,'
            'NULL as total_analyze_time,'
            'NULL as total_autoanalyze_time,'
            'pg_catalog.pg_stat_get_blocks_fetched(class.oid) -
                    pg_catalog.pg_stat_get_blocks_hit(class.oid),'
            'pg_catalog.pg_stat_get_blocks_hit(class.oid),'
            'I.idx_blks_read,'
            'I.idx_blks_hit,'
            'pg_catalog.pg_stat_get_blocks_fetched(class.reltoastrelid) - '
                'pg_catalog.pg_stat_get_blocks_hit(class.reltoastrelid) '
                'AS toast_blks_read,'
            'pg_catalog.pg_stat_get_blocks_hit(class.reltoastrelid) '
                'AS toast_blks_hit,'
            'X.idx_blks_read AS tidx_blks_read,'
            'X.idx_blks_hit AS tidx_blks_hit,'
            -- Size of all forks without TOAST
            '{relation_size} relsize,'
            '0 relsize_diff,'
            'class.reltablespace AS tablespaceid,'
            'class.reltoastrelid,'
            'class.relkind,'
            'class.relpages::bigint * current_setting(''block_size'')::bigint AS relpages_bytes,'
            '0 AS relpages_bytes_diff,'
            'NULL AS last_seq_scan,'
            'NULL AS last_idx_scan,'
            'NULL AS n_tup_newpage_upd,'
            'to_jsonb(class.reloptions) '
          'FROM pg_catalog.pg_stat_all_tables st '
          'JOIN pg_catalog.pg_class class ON (st.relid = class.oid) '
          'LEFT JOIN ixstat I ON I.indrelid = class.oid '
          'LEFT JOIN ixstat X ON I.indrelid = class.reltoastrelid '
          -- is relation or its dependant is locked
          '{lock_join}'
          ;

        WHEN pg_version < 160000 THEN
          t_query := 'SELECT '
            'st.relid,'
            'st.schemaname,'
            'st.relname,'
            'st.seq_scan,'
            'st.seq_tup_read,'
            'st.idx_scan,'
            'st.idx_tup_fetch,'
            'st.n_tup_ins,'
            'st.n_tup_upd,'
            'st.n_tup_del,'
            'st.n_tup_hot_upd,'
            'st.n_live_tup,'
            'st.n_dead_tup,'
            'st.n_mod_since_analyze,'
            'st.n_ins_since_vacuum,'
            'st.last_vacuum,'
            'st.last_autovacuum,'
            'st.last_analyze,'
            'st.last_autoanalyze,'
            'st.vacuum_count,'
            'st.autovacuum_count,'
            'st.analyze_count,'
            'st.autoanalyze_count,'
            'NULL as total_vacuum_time,'
            'NULL as total_autovacuum_time,'
            'NULL as total_analyze_time,'
            'NULL as total_autoanalyze_time,'
            'stio.heap_blks_read,'
            'stio.heap_blks_hit,'
            'stio.idx_blks_read,'
            'stio.idx_blks_hit,'
            'stio.toast_blks_read,'
            'stio.toast_blks_hit,'
            'stio.tidx_blks_read,'
            'stio.tidx_blks_hit,'
            -- Size of all forks without TOAST
            '{relation_size} relsize,'
            '0 relsize_diff,'
            'class.reltablespace AS tablespaceid,'
            'class.reltoastrelid,'
            'class.relkind,'
            'class.relpages::bigint * current_setting(''block_size'')::bigint AS relpages_bytes,'
            '0 AS relpages_bytes_diff,'
            'NULL AS last_seq_scan,'
            'NULL AS last_idx_scan,'
            'NULL AS n_tup_newpage_upd,'
            'to_jsonb(class.reloptions) '
          'FROM pg_catalog.pg_stat_all_tables st '
          'JOIN pg_catalog.pg_statio_all_tables stio USING (relid, schemaname, relname) '
          'JOIN pg_catalog.pg_class class ON (st.relid = class.oid) '
          -- is relation or its dependant is locked
          '{lock_join}'
          ;

        WHEN pg_version < 180000 THEN
          t_query := 'SELECT '
            'st.relid,'
            'st.schemaname,'
            'st.relname,'
            'st.seq_scan,'
            'st.seq_tup_read,'
            'st.idx_scan,'
            'st.idx_tup_fetch,'
            'st.n_tup_ins,'
            'st.n_tup_upd,'
            'st.n_tup_del,'
            'st.n_tup_hot_upd,'
            'st.n_live_tup,'
            'st.n_dead_tup,'
            'st.n_mod_since_analyze,'
            'st.n_ins_since_vacuum,'
            'st.last_vacuum,'
            'st.last_autovacuum,'
            'st.last_analyze,'
            'st.last_autoanalyze,'
            'st.vacuum_count,'
            'st.autovacuum_count,'
            'st.analyze_count,'
            'st.autoanalyze_count,'
            'NULL as total_vacuum_time,'
            'NULL as total_autovacuum_time,'
            'NULL as total_analyze_time,'
            'NULL as total_autoanalyze_time,'
            'stio.heap_blks_read,'
            'stio.heap_blks_hit,'
            'stio.idx_blks_read,'
            'stio.idx_blks_hit,'
            'stio.toast_blks_read,'
            'stio.toast_blks_hit,'
            'stio.tidx_blks_read,'
            'stio.tidx_blks_hit,'
            -- Size of all forks without TOAST
            '{relation_size} relsize,'
            '0 relsize_diff,'
            'class.reltablespace AS tablespaceid,'
            'class.reltoastrelid,'
            'class.relkind,'
            'class.relpages::bigint * current_setting(''block_size'')::bigint AS relpages_bytes,'
            '0 AS relpages_bytes_diff,'
            'st.last_seq_scan,'
            'st.last_idx_scan,'
            'st.n_tup_newpage_upd,'
            'to_jsonb(class.reloptions) '
          'FROM pg_catalog.pg_stat_all_tables st '
          'JOIN pg_catalog.pg_statio_all_tables stio USING (relid, schemaname, relname) '
          'JOIN pg_catalog.pg_class class ON (st.relid = class.oid) '
          -- is relation or its dependant is locked
          '{lock_join}'
          ;

        WHEN pg_version >= 180000 THEN
          t_query := 'SELECT '
            'st.relid,'
            'st.schemaname,'
            'st.relname,'
            'st.seq_scan,'
            'st.seq_tup_read,'
            'st.idx_scan,'
            'st.idx_tup_fetch,'
            'st.n_tup_ins,'
            'st.n_tup_upd,'
            'st.n_tup_del,'
            'st.n_tup_hot_upd,'
            'st.n_live_tup,'
            'st.n_dead_tup,'
            'st.n_mod_since_analyze,'
            'st.n_ins_since_vacuum,'
            'st.last_vacuum,'
            'st.last_autovacuum,'
            'st.last_analyze,'
            'st.last_autoanalyze,'
            'st.vacuum_count,'
            'st.autovacuum_count,'
            'st.analyze_count,'
            'st.autoanalyze_count,'
            'st.total_vacuum_time,'
            'st.total_autovacuum_time,'
            'st.total_analyze_time,'
            'st.total_autoanalyze_time,'
            'stio.heap_blks_read,'
            'stio.heap_blks_hit,'
            'stio.idx_blks_read,'
            'stio.idx_blks_hit,'
            'stio.toast_blks_read,'
            'stio.toast_blks_hit,'
            'stio.tidx_blks_read,'
            'stio.tidx_blks_hit,'
            -- Size of all forks without TOAST
            '{relation_size} relsize,'
            '0 relsize_diff,'
            'class.reltablespace AS tablespaceid,'
            'class.reltoastrelid,'
            'class.relkind,'
            'class.relpages::bigint * current_setting(''block_size'')::bigint AS relpages_bytes,'
            '0 AS relpages_bytes_diff,'
            'st.last_seq_scan,'
            'st.last_idx_scan,'
            'st.n_tup_newpage_upd,'
            'to_jsonb(class.reloptions) '
          'FROM pg_catalog.pg_stat_all_tables st '
          'JOIN pg_catalog.pg_statio_all_tables stio USING (relid, schemaname, relname) '
          'JOIN pg_catalog.pg_class class ON (st.relid = class.oid) '
          -- is relation or its dependant is locked
          '{lock_join}'
          ;

        ELSE
          RAISE 'Unsupported server version.';
      END CASE;

      IF skip_sizes THEN
        t_query := replace(t_query,'{relation_size}','NULL');
        t_query := replace(t_query,'{lock_join}','');
      ELSE
        t_query := replace(t_query,'{relation_size}','CASE locked.objid WHEN st.relid THEN NULL ELSE '
          'pg_catalog.pg_table_size(st.relid) - '
          'coalesce(pg_catalog.pg_relation_size(class.reltoastrelid),0) END');
        t_query := replace(t_query,'{lock_join}',
          'LEFT OUTER JOIN LATERAL '
            '(WITH RECURSIVE deps (objid) AS ('
              'SELECT relation FROM pg_catalog.pg_locks WHERE granted AND locktype = ''relation'' AND mode=''AccessExclusiveLock'' '
              'UNION '
              'SELECT refobjid FROM pg_catalog.pg_depend d JOIN deps dd ON (d.objid = dd.objid)'
            ') '
            'SELECT objid FROM deps) AS locked ON (st.relid = locked.objid)');
      END IF;

      IF COALESCE((properties #> '{collect,relations}')::boolean, true) THEN
        INSERT INTO last_stat_tables(
          server_id,
          sample_id,
          datid,
          relid,
          schemaname,
          relname,
          seq_scan,
          seq_tup_read,
          idx_scan,
          idx_tup_fetch,
          n_tup_ins,
          n_tup_upd,
          n_tup_del,
          n_tup_hot_upd,
          n_live_tup,
          n_dead_tup,
          n_mod_since_analyze,
          n_ins_since_vacuum,
          last_vacuum,
          last_autovacuum,
          last_analyze,
          last_autoanalyze,
          vacuum_count,
          autovacuum_count,
          analyze_count,
          autoanalyze_count,
          total_vacuum_time,
          total_autovacuum_time,
          total_analyze_time,
          total_autoanalyze_time,
          heap_blks_read,
          heap_blks_hit,
          idx_blks_read,
          idx_blks_hit,
          toast_blks_read,
          toast_blks_hit,
          tidx_blks_read,
          tidx_blks_hit,
          relsize,
          relsize_diff,
          tablespaceid,
          reltoastrelid,
          relkind,
          in_sample,
          relpages_bytes,
          relpages_bytes_diff,
          last_seq_scan,
          last_idx_scan,
          n_tup_newpage_upd,
          reloptions
        )
        SELECT
          sserver_id,
          s_id,
          qres.datid,
          dbl.relid,
          dbl.schemaname,
          dbl.relname,
          dbl.seq_scan AS seq_scan,
          dbl.seq_tup_read AS seq_tup_read,
          dbl.idx_scan AS idx_scan,
          dbl.idx_tup_fetch AS idx_tup_fetch,
          dbl.n_tup_ins AS n_tup_ins,
          dbl.n_tup_upd AS n_tup_upd,
          dbl.n_tup_del AS n_tup_del,
          dbl.n_tup_hot_upd AS n_tup_hot_upd,
          dbl.n_live_tup AS n_live_tup,
          dbl.n_dead_tup AS n_dead_tup,
          dbl.n_mod_since_analyze AS n_mod_since_analyze,
          dbl.n_ins_since_vacuum AS n_ins_since_vacuum,
          dbl.last_vacuum,
          dbl.last_autovacuum,
          dbl.last_analyze,
          dbl.last_autoanalyze,
          dbl.vacuum_count AS vacuum_count,
          dbl.autovacuum_count AS autovacuum_count,
          dbl.analyze_count AS analyze_count,
          dbl.autoanalyze_count AS autoanalyze_count,
          dbl.total_vacuum_time AS total_vacuum_time,
          dbl.total_autovacuum_time AS total_autovacuum_time,
          dbl.total_analyze_time AS total_analyze_time,
          dbl.total_autoanalyze_time AS total_autoanalyze_time,
          dbl.heap_blks_read AS heap_blks_read,
          dbl.heap_blks_hit AS heap_blks_hit,
          dbl.idx_blks_read AS idx_blks_read,
          dbl.idx_blks_hit AS idx_blks_hit,
          dbl.toast_blks_read AS toast_blks_read,
          dbl.toast_blks_hit AS toast_blks_hit,
          dbl.tidx_blks_read AS tidx_blks_read,
          dbl.tidx_blks_hit AS tidx_blks_hit,
          dbl.relsize AS relsize,
          dbl.relsize_diff AS relsize_diff,
          CASE WHEN dbl.tablespaceid=0 THEN qres.tablespaceid ELSE dbl.tablespaceid END AS tablespaceid,
          NULLIF(dbl.reltoastrelid, 0),
          dbl.relkind,
          false,
          dbl.relpages_bytes,
          dbl.relpages_bytes_diff,
          dbl.last_seq_scan,
          dbl.last_idx_scan,
          dbl.n_tup_newpage_upd,
          dbl.reloptions
        FROM dblink('server_db_connection', t_query)
        AS dbl (
            relid                 oid,
            schemaname            name,
            relname               name,
            seq_scan              bigint,
            seq_tup_read          bigint,
            idx_scan              bigint,
            idx_tup_fetch         bigint,
            n_tup_ins             bigint,
            n_tup_upd             bigint,
            n_tup_del             bigint,
            n_tup_hot_upd         bigint,
            n_live_tup            bigint,
            n_dead_tup            bigint,
            n_mod_since_analyze   bigint,
            n_ins_since_vacuum    bigint,
            last_vacuum           timestamp with time zone,
            last_autovacuum       timestamp with time zone,
            last_analyze          timestamp with time zone,
            last_autoanalyze      timestamp with time zone,
            vacuum_count          bigint,
            autovacuum_count      bigint,
            analyze_count         bigint,
            autoanalyze_count     bigint,
            total_vacuum_time       double precision,
            total_autovacuum_time   double precision,
            total_analyze_time      double precision,
            total_autoanalyze_time  double precision,
            heap_blks_read        bigint,
            heap_blks_hit         bigint,
            idx_blks_read         bigint,
            idx_blks_hit          bigint,
            toast_blks_read       bigint,
            toast_blks_hit        bigint,
            tidx_blks_read        bigint,
            tidx_blks_hit         bigint,
            relsize               bigint,
            relsize_diff          bigint,
            tablespaceid          oid,
            reltoastrelid         oid,
            relkind               char,
            relpages_bytes        bigint,
            relpages_bytes_diff   bigint,
            last_seq_scan         timestamp with time zone,
            last_idx_scan         timestamp with time zone,
            n_tup_newpage_upd     bigint,
            reloptions            jsonb
        );

        IF NOT analyze_list @> ARRAY[format('last_stat_tables_srv%1$s', sserver_id)] THEN
          analyze_list := analyze_list ||
            format('last_stat_tables_srv%1$s', sserver_id);
        END IF;
      END IF; -- relation collection condition

      result := log_sample_timings(result, format('db:%s collect tables stats',qres.datname), 'end');
      result := log_sample_timings(result, format('db:%s collect indexes stats',qres.datname), 'start');

      -- Generate index stats query
      CASE
        WHEN (
          SELECT count(*) = 1 FROM jsonb_to_recordset(properties #> '{settings}')
            AS x(name text, reset_val text)
          WHERE name = 'server_version_num'
            AND reset_val::integer < 160000
        )
        THEN
          t_query := 'SELECT '
            'st.relid,'
            'st.indexrelid,'
            'st.schemaname,'
            'st.relname,'
            'st.indexrelname,'
            'st.idx_scan,'
            'NULL AS last_idx_scan,'
            'st.idx_tup_read,'
            'st.idx_tup_fetch,'
            'stio.idx_blks_read,'
            'stio.idx_blks_hit,'
            '{relation_size} relsize,'
            '0,'
            'pg_class.reltablespace as tablespaceid,'
            '(ix.indisunique OR con.conindid IS NOT NULL) AS indisunique,'
            'pg_class.relpages::bigint * current_setting(''block_size'')::bigint AS relpages_bytes,'
            '0 AS relpages_bytes_diff,'
            'to_jsonb(pg_class.reloptions) '
          'FROM pg_catalog.pg_stat_all_indexes st '
            'JOIN pg_catalog.pg_statio_all_indexes stio USING (relid, indexrelid, schemaname, relname, indexrelname) '
            'JOIN pg_catalog.pg_index ix ON (ix.indexrelid = st.indexrelid) '
            'JOIN pg_catalog.pg_class ON (pg_class.oid = st.indexrelid) '
            'LEFT OUTER JOIN pg_catalog.pg_constraint con ON '
              '(con.conrelid, con.conindid) = (ix.indrelid, ix.indexrelid) AND con.contype in (''p'',''u'') '
            '{lock_join}'
            ;
        WHEN (
          SELECT count(*) = 1 FROM jsonb_to_recordset(properties #> '{settings}')
            AS x(name text, reset_val text)
          WHERE name = 'server_version_num'
            AND reset_val::integer >= 160000
        )
        THEN
          t_query := 'SELECT '
            'st.relid,'
            'st.indexrelid,'
            'st.schemaname,'
            'st.relname,'
            'st.indexrelname,'
            'st.idx_scan,'
            'st.last_idx_scan,'
            'st.idx_tup_read,'
            'st.idx_tup_fetch,'
            'stio.idx_blks_read,'
            'stio.idx_blks_hit,'
            '{relation_size} relsize,'
            '0,'
            'pg_class.reltablespace as tablespaceid,'
            '(ix.indisunique OR con.conindid IS NOT NULL) AS indisunique,'
            'pg_class.relpages::bigint * current_setting(''block_size'')::bigint AS relpages_bytes,'
            '0 AS relpages_bytes_diff,'
            'to_jsonb(pg_class.reloptions) '
          'FROM pg_catalog.pg_stat_all_indexes st '
            'JOIN pg_catalog.pg_statio_all_indexes stio USING (relid, indexrelid, schemaname, relname, indexrelname) '
            'JOIN pg_catalog.pg_index ix ON (ix.indexrelid = st.indexrelid) '
            'JOIN pg_catalog.pg_class ON (pg_class.oid = st.indexrelid) '
            'LEFT OUTER JOIN pg_catalog.pg_constraint con ON '
              '(con.conrelid, con.conindid) = (ix.indrelid, ix.indexrelid) AND con.contype in (''p'',''u'') '
            '{lock_join}'
            ;
        ELSE
          RAISE 'Unsupported server version.';
      END CASE;

      IF skip_sizes THEN
        t_query := replace(t_query,'{relation_size}','NULL');
        t_query := replace(t_query,'{lock_join}','');
      ELSE
        t_query := replace(t_query,'{relation_size}',
          'CASE l.relation WHEN st.indexrelid THEN NULL ELSE pg_relation_size(st.indexrelid) END');
        t_query := replace(t_query,'{lock_join}',
          'LEFT OUTER JOIN LATERAL ('
            'SELECT relation '
            'FROM pg_catalog.pg_locks '
            'WHERE '
            '(relation = st.indexrelid AND granted AND locktype = ''relation'' AND mode=''AccessExclusiveLock'')'
          ') l ON (l.relation = st.indexrelid)');
      END IF;

      IF COALESCE((properties #> '{collect,relations}')::boolean, true) THEN
        INSERT INTO last_stat_indexes(
          server_id,
          sample_id,
          datid,
          relid,
          indexrelid,
          schemaname,
          relname,
          indexrelname,
          idx_scan,
          last_idx_scan,
          idx_tup_read,
          idx_tup_fetch,
          idx_blks_read,
          idx_blks_hit,
          relsize,
          relsize_diff,
          tablespaceid,
          indisunique,
          in_sample,
          relpages_bytes,
          relpages_bytes_diff,
          reloptions
        )
        SELECT
          sserver_id,
          s_id,
          qres.datid,
          relid,
          indexrelid,
          schemaname,
          relname,
          indexrelname,
          dbl.idx_scan AS idx_scan,
          dbl.last_idx_scan AS last_idx_scan,
          dbl.idx_tup_read AS idx_tup_read,
          dbl.idx_tup_fetch AS idx_tup_fetch,
          dbl.idx_blks_read AS idx_blks_read,
          dbl.idx_blks_hit AS idx_blks_hit,
          dbl.relsize AS relsize,
          dbl.relsize_diff AS relsize_diff,
          CASE WHEN tablespaceid=0 THEN qres.tablespaceid ELSE tablespaceid END tablespaceid,
          indisunique,
          false,
          dbl.relpages_bytes,
          dbl.relpages_bytes_diff,
          dbl.reloptions
        FROM dblink('server_db_connection', t_query)
        AS dbl (
           relid          oid,
           indexrelid     oid,
           schemaname     name,
           relname        name,
           indexrelname   name,
           idx_scan       bigint,
           last_idx_scan  timestamp with time zone,
           idx_tup_read   bigint,
           idx_tup_fetch  bigint,
           idx_blks_read  bigint,
           idx_blks_hit   bigint,
           relsize        bigint,
           relsize_diff   bigint,
           tablespaceid   oid,
           indisunique    bool,
           relpages_bytes bigint,
           relpages_bytes_diff  bigint,
           reloptions jsonb
        );

        IF NOT analyze_list @> ARRAY[format('last_stat_indexes_srv%1$s', sserver_id)] THEN
          analyze_list := analyze_list ||
            format('last_stat_indexes_srv%1$s', sserver_id);
        END IF;
      END IF; -- relation collection condition

      result := log_sample_timings(result, format('db:%s collect indexes stats',qres.datname), 'end');
      result := log_sample_timings(result, format('db:%s collect functions stats',qres.datname), 'start');

      -- Generate Function stats query
      t_query := 'SELECT f.funcid,'
        'f.schemaname,'
        'f.funcname,'
        'pg_get_function_arguments(f.funcid) AS funcargs,'
        'f.calls,'
        'f.total_time,'
        'f.self_time,'
        'p.prorettype::regtype::text =''trigger'' AS trg_fn '
      'FROM pg_catalog.pg_stat_user_functions f '
        'JOIN pg_catalog.pg_proc p ON (f.funcid = p.oid) '
      'WHERE pg_get_function_arguments(f.funcid) IS NOT NULL';

      IF COALESCE((properties #> '{collect,functions}')::boolean, true) THEN
        INSERT INTO last_stat_user_functions(
          server_id,
          sample_id,
          datid,
          funcid,
          schemaname,
          funcname,
          funcargs,
          calls,
          total_time,
          self_time,
          trg_fn
        )
        SELECT
          sserver_id,
          s_id,
          qres.datid,
          funcid,
          schemaname,
          funcname,
          funcargs,
          dbl.calls AS calls,
          dbl.total_time AS total_time,
          dbl.self_time AS self_time,
          dbl.trg_fn
        FROM dblink('server_db_connection', t_query)
        AS dbl (
           funcid       oid,
           schemaname   name,
           funcname     name,
           funcargs     text,
           calls        bigint,
           total_time   double precision,
           self_time    double precision,
           trg_fn       boolean
        );

        IF NOT analyze_list @> ARRAY[format('last_stat_user_functions_srv%1$s', sserver_id)] THEN
          analyze_list := analyze_list ||
            format('last_stat_user_functions_srv%1$s', sserver_id);
        END IF;
      END IF; -- functions collection condition

      result := log_sample_timings(result, format('db:%s collect functions stats',qres.datname), 'end');
      PERFORM dblink('server_db_connection', 'COMMIT');
      PERFORM dblink_disconnect('server_db_connection');
    END LOOP; -- over databases

    -- Now we should preform ANALYZE on collected data
    result := log_sample_timings(result, 'analyzing collected data', 'start');

    FOREACH analyze_obj IN ARRAY analyze_list
    LOOP
      EXECUTE format('ANALYZE %1$I', analyze_obj);
    END LOOP;

    result := log_sample_timings(result, 'analyzing collected data', 'end');

   RETURN result;
END;
$$ LANGUAGE plpgsql;
CREATE FUNCTION collect_tablespace_stats(IN sserver_id integer, IN ssample_id integer
) RETURNS void AS $collect_tablespace_stats$
begin
    -- Get tablespace stats
    INSERT INTO last_stat_tablespaces(
      server_id,
      sample_id,
      tablespaceid,
      tablespacename,
      tablespacepath,
      size,
      size_delta
    )
    SELECT
      sserver_id,
      ssample_id,
      dbl.tablespaceid,
      dbl.tablespacename,
      dbl.tablespacepath,
      dbl.size AS size,
      dbl.size_delta AS size_delta
      FROM dblink('server_connection', $$
            SELECT oid as tablespaceid,
                   spcname as tablespacename,
                   pg_catalog.pg_tablespace_location(oid) as tablespacepath,
                   pg_catalog.pg_tablespace_size(oid) as size,
                   0 as size_delta
              FROM pg_catalog.pg_tablespace
            $$)
    AS dbl (
        tablespaceid            oid,
        tablespacename          name,
        tablespacepath          text,
        size                    bigint,
        size_delta              bigint
    );
    EXECUTE format('ANALYZE last_stat_tablespaces_srv%1$s',
      sserver_id);
end;
$collect_tablespace_stats$ LANGUAGE plpgsql;
CREATE FUNCTION delete_obsolete_samples(IN sserver_id integer, IN ssample_id integer
) RETURNS void SET search_path=@extschema@ AS $$
declare
    ret    integer;
begin
    -- Updating dictionary tables setting last_sample_id
    UPDATE tablespaces_list utl SET last_sample_id = ssample_id - 1
    FROM tablespaces_list tl LEFT JOIN sample_stat_tablespaces cur
      ON (cur.server_id, cur.sample_id, cur.tablespaceid) =
        (sserver_id, ssample_id, tl.tablespaceid)
    WHERE
      tl.last_sample_id IS NULL AND
      (utl.server_id, utl.tablespaceid) = (sserver_id, tl.tablespaceid) AND
      tl.server_id = sserver_id AND cur.server_id IS NULL;

    UPDATE funcs_list ufl SET last_sample_id = ssample_id - 1
    FROM funcs_list fl LEFT JOIN sample_stat_user_functions cur
      ON (cur.server_id, cur.sample_id, cur.datid, cur.funcid) =
        (sserver_id, ssample_id, fl.datid, fl.funcid)
    WHERE
      fl.last_sample_id IS NULL AND
      fl.server_id = sserver_id AND cur.server_id IS NULL AND
      (ufl.server_id, ufl.datid, ufl.funcid) =
      (sserver_id, fl.datid, fl.funcid);

    UPDATE indexes_list uil SET last_sample_id = ssample_id - 1
    FROM indexes_list il LEFT JOIN sample_stat_indexes cur
      ON (cur.server_id, cur.sample_id, cur.datid, cur.indexrelid) =
        (sserver_id, ssample_id, il.datid, il.indexrelid)
    WHERE
      il.last_sample_id IS NULL AND
      il.server_id = sserver_id AND cur.server_id IS NULL AND
      (uil.server_id, uil.datid, uil.indexrelid) =
      (sserver_id, il.datid, il.indexrelid);

    UPDATE tables_list utl SET last_sample_id = ssample_id - 1
    FROM tables_list tl LEFT JOIN sample_stat_tables cur
      ON (cur.server_id, cur.sample_id, cur.datid, cur.relid) =
        (sserver_id, ssample_id, tl.datid, tl.relid)
    WHERE
      tl.last_sample_id IS NULL AND
      tl.server_id = sserver_id AND cur.server_id IS NULL AND
      (utl.server_id, utl.datid, utl.relid) =
      (sserver_id, tl.datid, tl.relid);

    UPDATE stmt_list slu SET last_sample_id = ssample_id - 1
    FROM sample_statements ss RIGHT JOIN stmt_list sl
      ON (ss.server_id, ss.sample_id, ss.queryid_md5) =
        (sserver_id, ssample_id, sl.queryid_md5)
    WHERE
      sl.server_id = sserver_id AND
      sl.last_sample_id IS NULL AND
      ss.server_id IS NULL AND
      (slu.server_id, slu.queryid_md5) = (sserver_id, sl.queryid_md5);

    UPDATE roles_list rlu SET last_sample_id = ssample_id - 1
    FROM
        sample_statements ss
      RIGHT JOIN roles_list rl
      ON (ss.server_id, ss.sample_id, ss.userid) =
        (sserver_id, ssample_id, rl.userid)
    WHERE
      rl.server_id = sserver_id AND
      rl.last_sample_id IS NULL AND
      ss.server_id IS NULL AND
      (rlu.server_id, rlu.userid) = (sserver_id, rl.userid);

    -- Deleting obsolete baselines
    DELETE FROM baselines
    WHERE keep_until < now()
      AND server_id = sserver_id;

    -- Getting max_sample_age setting
    BEGIN
        ret := COALESCE(current_setting('pg_profile.max_sample_age')::integer);
    EXCEPTION
        WHEN OTHERS THEN ret := 7;
    END;

    -- Deleting obsolete samples
    PERFORM num_nulls(min(s.sample_id),max(s.sample_id)) > 0 OR
      delete_samples(sserver_id, min(s.sample_id), max(s.sample_id)) > 0
    FROM samples s JOIN
      servers n USING (server_id)
    WHERE s.server_id = sserver_id
        AND s.sample_time < now() - (COALESCE(n.max_sample_age,ret) || ' days')::interval
        AND (s.server_id,s.sample_id) NOT IN (SELECT server_id,sample_id FROM bl_samples WHERE server_id = sserver_id);
end;
$$ LANGUAGE plpgsql;
CREATE FUNCTION init_sample(IN sserver_id integer
) RETURNS jsonb SET search_path=@extschema@ AS $$
DECLARE
    server_properties jsonb = '{"extensions":[],"settings":[],"timings":[],"properties":{}}'; -- version, extensions, etc.
    qres              record;
    qres_subsample    record;
    server_connstr    text;

    server_query      text;
    server_host       text = NULL;
BEGIN
    server_properties := jsonb_set(server_properties, '{properties,in_sample}', to_jsonb(false));
    -- Conditionally set lock_timeout when it's not set
    server_properties := jsonb_set(server_properties,'{properties,lock_timeout_init}',
      to_jsonb(current_setting('lock_timeout')));
    IF (SELECT current_setting('lock_timeout')::interval = '0s'::interval) THEN
      SET lock_timeout TO '3s';
    END IF;
    server_properties := jsonb_set(server_properties,'{properties,lock_timeout_effective}',
      to_jsonb(current_setting('lock_timeout')));

    -- Get server connstr
    SELECT properties INTO server_properties FROM get_connstr(sserver_id, server_properties);

    -- Getting timing collection setting
    BEGIN
        SELECT current_setting('pg_profile.track_sample_timings')::boolean AS collect_timings
          INTO qres;
        server_properties := jsonb_set(server_properties,
          '{collect_timings}',
          to_jsonb(qres.collect_timings)
        );
    EXCEPTION
        WHEN OTHERS THEN
          server_properties := jsonb_set(server_properties,
            '{collect_timings}',
            to_jsonb(false)
          );
    END;

    -- Getting TopN setting
    BEGIN
        SELECT least(current_setting('pg_profile.topn')::integer, 100) AS topn INTO qres;
        server_properties := jsonb_set(server_properties,'{properties,topn}',to_jsonb(qres.topn));
    EXCEPTION
        WHEN OTHERS THEN
          server_properties := jsonb_set(server_properties,
            '{properties,topn}',
            to_jsonb(20)
          );
    END;

    -- Getting statement stats reset setting
    BEGIN
        server_properties := jsonb_set(server_properties,
          '{properties,statements_reset}',
          to_jsonb(current_setting('pg_profile.statements_reset')::boolean)
        );
    EXCEPTION
        WHEN OTHERS THEN
          server_properties := jsonb_set(server_properties,
            '{properties,statements_reset}',
            to_jsonb(true)
          );
    END;

    -- Adding dblink extension schema to search_path if it does not already there
    IF (SELECT count(*) = 0 FROM pg_catalog.pg_extension WHERE extname = 'dblink') THEN
      RAISE 'dblink extension must be installed';
    END IF;

    SELECT extnamespace::regnamespace AS dblink_schema INTO STRICT qres FROM pg_catalog.pg_extension WHERE extname = 'dblink';
    IF NOT string_to_array(current_setting('search_path'),', ') @> ARRAY[qres.dblink_schema::text] THEN
      EXECUTE 'SET LOCAL search_path TO ' || current_setting('search_path')||','|| qres.dblink_schema;
    END IF;

    IF dblink_get_connections() @> ARRAY['server_connection'] THEN
        PERFORM dblink_disconnect('server_connection');
    END IF;

    server_properties := log_sample_timings(server_properties, 'connect', 'start');
    server_properties := log_sample_timings(server_properties, 'total', 'start');

    -- Server connection
    PERFORM dblink_connect('server_connection', server_properties #>> '{properties,server_connstr}');
    -- Transaction
    PERFORM dblink('server_connection','BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY');
    -- Setting application name
    PERFORM dblink('server_connection','SET application_name=''pg_profile''');
    -- Conditionally set lock_timeout
    IF (
      SELECT lock_timeout_unset
      FROM dblink('server_connection',
        $sql$SELECT current_setting('lock_timeout')::interval = '0s'::interval$sql$)
        AS probe(lock_timeout_unset boolean)
      )
    THEN
      -- Setting lock_timout prevents hanging due to DDL in long transaction
      PERFORM dblink('server_connection',
        format('SET lock_timeout TO %L',
          COALESCE(server_properties #>> '{properties,lock_timeout_effective}','3s')
        )
      );
    END IF;
    -- Reset search_path for security reasons
    PERFORM dblink('server_connection','SET search_path=''''');

    server_properties := log_sample_timings(server_properties, 'connect', 'end');
    server_properties := log_sample_timings(server_properties, 'get server environment', 'start');
    -- Get settings values for the server
    FOR qres IN
      SELECT * FROM dblink('server_connection',
          'SELECT name, '
          'reset_val, '
          'unit, '
          'pending_restart '
          'FROM pg_catalog.pg_settings '
          'WHERE name IN ('
            '''server_version_num'''
          ')')
        AS dbl(name text, reset_val text, unit text, pending_restart boolean)
    LOOP
      server_properties := jsonb_insert(server_properties,'{"settings",0}',to_jsonb(qres));
    END LOOP;

    -- Is it PostgresPro?
    IF (SELECT pgpro_fxs = 3
        FROM dblink('server_connection',
          'select count(1) as pgpro_fxs '
          'from pg_catalog.pg_settings '
          'where name IN (''pgpro_build'',''pgpro_edition'',''pgpro_version'')'
        ) AS pgpro (pgpro_fxs integer))
    THEN
      server_properties := jsonb_set(server_properties,'{properties,pgpro}',to_jsonb(true));
    ELSE
      server_properties := jsonb_set(server_properties,'{properties,pgpro}',to_jsonb(false));
    END IF;

    -- Get extensions, that we need to perform statements stats collection
    FOR qres IN
      SELECT * FROM dblink('server_connection',
          'SELECT extname, '
          'extnamespace::regnamespace::name AS extnamespace, '
          'extversion '
          'FROM pg_catalog.pg_extension '
          'WHERE extname IN ('
            '''pg_stat_statements'','
            '''pg_wait_sampling'','
            '''pg_stat_kcache'''
          ')')
        AS dbl(extname name, extnamespace name, extversion text)
    LOOP
      server_properties := jsonb_insert(server_properties,'{"extensions",0}',to_jsonb(qres));
    END LOOP;

    -- Check system identifier
    WITH remote AS (
      SELECT
        dbl.system_identifier
      FROM dblink('server_connection',
        'SELECT system_identifier '
        'FROM pg_catalog.pg_control_system()'
      ) AS dbl (system_identifier bigint)
    )
    SELECT min(reset_val::bigint) != (
        SELECT
          system_identifier
        FROM remote
      ) AS sysid_changed,
      (
        SELECT
          s.server_name = 'local' AND cs.system_identifier != r.system_identifier
        FROM
          pg_catalog.pg_control_system() cs
          CROSS JOIN remote r
          JOIN servers s ON (s.server_id = sserver_id)
      ) AS local_missmatch
      INTO STRICT qres
    FROM sample_settings
    WHERE server_id = sserver_id AND name = 'system_identifier';
    IF qres.sysid_changed THEN
      RAISE 'Server system_identifier has changed! '
        'Ensure server connection string is correct. '
        'Consider creating a new server for this cluster.';
    END IF;
    IF qres.local_missmatch THEN
      RAISE 'Local system_identifier does not match '
        'with server specified by connection string of '
        '"local" server';
    END IF;

    -- Subsample settings collection
    -- Get last base sample identifier of a server
    SELECT
      last_sample_id,
      subsample_enabled,
      min_query_dur,
      min_xact_dur,
      min_xact_age,
      min_idle_xact_dur
      INTO STRICT qres_subsample
    FROM servers JOIN server_subsample USING (server_id)
    WHERE server_id = sserver_id;

    server_properties := jsonb_set(server_properties,
      '{properties,last_sample_id}',
      to_jsonb(qres_subsample.last_sample_id)
    );

    /* Getting subsample GUC thresholds used as defaults*/
    BEGIN
        SELECT current_setting('pg_profile.subsample_enabled')::boolean AS subsample_enabled
          INTO qres;
        server_properties := jsonb_set(
          server_properties,
          '{properties,subsample_enabled}',
          to_jsonb(COALESCE(qres_subsample.subsample_enabled, qres.subsample_enabled))
        );
    EXCEPTION
        WHEN OTHERS THEN
          server_properties := jsonb_set(server_properties,
            '{properties,subsample_enabled}',
            to_jsonb(COALESCE(qres_subsample.subsample_enabled, true))
          );
    END;

    -- Setup subsample settings when they are enabled
    IF (server_properties #>> '{properties,subsample_enabled}')::boolean THEN
      BEGIN
          SELECT current_setting('pg_profile.min_query_duration')::interval AS min_query_dur INTO qres;
          server_properties := jsonb_set(
            server_properties,
            '{properties,min_query_dur}',
            to_jsonb(COALESCE(qres_subsample.min_query_dur, qres.min_query_dur))
          );
      EXCEPTION
          WHEN OTHERS THEN
            server_properties := jsonb_set(server_properties,
              '{properties,min_query_dur}',
              COALESCE (
                to_jsonb(qres_subsample.min_query_dur)
                , 'null'::jsonb
              )
            );
      END;

      BEGIN
          SELECT current_setting('pg_profile.min_xact_duration')::interval AS min_xact_dur INTO qres;
          server_properties := jsonb_set(
            server_properties,
            '{properties,min_xact_dur}',
            to_jsonb(COALESCE(qres_subsample.min_xact_dur, qres.min_xact_dur))
          );
      EXCEPTION
          WHEN OTHERS THEN
            server_properties := jsonb_set(server_properties,
              '{properties,min_xact_dur}',
              COALESCE (
                to_jsonb(qres_subsample.min_xact_dur)
                , 'null'::jsonb
              )
            );
      END;

      BEGIN
          SELECT current_setting('pg_profile.min_xact_age')::integer AS min_xact_age INTO qres;
          server_properties := jsonb_set(
            server_properties,
            '{properties,min_xact_age}',
            to_jsonb(COALESCE(qres_subsample.min_xact_age, qres.min_xact_age))
          );
      EXCEPTION
          WHEN OTHERS THEN
            server_properties := jsonb_set(server_properties,
              '{properties,min_xact_age}',
              COALESCE (
                to_jsonb(qres_subsample.min_xact_age)
                , 'null'::jsonb
              )
            );
      END;

      BEGIN
          SELECT current_setting('pg_profile.min_idle_xact_duration')::interval AS min_idle_xact_dur INTO qres;
          server_properties := jsonb_set(
            server_properties,
            '{properties,min_idle_xact_dur}',
            to_jsonb(COALESCE(qres_subsample.min_idle_xact_dur, qres.min_idle_xact_dur))
          );
      EXCEPTION
          WHEN OTHERS THEN
            server_properties := jsonb_set(server_properties,
              '{properties,min_idle_xact_dur}',
              COALESCE (
                to_jsonb(qres_subsample.min_idle_xact_dur)
                , 'null'::jsonb
              )
            );
      END;
    END IF; -- when subsamples enabled
    RETURN server_properties;
END;
$$ LANGUAGE plpgsql;
CREATE FUNCTION query_pg_stat_archiver(IN server_properties jsonb, IN sserver_id integer, IN ssample_id integer
) RETURNS jsonb AS $$
declare
    server_query text;
    pg_version int := (get_sp_setting(server_properties, 'server_version_num')).reset_val::integer;
begin
    server_properties := log_sample_timings(server_properties, 'query pg_stat_archiver', 'start');
    -- pg_stat_archiver data
    CASE
      WHEN pg_version > 90500 THEN
        server_query := 'SELECT '
          'archived_count,'
          'last_archived_wal,'
          'last_archived_time,'
          'failed_count,'
          'last_failed_wal,'
          'last_failed_time,'
          'stats_reset '
          'FROM pg_catalog.pg_stat_archiver';
      ELSE
        server_query := NULL;
    END CASE;

    IF server_query IS NOT NULL THEN
      INSERT INTO last_stat_archiver (
        server_id,
        sample_id,
        archived_count,
        last_archived_wal,
        last_archived_time,
        failed_count,
        last_failed_wal,
        last_failed_time,
        stats_reset)
      SELECT
        sserver_id,
        ssample_id,
        archived_count as archived_count,
        last_archived_wal as last_archived_wal,
        last_archived_time as last_archived_time,
        failed_count as failed_count,
        last_failed_wal as last_failed_wal,
        last_failed_time as last_failed_time,
        stats_reset as stats_reset
      FROM dblink('server_connection',server_query) AS rs (
        archived_count              bigint,
        last_archived_wal           text,
        last_archived_time          timestamp with time zone,
        failed_count                bigint,
        last_failed_wal             text,
        last_failed_time            timestamp with time zone,
        stats_reset                 timestamp with time zone
      );
    END IF;
    server_properties := log_sample_timings(server_properties, 'query pg_stat_archiver', 'end');
    return server_properties;
end;
$$ LANGUAGE plpgsql;
CREATE FUNCTION query_pg_stat_bgwriter(IN server_properties jsonb, IN sserver_id integer, IN ssample_id integer
) RETURNS jsonb AS $$
declare
    server_query text;
    pg_version int := (get_sp_setting(server_properties, 'server_version_num')).reset_val::integer;
begin
    server_properties := log_sample_timings(server_properties, 'query pg_stat_bgwriter', 'start');
    -- pg_stat_bgwriter data
    CASE
      WHEN pg_version < 100000 THEN
        server_query := 'SELECT '
          'checkpoints_timed,'
          'checkpoints_req,'
          'NULL as checkpoints_done,'
          'checkpoint_write_time,'
          'checkpoint_sync_time,'
          'buffers_checkpoint,'
          'NULL as slru_checkpoint,'
          'buffers_clean,'
          'maxwritten_clean,'
          'buffers_backend,'
          'buffers_backend_fsync,'
          'buffers_alloc,'
          'stats_reset,'
          'CASE WHEN pg_catalog.pg_is_in_recovery() '
          'THEN pg_catalog.pg_xlog_location_diff(pg_catalog.pg_last_xlog_replay_location(),''0/00000000'') '
          'ELSE pg_catalog.pg_xlog_location_diff(pg_catalog.pg_current_xlog_location(),''0/00000000'') '
          'END AS wal_size,'
          'CASE WHEN pg_catalog.pg_is_in_recovery() '
          'THEN pg_catalog.pg_last_xlog_replay_location() '
          'ELSE pg_catalog.pg_current_xlog_location() '
          'END AS wal_lsn,'
          'pg_is_in_recovery() AS in_recovery,'
          'NULL AS restartpoints_timed,'
          'NULL AS restartpoints_req,'
          'NULL AS restartpoints_done,'
          'stats_reset as checkpoint_stats_reset '
          'FROM pg_catalog.pg_stat_bgwriter';
      WHEN pg_version < 170000 THEN
        server_query := 'SELECT '
          'checkpoints_timed,'
          'checkpoints_req,'
          'NULL as checkpoints_done,'
          'checkpoint_write_time,'
          'checkpoint_sync_time,'
          'buffers_checkpoint,'
          'NULL as slru_checkpoint,'
          'buffers_clean,'
          'maxwritten_clean,'
          'buffers_backend,'
          'buffers_backend_fsync,'
          'buffers_alloc,'
          'stats_reset,'
          'CASE WHEN pg_catalog.pg_is_in_recovery() '
            'THEN pg_catalog.pg_wal_lsn_diff(pg_catalog.pg_last_wal_replay_lsn(),''0/00000000'') '
            'ELSE pg_catalog.pg_wal_lsn_diff(pg_catalog.pg_current_wal_lsn(),''0/00000000'') '
          'END AS wal_size,'
          'CASE WHEN pg_catalog.pg_is_in_recovery() '
            'THEN pg_catalog.pg_last_wal_replay_lsn() '
            'ELSE pg_catalog.pg_current_wal_lsn() '
          'END AS wal_lsn,'
          'pg_catalog.pg_is_in_recovery() as in_recovery, '
          'NULL AS restartpoints_timed,'
          'NULL AS restartpoints_req,'
          'NULL AS restartpoints_done,'
          'stats_reset as checkpoint_stats_reset '
        'FROM pg_catalog.pg_stat_bgwriter';
      WHEN pg_version < 180000 THEN
        server_query := 'SELECT '
          'c.num_timed as checkpoints_timed,'
          'c.num_requested as checkpoints_req,'
          'NULL as checkpoints_done,'
          'c.write_time as checkpoint_write_time,'
          'c.sync_time as checkpoint_sync_time,'
          'c.buffers_written as buffers_checkpoint,'
          'NULL as slru_checkpoint,'
          'b.buffers_clean as buffers_clean,'
          'b.maxwritten_clean as maxwritten_clean,'
          'NULL as buffers_backend,'
          'NULL as buffers_backend_fsync,'
          'b.buffers_alloc,'
          'b.stats_reset as stats_reset,'
          'CASE WHEN pg_catalog.pg_is_in_recovery() '
            'THEN pg_catalog.pg_wal_lsn_diff(pg_catalog.pg_last_wal_replay_lsn(),''0/00000000'') '
            'ELSE pg_catalog.pg_wal_lsn_diff(pg_catalog.pg_current_wal_lsn(),''0/00000000'') '
          'END AS wal_size,'
          'CASE WHEN pg_catalog.pg_is_in_recovery()'
            'THEN pg_catalog.pg_last_wal_replay_lsn()'
            'ELSE pg_catalog.pg_current_wal_lsn()'
          'END AS wal_lsn,'
          'pg_catalog.pg_is_in_recovery() as in_recovery,'
          'c.restartpoints_timed,'
          'c.restartpoints_req,'
          'c.restartpoints_done,'
          'c.stats_reset as checkpoint_stats_reset '
        'FROM '
          'pg_catalog.pg_stat_checkpointer c CROSS JOIN '
          'pg_catalog.pg_stat_bgwriter b';
      WHEN pg_version >= 180000 THEN
        server_query := 'SELECT '
          'c.num_timed as checkpoints_timed,'
          'c.num_requested as checkpoints_req,'
          'c.num_done as checkpoints_done,'
          'c.write_time as checkpoint_write_time,'
          'c.sync_time as checkpoint_sync_time,'
          'c.buffers_written as buffers_checkpoint,'
          'c.slru_written as slru_checkpoint,'
          'b.buffers_clean as buffers_clean,'
          'b.maxwritten_clean as maxwritten_clean,'
          'NULL as buffers_backend,'
          'NULL as buffers_backend_fsync,'
          'b.buffers_alloc,'
          'b.stats_reset as stats_reset,'
          'CASE WHEN pg_catalog.pg_is_in_recovery() '
            'THEN pg_catalog.pg_wal_lsn_diff(pg_catalog.pg_last_wal_replay_lsn(),''0/00000000'') '
            'ELSE pg_catalog.pg_wal_lsn_diff(pg_catalog.pg_current_wal_lsn(),''0/00000000'') '
          'END AS wal_size,'
          'CASE WHEN pg_catalog.pg_is_in_recovery()'
            'THEN pg_catalog.pg_last_wal_replay_lsn()'
            'ELSE pg_catalog.pg_current_wal_lsn()'
          'END AS wal_lsn,'
          'pg_catalog.pg_is_in_recovery() as in_recovery,'
          'c.restartpoints_timed,'
          'c.restartpoints_req,'
          'c.restartpoints_done,'
          'c.stats_reset as checkpoint_stats_reset '
        'FROM '
          'pg_catalog.pg_stat_checkpointer c CROSS JOIN '
          'pg_catalog.pg_stat_bgwriter b';
    END CASE;

    IF server_query IS NOT NULL THEN
      INSERT INTO last_stat_cluster (
        server_id,
        sample_id,
        checkpoints_timed,
        checkpoints_req,
        checkpoints_done,
        checkpoint_write_time,
        checkpoint_sync_time,
        buffers_checkpoint,
        slru_checkpoint,
        buffers_clean,
        maxwritten_clean,
        buffers_backend,
        buffers_backend_fsync,
        buffers_alloc,
        stats_reset,
        wal_size,
        wal_lsn,
        in_recovery,
        restartpoints_timed,
        restartpoints_req,
        restartpoints_done,
        checkpoint_stats_reset)
      SELECT
        sserver_id,
        ssample_id,
        checkpoints_timed,
        checkpoints_req,
        checkpoints_done,
        checkpoint_write_time,
        checkpoint_sync_time,
        buffers_checkpoint,
        slru_checkpoint,
        buffers_clean,
        maxwritten_clean,
        buffers_backend,
        buffers_backend_fsync,
        buffers_alloc,
        stats_reset,
        wal_size,
        wal_lsn,
        in_recovery,
        restartpoints_timed,
        restartpoints_req,
        restartpoints_done,
        checkpoint_stats_reset
      FROM dblink('server_connection',server_query) AS rs (
        checkpoints_timed bigint,
        checkpoints_req bigint,
        checkpoints_done bigint,
        checkpoint_write_time double precision,
        checkpoint_sync_time double precision,
        buffers_checkpoint bigint,
        slru_checkpoint bigint,
        buffers_clean bigint,
        maxwritten_clean bigint,
        buffers_backend bigint,
        buffers_backend_fsync bigint,
        buffers_alloc bigint,
        stats_reset timestamp with time zone,
        wal_size bigint,
        wal_lsn pg_lsn,
        in_recovery boolean,
        restartpoints_timed bigint,
        restartpoints_req bigint,
        restartpoints_done bigint,
        checkpoint_stats_reset timestamp with time zone);
    END IF;
    server_properties := log_sample_timings(server_properties, 'query pg_stat_bgwriter', 'end');
    return server_properties;
end;
$$ LANGUAGE plpgsql;
CREATE FUNCTION query_pg_stat_io(IN server_properties jsonb, IN sserver_id integer, IN ssample_id integer
) RETURNS jsonb AS $$
declare
    server_query text;
    pg_version int := (get_sp_setting(server_properties, 'server_version_num')).reset_val::integer;
begin
    server_properties := log_sample_timings(server_properties, 'query pg_stat_io', 'start');
    -- pg_stat_io data
    CASE
      WHEN pg_version >= 180000 THEN
        server_query := 'SELECT '
          'backend_type,'
          'object,'
          'pg_stat_io.context,'
          'reads,'
          'read_bytes,'
          'read_time,'
          'writes,'
          'write_bytes,'
          'write_time,'
          'writebacks,'
          'writeback_time,'
          'extends,'
          'extend_bytes,'
          'extend_time,'
          'ps.setting::integer AS op_bytes,'
          'hits,'
          'evictions,'
          'reuses,'
          'fsyncs,'
          'fsync_time,'
          'stats_reset '
          'FROM pg_catalog.pg_stat_io '
          'JOIN pg_catalog.pg_settings ps ON name = ''block_size'' '
          'WHERE greatest('
              'reads,'
              'writes,'
              'writebacks,'
              'extends,'
              'hits,'
              'evictions,'
              'reuses,'
              'fsyncs'
            ') > 0'
          ;
      WHEN pg_version >= 160000 THEN
        server_query := 'SELECT '
          'backend_type,'
          'object,'
          'context,'
          'reads,'
          'NULL as read_bytes,'
          'read_time,'
          'writes,'
          'NULL as write_bytes,'
          'write_time,'
          'writebacks,'
          'writeback_time,'
          'extends,'
          'NULL as extend_bytes,'
          'extend_time,'
          'op_bytes,'
          'hits,'
          'evictions,'
          'reuses,'
          'fsyncs,'
          'fsync_time,'
          'stats_reset '
          'FROM pg_catalog.pg_stat_io '
          'WHERE greatest('
              'reads,'
              'writes,'
              'writebacks,'
              'extends,'
              'hits,'
              'evictions,'
              'reuses,'
              'fsyncs'
            ') > 0'
          ;
      ELSE
        server_query := NULL;
    END CASE;

    IF server_query IS NOT NULL THEN
      INSERT INTO last_stat_io (
        server_id,
        sample_id,
        backend_type,
        object,
        context,
        reads,
        read_bytes,
        read_time,
        writes,
        write_bytes,
        write_time,
        writebacks,
        writeback_time,
        extends,
        extend_bytes,
        extend_time,
        op_bytes,
        hits,
        evictions,
        reuses,
        fsyncs,
        fsync_time,
        stats_reset
      )
      SELECT
        sserver_id,
        ssample_id,
        backend_type,
        object,
        context,
        reads,
        read_bytes,
        read_time,
        writes,
        write_bytes,
        write_time,
        writebacks,
        writeback_time,
        extends,
        extend_bytes,
        extend_time,
        op_bytes,
        hits,
        evictions,
        reuses,
        fsyncs,
        fsync_time,
        stats_reset
      FROM dblink('server_connection',server_query) AS rs (
        backend_type      text,
        object            text,
        context           text,
        reads             bigint,
        read_bytes        numeric,
        read_time         double precision,
        writes            bigint,
        write_bytes       numeric,
        write_time        double precision,
        writebacks        bigint,
        writeback_time    double precision,
        extends           bigint,
        extend_bytes      numeric,
        extend_time       double precision,
        op_bytes          bigint,
        hits              bigint,
        evictions         bigint,
        reuses            bigint,
        fsyncs            bigint,
        fsync_time        double precision,
        stats_reset       timestamp with time zone
      );
    END IF;
    server_properties := log_sample_timings(server_properties, 'query pg_stat_io', 'end');
    return server_properties;
end;
$$ LANGUAGE plpgsql;
CREATE FUNCTION query_pg_stat_slru(IN server_properties jsonb, IN sserver_id integer, IN ssample_id integer
) RETURNS jsonb AS $$
declare
    server_query text;
    pg_version int := (get_sp_setting(server_properties, 'server_version_num')).reset_val::integer;
begin
    server_properties := log_sample_timings(server_properties, 'query pg_stat_slru', 'start');
    -- pg_stat_slru data
    CASE
      WHEN pg_version >= 130000 THEN
        server_query := 'SELECT '
          'name,'
          'blks_zeroed,'
          'blks_hit,'
          'blks_read,'
          'blks_written,'
          'blks_exists,'
          'flushes,'
          'truncates,'
          'stats_reset '
          'FROM pg_catalog.pg_stat_slru '
          'WHERE greatest('
              'blks_zeroed,'
              'blks_hit,'
              'blks_read,'
              'blks_written,'
              'blks_exists,'
              'flushes,'
              'truncates'
            ') > 0'
          ;
      ELSE
        server_query := NULL;
    END CASE;

    IF server_query IS NOT NULL THEN
      INSERT INTO last_stat_slru (
        server_id,
        sample_id,
        name,
        blks_zeroed,
        blks_hit,
        blks_read,
        blks_written,
        blks_exists,
        flushes,
        truncates,
        stats_reset
      )
      SELECT
        sserver_id,
        ssample_id,
        name,
        blks_zeroed,
        blks_hit,
        blks_read,
        blks_written,
        blks_exists,
        flushes,
        truncates,
        stats_reset
      FROM dblink('server_connection',server_query) AS rs (
        name          text,
        blks_zeroed   bigint,
        blks_hit      bigint,
        blks_read     bigint,
        blks_written  bigint,
        blks_exists   bigint,
        flushes       bigint,
        truncates     bigint,
        stats_reset   timestamp with time zone
      );
    END IF;
    server_properties := log_sample_timings(server_properties, 'query pg_stat_slru', 'end');
    return server_properties;
end;
$$ LANGUAGE plpgsql;
CREATE FUNCTION query_pg_stat_wal(IN server_properties jsonb, IN sserver_id integer, IN ssample_id integer
) RETURNS jsonb AS $$
declare
    server_query text;
    pg_version int := (get_sp_setting(server_properties, 'server_version_num')).reset_val::integer;
begin
    server_properties := log_sample_timings(server_properties, 'query pg_stat_wal', 'start');
    -- pg_stat_wal data
    CASE
      WHEN pg_version >= 180000 THEN
        server_query := 'SELECT '
          'wal.wal_records,'
          'wal.wal_fpi,'
          'wal.wal_bytes,'
          'wal.wal_buffers_full,'
          'NULL as wal_write,'
          'NULL as wal_sync,'
          'NULL as wal_write_time,'
          'NULL as wal_sync_time,'
          'wal.stats_reset '
          'FROM pg_catalog.pg_stat_wal wal';
      WHEN pg_version >= 140000 THEN
        server_query := 'SELECT '
          'wal_records,'
          'wal_fpi,'
          'wal_bytes,'
          'wal_buffers_full,'
          'wal_write,'
          'wal_sync,'
          'wal_write_time,'
          'wal_sync_time,'
          'stats_reset '
          'FROM pg_catalog.pg_stat_wal';
      ELSE
        server_query := NULL;
    END CASE;

    IF server_query IS NOT NULL THEN
      INSERT INTO last_stat_wal (
        server_id,
        sample_id,
        wal_records,
        wal_fpi,
        wal_bytes,
        wal_buffers_full,
        wal_write,
        wal_sync,
        wal_write_time,
        wal_sync_time,
        stats_reset
      )
      SELECT
        sserver_id,
        ssample_id,
        wal_records,
        wal_fpi,
        wal_bytes,
        wal_buffers_full,
        wal_write,
        wal_sync,
        wal_write_time,
        wal_sync_time,
        stats_reset
      FROM dblink('server_connection',server_query) AS rs (
        wal_records         bigint,
        wal_fpi             bigint,
        wal_bytes           numeric,
        wal_buffers_full    bigint,
        wal_write           bigint,
        wal_sync            bigint,
        wal_write_time      double precision,
        wal_sync_time       double precision,
        stats_reset         timestamp with time zone);
    END IF;
    server_properties := log_sample_timings(server_properties, 'query pg_stat_wal', 'end');
    return server_properties;
end;
$$ LANGUAGE plpgsql;
CREATE FUNCTION sample_dbobj_delta(IN properties jsonb, IN sserver_id integer, IN s_id integer,
  IN topn integer, IN skip_sizes boolean) RETURNS jsonb AS $$
DECLARE
    result  jsonb := sample_dbobj_delta.properties;
BEGIN

    /* This function will calculate statistics increments for database objects
    * and store top objects values in sample.
    * Due to relations between objects we need to mark top objects (and their
    * dependencies) first, and calculate increments later
    */
    result := log_sample_timings(result, 'calculate tables stats', 'start');

    -- Marking functions
    UPDATE last_stat_user_functions ulf
    SET in_sample = true
    FROM
        (SELECT
            cur.server_id,
            cur.sample_id,
            cur.datid,
            cur.funcid,
            row_number() OVER (PARTITION BY cur.trg_fn ORDER BY cur.total_time - COALESCE(lst.total_time,0) DESC) time_rank,
            row_number() OVER (PARTITION BY cur.trg_fn ORDER BY cur.self_time - COALESCE(lst.self_time,0) DESC) stime_rank,
            row_number() OVER (PARTITION BY cur.trg_fn ORDER BY cur.calls - COALESCE(lst.calls,0) DESC) calls_rank
        FROM last_stat_user_functions cur JOIN last_stat_database dbcur USING (server_id, sample_id, datid)
          LEFT OUTER JOIN last_stat_database dblst ON
            (dblst.server_id, dblst.datid, dblst.sample_id) =
            (sserver_id, dbcur.datid, s_id - 1)
            AND dblst.stats_reset IS NOT DISTINCT FROM dbcur.stats_reset
          LEFT OUTER JOIN last_stat_user_functions lst ON
            (lst.server_id, lst.sample_id, lst.datid, lst.funcid) =
            (sserver_id, s_id - 1, dblst.datid, cur.funcid)
        WHERE
            (cur.server_id, cur.sample_id) =
            (sserver_id, s_id)
            AND cur.calls - COALESCE(lst.calls,0) > 0) diff
    WHERE
      least(
        time_rank,
        calls_rank,
        stime_rank
      ) <= topn
      AND (ulf.server_id, ulf.sample_id, ulf.datid, ulf.funcid) =
        (diff.server_id, diff.sample_id, diff.datid, diff.funcid);

    -- Marking indexes
    UPDATE last_stat_indexes uli
    SET in_sample = true
    FROM
      (SELECT
          cur.server_id,
          cur.sample_id,
          cur.datid,
          cur.indexrelid,
          -- Index ranks
          row_number() OVER (ORDER BY cur.idx_blks_read - COALESCE(lst.idx_blks_read,0) DESC) read_rank,
          row_number() OVER (ORDER BY cur.idx_blks_read+cur.idx_blks_hit-
            COALESCE(lst.idx_blks_read+lst.idx_blks_hit,0) DESC) gets_rank,
          row_number() OVER (PARTITION BY cur.idx_scan - COALESCE(lst.idx_scan,0) = 0
            ORDER BY tblcur.n_tup_ins - COALESCE(tbllst.n_tup_ins,0) +
            tblcur.n_tup_upd - COALESCE(tbllst.n_tup_upd,0) +
            tblcur.n_tup_del - COALESCE(tbllst.n_tup_del,0) DESC) dml_unused_rank,
          row_number() OVER (ORDER BY (tblcur.vacuum_count - COALESCE(tbllst.vacuum_count,0) +
            tblcur.autovacuum_count - COALESCE(tbllst.autovacuum_count,0)) *
              -- Coalesce is used here in case of skipped size collection
              COALESCE(cur.relsize,lst.relsize) DESC) vacuum_bytes_rank
      FROM last_stat_indexes cur JOIN last_stat_tables tblcur USING (server_id, sample_id, datid, relid)
        JOIN last_stat_database dbcur USING (server_id, sample_id, datid)
        LEFT OUTER JOIN last_stat_database dblst ON
          (dblst.server_id, dblst.datid, dblst.sample_id) =
          (sserver_id, dbcur.datid, s_id - 1)
          AND dblst.stats_reset IS NOT DISTINCT FROM dbcur.stats_reset
        LEFT OUTER JOIN last_stat_indexes lst ON
          (lst.server_id, lst.sample_id, lst.datid, lst.relid, lst.indexrelid) =
          (sserver_id, s_id - 1, dblst.datid, cur.relid, cur.indexrelid)
        LEFT OUTER JOIN last_stat_tables tbllst ON
          (tbllst.server_id, tbllst.sample_id, tbllst.datid, tbllst.relid) =
          (sserver_id, s_id - 1, dblst.datid, lst.relid)
      WHERE
        (cur.server_id, cur.sample_id) =
        (sserver_id, s_id)
      ) diff
    WHERE
      (least(
        read_rank,
        gets_rank,
        vacuum_bytes_rank
      ) <= topn
      OR (dml_unused_rank <= topn AND idx_scan = 0))
      AND (uli.server_id, uli.sample_id, uli.datid, uli.indexrelid, uli.in_sample) =
        (diff.server_id, diff.sample_id, diff.datid, diff.indexrelid, false);

    -- Growth rank is to be calculated independently of database stats_reset value
    UPDATE last_stat_indexes uli
    SET in_sample = true
    FROM
      (SELECT
          cur.server_id,
          cur.sample_id,
          cur.datid,
          cur.indexrelid,
          cur.relsize IS NOT NULL AS relsize_avail,
          cur.relpages_bytes IS NOT NULL AS relpages_avail,
          -- Index ranks
          row_number() OVER (ORDER BY cur.relsize - COALESCE(lst.relsize,0) DESC NULLS LAST) growth_rank,
          row_number() OVER (ORDER BY cur.relpages_bytes - COALESCE(lst.relpages_bytes,0) DESC NULLS LAST) pagegrowth_rank
      FROM last_stat_indexes cur
        LEFT OUTER JOIN last_stat_indexes lst ON
          (lst.server_id, lst.sample_id, lst.datid, lst.relid, lst.indexrelid) =
          (sserver_id, s_id - 1, cur.datid, cur.relid, cur.indexrelid)
      WHERE
        (cur.server_id, cur.sample_id) =
        (sserver_id, s_id)
      ) diff
    WHERE
      ((relsize_avail AND growth_rank <= topn) OR
      ((NOT relsize_avail) AND relpages_avail AND pagegrowth_rank <= topn))
      AND (uli.server_id, uli.sample_id, uli.datid, uli.indexrelid, uli.in_sample) =
        (diff.server_id, diff.sample_id, diff.datid, diff.indexrelid, false);

    -- Marking tables
    UPDATE last_stat_tables ulst
    SET in_sample = true
    FROM (
      SELECT
          cur.server_id AS server_id,
          cur.sample_id AS sample_id,
          cur.datid AS datid,
          cur.relid AS relid,
          tcur.relid AS toastrelid,
          -- Seq. scanned blocks rank
          row_number() OVER (ORDER BY
            (cur.seq_scan - COALESCE(lst.seq_scan,0)) * (cur.relpages_bytes / 8192) +
            (tcur.seq_scan - COALESCE(tlst.seq_scan,0)) * (tcur.relpages_bytes / 8192) DESC) scan_rank,
          row_number() OVER (ORDER BY cur.n_tup_ins + cur.n_tup_upd + cur.n_tup_del -
            COALESCE(lst.n_tup_ins + lst.n_tup_upd + lst.n_tup_del, 0) +
            COALESCE(tcur.n_tup_ins + tcur.n_tup_upd + tcur.n_tup_del, 0) -
            COALESCE(tlst.n_tup_ins + tlst.n_tup_upd + tlst.n_tup_del, 0) DESC) dml_rank,
          row_number() OVER (ORDER BY cur.n_tup_upd+cur.n_tup_del -
            COALESCE(lst.n_tup_upd + lst.n_tup_del, 0) +
            COALESCE(tcur.n_tup_upd + tcur.n_tup_del, 0) -
            COALESCE(tlst.n_tup_upd + tlst.n_tup_del, 0) DESC) vacuum_dml_rank,
          row_number() OVER (ORDER BY
            cur.n_dead_tup / NULLIF(cur.n_live_tup+cur.n_dead_tup, 0)
            DESC NULLS LAST) dead_pct_rank,
          row_number() OVER (ORDER BY
            cur.n_mod_since_analyze / NULLIF(cur.n_live_tup, 0)
            DESC NULLS LAST) mod_pct_rank,
          -- Read rank
          row_number() OVER (ORDER BY
            cur.heap_blks_read - COALESCE(lst.heap_blks_read,0) +
            cur.idx_blks_read - COALESCE(lst.idx_blks_read,0) +
            cur.toast_blks_read - COALESCE(lst.toast_blks_read,0) +
            cur.tidx_blks_read - COALESCE(lst.tidx_blks_read,0) DESC) read_rank,
          -- Page processing rank
          row_number() OVER (ORDER BY cur.heap_blks_read+cur.heap_blks_hit+cur.idx_blks_read+cur.idx_blks_hit+
            cur.toast_blks_read+cur.toast_blks_hit+cur.tidx_blks_read+cur.tidx_blks_hit-
            COALESCE(lst.heap_blks_read+lst.heap_blks_hit+lst.idx_blks_read+lst.idx_blks_hit+
            lst.toast_blks_read+lst.toast_blks_hit+lst.tidx_blks_read+lst.tidx_blks_hit, 0) DESC) gets_rank,
          -- Vacuum rank
          row_number() OVER (ORDER BY cur.vacuum_count - COALESCE(lst.vacuum_count, 0) +
            cur.autovacuum_count - COALESCE(lst.autovacuum_count, 0) DESC) vacuum_count_rank,
          row_number() OVER (ORDER BY cur.analyze_count - COALESCE(lst.analyze_count,0) +
            cur.autoanalyze_count - COALESCE(lst.autoanalyze_count,0) DESC) analyze_count_rank,
          row_number() OVER (ORDER BY cur.total_vacuum_time - COALESCE(lst.total_vacuum_time, 0) +
            cur.total_autovacuum_time - COALESCE(lst.total_autovacuum_time, 0) DESC) vacuum_time_rank,
          row_number() OVER (ORDER BY cur.total_analyze_time - COALESCE(lst.total_analyze_time,0) +
            cur.total_autoanalyze_time - COALESCE(lst.total_autoanalyze_time,0) DESC) analyze_time_rank,

          -- Newpage updates rank (since PG16)
          CASE WHEN cur.n_tup_newpage_upd IS NOT NULL THEN
            row_number() OVER (ORDER BY cur.n_tup_newpage_upd -
              COALESCE(lst.n_tup_newpage_upd, 0) DESC)
          ELSE
            NULL
          END newpage_upd_rank
      FROM
        -- main relations diff
        last_stat_tables cur JOIN last_stat_database dbcur USING (server_id, sample_id, datid)
        LEFT OUTER JOIN last_stat_database dblst ON
          (dblst.server_id, dblst.datid, dblst.sample_id) =
          (sserver_id, dbcur.datid, s_id - 1)
          AND dblst.stats_reset IS NOT DISTINCT FROM dbcur.stats_reset
        LEFT OUTER JOIN last_stat_tables lst ON
          (lst.server_id, lst.sample_id, lst.datid, lst.relid) =
          (sserver_id, s_id - 1, dblst.datid, cur.relid)
        -- toast relations diff
        LEFT OUTER JOIN last_stat_tables tcur ON
          (tcur.server_id, tcur.sample_id, tcur.datid, tcur.relid) =
          (sserver_id, s_id, dbcur.datid, cur.reltoastrelid)
        LEFT OUTER JOIN last_stat_tables tlst ON
          (tlst.server_id, tlst.sample_id, tlst.datid, tlst.relid) =
          (sserver_id, s_id - 1, dblst.datid, lst.reltoastrelid)
      WHERE
        (cur.server_id, cur.sample_id, cur.in_sample) =
        (sserver_id, s_id, false)
        AND cur.relkind IN ('r','m')) diff
    WHERE
      least(
        scan_rank,
        dml_rank,
        dead_pct_rank,
        mod_pct_rank,
        vacuum_dml_rank,
        read_rank,
        gets_rank,
        vacuum_count_rank,
        analyze_count_rank,
        vacuum_time_rank,
        analyze_time_rank,
        newpage_upd_rank
      ) <= topn
      AND (ulst.server_id, ulst.sample_id, ulst.datid, ulst.in_sample) =
        (sserver_id, s_id, diff.datid, false)
      AND (ulst.relid = diff.relid OR ulst.relid = diff.toastrelid);

    -- Growth rank is to be calculated independently of database stats_reset value
    UPDATE last_stat_tables ulst
    SET in_sample = true
    FROM (
      SELECT
          cur.server_id AS server_id,
          cur.sample_id AS sample_id,
          cur.datid AS datid,
          cur.relid AS relid,
          tcur.relid AS toastrelid,
          cur.relsize IS NOT NULL AS relsize_avail,
          cur.relpages_bytes IS NOT NULL AS relpages_avail,
          row_number() OVER (ORDER BY cur.relsize - COALESCE(lst.relsize, 0) +
            COALESCE(tcur.relsize,0) - COALESCE(tlst.relsize, 0) DESC NULLS LAST) growth_rank,
          row_number() OVER (ORDER BY cur.relpages_bytes - COALESCE(lst.relpages_bytes, 0) +
            COALESCE(tcur.relpages_bytes,0) - COALESCE(tlst.relpages_bytes, 0) DESC NULLS LAST) pagegrowth_rank
      FROM
        -- main relations diff
        last_stat_tables cur
        LEFT OUTER JOIN last_stat_tables lst ON
          (lst.server_id, lst.sample_id, lst.datid, lst.relid) =
          (sserver_id, s_id - 1, cur.datid, cur.relid)
        -- toast relations diff
        LEFT OUTER JOIN last_stat_tables tcur ON
          (tcur.server_id, tcur.sample_id, tcur.datid, tcur.relid) =
          (sserver_id, s_id, cur.datid, cur.reltoastrelid)
        LEFT OUTER JOIN last_stat_tables tlst ON
          (tlst.server_id, tlst.sample_id, tlst.datid, tlst.relid) =
          (sserver_id, s_id - 1, lst.datid, lst.reltoastrelid)
      WHERE (cur.server_id, cur.sample_id) = (sserver_id, s_id)
        AND cur.relkind IN ('r','m')) diff
    WHERE
      ((relsize_avail AND growth_rank <= topn) OR
      ((NOT relsize_avail) AND relpages_avail AND pagegrowth_rank <= topn))
      AND (ulst.server_id, ulst.sample_id, ulst.datid, in_sample) =
        (sserver_id, s_id, diff.datid, false)
      AND (ulst.relid = diff.relid OR ulst.relid = diff.toastrelid);

    /* Also mark tables having marked indexes on them including main
    * table in case of a TOAST index and TOAST table if index is on
    * main table
    */
    UPDATE last_stat_tables ulst
    SET in_sample = true
    FROM
      last_stat_indexes ix
      JOIN last_stat_tables tbl ON
        (tbl.server_id, tbl.sample_id, tbl.datid, tbl.relid) =
        (sserver_id, s_id, ix.datid, ix.relid)
      LEFT JOIN last_stat_tables mtbl ON
        (mtbl.server_id, mtbl.sample_id, mtbl.datid, mtbl.reltoastrelid) =
        (sserver_id, s_id, tbl.datid, tbl.relid)
    WHERE
      (ix.server_id, ix.sample_id, ix.in_sample) =
      (sserver_id, s_id, true)
      AND (ulst.server_id, ulst.sample_id, ulst.datid, ulst.in_sample) =
        (sserver_id, s_id, tbl.datid, false)
      AND ulst.relid IN (tbl.relid, tbl.reltoastrelid, mtbl.relid);

    -- Insert marked objects statistics increments
    -- New table names
    INSERT INTO tables_list AS itl (
      server_id,
      last_sample_id,
      datid,
      relid,
      relkind,
      schemaname,
      relname
    )
    SELECT
      cur.server_id,
      NULL,
      cur.datid,
      cur.relid,
      cur.relkind,
      cur.schemaname,
      cur.relname
    FROM
      last_stat_tables cur
    WHERE
      (cur.server_id, cur.sample_id, cur.in_sample) =
      (sserver_id, s_id, true)
    ON CONFLICT ON CONSTRAINT pk_tables_list DO
      UPDATE SET
        (last_sample_id, schemaname, relname) =
        (EXCLUDED.last_sample_id, EXCLUDED.schemaname, EXCLUDED.relname)
      WHERE
        (itl.last_sample_id, itl.schemaname, itl.relname) IS DISTINCT FROM
        (EXCLUDED.last_sample_id, EXCLUDED.schemaname, EXCLUDED.relname);

    -- Tables
    INSERT INTO sample_stat_tables (
      server_id,
      sample_id,
      datid,
      relid,
      reltoastrelid,
      tablespaceid,
      seq_scan,
      seq_tup_read,
      idx_scan,
      idx_tup_fetch,
      n_tup_ins,
      n_tup_upd,
      n_tup_del,
      n_tup_hot_upd,
      n_live_tup,
      n_dead_tup,
      n_mod_since_analyze,
      n_ins_since_vacuum,
      last_vacuum,
      last_autovacuum,
      last_analyze,
      last_autoanalyze,
      vacuum_count,
      autovacuum_count,
      analyze_count,
      autoanalyze_count,
      total_vacuum_time,
      total_autovacuum_time,
      total_analyze_time,
      total_autoanalyze_time,
      heap_blks_read,
      heap_blks_hit,
      idx_blks_read,
      idx_blks_hit,
      toast_blks_read,
      toast_blks_hit,
      tidx_blks_read,
      tidx_blks_hit,
      relsize,
      relsize_diff,
      relpages_bytes,
      relpages_bytes_diff,
      last_seq_scan,
      last_idx_scan,
      n_tup_newpage_upd
    )
    SELECT
      cur.server_id AS server_id,
      cur.sample_id AS sample_id,
      cur.datid AS datid,
      cur.relid AS relid,
      cur.reltoastrelid AS reltoastrelid,
      cur.tablespaceid AS tablespaceid,
      cur.seq_scan - COALESCE(lst.seq_scan,0) AS seq_scan,
      cur.seq_tup_read - COALESCE(lst.seq_tup_read,0) AS seq_tup_read,
      cur.idx_scan - COALESCE(lst.idx_scan,0) AS idx_scan,
      cur.idx_tup_fetch - COALESCE(lst.idx_tup_fetch,0) AS idx_tup_fetch,
      cur.n_tup_ins - COALESCE(lst.n_tup_ins,0) AS n_tup_ins,
      cur.n_tup_upd - COALESCE(lst.n_tup_upd,0) AS n_tup_upd,
      cur.n_tup_del - COALESCE(lst.n_tup_del,0) AS n_tup_del,
      cur.n_tup_hot_upd - COALESCE(lst.n_tup_hot_upd,0) AS n_tup_hot_upd,
      cur.n_live_tup AS n_live_tup,
      cur.n_dead_tup AS n_dead_tup,
      cur.n_mod_since_analyze AS n_mod_since_analyze,
      cur.n_ins_since_vacuum AS n_ins_since_vacuum,
      cur.last_vacuum AS last_vacuum,
      cur.last_autovacuum AS last_autovacuum,
      cur.last_analyze AS last_analyze,
      cur.last_autoanalyze AS last_autoanalyze,
      cur.vacuum_count - COALESCE(lst.vacuum_count,0) AS vacuum_count,
      cur.autovacuum_count - COALESCE(lst.autovacuum_count,0) AS autovacuum_count,
      cur.analyze_count - COALESCE(lst.analyze_count,0) AS analyze_count,
      cur.autoanalyze_count - COALESCE(lst.autoanalyze_count,0) AS autoanalyze_count,
      cur.total_vacuum_time - COALESCE(lst.total_vacuum_time,0) AS total_vacuum_time,
      cur.total_autovacuum_time - COALESCE(lst.total_autovacuum_time,0) AS total_autovacuum_time,
      cur.total_analyze_time - COALESCE(lst.total_analyze_time,0) AS total_analyze_time,
      cur.total_autoanalyze_time - COALESCE(lst.total_autoanalyze_time,0) AS total_autoanalyze_time,
      cur.heap_blks_read - COALESCE(lst.heap_blks_read,0) AS heap_blks_read,
      cur.heap_blks_hit - COALESCE(lst.heap_blks_hit,0) AS heap_blks_hit,
      cur.idx_blks_read - COALESCE(lst.idx_blks_read,0) AS idx_blks_read,
      cur.idx_blks_hit - COALESCE(lst.idx_blks_hit,0) AS idx_blks_hit,
      cur.toast_blks_read - COALESCE(lst.toast_blks_read,0) AS toast_blks_read,
      cur.toast_blks_hit - COALESCE(lst.toast_blks_hit,0) AS toast_blks_hit,
      cur.tidx_blks_read - COALESCE(lst.tidx_blks_read,0) AS tidx_blks_read,
      cur.tidx_blks_hit - COALESCE(lst.tidx_blks_hit,0) AS tidx_blks_hit,
      cur.relsize AS relsize,
      cur.relsize - COALESCE(lst.relsize,0) AS relsize_diff,
      cur.relpages_bytes AS relpages_bytes,
      cur.relpages_bytes - COALESCE(lst.relpages_bytes,0) AS relpages_bytes_diff,
      cur.last_seq_scan AS last_seq_scan,
      cur.last_idx_scan AS last_idx_scan,
      cur.n_tup_newpage_upd - COALESCE(lst.n_tup_newpage_upd,0) AS n_tup_newpage_upd
    FROM
      last_stat_tables cur JOIN last_stat_database dbcur USING (server_id, sample_id, datid)
      LEFT JOIN last_stat_database dblst ON
        (dblst.server_id, dblst.sample_id, dblst.datid) =
        (sserver_id, s_id - 1, dbcur.datid)
        AND dblst.stats_reset IS NOT DISTINCT FROM dbcur.stats_reset
      LEFT OUTER JOIN last_stat_tables lst ON
        (lst.server_id, lst.sample_id, lst.datid, lst.relid) =
        (sserver_id, s_id - 1, dblst.datid, cur.relid)
    WHERE
      (cur.server_id, cur.sample_id, cur.in_sample) = (sserver_id, s_id, true)
    ORDER BY cur.reltoastrelid NULLS FIRST;

    -- Update incorrectly calculated relation growth in case of database stats reset
    UPDATE sample_stat_tables usst
    SET
      relsize_diff = cur.relsize - COALESCE(lst.relsize,0),
      relpages_bytes_diff = cur.relpages_bytes - COALESCE(lst.relpages_bytes,0)
    FROM
      last_stat_tables cur JOIN last_stat_database dbcur USING (server_id, sample_id, datid)
      JOIN last_stat_database dblst ON
        (dblst.server_id, dblst.sample_id, dblst.datid) =
        (sserver_id, s_id - 1, dbcur.datid)
      LEFT OUTER JOIN last_stat_tables lst ON
        (lst.server_id, lst.sample_id, lst.datid, lst.relid) =
        (sserver_id, s_id - 1, dblst.datid, cur.relid)
    WHERE
      (cur.server_id, cur.sample_id, cur.in_sample) = (sserver_id, s_id, true)
      AND dblst.stats_reset IS DISTINCT FROM dbcur.stats_reset
      AND (usst.server_id, usst.sample_id, usst.datid, usst.relid) =
        (sserver_id, s_id, cur.datid, cur.relid);

    -- Total table stats
    INSERT INTO sample_stat_tables_total(
      server_id,
      sample_id,
      datid,
      tablespaceid,
      relkind,
      seq_scan,
      seq_tup_read,
      idx_scan,
      idx_tup_fetch,
      n_tup_ins,
      n_tup_upd,
      n_tup_del,
      n_tup_hot_upd,
      vacuum_count,
      autovacuum_count,
      analyze_count,
      autoanalyze_count,
      total_vacuum_time,
      total_autovacuum_time,
      total_analyze_time,
      total_autoanalyze_time,
      heap_blks_read,
      heap_blks_hit,
      idx_blks_read,
      idx_blks_hit,
      toast_blks_read,
      toast_blks_hit,
      tidx_blks_read,
      tidx_blks_hit,
      relsize_diff,
      n_tup_newpage_upd
    )
    SELECT
      cur.server_id,
      cur.sample_id,
      cur.datid,
      cur.tablespaceid,
      cur.relkind,
      sum(cur.seq_scan - COALESCE(lst.seq_scan,0)),
      sum(cur.seq_tup_read - COALESCE(lst.seq_tup_read,0)),
      sum(cur.idx_scan - COALESCE(lst.idx_scan,0)),
      sum(cur.idx_tup_fetch - COALESCE(lst.idx_tup_fetch,0)),
      sum(cur.n_tup_ins - COALESCE(lst.n_tup_ins,0)),
      sum(cur.n_tup_upd - COALESCE(lst.n_tup_upd,0)),
      sum(cur.n_tup_del - COALESCE(lst.n_tup_del,0)),
      sum(cur.n_tup_hot_upd - COALESCE(lst.n_tup_hot_upd,0)),
      sum(cur.vacuum_count - COALESCE(lst.vacuum_count,0)),
      sum(cur.autovacuum_count - COALESCE(lst.autovacuum_count,0)),
      sum(cur.analyze_count - COALESCE(lst.analyze_count,0)),
      sum(cur.autoanalyze_count - COALESCE(lst.autoanalyze_count,0)),
      sum(cur.total_vacuum_time - COALESCE(lst.total_vacuum_time,0)),
      sum(cur.total_autovacuum_time - COALESCE(lst.total_autovacuum_time,0)),
      sum(cur.total_analyze_time - COALESCE(lst.total_analyze_time,0)),
      sum(cur.total_autoanalyze_time - COALESCE(lst.total_autoanalyze_time,0)),
      sum(cur.heap_blks_read - COALESCE(lst.heap_blks_read,0)),
      sum(cur.heap_blks_hit - COALESCE(lst.heap_blks_hit,0)),
      sum(cur.idx_blks_read - COALESCE(lst.idx_blks_read,0)),
      sum(cur.idx_blks_hit - COALESCE(lst.idx_blks_hit,0)),
      sum(cur.toast_blks_read - COALESCE(lst.toast_blks_read,0)),
      sum(cur.toast_blks_hit - COALESCE(lst.toast_blks_hit,0)),
      sum(cur.tidx_blks_read - COALESCE(lst.tidx_blks_read,0)),
      sum(cur.tidx_blks_hit - COALESCE(lst.tidx_blks_hit,0)),
      CASE
        WHEN skip_sizes THEN NULL
        ELSE sum(cur.relsize - COALESCE(lst.relsize,0))
      END,
      sum(cur.n_tup_newpage_upd - COALESCE(lst.n_tup_newpage_upd,0))
    FROM last_stat_tables cur JOIN last_stat_database dbcur USING (server_id, sample_id, datid)
      LEFT OUTER JOIN last_stat_database dblst ON
        (dblst.server_id, dblst.datid, dblst.sample_id) =
        (sserver_id, dbcur.datid, s_id - 1)
        AND dblst.stats_reset IS NOT DISTINCT FROM dbcur.stats_reset
      LEFT OUTER JOIN last_stat_tables lst ON
        (lst.server_id, lst.sample_id, lst.datid, lst.relid) =
        (sserver_id, s_id - 1, dblst.datid, cur.relid)
    WHERE (cur.server_id, cur.sample_id) = (sserver_id, s_id)
    GROUP BY cur.server_id, cur.sample_id, cur.datid, cur.relkind, cur.tablespaceid;

    IF NOT skip_sizes THEN
    /* Update incorrectly calculated aggregated tables growth in case of
     * database statistics reset
     */
      UPDATE sample_stat_tables_total usstt
      SET relsize_diff = calc.relsize_diff
      FROM (
          SELECT
            cur.server_id,
            cur.sample_id,
            cur.datid,
            cur.relkind,
            cur.tablespaceid,
            sum(cur.relsize - COALESCE(lst.relsize,0)) AS relsize_diff
          FROM last_stat_tables cur JOIN last_stat_database dbcur USING (server_id, sample_id, datid)
            JOIN last_stat_database dblst ON
              (dblst.server_id, dblst.sample_id, dblst.datid) =
              (sserver_id, s_id - 1, dbcur.datid)
            LEFT OUTER JOIN last_stat_tables lst ON
              (lst.server_id, lst.sample_id, lst.datid, lst.relid) =
              (sserver_id, s_id - 1, dblst.datid, cur.relid)
          WHERE (cur.server_id, cur.sample_id) = (sserver_id, s_id)
            AND dblst.stats_reset IS DISTINCT FROM dbcur.stats_reset
          GROUP BY cur.server_id, cur.sample_id, cur.datid, cur.relkind, cur.tablespaceid
        ) calc
      WHERE (usstt.server_id, usstt.sample_id, usstt.datid, usstt.relkind, usstt.tablespaceid) =
        (sserver_id, s_id, calc.datid, calc.relkind, calc.tablespaceid);
    END IF;

    /*
    Preserve previous relation sizes in if we couldn't collect
    size this time (for example, due to locked relation)*/
    UPDATE last_stat_tables cur
    SET relsize = lst.relsize
    FROM last_stat_tables lst
    WHERE
      (cur.server_id, cur.sample_id) = (sserver_id, s_id)
      AND (lst.server_id, lst.sample_id, lst.datid, lst.relid) =
      (cur.server_id, s_id - 1, cur.datid, cur.relid)
      AND cur.relsize IS NULL;

    result := log_sample_timings(result, 'calculate tables stats', 'end');
    result := log_sample_timings(result, 'calculate indexes stats', 'start');

    -- New index names
    INSERT INTO indexes_list AS iil (
      server_id,
      last_sample_id,
      datid,
      indexrelid,
      relid,
      schemaname,
      indexrelname
    )
    SELECT
      cur.server_id,
      NULL,
      cur.datid,
      cur.indexrelid,
      cur.relid,
      cur.schemaname,
      cur.indexrelname
    FROM
      last_stat_indexes cur
    WHERE
      (cur.server_id, cur.sample_id, cur.in_sample) =
      (sserver_id, s_id, true)
    ON CONFLICT ON CONSTRAINT pk_indexes_list DO
      UPDATE SET
        (last_sample_id, relid, schemaname, indexrelname) =
        (EXCLUDED.last_sample_id, EXCLUDED.relid, EXCLUDED.schemaname, EXCLUDED.indexrelname)
      WHERE
        (iil.last_sample_id, iil.relid, iil.schemaname, iil.indexrelname) IS DISTINCT FROM
        (EXCLUDED.last_sample_id, EXCLUDED.relid, EXCLUDED.schemaname, EXCLUDED.indexrelname);

    -- Index stats
    INSERT INTO sample_stat_indexes (
      server_id,
      sample_id,
      datid,
      indexrelid,
      tablespaceid,
      idx_scan,
      idx_tup_read,
      idx_tup_fetch,
      idx_blks_read,
      idx_blks_hit,
      relsize,
      relsize_diff,
      indisunique,
      relpages_bytes,
      relpages_bytes_diff,
      last_idx_scan
    )
    SELECT
      cur.server_id AS server_id,
      cur.sample_id AS sample_id,
      cur.datid AS datid,
      cur.indexrelid AS indexrelid,
      cur.tablespaceid AS tablespaceid,
      cur.idx_scan - COALESCE(lst.idx_scan,0) AS idx_scan,
      cur.idx_tup_read - COALESCE(lst.idx_tup_read,0) AS idx_tup_read,
      cur.idx_tup_fetch - COALESCE(lst.idx_tup_fetch,0) AS idx_tup_fetch,
      cur.idx_blks_read - COALESCE(lst.idx_blks_read,0) AS idx_blks_read,
      cur.idx_blks_hit - COALESCE(lst.idx_blks_hit,0) AS idx_blks_hit,
      cur.relsize,
      cur.relsize - COALESCE(lst.relsize,0) AS relsize_diff,
      cur.indisunique,
      cur.relpages_bytes AS relpages_bytes,
      cur.relpages_bytes - COALESCE(lst.relpages_bytes,0) AS relpages_bytes_diff,
      cur.last_idx_scan
    FROM
      last_stat_indexes cur JOIN last_stat_database dbcur USING (server_id, sample_id, datid)
      LEFT JOIN last_stat_database dblst ON
        (dblst.server_id, dblst.sample_id, dblst.datid) =
        (sserver_id, s_id - 1, dbcur.datid)
        AND dblst.stats_reset IS NOT DISTINCT FROM dbcur.stats_reset
      LEFT OUTER JOIN last_stat_indexes lst ON
        (lst.server_id, lst.sample_id, lst.datid, lst.indexrelid) =
        (sserver_id, s_id - 1, dblst.datid, cur.indexrelid)
    WHERE
      (cur.server_id, cur.sample_id, cur.in_sample) = (sserver_id, s_id, true);

    -- Update incorrectly calculated relation growth in case of database stats reset
    UPDATE sample_stat_indexes ussi
    SET
      relsize_diff = cur.relsize - COALESCE(lst.relsize,0),
      relpages_bytes_diff = cur.relpages_bytes - COALESCE(lst.relpages_bytes,0)
    FROM
      last_stat_indexes cur JOIN last_stat_database dbcur USING (server_id, sample_id, datid)
      JOIN last_stat_database dblst ON
        (dblst.server_id, dblst.sample_id, dblst.datid) =
        (sserver_id, s_id - 1, dbcur.datid)
      LEFT OUTER JOIN last_stat_indexes lst ON
        (lst.server_id, lst.sample_id, lst.datid, lst.indexrelid) =
        (sserver_id, s_id - 1, dblst.datid, cur.indexrelid)
    WHERE
      (cur.server_id, cur.sample_id, cur.in_sample) = (sserver_id, s_id, true)
      AND dblst.stats_reset IS DISTINCT FROM dbcur.stats_reset
      AND (ussi.server_id, ussi.sample_id, ussi.datid, ussi.indexrelid) =
        (sserver_id, s_id, cur.datid, cur.indexrelid);

    -- Total indexes stats
    INSERT INTO sample_stat_indexes_total(
      server_id,
      sample_id,
      datid,
      tablespaceid,
      idx_scan,
      idx_tup_read,
      idx_tup_fetch,
      idx_blks_read,
      idx_blks_hit,
      relsize_diff
    )
    SELECT
      cur.server_id,
      cur.sample_id,
      cur.datid,
      cur.tablespaceid,
      sum(cur.idx_scan - COALESCE(lst.idx_scan,0)),
      sum(cur.idx_tup_read - COALESCE(lst.idx_tup_read,0)),
      sum(cur.idx_tup_fetch - COALESCE(lst.idx_tup_fetch,0)),
      sum(cur.idx_blks_read - COALESCE(lst.idx_blks_read,0)),
      sum(cur.idx_blks_hit - COALESCE(lst.idx_blks_hit,0)),
      CASE
        WHEN skip_sizes THEN NULL
        ELSE sum(cur.relsize - COALESCE(lst.relsize,0))
      END
    FROM last_stat_indexes cur JOIN last_stat_database dbcur USING (server_id, sample_id, datid)
      LEFT OUTER JOIN last_stat_database dblst ON
        (dblst.server_id, dblst.sample_id, dblst.datid) =
        (sserver_id, s_id - 1, dbcur.datid)
        AND dblst.stats_reset IS NOT DISTINCT FROM dbcur.stats_reset
      LEFT OUTER JOIN last_stat_indexes lst ON
        (lst.server_id, lst.sample_id, lst.datid, lst.relid, lst.indexrelid) =
        (sserver_id, s_id - 1, dblst.datid, cur.relid, cur.indexrelid)
    WHERE
      (cur.server_id, cur.sample_id) = (sserver_id, s_id)
    GROUP BY cur.server_id, cur.sample_id, cur.datid, cur.tablespaceid;

    /* Update incorrectly calculated aggregated index growth in case of
     * database statistics reset
     */
    IF NOT skip_sizes THEN
      UPDATE sample_stat_indexes_total ussit
      SET relsize_diff = calc.relsize_diff
      FROM (
          SELECT
            cur.server_id,
            cur.sample_id,
            cur.datid,
            cur.tablespaceid,
            sum(cur.relsize - COALESCE(lst.relsize,0)) AS relsize_diff
          FROM last_stat_indexes cur JOIN last_stat_database dbcur USING (server_id, sample_id, datid)
            JOIN last_stat_database dblst ON
              (dblst.server_id, dblst.sample_id, dblst.datid) =
              (sserver_id, s_id - 1, dbcur.datid)
            LEFT OUTER JOIN last_stat_indexes lst ON
              (lst.server_id, lst.sample_id, lst.datid, lst.indexrelid) =
              (sserver_id, s_id - 1, dblst.datid, cur.indexrelid)
          WHERE (cur.server_id, cur.sample_id) = (sserver_id, s_id)
            AND dblst.stats_reset IS DISTINCT FROM dbcur.stats_reset
          GROUP BY cur.server_id, cur.sample_id, cur.datid, cur.tablespaceid
        ) calc
      WHERE (ussit.server_id, ussit.sample_id, ussit.datid, ussit.tablespaceid) =
        (sserver_id, s_id, calc.datid, calc.tablespaceid);
    END IF;
    /*
    Preserve previous relation sizes in if we couldn't collect
    size this time (for example, due to locked relation)*/
    UPDATE last_stat_indexes cur
    SET relsize = lst.relsize
    FROM last_stat_indexes lst
    WHERE
      (cur.server_id, cur.sample_id) = (sserver_id, s_id)
      AND (lst.server_id, lst.sample_id, lst.datid, lst.indexrelid) =
      (sserver_id, s_id - 1, cur.datid, cur.indexrelid)
      AND cur.relsize IS NULL;

    result := log_sample_timings(result, 'calculate indexes stats', 'end');
    result := log_sample_timings(result, 'calculate functions stats', 'start');

    -- New function names
    INSERT INTO funcs_list AS ifl (
      server_id,
      last_sample_id,
      datid,
      funcid,
      schemaname,
      funcname,
      funcargs
    )
    SELECT
      cur.server_id,
      NULL,
      cur.datid,
      cur.funcid,
      cur.schemaname,
      cur.funcname,
      cur.funcargs
    FROM
      last_stat_user_functions cur
    WHERE
      (cur.server_id, cur.sample_id, cur.in_sample) =
      (sserver_id, s_id, true)
    ON CONFLICT ON CONSTRAINT pk_funcs_list DO
      UPDATE SET
        (last_sample_id, funcid, schemaname, funcname, funcargs) =
        (EXCLUDED.last_sample_id, EXCLUDED.funcid, EXCLUDED.schemaname,
          EXCLUDED.funcname, EXCLUDED.funcargs)
      WHERE
        (ifl.last_sample_id, ifl.funcid, ifl.schemaname,
          ifl.funcname, ifl.funcargs) IS DISTINCT FROM
        (EXCLUDED.last_sample_id, EXCLUDED.funcid, EXCLUDED.schemaname,
          EXCLUDED.funcname, EXCLUDED.funcargs);

    -- Function stats
    INSERT INTO sample_stat_user_functions (
      server_id,
      sample_id,
      datid,
      funcid,
      calls,
      total_time,
      self_time,
      trg_fn
    )
    SELECT
      cur.server_id AS server_id,
      cur.sample_id AS sample_id,
      cur.datid AS datid,
      cur.funcid,
      cur.calls - COALESCE(lst.calls,0) AS calls,
      cur.total_time - COALESCE(lst.total_time,0) AS total_time,
      cur.self_time - COALESCE(lst.self_time,0) AS self_time,
      cur.trg_fn
    FROM last_stat_user_functions cur JOIN last_stat_database dbcur USING (server_id, sample_id, datid)
      LEFT OUTER JOIN last_stat_database dblst ON
        (dblst.server_id, dblst.sample_id, dblst.datid) =
        (sserver_id, s_id - 1, dbcur.datid)
        AND dblst.stats_reset IS NOT DISTINCT FROM dbcur.stats_reset
      LEFT OUTER JOIN last_stat_user_functions lst ON
        (lst.server_id, lst.sample_id, lst.datid, lst.funcid) =
        (sserver_id, s_id - 1, dblst.datid, cur.funcid)
    WHERE
      (cur.server_id, cur.sample_id, cur.in_sample) = (sserver_id, s_id, true);

    -- Total functions stats
    INSERT INTO sample_stat_user_func_total(
      server_id,
      sample_id,
      datid,
      calls,
      total_time,
      trg_fn
    )
    SELECT
      cur.server_id,
      cur.sample_id,
      cur.datid,
      sum(cur.calls - COALESCE(lst.calls,0)),
      sum(cur.total_time - COALESCE(lst.total_time,0)),
      cur.trg_fn
    FROM last_stat_user_functions cur JOIN last_stat_database dbcur USING (server_id, sample_id, datid)
      LEFT OUTER JOIN last_stat_database dblst ON
        (dblst.server_id, dblst.sample_id, dblst.datid) =
        (sserver_id, s_id - 1, dbcur.datid)
        AND dblst.stats_reset IS NOT DISTINCT FROM dbcur.stats_reset
      LEFT OUTER JOIN last_stat_user_functions lst ON
        (lst.server_id, lst.sample_id, lst.datid, lst.funcid) =
        (sserver_id, s_id - 1, dblst.datid, cur.funcid)
    WHERE
      (cur.server_id, cur.sample_id) = (sserver_id, s_id)
    GROUP BY cur.server_id, cur.sample_id, cur.datid, cur.trg_fn;

    result := log_sample_timings(result, 'calculate functions stats', 'end');
    result := log_sample_timings(result, 'merge new extensions version', 'start');

    UPDATE extension_versions ev
    SET last_sample_id = s_id - 1
    FROM last_extension_versions prev_lev
      LEFT JOIN last_extension_versions cur_lev ON
        (cur_lev.server_id, cur_lev.datid, cur_lev.sample_id, cur_lev.extname, cur_lev.extversion) =
        (sserver_id, prev_lev.datid, s_id, prev_lev.extname, prev_lev.extversion)
    WHERE
      (prev_lev.server_id, prev_lev.sample_id) = (sserver_id, s_id - 1) AND
      (ev.server_id, ev.datid, ev.extname, ev.extversion) =
      (sserver_id, prev_lev.datid, prev_lev.extname, prev_lev.extversion) AND
      ev.last_sample_id IS NULL AND
      cur_lev.extname IS NULL;

    INSERT INTO extension_versions (
      server_id,
      datid,
      first_seen,
      extname,
      extversion
    )
    SELECT
      cur_lev.server_id,
      cur_lev.datid,
      s.sample_time as first_seen,
      cur_lev.extname,
      cur_lev.extversion
    FROM last_extension_versions cur_lev
      JOIN samples s on (s.server_id, s.sample_id) = (sserver_id, s_id)
      LEFT JOIN last_extension_versions prev_lev ON
        (prev_lev.server_id, prev_lev.datid, prev_lev.sample_id, prev_lev.extname, prev_lev.extversion) =
        (sserver_id, cur_lev.datid, s_id - 1, cur_lev.extname, cur_lev.extversion)
    WHERE
      (cur_lev.server_id, cur_lev.sample_id) = (sserver_id, s_id) AND
      prev_lev.extname IS NULL;

    result := log_sample_timings(result, 'merge new extensions version', 'end');
    result := log_sample_timings(result, 'merge new relation storage parameters', 'start');

    UPDATE table_storage_parameters tsp
    SET last_sample_id = s_id - 1
    FROM last_stat_tables prev_lst
      LEFT JOIN last_stat_tables cur_lst ON
        (cur_lst.server_id, cur_lst.datid, cur_lst.relid, cur_lst.sample_id, cur_lst.reloptions) =
        (sserver_id, prev_lst.datid, prev_lst.relid, s_id, prev_lst.reloptions)
    WHERE
      (prev_lst.server_id, prev_lst.sample_id) = (sserver_id, s_id - 1) AND
      prev_lst.reloptions IS NOT NULL AND
      (tsp.server_id, tsp.datid, tsp.relid, tsp.reloptions) =
      (sserver_id, prev_lst.datid, prev_lst.relid, prev_lst.reloptions) AND
      tsp.last_sample_id IS NULL AND
      cur_lst IS NULL;

    INSERT INTO table_storage_parameters (
      server_id,
      datid,
      relid,
      first_seen,
      reloptions
    )
    SELECT
      cur_lst.server_id,
      cur_lst.datid,
      cur_lst.relid,
      s.sample_time as first_seen,
      cur_lst.reloptions
    FROM last_stat_tables cur_lst
      JOIN samples s on (s.server_id, s.sample_id) = (sserver_id, s_id)
      LEFT JOIN last_stat_tables prev_lst ON
        (prev_lst.server_id, prev_lst.datid, prev_lst.relid, prev_lst.sample_id, prev_lst.in_sample, prev_lst.reloptions) =
        (sserver_id, cur_lst.datid, cur_lst.relid, s_id - 1, true, cur_lst.reloptions)
      LEFT JOIN table_storage_parameters tsp ON
        (tsp.server_id, tsp.datid, tsp.relid, tsp.reloptions) =
        (sserver_id, cur_lst.datid, cur_lst.relid, cur_lst.reloptions)
    WHERE
      (cur_lst.server_id, cur_lst.sample_id, cur_lst.in_sample) = (sserver_id, s_id, true) AND
      cur_lst.reloptions IS NOT NULL AND
      prev_lst IS NULL AND
      tsp IS NULL;

    UPDATE index_storage_parameters tsp
    SET last_sample_id = s_id - 1
      FROM last_stat_indexes prev_lsi
      LEFT JOIN last_stat_indexes cur_lsi ON
        (cur_lsi.server_id, cur_lsi.datid, cur_lsi.relid, cur_lsi.indexrelid, cur_lsi.sample_id, cur_lsi.reloptions) =
        (sserver_id, prev_lsi.datid, prev_lsi.relid, prev_lsi.indexrelid, s_id, prev_lsi.reloptions)
    WHERE (prev_lsi.server_id, prev_lsi.sample_id) = (sserver_id, s_id - 1)AND
      prev_lsi.reloptions IS NOT NULL AND
      (tsp.server_id, tsp.datid, tsp.relid, tsp.indexrelid, tsp.reloptions) =
      (sserver_id, prev_lsi.datid, prev_lsi.relid, prev_lsi.indexrelid, prev_lsi.reloptions) AND
      tsp.last_sample_id IS NULL AND
      cur_lsi IS NULL;

    INSERT INTO index_storage_parameters (
      server_id,
      datid,
      relid,
      indexrelid,
      first_seen,
      reloptions
    )
    SELECT
      cur_lsi.server_id,
      cur_lsi.datid,
      cur_lsi.relid,
      cur_lsi.indexrelid,
      s.sample_time as first_seen,
      cur_lsi.reloptions
    FROM last_stat_indexes cur_lsi
      JOIN samples s on (s.server_id, s.sample_id) = (sserver_id, s_id)
      LEFT JOIN last_stat_indexes prev_lsi ON
        (prev_lsi.server_id, prev_lsi.datid, prev_lsi.relid, prev_lsi.indexrelid, prev_lsi.sample_id, prev_lsi.in_sample, prev_lsi.reloptions) =
        (sserver_id, cur_lsi.datid, cur_lsi.relid, cur_lsi.indexrelid, s_id - 1, true, cur_lsi.reloptions)
      LEFT JOIN index_storage_parameters isp ON
        (isp.server_id, isp.datid, isp.relid, isp.indexrelid, isp.reloptions) =
        (sserver_id, cur_lsi.datid, cur_lsi.relid, cur_lsi.indexrelid, cur_lsi.reloptions)
    WHERE
      (cur_lsi.server_id, cur_lsi.sample_id, cur_lsi.in_sample) = (sserver_id, s_id, true) AND
      cur_lsi.reloptions IS NOT NULL AND
      prev_lsi IS NULL AND
      isp IS NULL;

    result := log_sample_timings(result, 'merge new relation storage parameters', 'end');
    result := log_sample_timings(result, 'clear last_ tables', 'start');

    -- Clear data in last_ tables, holding data only for next diff sample
    DELETE FROM last_stat_tables WHERE server_id=sserver_id AND sample_id != s_id;

    DELETE FROM last_stat_indexes WHERE server_id=sserver_id AND sample_id != s_id;

    DELETE FROM last_stat_user_functions WHERE server_id=sserver_id AND sample_id != s_id;

    DELETE FROM last_extension_versions WHERE server_id = sserver_id AND sample_id != s_id;

    result := log_sample_timings(result, 'clear last_ tables', 'end');

    RETURN result;
END;
$$ LANGUAGE plpgsql;
CREATE FUNCTION take_sample_subset(IN sets_cnt integer = 1, IN current_set integer = 0) RETURNS TABLE (
    server      name,
    result      text,
    elapsed     interval day to second (2)
)
SET search_path=@extschema@ AS $$
DECLARE
    c_servers CURSOR FOR
      SELECT server_id,server_name FROM (
        SELECT server_id,server_name, row_number() OVER (ORDER BY server_id) AS srv_rn
        FROM servers WHERE enabled
        ) AS t1
      WHERE srv_rn % sets_cnt = current_set;
    server_sampleres    integer;
    etext               text := '';
    edetail             text := '';
    econtext            text := '';

    qres          RECORD;
    conname       text;
    start_clock   timestamp (2) with time zone;
BEGIN
    IF sets_cnt IS NULL OR sets_cnt < 1 THEN
      RAISE 'sets_cnt value is invalid. Must be positive';
    END IF;
    IF current_set IS NULL OR current_set < 0 OR current_set > sets_cnt - 1 THEN
      RAISE 'current_cnt value is invalid. Must be between 0 and sets_cnt - 1';
    END IF;
    /*
    * We should include dblink schema to perform disconnections
    * on exception conditions
    */
    SELECT extnamespace::regnamespace AS dblink_schema INTO STRICT qres FROM pg_catalog.pg_extension WHERE extname = 'dblink';
    IF NOT string_to_array(current_setting('search_path'),', ') @> ARRAY[qres.dblink_schema::text] THEN
      EXECUTE 'SET LOCAL search_path TO ' || current_setting('search_path')||','|| qres.dblink_schema;
    END IF;

    FOR qres IN c_servers LOOP
        BEGIN
            start_clock := clock_timestamp()::timestamp (2) with time zone;
            server := qres.server_name;
            server_sampleres := take_sample(qres.server_id, NULL);
            elapsed := clock_timestamp()::timestamp (2) with time zone - start_clock;
            CASE server_sampleres
              WHEN 0 THEN
                result := 'OK';
              ELSE
                result := 'FAIL';
            END CASE;
            RETURN NEXT;
        EXCEPTION
            WHEN OTHERS THEN
                BEGIN
                    GET STACKED DIAGNOSTICS etext = MESSAGE_TEXT,
                        edetail = PG_EXCEPTION_DETAIL,
                        econtext = PG_EXCEPTION_CONTEXT;
                    result := format (E'%s\n%s\n%s', etext, econtext, edetail);
                    elapsed := clock_timestamp()::timestamp (2) with time zone - start_clock;
                    RETURN NEXT;
                    /*
                      Cleanup dblink connections
                    */
                    FOREACH conname IN ARRAY
                        coalesce(dblink_get_connections(), array[]::text[])
                    LOOP
                        IF conname IN ('server_connection', 'server_db_connection') THEN
                            PERFORM dblink_disconnect(conname);
                        END IF;
                    END LOOP;
                END;
        END;
    END LOOP;
    RETURN;
END;
$$ LANGUAGE plpgsql;
COMMENT ON FUNCTION take_sample_subset(IN sets_cnt integer, IN current_set integer) IS
  'Statistics sample creation function (for subset of enabled servers). Used for simplification of parallel sample collection.';
CREATE FUNCTION take_sample(IN sserver_id integer, IN skip_sizes boolean
) RETURNS integer SET search_path=@extschema@ AS $$
DECLARE
    s_id              integer;
    topn              integer;
    server_properties jsonb;
    qres              record;
    qres_settings     record;
    settings_refresh  boolean = true;

    server_query      text;
BEGIN
    -- Adding dblink extension schema to search_path if it does not already there
    IF (SELECT count(*) = 0 FROM pg_catalog.pg_extension WHERE extname = 'dblink') THEN
      RAISE 'dblink extension must be installed';
    END IF;

    SELECT extnamespace::regnamespace AS dblink_schema INTO STRICT qres FROM pg_catalog.pg_extension WHERE extname = 'dblink';
    IF NOT string_to_array(current_setting('search_path'),', ') @> ARRAY[qres.dblink_schema::text] THEN
      EXECUTE 'SET LOCAL search_path TO ' || current_setting('search_path')||','|| qres.dblink_schema;
    END IF;

    -- Only one running take_sample() function allowed per server!
    -- Explicitly lock server in servers table
    BEGIN
        SELECT * INTO qres FROM servers WHERE server_id = sserver_id FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN OTHERS THEN RAISE 'Can''t get lock on server. Is there another take_sample() function running on this server?';
    END;

    -- Initialize sample
    server_properties := init_sample(sserver_id);
    ASSERT server_properties IS NOT NULL, 'lost properties';

    -- Merge srv_settings into server_properties structure
    FOR qres_settings IN (
      SELECT key, value
      FROM jsonb_each(qres.srv_settings)
    ) LOOP
      server_properties := jsonb_set(
        server_properties,
        ARRAY[qres_settings.key],
        qres_settings.value
      );
    END LOOP; -- over srv_settings enties
    ASSERT server_properties IS NOT NULL, 'lost properties on srv_settings merge';

    /* Set the in_sample flag notifying sampling functions that the current
      processing caused by take_sample(), not by take_subsample()
    */
    server_properties := jsonb_set(server_properties, '{properties,in_sample}', to_jsonb(true));

    topn := (server_properties #>> '{properties,topn}')::integer;

    -- Creating a new sample record
    UPDATE servers SET last_sample_id = last_sample_id + 1 WHERE server_id = sserver_id
      RETURNING last_sample_id INTO s_id;
    INSERT INTO samples(sample_time,server_id,sample_id)
      VALUES (now(),sserver_id,s_id);

    -- Once the new sample is created it becomes last one
    server_properties := jsonb_set(
      server_properties,
      '{properties,last_sample_id}',
      to_jsonb(s_id)
    );

    -- Applying skip sizes policy
    IF skip_sizes IS NULL THEN
      CASE COALESCE(
        qres.srv_settings #>> '{relsizes,collect_mode}',
        nullif(current_setting('pg_profile.relsize_collect_mode', true)::text,''),
        'off'
      )
        WHEN 'on' THEN
          skip_sizes := false;
        WHEN 'off' THEN
          skip_sizes := true;
        WHEN 'schedule' THEN
          /*
          Skip sizes collection if there was a sample with sizes recently
          or if we are not in size collection time window
          */
          SELECT
            count(*) > 0 OR
            NOT
            CASE WHEN timezone('UTC',current_time) > timezone('UTC',(qres.srv_settings #>> '{relsizes,window_start}')::timetz) THEN
              timezone('UTC',now()) <=
              timezone('UTC',(timezone('UTC',now())::pg_catalog.date +
              timezone('UTC',(qres.srv_settings #>> '{relsizes,window_start}')::timetz) +
              (qres.srv_settings #>> '{relsizes,window_duration}')::interval))
            ELSE
              timezone('UTC',now()) <=
              timezone('UTC',(timezone('UTC',now() - interval '1 day')::pg_catalog.date +
              timezone('UTC',(qres.srv_settings #>> '{relsizes,window_start}')::timetz) +
              (qres.srv_settings #>> '{relsizes,window_duration}')::interval))
            END
              INTO STRICT skip_sizes
          FROM
            sample_stat_tables_total st
            JOIN samples s USING (server_id, sample_id)
          WHERE
            server_id = sserver_id
            AND st.relsize_diff IS NOT NULL
            AND sample_time > now() - (qres.srv_settings #>> '{relsizes,sample_interval}')::interval;
        ELSE
          skip_sizes := true;
      END CASE;
    END IF;

    -- Collecting postgres parameters
    /* We might refresh all parameters if version() was changed
    * This is needed for deleting obsolete parameters, not appearing in new
    * Postgres version.
    */
    SELECT ss.setting != dblver.version INTO settings_refresh
    FROM v_sample_settings ss, dblink('server_connection','SELECT version() as version') AS dblver (version text)
    WHERE ss.server_id = sserver_id AND ss.sample_id = s_id AND ss.name='version' AND ss.setting_scope = 2;
    settings_refresh := COALESCE(settings_refresh,true);

    -- Constructing server sql query for settings
    server_query := 'SELECT 1 as setting_scope,name,setting,reset_val,boot_val,unit,sourcefile,sourceline,pending_restart '
      'FROM pg_catalog.pg_settings '
      'UNION ALL SELECT 2 as setting_scope,''version'',version(),version(),NULL,NULL,NULL,NULL,False '
      'UNION ALL SELECT 2 as setting_scope,''pg_postmaster_start_time'','
      'pg_catalog.pg_postmaster_start_time()::text,'
      'pg_catalog.pg_postmaster_start_time()::text,NULL,NULL,NULL,NULL,False '
      'UNION ALL SELECT 2 as setting_scope,''pg_conf_load_time'','
      'pg_catalog.pg_conf_load_time()::text,pg_catalog.pg_conf_load_time()::text,NULL,NULL,NULL,NULL,False '
      'UNION ALL SELECT 2 as setting_scope,''system_identifier'','
      'system_identifier::text,system_identifier::text,system_identifier::text,'
      'NULL,NULL,NULL,False FROM pg_catalog.pg_control_system()';

    INSERT INTO sample_settings(
      server_id,
      first_seen,
      setting_scope,
      name,
      setting,
      reset_val,
      boot_val,
      unit,
      sourcefile,
      sourceline,
      pending_restart
    )
    SELECT
      s.server_id as server_id,
      s.sample_time as first_seen,
      cur.setting_scope,
      cur.name,
      cur.setting,
      cur.reset_val,
      cur.boot_val,
      cur.unit,
      cur.sourcefile,
      cur.sourceline,
      cur.pending_restart
    FROM
      sample_settings lst JOIN (
        -- Getting last versions of settings
        SELECT server_id, name, max(first_seen) as first_seen
        FROM sample_settings
        WHERE server_id = sserver_id AND (
          NOT settings_refresh
          -- system identifier shouldn't have a duplicate in case of version change
          -- this breaks export/import procedures, as those are related to this ID
          OR name = 'system_identifier'
        )
        GROUP BY server_id, name
      ) lst_times
      USING (server_id, name, first_seen)
      -- Getting current settings values
      RIGHT OUTER JOIN dblink('server_connection',server_query
          ) AS cur (
            setting_scope smallint,
            name text,
            setting text,
            reset_val text,
            boot_val text,
            unit text,
            sourcefile text,
            sourceline integer,
            pending_restart boolean
          )
        USING (setting_scope, name)
      JOIN samples s ON (s.server_id = sserver_id AND s.sample_id = s_id)
    WHERE
      cur.reset_val IS NOT NULL AND (
        lst.name IS NULL
        OR cur.reset_val != lst.reset_val
        OR cur.pending_restart != lst.pending_restart
        OR lst.sourcefile != cur.sourcefile
        OR lst.sourceline != cur.sourceline
        OR lst.unit != cur.unit
      );

    INSERT INTO sample_settings(
      server_id,
      first_seen,
      setting_scope,
      name,
      setting,
      reset_val,
      boot_val,
      unit,
      sourcefile,
      sourceline,
      pending_restart
    )
    SELECT
      s.server_id,
      s.sample_time,
      1 as setting_scope,
      'pg_profile.topn',
      topn,
      topn,
      topn,
      null,
      null,
      null,
      false
    FROM samples s LEFT OUTER JOIN  v_sample_settings prm ON
      (s.server_id = prm.server_id AND s.sample_id = prm.sample_id AND prm.name = 'pg_profile.topn' AND prm.setting_scope = 1)
    WHERE s.server_id = sserver_id AND s.sample_id = s_id AND (prm.setting IS NULL OR prm.setting::integer != topn);
    server_properties := log_sample_timings(server_properties, 'get server environment', 'end');

    server_properties := collect_database_stats(server_properties, sserver_id, s_id);

    server_properties := log_sample_timings(server_properties, 'calculate database stats', 'start');
    perform calculate_database_stats(sserver_id, s_id);
    server_properties := log_sample_timings(server_properties, 'calculate database stats', 'end');

    server_properties := log_sample_timings(server_properties, 'collect tablespace stats', 'start');
    perform collect_tablespace_stats(sserver_id, s_id);
    server_properties := log_sample_timings(server_properties, 'collect tablespace stats', 'end');

    server_properties := log_sample_timings(server_properties, 'collect statement stats', 'start');
    -- Search for statements statistics extension
    CASE
      -- pg_stat_statements statistics collection
      WHEN (
        SELECT count(*) = 1
        FROM jsonb_to_recordset(server_properties #> '{extensions}') AS ext(extname text)
        WHERE extname = 'pg_stat_statements'
      ) AND COALESCE((server_properties #> '{collect,pg_stat_statements}')::boolean, true) THEN
        PERFORM collect_pg_stat_statements_stats(server_properties, sserver_id, s_id, topn);
      ELSE
        NULL;
    END CASE;
    server_properties := log_sample_timings(server_properties, 'collect statement stats', 'end');

    server_properties := log_sample_timings(server_properties, 'collect wait sampling stats', 'start');
    -- Search for wait sampling extension
    CASE
      -- pg_wait_sampling statistics collection
      WHEN (
        SELECT count(*) = 1
        FROM jsonb_to_recordset(server_properties #> '{extensions}') AS ext(extname text)
        WHERE extname = 'pg_wait_sampling'
      ) AND COALESCE((server_properties #> '{collect,pg_wait_sampling}')::boolean, true)THEN
        PERFORM collect_pg_wait_sampling_stats(server_properties, sserver_id, s_id, topn);
      ELSE
        NULL;
    END CASE;
    server_properties := log_sample_timings(server_properties, 'collect wait sampling stats', 'end');

    server_properties := query_pg_stat_bgwriter(server_properties, sserver_id, s_id);
    server_properties := query_pg_stat_wal(server_properties, sserver_id, s_id);
    server_properties := query_pg_stat_io(server_properties, sserver_id, s_id);
    server_properties := query_pg_stat_slru(server_properties, sserver_id, s_id);
    server_properties := query_pg_stat_archiver(server_properties, sserver_id, s_id);

    server_properties := log_sample_timings(server_properties, 'collect object stats', 'start');
    -- Collecting stat info for objects of all databases
    IF COALESCE((server_properties #> '{collect,objects}')::boolean, true) THEN
      server_properties := collect_obj_stats(server_properties, sserver_id, s_id, skip_sizes);
      ASSERT server_properties IS NOT NULL, 'lost properties';
    END IF;
    server_properties := log_sample_timings(server_properties, 'collect object stats', 'end');

    server_properties := log_sample_timings(server_properties, 'processing subsamples', 'start');
    -- Process subsamples if enabled
    IF (server_properties #>> '{properties,subsample_enabled}')::boolean THEN
      /*
       We must get a lock on subsample before taking a subsample to avoid
       sample failure due to lock held in concurrent take_subsample() call.
       take_subsample() function acquires a lock in NOWAIT mode to avoid long
       waits in a subsample. But we should wait here in sample because sample
       must be taken anyway and we need to avoid subsample interfere.
      */
      PERFORM
      FROM server_subsample
      WHERE server_id = sserver_id
      FOR UPDATE;

      server_properties := take_subsample(sserver_id, server_properties);
      server_properties := collect_subsamples(sserver_id, s_id, server_properties);
      ASSERT server_properties IS NOT NULL, 'lost properties';
    END IF;

    IF (SELECT count(*) > 0 FROM last_stat_activity_count WHERE server_id = sserver_id) OR
       (SELECT count(*) > 0 FROM last_stat_activity WHERE server_id = sserver_id)
    THEN
      EXECUTE format('DELETE FROM last_stat_activity_srv%1$s',
        sserver_id);
      EXECUTE format('DELETE FROM last_stat_activity_count_srv%1$s',
        sserver_id);
    END IF;

    server_properties := log_sample_timings(server_properties, 'processing subsamples', 'end');

    server_properties := log_sample_timings(server_properties, 'disconnect', 'start');
    PERFORM dblink('server_connection', 'COMMIT');
    PERFORM dblink_disconnect('server_connection');
    server_properties := log_sample_timings(server_properties, 'disconnect', 'end');

    server_properties := log_sample_timings(server_properties, 'maintain repository', 'start');
    -- Updating dictionary table in case of object renaming:
    -- Databases
    UPDATE sample_stat_database AS db
    SET datname = lst.datname
    FROM last_stat_database AS lst
    WHERE
      (db.server_id, lst.server_id, lst.sample_id, db.datid) =
      (sserver_id, sserver_id, s_id, lst.datid)
      AND db.datname != lst.datname;
    -- Tables
    UPDATE tables_list AS tl
    SET (schemaname, relname) = (lst.schemaname, lst.relname)
    FROM last_stat_tables AS lst
    WHERE (tl.server_id, lst.server_id, lst.sample_id, tl.datid, tl.relid, tl.relkind) =
        (sserver_id, sserver_id, s_id, lst.datid, lst.relid, lst.relkind)
      AND (tl.schemaname, tl.relname) != (lst.schemaname, lst.relname);
    -- Functions
    UPDATE funcs_list AS fl
    SET (schemaname, funcname, funcargs) =
      (lst.schemaname, lst.funcname, lst.funcargs)
    FROM last_stat_user_functions AS lst
    WHERE (fl.server_id, lst.server_id, lst.sample_id, fl.datid, fl.funcid) =
        (sserver_id, sserver_id, s_id, lst.datid, lst.funcid)
      AND (fl.schemaname, fl.funcname, fl.funcargs) !=
        (lst.schemaname, lst.funcname, lst.funcargs);

    server_properties := log_sample_timings(server_properties, 'maintain repository', 'end');

    server_properties := log_sample_timings(server_properties, 'calculate tablespace stats', 'start');
    perform calculate_tablespace_stats(sserver_id, s_id);
    server_properties := log_sample_timings(server_properties, 'calculate tablespace stats', 'end');

    server_properties := log_sample_timings(server_properties, 'calculate object stats', 'start');
    -- collect databases objects stats
    IF COALESCE((server_properties #> '{collect,objects}')::boolean, true) THEN
      server_properties := sample_dbobj_delta(server_properties,sserver_id,s_id,topn,skip_sizes);
      ASSERT server_properties IS NOT NULL, 'lost properties';
    END IF;

    DELETE FROM last_stat_tablespaces WHERE server_id = sserver_id AND sample_id != s_id;

    DELETE FROM last_stat_database WHERE server_id = sserver_id AND sample_id != s_id;

    server_properties := log_sample_timings(server_properties, 'calculate object stats', 'end');

    server_properties := log_sample_timings(server_properties, 'calculate cluster stats', 'start');
    perform calculate_cluster_stats(sserver_id, s_id);
    server_properties := log_sample_timings(server_properties, 'calculate cluster stats', 'end');

    server_properties := log_sample_timings(server_properties, 'calculate IO stats', 'start');
    perform calculate_io_stats(sserver_id, s_id);
    server_properties := log_sample_timings(server_properties, 'calculate IO stats', 'end');

    server_properties := log_sample_timings(server_properties, 'calculate SLRU stats', 'start');
    perform calculate_slru_stats(sserver_id, s_id);
    server_properties := log_sample_timings(server_properties, 'calculate SLRU stats', 'end');

    server_properties := log_sample_timings(server_properties, 'calculate WAL stats', 'start');
    perform calculate_wal_stats(sserver_id, s_id);
    server_properties := log_sample_timings(server_properties, 'calculate WAL stats', 'end');

    server_properties := log_sample_timings(server_properties, 'calculate archiver stats', 'start');
    perform calculate_archiver_stats(sserver_id, s_id);
    server_properties := log_sample_timings(server_properties, 'calculate archiver stats', 'end');

    server_properties := log_sample_timings(server_properties, 'delete obsolete samples', 'start');
    perform delete_obsolete_samples(sserver_id, s_id);
    server_properties := log_sample_timings(server_properties, 'delete obsolete samples', 'end');

    server_properties := log_sample_timings(server_properties, 'total', 'end');
    IF (server_properties #>> '{collect_timings}')::boolean THEN
      -- Save timing statistics of sample
      INSERT INTO sample_timings (server_id, sample_id, "event", exec_point, event_ts)
      SELECT sserver_id, s_id, t.sampling_event, t.exec_point, t.event_tm
      FROM jsonb_to_recordset(server_properties -> 'timings') as t (sampling_event text, exec_point text, event_tm timestamptz);
    END IF;
    ASSERT server_properties IS NOT NULL, 'lost properties';

    -- Reset lock_timeout setting to its initial value
    EXECUTE format('SET lock_timeout TO %L', server_properties #>> '{properties,lock_timeout_init}');

    RETURN 0;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION take_sample(IN sserver_id integer, IN skip_sizes boolean) IS
  'Statistics sample creation function (by server_id)';
CREATE FUNCTION take_sample(IN server name, IN skip_sizes boolean = NULL)
RETURNS TABLE (
    result      text,
    elapsed     interval day to second (2)
)
SET search_path=@extschema@ AS $$
DECLARE
    sserver_id          integer;
    server_sampleres    integer;
    etext               text := '';
    edetail             text := '';
    econtext            text := '';

    qres                record;
    conname             text;
    start_clock         timestamp (2) with time zone;
BEGIN
    SELECT server_id INTO sserver_id FROM servers WHERE server_name = take_sample.server;
    IF sserver_id IS NULL THEN
        RAISE 'Server not found';
    ELSE
        /*
        * We should include dblink schema to perform disconnections
        * on exception conditions
        */
        SELECT extnamespace::regnamespace AS dblink_schema INTO STRICT qres FROM pg_catalog.pg_extension WHERE extname = 'dblink';
        IF NOT string_to_array(current_setting('search_path'),', ') @> ARRAY[qres.dblink_schema::text] THEN
          EXECUTE 'SET LOCAL search_path TO ' || current_setting('search_path')||','|| qres.dblink_schema;
        END IF;

        BEGIN
            start_clock := clock_timestamp()::timestamp (2) with time zone;
            server_sampleres := take_sample(sserver_id, take_sample.skip_sizes);
            elapsed := clock_timestamp()::timestamp (2) with time zone - start_clock;
            CASE server_sampleres
              WHEN 0 THEN
                result := 'OK';
              ELSE
                result := 'FAIL';
            END CASE;
            RETURN NEXT;
        EXCEPTION
            WHEN OTHERS THEN
                BEGIN
                    GET STACKED DIAGNOSTICS etext = MESSAGE_TEXT,
                        edetail = PG_EXCEPTION_DETAIL,
                        econtext = PG_EXCEPTION_CONTEXT;
                    result := format (E'%s\n%s\n%s', etext, econtext, edetail);
                    elapsed := clock_timestamp()::timestamp (2) with time zone - start_clock;
                    RETURN NEXT;
                    /*
                      Cleanup dblink connections
                    */
                    FOREACH conname IN ARRAY
                        coalesce(dblink_get_connections(), array[]::text[])
                    LOOP
                        IF conname IN ('server_connection', 'server_db_connection') THEN
                            PERFORM dblink_disconnect(conname);
                        END IF;
                    END LOOP;
                END;
        END;
    END IF;
    RETURN;
END;
$$ LANGUAGE plpgsql;
COMMENT ON FUNCTION take_sample(IN server name, IN skip_sizes boolean) IS
  'Statistics sample creation function (by server name)';
CREATE FUNCTION take_subsample(IN sserver_id integer, IN properties jsonb = NULL)
RETURNS jsonb SET search_path=@extschema@ AS $$
DECLARE
  server_query  text;

  session_rows  integer;
  qres          record;

  s_id          integer;  -- last base sample identifier
  srv_version   integer;

  guc_min_query_dur       interval hour to second;
  guc_min_xact_dur        interval hour to second;
  guc_min_xact_age        integer;
  guc_min_idle_xact_dur   interval hour to second;

BEGIN
  -- Adding dblink extension schema to search_path if it does not already there
  IF (SELECT count(*) = 0 FROM pg_catalog.pg_extension WHERE extname = 'dblink') THEN
    RAISE 'dblink extension must be installed';
  END IF;

  SELECT extnamespace::regnamespace AS dblink_schema INTO STRICT qres FROM pg_catalog.pg_extension WHERE extname = 'dblink';
  IF NOT string_to_array(current_setting('search_path'),',') @> ARRAY[qres.dblink_schema::text] THEN
    EXECUTE 'SET LOCAL search_path TO ' || current_setting('search_path')||','|| qres.dblink_schema;
  END IF;

  IF (properties IS NULL) THEN
    -- Initialization is not done yet
    properties := init_sample(sserver_id);
  END IF; -- empty properties

  -- Skip subsampling if it is disabled
  IF (NOT (properties #>> '{properties,subsample_enabled}')::boolean) THEN
    IF NOT (properties #>> '{properties,in_sample}')::boolean THEN
      -- Reset lock_timeout setting to its initial value
      EXECUTE format('SET lock_timeout TO %L', properties #>> '{properties,lock_timeout_init}');
    END IF;
    RETURN properties;
  END IF;

  -- Only one running take_subsample() function allowed per server!
  BEGIN
    PERFORM
    FROM server_subsample
    WHERE server_id = sserver_id
    FOR UPDATE NOWAIT;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE 'Can''t get lock on server. Is there another '
        'take_subsample() function running on this server?';
  END;

  s_id := (properties #>> '{properties,last_sample_id}')::integer;

  srv_version := (get_sp_setting(properties, 'server_version_num')).reset_val::integer;

  -- Current session states collection
  -- collect sessions and their states
  CASE
    WHEN srv_version >= 140000 THEN
      server_query :=
        'SELECT subsample_ts, datid, datname, pid, leader_pid, usesysid,'
          'usename, application_name, client_addr, client_hostname,'
          'client_port, backend_start, xact_start, query_start, state_change,'
          'state, backend_xid, backend_xmin, query_id, query, backend_type,'
          'backend_xmin_age '
        'FROM ('
            'SELECT '
              'clock_timestamp() as subsample_ts,'
              'datid,'
              'datname,'
              'pid,'
              'leader_pid,'
              'usesysid,'
              'usename,'
              'application_name,'
              'client_addr,'
              'client_hostname,'
              'client_port,'
              'backend_start,'
              'xact_start,'
              'query_start,'
              'state_change,'
              'state,'
              'backend_xid,'
              'backend_xmin,'
              'query_id,'
              'query,'
              'backend_type,'
              'age(backend_xmin) as backend_xmin_age,'
              'CASE '
                'WHEN xact_start <= now() - %1$L::interval THEN '
                  'row_number() OVER (ORDER BY xact_start ASC) '
                'ELSE NULL '
              'END as xact_ord, '
              'CASE '
                'WHEN query_start <= now() - %3$L::interval '
                  'AND state IN (''active'',''fastpath function call'') THEN '
                  'row_number() OVER (PARTITION BY state IN (''active'',''fastpath function call'') ORDER BY query_start ASC) '
                'ELSE NULL '
              'END as query_ord, '
              'CASE '
                'WHEN state_change <= now() - %4$L::interval '
                'AND state IN (''idle in transaction'',''idle in transaction (aborted)'') THEN '
                  'row_number() OVER (PARTITION BY state IN (''idle in transaction'',''idle in transaction (aborted)'') ORDER BY state_change ASC) '
                'ELSE NULL '
              'END as state_ord, '
              'CASE '
                'WHEN age(backend_xmin) >= %2$L THEN '
                  'row_number() OVER (ORDER BY age(backend_xmin) DESC) '
                'ELSE NULL '
              'END  as age_ord '
            'FROM pg_stat_activity '
            'WHERE state NOT IN (''idle'',''disabled'') '
          ') stat_activity '
        'WHERE least('
          'xact_ord,'
          'query_ord,'
          'state_ord,'
          'age_ord'
        ') <= %5$s';
    WHEN srv_version >= 130000 THEN
      server_query :=
        'SELECT subsample_ts, datid, datname, pid, leader_pid, usesysid,'
          'usename, application_name, client_addr, client_hostname,'
          'client_port, backend_start, xact_start, query_start, state_change,'
          'state, backend_xid, backend_xmin, query_id, query, backend_type,'
          'backend_xmin_age '
        'FROM ('
            'SELECT '
              'clock_timestamp() as subsample_ts,'
              'datid,'
              'datname,'
              'pid,'
              'leader_pid,'
              'usesysid,'
              'usename,'
              'application_name,'
              'client_addr,'
              'client_hostname,'
              'client_port,'
              'backend_start,'
              'xact_start,'
              'query_start,'
              'state_change,'
              'state,'
              'backend_xid,'
              'backend_xmin,'
              'NULL AS query_id,'
              'query,'
              'backend_type,'
              'age(backend_xmin) as backend_xmin_age,'
              'CASE '
                'WHEN xact_start <= now() - %1$L::interval THEN '
                  'row_number() OVER (ORDER BY xact_start ASC) '
                'ELSE NULL '
              'END as xact_ord, '
              'CASE '
                'WHEN query_start <= now() - %3$L::interval '
                  'AND state IN (''active'',''fastpath function call'') THEN '
                  'row_number() OVER (PARTITION BY state IN (''active'',''fastpath function call'') ORDER BY query_start ASC) '
                'ELSE NULL '
              'END as query_ord, '
              'CASE '
                'WHEN state_change <= now() - %4$L::interval '
                'AND state IN (''idle in transaction'',''idle in transaction (aborted)'') THEN '
                  'row_number() OVER (PARTITION BY state IN (''idle in transaction'',''idle in transaction (aborted)'') ORDER BY state_change ASC) '
                'ELSE NULL '
              'END as state_ord, '
              'CASE '
                'WHEN age(backend_xmin) >= %2$L THEN '
                  'row_number() OVER (ORDER BY age(backend_xmin) DESC) '
                'ELSE NULL '
              'END  as age_ord '
            'FROM pg_stat_activity '
            'WHERE state NOT IN (''idle'',''disabled'')'
          ') stat_activity '
        'WHERE least('
          'xact_ord,'
          'query_ord,'
          'state_ord,'
          'age_ord'
        ') <= %5$s';
    WHEN srv_version >= 100000 THEN
      server_query :=
        'SELECT subsample_ts, datid, datname, pid, leader_pid, usesysid,'
          'usename, application_name, client_addr, client_hostname,'
          'client_port, backend_start, xact_start, query_start, state_change,'
          'state, backend_xid, backend_xmin, query_id, query, backend_type,'
          'backend_xmin_age '
        'FROM ('
            'SELECT '
              'clock_timestamp() as subsample_ts,'
              'datid,'
              'datname,'
              'pid,'
              'NULL AS leader_pid,'
              'usesysid,'
              'usename,'
              'application_name,'
              'client_addr,'
              'client_hostname,'
              'client_port,'
              'backend_start,'
              'xact_start,'
              'query_start,'
              'state_change,'
              'state,'
              'backend_xid,'
              'backend_xmin,'
              'NULL AS query_id,'
              'query,'
              'backend_type,'
              'age(backend_xmin) as backend_xmin_age,'
              'CASE '
                'WHEN xact_start <= now() - %1$L::interval THEN '
                  'row_number() OVER (ORDER BY xact_start ASC) '
                'ELSE NULL '
              'END as xact_ord, '
              'CASE '
                'WHEN query_start <= now() - %3$L::interval '
                  'AND state IN (''active'',''fastpath function call'') THEN '
                  'row_number() OVER (PARTITION BY state IN (''active'',''fastpath function call'') ORDER BY query_start ASC) '
                'ELSE NULL '
              'END as query_ord, '
              'CASE '
                'WHEN state_change <= now() - %4$L::interval '
                'AND state IN (''idle in transaction'',''idle in transaction (aborted)'') THEN '
                  'row_number() OVER (PARTITION BY state IN (''idle in transaction'',''idle in transaction (aborted)'') ORDER BY state_change ASC) '
                'ELSE NULL '
              'END as state_ord, '
              'CASE '
                'WHEN age(backend_xmin) >= %2$L THEN '
                  'row_number() OVER (ORDER BY age(backend_xmin) DESC) '
                'ELSE NULL '
              'END  as age_ord '
            'FROM pg_stat_activity '
            'WHERE state NOT IN (''idle'',''disabled'')'
          ') stat_activity '
        'WHERE least('
          'xact_ord,'
          'query_ord,'
          'state_ord,'
          'age_ord'
        ') <= %5$s';
    ELSE
      RAISE 'Unsupported postgres version';
  END CASE;

  /*
   format() function will substitute defined values for us quoting
   them as it requested by the %L type. NULLs will be placed literally
   unquoted making threshold inactive. However we need the NULLIF()
   functions here to avoid errors in EDB instances having NULL strings
   to appear as the empty ones.
  */
  server_query := format(
      server_query,
      NULLIF(properties #>> '{properties,min_xact_dur}', ''),
      NULLIF(properties #>> '{properties,min_xact_age}', ''),
      NULLIF(properties #>> '{properties,min_query_dur}', ''),
      NULLIF(properties #>> '{properties,min_idle_xact_dur}', ''),
      properties #>> '{properties,topn}'
  );

  -- Save the current state of captured sessions satisfying thresholds
  INSERT INTO last_stat_activity
  SELECT
      sserver_id,
      s_id,
      dbl.subsample_ts,
      dbl.datid,
      dbl.datname,
      dbl.pid,
      dbl.leader_pid,
      dbl.usesysid,
      dbl.usename,
      dbl.application_name,
      dbl.client_addr,
      dbl.client_hostname,
      dbl.client_port,
      dbl.backend_start,
      dbl.xact_start,
      dbl.query_start,
      dbl.state_change,
      dbl.state,
      dbl.backend_xid,
      dbl.backend_xmin,
      dbl.query_id,
      dbl.query,
      dbl.backend_type,
      dbl.backend_xmin_age
  FROM
      dblink('server_connection', server_query) AS dbl(
          subsample_ts      timestamp with time zone,
          datid             oid,
          datname           name,
          pid               integer,
          leader_pid        integer,
          usesysid          oid,
          usename           name,
          application_name  text,
          client_addr       inet,
          client_hostname   text,
          client_port       integer,
          backend_start     timestamp with time zone,
          xact_start        timestamp with time zone,
          query_start       timestamp with time zone,
          state_change      timestamp with time zone,
          state             text,
          backend_xid       text,
          backend_xmin      text,
          query_id          bigint,
          query             text,
          backend_type      text,
          backend_xmin_age      bigint
      );
  GET DIAGNOSTICS session_rows = ROW_COUNT;

  IF session_rows > 0 THEN
    /*
      We have four thresholds probably defined for subsamples, so
      we'll delete the previous captured state when we don't need it
      anymore for all of them.
    */
    DELETE FROM last_stat_activity dlsa
    USING
      (
        SELECT pid, xact_start, max(subsample_ts) as subsample_ts
        FROM last_stat_activity
        WHERE (server_id, sample_id) = (sserver_id, s_id)
        GROUP BY pid, xact_start
      ) last_xact_state
      JOIN
      last_stat_activity lxs ON
        (sserver_id, s_id, last_xact_state.pid, last_xact_state.subsample_ts) =
        (lxs.server_id, lxs.sample_id, lxs.pid, lxs.subsample_ts)
    WHERE (dlsa.server_id, dlsa.sample_id, dlsa.pid, dlsa.xact_start) =
      (sserver_id, s_id, last_xact_state.pid, last_xact_state.xact_start)
      AND dlsa.subsample_ts < last_xact_state.subsample_ts
      AND
      /*
        As we are observing the same xact here (pid, xact_start)
        min_xact_dur threshold can't apply any limitation on deleting
        the old entry.
      */
      -- Can we delete dlsa state due to min_xact_age threshold?
        ((dlsa.backend_xmin IS NOT DISTINCT FROM lxs.backend_xmin)
        OR coalesce(
          dlsa.backend_xmin_age < (properties #>> '{properties,min_xact_age}')::integer,
          true)
        )
      AND
      -- Can we delete dlsa state due to min_query_dur threshold?
      CASE
        WHEN dlsa.state IN ('active', 'fastpath function call') THEN
        (
          ((dlsa.query_start, dlsa.state)
            IS NOT DISTINCT FROM
            (lxs.query_start, lxs.state)
          )
          OR coalesce(
            dlsa.subsample_ts - dlsa.query_start <
              (properties #>> '{properties,min_query_dur}')::interval,
            true)
        )
        ELSE true
      END
      AND
      -- Can we delete dlsa state due to min_idle_xact_dur threshold?
      CASE
        WHEN dlsa.state IN ('idle in transaction','idle in transaction (aborted)') THEN
        (
          ((dlsa.state_change)
            IS NOT DISTINCT FROM
            (lxs.state_change)
          )
          OR coalesce(
            dlsa.subsample_ts - dlsa.state_change <
              (properties #>> '{properties,min_idle_xact_dur}')::interval,
            true)
        )
        ELSE true
      END
    ;
  END IF;

  /* It seems we should avoid analyze here, hoping autoanalyze will do
  the trick */
  /*
  GET DIAGNOSTICS session_rows = ROW_COUNT; EXECUTE
  format('ANALYZE last_stat_activity_srv%1$s', sserver_id);
  */

  -- Collect sessions count by states and waits
  server_query :=
    'SELECT '
      'now() as subsample_ts,'
      'backend_type,'
      'datid,'
      'datname,'
      'usesysid,'
      'usename,'
      'application_name,'
      'client_addr,'
      'count(*) as total,'
      'count(*) FILTER (WHERE state = ''active'') as active,'
      'count(*) FILTER (WHERE state = ''idle'') as idle,'
      'count(*) FILTER (WHERE state = ''idle in transaction'') as idle_t,'
      'count(*) FILTER (WHERE state = ''idle in transaction (aborted)'') as idle_ta,'
      'count(*) FILTER (WHERE state IS NULL) as state_null,'
      'count(*) FILTER (WHERE wait_event_type = ''LWLock'') as lwlock,'
      'count(*) FILTER (WHERE wait_event_type = ''Lock'') as lock,'
      'count(*) FILTER (WHERE wait_event_type = ''BufferPin'') as bufferpin,'
      'count(*) FILTER (WHERE wait_event_type = ''Activity'') as activity,'
      'count(*) FILTER (WHERE wait_event_type = ''Extension'') as extension,'
      'count(*) FILTER (WHERE wait_event_type = ''Client'') as client,'
      'count(*) FILTER (WHERE wait_event_type = ''IPC'') as ipc,'
      'count(*) FILTER (WHERE wait_event_type = ''Timeout'') as timeout,'
      'count(*) FILTER (WHERE wait_event_type = ''IO'') as io '
    'FROM pg_stat_activity '
    'GROUP BY backend_type, datid, datname, usesysid, usename, application_name, client_addr';

  -- Save the current state of captured sessions satisfying thresholds
  INSERT INTO last_stat_activity_count
  SELECT
      sserver_id,
      s_id,
      dbl.subsample_ts,
      dbl.backend_type,
      dbl.datid,
      dbl.datname,
      dbl.usesysid,
      dbl.usename,
      dbl.application_name,
      dbl.client_addr,

      dbl.total,
      dbl.active,
      dbl.idle,
      dbl.idle_t,
      dbl.idle_ta,
      dbl.state_null,
      dbl.lwlock,
      dbl.lock,
      dbl.bufferpin,
      dbl.activity,
      dbl.extension,
      dbl.client,
      dbl.ipc,
      dbl.timeout,
      dbl.io
  FROM
      dblink('server_connection', server_query) AS dbl(
          subsample_ts      timestamp with time zone,
          backend_type      text,
          datid             oid,
          datname           name,
          usesysid          oid,
          usename           name,
          application_name  text,
          client_addr       inet,

          total             integer,
          active            integer,
          idle              integer,
          idle_t            integer,
          idle_ta           integer,
          state_null        integer,
          lwlock            integer,
          lock              integer,
          bufferpin         integer,
          activity          integer,
          extension         integer,
          client            integer,
          ipc               integer,
          timeout           integer,
          io                integer
      );

  IF NOT (properties #>> '{properties,in_sample}')::boolean THEN
    -- Reset lock_timeout setting to its initial value
    PERFORM dblink('server_connection', 'COMMIT');
    PERFORM dblink_disconnect('server_connection');
    EXECUTE format('SET lock_timeout TO %L', properties #>> '{properties,lock_timeout_init}');
  END IF;

  RETURN properties;
END
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION take_subsample(IN integer, IN jsonb) IS
  'Take a sub-sample for a server by server_id';
CREATE FUNCTION top_tables(IN sserver_id integer, IN start_id integer, IN end_id integer)
RETURNS TABLE(
    datid               oid,
    relid               oid,
    reltoastrelid       oid,
    dbname              name,
    tablespacename      name,
    schemaname          name,
    relname             name,
    seq_scan            bigint,
    seq_tup_read        bigint,
    idx_scan            bigint,
    idx_tup_fetch       bigint,
    n_tup_ins           bigint,
    n_tup_upd           bigint,
    n_tup_del           bigint,
    n_tup_hot_upd       bigint,
    n_tup_newpage_upd   bigint,
    np_upd_pct          numeric,
    vacuum_count        bigint,
    autovacuum_count    bigint,
    analyze_count       bigint,
    autoanalyze_count   bigint,
    total_vacuum_time       double precision,
    total_autovacuum_time   double precision,
    total_analyze_time      double precision,
    total_autoanalyze_time  double precision,
    growth              bigint,
    relpagegrowth_bytes bigint,
    seqscan_bytes_relsize numeric,
    seqscan_bytes_relpages numeric
) SET search_path=@extschema@ AS $$
    SELECT
        st.datid,
        st.relid,
        st.reltoastrelid,
        sample_db.datname AS dbname,
        st.tablespacename,
        st.schemaname,
        st.relname,
        sum(st.seq_scan)::bigint AS seq_scan,
        sum(st.seq_tup_read)::bigint AS seq_tup_read,
        sum(st.idx_scan)::bigint AS idx_scan,
        sum(st.idx_tup_fetch)::bigint AS idx_tup_fetch,
        sum(st.n_tup_ins)::bigint AS n_tup_ins,
        sum(st.n_tup_upd)::bigint AS n_tup_upd,
        sum(st.n_tup_del)::bigint AS n_tup_del,
        sum(st.n_tup_hot_upd)::bigint AS n_tup_hot_upd,
        sum(st.n_tup_newpage_upd)::bigint AS n_tup_newpage_upd,
        sum(st.n_tup_newpage_upd)::numeric * 100 /
          NULLIF(sum(st.n_tup_upd)::numeric, 0) AS np_upd_pct,
        sum(st.vacuum_count)::bigint AS vacuum_count,
        sum(st.autovacuum_count)::bigint AS autovacuum_count,
        sum(st.analyze_count)::bigint AS analyze_count,
        sum(st.autoanalyze_count)::bigint AS autoanalyze_count,
        sum(total_vacuum_time)::double precision AS total_vacuum_time,
        sum(total_autovacuum_time)::double precision AS total_autovacuum_time,
        sum(total_analyze_time)::double precision AS total_analyze_time,
        sum(total_autoanalyze_time)::double precision AS total_autoanalyze_time,
        sum(st.relsize_diff)::bigint AS growth,
        sum(st.relpages_bytes_diff)::bigint AS relpagegrowth_bytes,
        CASE WHEN bool_and(COALESCE(st.seq_scan, 0) = 0 OR st.relsize IS NOT NULL) THEN
          sum(st.seq_scan::numeric * st.relsize::numeric)
        ELSE NULL
        END AS seqscan_bytes_relsize,
        sum(st.seq_scan::numeric * st.relpages_bytes::numeric) AS seqscan_bytes_relpages
    FROM v_sample_stat_tables st
        -- Database name
        JOIN sample_stat_database sample_db
          USING (server_id, sample_id, datid)
    WHERE st.server_id = sserver_id AND st.relkind IN ('r','m')
      AND NOT sample_db.datistemplate
      AND st.sample_id BETWEEN start_id + 1 AND end_id
    GROUP BY st.server_id,st.datid,st.relid,st.reltoastrelid,sample_db.datname,st.tablespacename,st.schemaname,st.relname
$$ LANGUAGE sql;
CREATE FUNCTION top_toasts(IN sserver_id integer, IN start_id integer, IN end_id integer)
RETURNS TABLE(
    datid               oid,
    relid               oid,
    dbname              name,
    tablespacename      name,
    schemaname          name,
    relname             name,
    seq_scan            bigint,
    seq_tup_read        bigint,
    idx_scan            bigint,
    idx_tup_fetch       bigint,
    n_tup_ins           bigint,
    n_tup_upd           bigint,
    n_tup_del           bigint,
    n_tup_hot_upd       bigint,
    n_tup_newpage_upd   bigint,
    np_upd_pct          numeric,
    vacuum_count        bigint,
    autovacuum_count    bigint,
    analyze_count       bigint,
    autoanalyze_count   bigint,
    total_vacuum_time       double precision,
    total_autovacuum_time   double precision,
    total_analyze_time      double precision,
    total_autoanalyze_time  double precision,
    growth              bigint,
    relpagegrowth_bytes bigint,
    seqscan_bytes_relsize numeric,
    seqscan_bytes_relpages numeric
) SET search_path=@extschema@ AS $$
    SELECT
        st.datid,
        st.relid,
        sample_db.datname AS dbname,
        st.tablespacename,
        st.schemaname,
        st.relname,
        sum(st.seq_scan)::bigint AS seq_scan,
        sum(st.seq_tup_read)::bigint AS seq_tup_read,
        sum(st.idx_scan)::bigint AS idx_scan,
        sum(st.idx_tup_fetch)::bigint AS idx_tup_fetch,
        sum(st.n_tup_ins)::bigint AS n_tup_ins,
        sum(st.n_tup_upd)::bigint AS n_tup_upd,
        sum(st.n_tup_del)::bigint AS n_tup_del,
        sum(st.n_tup_hot_upd)::bigint AS n_tup_hot_upd,
        sum(st.n_tup_newpage_upd)::bigint AS n_tup_newpage_upd,
        sum(st.n_tup_newpage_upd)::numeric * 100 /
          NULLIF(sum(st.n_tup_upd)::numeric, 0) AS np_upd_pct,
        sum(st.vacuum_count)::bigint AS vacuum_count,
        sum(st.autovacuum_count)::bigint AS autovacuum_count,
        sum(st.analyze_count)::bigint AS analyze_count,
        sum(st.autoanalyze_count)::bigint AS autoanalyze_count,
        sum(total_vacuum_time)::double precision AS total_vacuum_time,
        sum(total_autovacuum_time)::double precision AS total_autovacuum_time,
        sum(total_analyze_time)::double precision AS total_analyze_time,
        sum(total_autoanalyze_time)::double precision AS total_autoanalyze_time,
        sum(st.relsize_diff)::bigint AS growth,
        sum(st.relpages_bytes_diff)::bigint AS relpagegrowth_bytes,
        CASE WHEN bool_and(COALESCE(st.seq_scan, 0) = 0 OR st.relsize IS NOT NULL) THEN
          sum(st.seq_scan::numeric * st.relsize::numeric)
        ELSE NULL
        END AS seqscan_bytes_relsize,
        sum(st.seq_scan::numeric * st.relpages_bytes::numeric) AS seqscan_bytes_relpages
    FROM v_sample_stat_tables st
        -- Database name
        JOIN sample_stat_database sample_db
          USING (server_id, sample_id, datid)
    WHERE st.server_id = sserver_id AND st.relkind = 't'
      AND NOT sample_db.datistemplate
      AND st.sample_id BETWEEN start_id + 1 AND end_id
    GROUP BY st.server_id,st.datid,st.relid,sample_db.datname,st.tablespacename,st.schemaname,st.relname
$$ LANGUAGE sql;
CREATE FUNCTION get_report_context(IN sserver_id integer, IN start1_id integer, IN end1_id integer,
  IN description text = NULL,
  IN start2_id integer = NULL, IN end2_id integer = NULL)
RETURNS jsonb SET search_path=@extschema@ AS $$
DECLARE
  report_context  jsonb;
  r_result    RECORD;

  qlen_limit  integer;
  topn        integer;

  start1_time timestamp with time zone;
  end1_time   timestamp with time zone;
  start2_time timestamp with time zone;
  end2_time   timestamp with time zone;
  start1_time_ut numeric;
  end1_time_ut   numeric;
  start2_time_ut numeric;
  end2_time_ut   numeric;
BEGIN
    IF num_nulls(start1_id, end1_id) > 0 THEN
        RAISE 'At least first interval bounds is necessary';
    END IF;

    -- Check for zero-length intervals
    IF num_nulls(start1_id, end1_id) = 0 AND start1_id >= end1_id THEN
        RAISE 'First interval doesn''t have positive duration'
            USING HINT = 'end1_id must be greater than start1_id';
    END IF;
    IF num_nulls(start2_id, end2_id) = 0 AND start2_id >= end2_id THEN
        RAISE 'Second interval doesn''t have positive duration'
            USING HINT = 'end2_id must be greater than start2_id';
    END IF;

    -- Getting query length limit setting
    BEGIN
        qlen_limit := current_setting('pg_profile.max_query_length')::integer;
    EXCEPTION
        WHEN OTHERS THEN qlen_limit := 20000;
    END;

    -- Getting TopN setting
    BEGIN
        topn := least(current_setting('pg_profile.topn')::integer, 100);
    EXCEPTION
        WHEN OTHERS THEN topn := 20;
    END;

    -- Populate report settings
    -- Check if all samples of requested interval are available
    IF (
      SELECT count(*) != end1_id - start1_id + 1 FROM samples
      WHERE server_id = sserver_id AND sample_id BETWEEN start1_id AND end1_id
    ) THEN
      RAISE 'Not enough samples between %',
        format('%s AND %s', start1_id, end1_id);
    END IF;

    -- Get report times
    SELECT sample_time INTO STRICT start1_time FROM samples
    WHERE (server_id,sample_id) = (sserver_id,start1_id);
    SELECT EXTRACT(EPOCH FROM sample_time) INTO STRICT start1_time_ut FROM samples
    WHERE (server_id,sample_id) = (sserver_id,start1_id);
    SELECT sample_time INTO STRICT end1_time FROM samples
    WHERE (server_id,sample_id) = (sserver_id,end1_id);
    SELECT EXTRACT(EPOCH FROM sample_time) INTO STRICT end1_time_ut FROM samples
    WHERE (server_id,sample_id) = (sserver_id,end1_id);
    IF num_nulls(start2_id, end2_id) = 2 THEN
      report_context := jsonb_build_object(
      'report_features',jsonb_build_object(
        'dbstats_reset', profile_checkavail_dbstats_reset(sserver_id, start1_id, end1_id),
        'stmt_cnt_range', profile_checkavail_stmt_cnt(sserver_id, start1_id, end1_id),
        'stmt_cnt_all', profile_checkavail_stmt_cnt(sserver_id, 0, 0),
        'cluster_stats_reset', profile_checkavail_cluster_stats_reset(sserver_id, start1_id, end1_id),
        'wal_stats_reset', profile_checkavail_wal_stats_reset(sserver_id, start1_id, end1_id),
        'statstatements',profile_checkavail_statstatements(sserver_id, start1_id, end1_id),
        'planning_times',profile_checkavail_planning_times(sserver_id, start1_id, end1_id),
        'wait_sampling_tot',profile_checkavail_wait_sampling_total(sserver_id, start1_id, end1_id),
        'io_times',profile_checkavail_io_times(sserver_id, start1_id, end1_id),
        'statement_wal_bytes',profile_checkavail_stmt_wal_bytes(sserver_id, start1_id, end1_id),
        'statements_top_temp', profile_checkavail_top_temp(sserver_id, start1_id, end1_id),
        'statements_temp_io_times', profile_checkavail_statements_temp_io_times(sserver_id, start1_id, end1_id),
        'wal_stats',profile_checkavail_walstats(sserver_id, start1_id, end1_id),
        'sess_stats',profile_checkavail_sessionstats(sserver_id, start1_id, end1_id),
        'function_stats',profile_checkavail_functions(sserver_id, start1_id, end1_id),
        'trigger_function_stats',profile_checkavail_trg_functions(sserver_id, start1_id, end1_id),
        'kcachestatements',profile_checkavail_rusage(sserver_id,start1_id,end1_id),
        'rusage_planstats',profile_checkavail_rusage_planstats(sserver_id,start1_id,end1_id),
        'statements_jit_stats',profile_checkavail_statements_jit_stats(sserver_id, start1_id, end1_id),
        'top_tables_dead', profile_checkavail_tbl_top_dead(sserver_id,start1_id,end1_id),
        'top_tables_mods', profile_checkavail_tbl_top_mods(sserver_id,start1_id,end1_id),
        'table_new_page_updates', (
          SELECT COALESCE(sum(n_tup_newpage_upd), 0) > 0
          FROM sample_stat_tables_total
          WHERE server_id = sserver_id AND sample_id BETWEEN start1_id + 1 AND end1_id
        ),
        'stat_io', (
          SELECT COUNT(*) > 0 FROM (
            SELECT backend_type
            FROM sample_stat_io
            WHERE server_id = sserver_id AND
              sample_id BETWEEN start1_id + 1 AND end1_id LIMIT 1
            ) c
        ),
        'stat_io_reset', (
          -- We should include both ends here to detect resets performed
          SELECT bool_or(group_reset)
          FROM (
            SELECT COUNT(DISTINCT stats_reset) > 1 AS group_reset
            FROM sample_stat_io
            WHERE server_id = sserver_id AND sample_id BETWEEN start1_id AND end1_id
            GROUP BY backend_type, object, context
          ) gr
        ),
        'stat_slru', (
          SELECT COUNT(*) > 0 FROM (
            SELECT name
            FROM sample_stat_slru
            WHERE server_id = sserver_id AND
              sample_id BETWEEN start1_id + 1 AND end1_id LIMIT 1
            ) c
        ),
        'stat_slru_reset', (
          -- We should include both ends here to detect resets performed
          SELECT bool_or(group_reset)
          FROM (
            SELECT COUNT(DISTINCT stats_reset) > 1 AS group_reset
            FROM sample_stat_slru
            WHERE server_id = sserver_id AND sample_id BETWEEN start1_id AND end1_id
            GROUP BY name
          ) gr
        ),
        'buffers_backend', (
          SELECT COUNT(buffers_backend) > 0 FROM sample_stat_cluster
          WHERE server_id = sserver_id AND
            sample_id BETWEEN start1_id + 1 AND end1_id
        ),
        'mean_mm_times', (
          SELECT COUNT(COALESCE(mean_max_exec_time, mean_min_exec_time,
              mean_max_plan_time, mean_min_plan_time)
            ) > 0
          FROM sample_statements_total
          WHERE server_id = sserver_id AND
            sample_id BETWEEN start1_id + 1 AND end1_id
        ),
        -- statements_cover should be used to control appearance of the cover field.
        'statements_coverage', (
          SELECT count(*) > 0
          FROM sample_statements
          WHERE server_id = sserver_id AND stats_since > start1_time AND
            sample_id BETWEEN start1_id + 1 AND end1_id
          ),
        'statements_jit_deform', (
          SELECT count(*) > 0
          FROM sample_statements_total
          WHERE server_id = sserver_id AND jit_deform_count > 0 AND
            sample_id BETWEEN start1_id + 1 AND end1_id
          ),
        'checksum_fail_detected', COALESCE((
          SELECT sum(checksum_failures) > 0
          FROM sample_stat_database
          WHERE server_id = sserver_id AND sample_id BETWEEN start1_id + 1 AND end1_id
          ), false),
        'extension_versions', (
          SELECT count(*) > 0
          FROM v_extension_versions
          WHERE server_id = sserver_id AND
            sample_id BETWEEN start1_id AND end1_id
          ),
        'extension_versions_show_date_columns', (
          SELECT count(*) > 0
          FROM v_extension_versions
          WHERE server_id = sserver_id AND
            sample_id BETWEEN start1_id AND end1_id AND
            (first_seen > start1_time OR last_sample_id < end1_id)
          ),
        'table_storage_parameters', (
          SELECT count(*) > 0
          FROM v_table_storage_parameters
          WHERE server_id = sserver_id AND
            sample_id BETWEEN start1_id AND end1_id
          ),
        'index_storage_parameters', (
          SELECT count(*) > 0
          FROM v_index_storage_parameters
          WHERE server_id = sserver_id AND
            sample_id BETWEEN start1_id AND end1_id
          ),
        'statements_workers_stats', (
          SELECT count(*) > 0
          FROM sample_statements
          WHERE server_id = sserver_id AND greatest(parallel_workers_to_launch,parallel_workers_launched) > 0 AND
            sample_id BETWEEN start1_id + 1 AND end1_id
          ),
        'wal_buffers_full', (
          SELECT count(*) > 0
          FROM sample_statements
          WHERE server_id = sserver_id AND wal_buffers_full > 0 AND
            sample_id BETWEEN start1_id + 1 AND end1_id
          ),
        'vacuum_time', (
          SELECT count(*) > 0
          FROM sample_stat_tables_total
          WHERE server_id = sserver_id AND
            total_vacuum_time + total_autovacuum_time > 0  AND
            sample_id BETWEEN start1_id + 1 AND end1_id
          ),
        'analyze_time', (
          SELECT count(*) > 0
          FROM sample_stat_tables_total
          WHERE server_id = sserver_id AND
            total_analyze_time + total_autoanalyze_time > 0  AND
            sample_id BETWEEN start1_id + 1 AND end1_id
          ),
        'db_parallel_workers', (
          SELECT count(*) > 0
          FROM sample_stat_database
          WHERE server_id = sserver_id AND greatest(parallel_workers_to_launch, parallel_workers_launched) > 0 AND
          sample_id BETWEEN start1_id + 1 AND end1_id
          ),
        'checkpoints_done_and_slru', (
          SELECT COUNT(*) > 0
          FROM sample_stat_cluster
          WHERE server_id = sserver_id AND
            greatest(slru_checkpoint, checkpoints_done) > 0 AND
            sample_id BETWEEN start1_id AND end1_id
          ),
        'restartpoints', (
          SELECT COUNT(*) > 0
          FROM sample_stat_cluster
          WHERE server_id = sserver_id AND
            greatest(restartpoints_timed, restartpoints_req, restartpoints_done) > 0 AND
            sample_id BETWEEN start1_id AND end1_id
        )
      ),
      'report_properties',jsonb_build_object(
        'interval_duration_sec',
          (SELECT extract(epoch FROM e.sample_time - s.sample_time)
          FROM samples s JOIN samples e USING (server_id)
          WHERE e.sample_id=end1_id and s.sample_id=start1_id
            AND server_id = sserver_id),
        'topn', topn,
        'max_query_length', qlen_limit,
        'start1_id', start1_id,
        'end1_id', end1_id,
        'report_start1', start1_time::text,
        'report_end1', end1_time::text,
        'report_start1_ut', start1_time_ut,
        'report_end1_ut', end1_time_ut
        )
      );

      -- stat_activity features
      IF has_table_privilege('sample_act_backend', 'SELECT') THEN
        report_context := jsonb_set(report_context, '{report_features,act_backend}',
          (
          SELECT
            to_jsonb(COUNT(*) > 0) FROM (
              SELECT 1
              FROM sample_act_backend
              WHERE server_id = sserver_id AND (
                  sample_id BETWEEN start1_id + 1 AND end1_id
                )
              LIMIT 1
            ) c
          )
        );
        report_context := jsonb_set(report_context, '{report_features,act_ix}',
          (
          SELECT
            to_jsonb(COUNT(*) > 0) FROM (
              SELECT 1
              FROM sample_act_backend_state
              WHERE server_id = sserver_id AND
                state_code = 1 AND (
                  sample_id BETWEEN start1_id + 1 AND end1_id
                )
              LIMIT 1
            ) c
          )
        );
        report_context := jsonb_set(report_context, '{report_features,act_ixa}',
          (
          SELECT
            to_jsonb(COUNT(*) > 0) FROM (
              SELECT 1
              FROM sample_act_backend_state
              WHERE server_id = sserver_id AND
                state_code = 2 AND (
                  sample_id BETWEEN start1_id + 1 AND end1_id
                )
              LIMIT 1
            ) c
          )
        );
        report_context := jsonb_set(report_context, '{report_features,act_active}',
          (
          SELECT
            to_jsonb(COUNT(*) > 0) FROM (
              SELECT 1
              FROM sample_act_backend_state JOIN sample_act_statement
                USING (server_id, sample_id, pid, xact_start)
              WHERE server_id = sserver_id AND
                state_code = 3 AND (
                  sample_id BETWEEN start1_id + 1 AND end1_id
                )
              LIMIT 1
            ) c
          )
        );
      END IF;
    ELSIF num_nulls(start2_id, end2_id) = 0 THEN
      -- Get report times
      SELECT sample_time INTO STRICT start2_time FROM samples
      WHERE (server_id,sample_id) = (sserver_id,start2_id);
      SELECT EXTRACT(EPOCH FROM sample_time) INTO STRICT start2_time_ut FROM samples
      WHERE (server_id,sample_id) = (sserver_id,start2_id);
      SELECT sample_time INTO STRICT end2_time FROM samples
      WHERE (server_id,sample_id) = (sserver_id,end2_id);
      SELECT EXTRACT(EPOCH FROM sample_time) INTO STRICT end2_time_ut FROM samples
      WHERE (server_id,sample_id) = (sserver_id,end2_id);
      -- Check if all samples of requested interval are available
      IF (
        SELECT count(*) != end2_id - start2_id + 1 FROM samples
        WHERE server_id = sserver_id AND sample_id BETWEEN start2_id AND end2_id
      ) THEN
        RAISE 'Not enough samples between %',
          format('%s AND %s', start2_id, end2_id);
      END IF;
      report_context := jsonb_build_object(
      'report_features',jsonb_build_object(
        'dbstats_reset', profile_checkavail_dbstats_reset(sserver_id, start1_id, end1_id) OR
          profile_checkavail_dbstats_reset(sserver_id, start2_id, end2_id),
        'stmt_cnt_range', profile_checkavail_stmt_cnt(sserver_id, start1_id, end1_id) OR
          profile_checkavail_stmt_cnt(sserver_id, start2_id, end2_id),
        'stmt_cnt_all', profile_checkavail_stmt_cnt(sserver_id, 0, 0),
        'cluster_stats_reset', profile_checkavail_cluster_stats_reset(sserver_id, start1_id, end1_id) OR
          profile_checkavail_cluster_stats_reset(sserver_id, start2_id, end2_id),
        'wal_stats_reset', profile_checkavail_wal_stats_reset(sserver_id, start1_id, end1_id) OR
          profile_checkavail_wal_stats_reset(sserver_id, start2_id, end2_id),
        'statstatements',profile_checkavail_statstatements(sserver_id, start1_id, end1_id) OR
          profile_checkavail_statstatements(sserver_id, start2_id, end2_id),
        'planning_times',profile_checkavail_planning_times(sserver_id, start1_id, end1_id) OR
          profile_checkavail_planning_times(sserver_id, start2_id, end2_id),
        'wait_sampling_tot',profile_checkavail_wait_sampling_total(sserver_id, start1_id, end1_id) OR
          profile_checkavail_wait_sampling_total(sserver_id, start2_id, end2_id),
        'io_times',profile_checkavail_io_times(sserver_id, start1_id, end1_id) OR
          profile_checkavail_io_times(sserver_id, start2_id, end2_id),
        'statement_wal_bytes',profile_checkavail_stmt_wal_bytes(sserver_id, start1_id, end1_id) OR
          profile_checkavail_stmt_wal_bytes(sserver_id, start2_id, end2_id),
        'statements_top_temp', profile_checkavail_top_temp(sserver_id, start1_id, end1_id) OR
            profile_checkavail_top_temp(sserver_id, start2_id, end2_id),
        'statements_temp_io_times', profile_checkavail_statements_temp_io_times(sserver_id, start1_id, end1_id) OR
            profile_checkavail_statements_temp_io_times(sserver_id, start2_id, end2_id),
        'wal_stats',profile_checkavail_walstats(sserver_id, start1_id, end1_id) OR
          profile_checkavail_walstats(sserver_id, start2_id, end2_id),
        'sess_stats',profile_checkavail_sessionstats(sserver_id, start1_id, end1_id) OR
          profile_checkavail_sessionstats(sserver_id, start2_id, end2_id),
        'function_stats',profile_checkavail_functions(sserver_id, start1_id, end1_id) OR
          profile_checkavail_functions(sserver_id, start2_id, end2_id),
        'trigger_function_stats',profile_checkavail_trg_functions(sserver_id, start1_id, end1_id) OR
          profile_checkavail_trg_functions(sserver_id, start2_id, end2_id),
        'kcachestatements',profile_checkavail_rusage(sserver_id, start1_id, end1_id) OR
          profile_checkavail_rusage(sserver_id, start2_id, end2_id),
        'rusage_planstats',profile_checkavail_rusage_planstats(sserver_id, start1_id, end1_id) OR
          profile_checkavail_rusage_planstats(sserver_id, start2_id, end2_id),
        'statements_jit_stats',profile_checkavail_statements_jit_stats(sserver_id, start1_id, end1_id) OR
          profile_checkavail_statements_jit_stats(sserver_id, start2_id, end2_id),
        'table_new_page_updates', (
          SELECT COALESCE(sum(n_tup_newpage_upd), 0) > 0
          FROM sample_stat_tables_total
          WHERE server_id = sserver_id AND
            (sample_id BETWEEN start1_id + 1 AND end1_id OR
            sample_id BETWEEN start2_id + 1 AND end2_id)
        ),
        'stat_io', (
          SELECT COUNT(*) > 0 FROM (
            SELECT backend_type
            FROM sample_stat_io
            WHERE server_id = sserver_id AND (
              sample_id BETWEEN start1_id + 1 AND end1_id OR
              sample_id BETWEEN start2_id + 1 AND end2_id
              ) LIMIT 1
            ) c
        ),
        'stat_io_reset', (
          -- We should include both ends here to detect resets performed
          SELECT bool_or(group_reset)
          FROM (
            SELECT COUNT(DISTINCT stats_reset) > 1 AS group_reset
            FROM sample_stat_io
            WHERE server_id = sserver_id AND (
              sample_id BETWEEN start1_id AND end1_id OR
              sample_id BETWEEN start2_id AND end2_id
              )
            GROUP BY backend_type, object, context
          ) gr
        ),
        'stat_slru', (
          SELECT COUNT(*) > 0 FROM (
            SELECT name
            FROM sample_stat_slru
            WHERE server_id = sserver_id AND (
              sample_id BETWEEN start1_id + 1 AND end1_id OR
              sample_id BETWEEN start2_id + 1 AND end2_id
              ) LIMIT 1
            ) c
        ),
        'stat_slru_reset', (
          -- We should include both ends here to detect resets performed
          SELECT bool_or(group_reset)
          FROM (
            SELECT COUNT(DISTINCT stats_reset) > 1 AS group_reset
            FROM sample_stat_slru
            WHERE server_id = sserver_id AND (
              sample_id BETWEEN start1_id AND end1_id OR
              sample_id BETWEEN start2_id AND end2_id
            )
            GROUP BY name
          ) gr
        ),
        'buffers_backend', (
          SELECT COUNT(buffers_backend) > 0 FROM sample_stat_cluster
          WHERE server_id = sserver_id AND (
              sample_id BETWEEN start1_id AND end1_id OR
              sample_id BETWEEN start2_id AND end2_id
            )
        ),
        'mean_mm_times', (
          SELECT COUNT(COALESCE(mean_max_exec_time, mean_min_exec_time,
              mean_max_plan_time, mean_min_plan_time)
            ) > 0
          FROM sample_statements_total
          WHERE server_id = sserver_id AND (
              sample_id BETWEEN start1_id AND end1_id OR
              sample_id BETWEEN start2_id AND end2_id
            )
        ),
        -- statements_cover should be used to control appearance of the cover field.
        'statements_coverage', (
          SELECT count(*) > 0
          FROM sample_statements
          WHERE server_id = sserver_id AND
            ((stats_since > start1_time AND sample_id BETWEEN start1_id + 1 AND end1_id) OR
            (stats_since > start2_time AND sample_id BETWEEN start2_id + 1 AND end2_id))
          ),
        'statements_jit_deform', (
          SELECT count(*) > 0
          FROM sample_statements_total
          WHERE server_id = sserver_id AND jit_deform_count > 0 AND
            (sample_id BETWEEN start1_id + 1 AND end1_id OR
            sample_id BETWEEN start2_id + 1 AND end2_id)
          ),
        'checksum_fail_detected', COALESCE((
          SELECT sum(checksum_failures) > 0
          FROM sample_stat_database
          WHERE server_id = sserver_id AND
            (sample_id BETWEEN start1_id + 1 AND end1_id OR
            sample_id BETWEEN start2_id + 1 AND end2_id)
          ), false),
        'extension_versions', (
          SELECT count(*) > 0
          FROM v_extension_versions
          WHERE server_id = sserver_id AND
            (sample_id BETWEEN start1_id AND end1_id OR
            sample_id BETWEEN start2_id AND end2_id)
          ),
        'extension_versions_show_date_columns', (
          SELECT count(*) > 0
          FROM v_extension_versions
          WHERE server_id = sserver_id AND
            (sample_id BETWEEN start1_id AND end1_id OR
            sample_id BETWEEN start2_id AND end2_id) AND
            (first_seen > least(start1_time, start2_time) OR last_sample_id < greatest(end1_id, end2_id))
          ),
        'table_storage_parameters', (
          SELECT count(*) > 0
          FROM v_table_storage_parameters
          WHERE server_id = sserver_id AND
            sample_id BETWEEN start1_id AND end1_id
          ),
        'index_storage_parameters', (
          SELECT count(*) > 0
          FROM v_index_storage_parameters
          WHERE server_id = sserver_id AND
            sample_id BETWEEN start1_id AND end1_id
          ),
        'statements_workers_stats', (
          SELECT count(*) > 0
          FROM sample_statements
          WHERE server_id = sserver_id AND
            greatest(parallel_workers_to_launch, parallel_workers_launched) > 0 AND
            (sample_id BETWEEN start1_id + 1 AND end1_id OR
            sample_id BETWEEN start2_id + 1 AND end2_id)
          ),
        'wal_buffers_full', (
          SELECT count(*) > 0
          FROM sample_statements
          WHERE server_id = sserver_id AND wal_buffers_full > 0 AND
            (sample_id BETWEEN start1_id + 1 AND end1_id OR
            sample_id BETWEEN start2_id + 1 AND end2_id)
          ),
        'vacuum_time', (
          SELECT count(*) > 0
          FROM sample_stat_tables_total
          WHERE server_id = sserver_id AND
            total_vacuum_time + total_autovacuum_time > 0  AND
            (sample_id BETWEEN start1_id + 1 AND end1_id OR
            sample_id BETWEEN start2_id + 1 AND end2_id)
          ),
        'analyze_time', (
          SELECT count(*) > 0
          FROM sample_stat_tables_total
          WHERE server_id = sserver_id AND
            total_analyze_time + total_autoanalyze_time > 0  AND
            (sample_id BETWEEN start1_id + 1 AND end1_id OR
            sample_id BETWEEN start2_id + 1 AND end2_id)
          ),
        'db_parallel_workers', (
          SELECT count(*) > 0
          FROM sample_stat_database
          WHERE server_id = sserver_id AND greatest(parallel_workers_to_launch, parallel_workers_launched) > 0 AND
            (sample_id BETWEEN start1_id + 1 AND end1_id OR
            sample_id BETWEEN start2_id + 1 AND end2_id)
          ),
        'checkpoints_done_and_slru', (
          SELECT COUNT(*) > 0
          FROM sample_stat_cluster
          WHERE server_id = sserver_id AND
            greatest(slru_checkpoint, checkpoints_done) > 0 AND (
              sample_id BETWEEN start1_id AND end1_id OR
              sample_id BETWEEN start2_id AND end2_id
            )
          ),
        'restartpoints', (
          SELECT COUNT(*) > 0
          FROM sample_stat_cluster
          WHERE server_id = sserver_id AND
            greatest(restartpoints_timed, restartpoints_req, restartpoints_done) > 0 AND (
              sample_id BETWEEN start1_id AND end1_id OR
              sample_id BETWEEN start2_id AND end2_id
            )
        )
      ),
      'report_properties', jsonb_build_object(
        'interval1_duration_sec',
          (SELECT extract(epoch FROM e.sample_time - s.sample_time)
          FROM samples s JOIN samples e USING (server_id)
          WHERE e.sample_id=end1_id and s.sample_id=start1_id
            AND server_id = sserver_id),
        'interval2_duration_sec',
          (SELECT extract(epoch FROM e.sample_time - s.sample_time)
          FROM samples s JOIN samples e USING (server_id)
          WHERE e.sample_id=end2_id and s.sample_id=start2_id
            AND server_id = sserver_id),

        'topn', topn,
        'max_query_length', qlen_limit,

        'start1_id', start1_id,
        'end1_id', end1_id,
        'report_start1', start1_time::text,
        'report_end1', end1_time::text,
        'report_start1_ut', start1_time_ut,
        'report_end1_ut', end1_time_ut,

        'start2_id', start2_id,
        'end2_id', end2_id,
        'report_start2', start2_time::text,
        'report_end2', end2_time::text,
        'report_start2_ut', start2_time_ut,
        'report_end2_ut', end2_time_ut
        )
      );

      -- stat_activity features
      IF has_table_privilege('sample_act_backend', 'SELECT') THEN
        report_context := jsonb_set(report_context, '{report_features,act_backend}',
          (
          SELECT
            to_jsonb(COUNT(*) > 0) FROM (
              SELECT 1
              FROM sample_act_backend
              WHERE server_id = sserver_id AND (
                  sample_id BETWEEN start1_id + 1 AND end1_id OR
                  sample_id BETWEEN start2_id + 1 AND end2_id
                )
              LIMIT 1
            ) c
          )
        );
        report_context := jsonb_set(report_context, '{report_features,act_ix}',
          (
          SELECT
            to_jsonb(COUNT(*) > 0) FROM (
              SELECT 1
              FROM sample_act_backend_state
              WHERE server_id = sserver_id AND
                state_code = 1 AND (
                  sample_id BETWEEN start1_id + 1 AND end1_id OR
                  sample_id BETWEEN start2_id + 1 AND end2_id
                )
              LIMIT 1
            ) c
          )
        );
        report_context := jsonb_set(report_context, '{report_features,act_ixa}',
          (
          SELECT
            to_jsonb(COUNT(*) > 0) FROM (
              SELECT 1
              FROM sample_act_backend_state
              WHERE server_id = sserver_id AND
                state_code = 2 AND (
                  sample_id BETWEEN start1_id + 1 AND end1_id OR
                  sample_id BETWEEN start2_id + 1 AND end2_id
                )
              LIMIT 1
            ) c
          )
        );
        report_context := jsonb_set(report_context, '{report_features,act_active}',
          (
          SELECT
            to_jsonb(COUNT(*) > 0) FROM (
              SELECT 1
              FROM sample_act_backend_state
              WHERE server_id = sserver_id AND
                state_code = 3 AND (
                  sample_id BETWEEN start1_id + 1 AND end1_id OR
                  sample_id BETWEEN start2_id + 1 AND end2_id
                )
              LIMIT 1
            ) c
          )
        );
      END IF;
    ELSE
      RAISE 'Two bounds must be specified for second interval';
    END IF;

    -- Server name and description
    SELECT server_name, server_description INTO STRICT r_result
    FROM servers WHERE server_id = sserver_id;
    report_context := jsonb_set(report_context, '{report_properties,server_name}',
      to_jsonb(r_result.server_name)
    );
    IF r_result.server_description IS NOT NULL AND r_result.server_description != ''
    THEN
      report_context := jsonb_set(report_context, '{report_properties,server_description}',
        to_jsonb(r_result.server_description)
      );
    END IF;
    -- Report description
    IF description IS NOT NULL AND description != '' THEN
      report_context := jsonb_set(report_context, '{report_properties,description}',
        to_jsonb(description)
      );
    END IF;
    -- Version substitution
    IF (SELECT count(*) = 1 FROM pg_catalog.pg_extension WHERE extname = 'pg_profile') THEN
      SELECT extversion INTO STRICT r_result FROM pg_catalog.pg_extension WHERE extname = 'pg_profile';
      report_context := jsonb_set(report_context, '{report_properties,pgprofile_version}',
        to_jsonb(r_result.extversion)
      );
    END IF;
  RETURN report_context;
END;
$$ LANGUAGE plpgsql;
INSERT INTO import_queries_version_order VALUES
('pg_profile','4.11','pg_profile','4.10')
;

DELETE FROM report_struct;
DELETE FROM report;
DELETE FROM report_static;

-- PWR-238
truncate table sample_timings;
drop VIEW v_sample_timings;
alter table sample_timings drop CONSTRAINT pk_sample_timings;
alter table sample_timings drop time_spent;
alter table sample_timings add exec_point text;
alter table sample_timings add event_ts timestamp;
alter table sample_timings add CONSTRAINT pk_sample_timings PRIMARY KEY (server_id, sample_id, event, exec_point);
CREATE VIEW v_sample_timings AS
SELECT
  srv.server_name,
  smp.sample_id,
  smp.sample_time,
  tm.event as sampling_event,
  tm.exec_point,
  tm.event_ts
FROM
  sample_timings tm
  JOIN servers srv USING (server_id)
  JOIN samples smp USING (server_id, sample_id);
COMMENT ON VIEW v_sample_timings IS 'Sample taking time statistics with server names and sample times';
GRANT SELECT ON v_sample_timings TO public;
/* === report_static table data === */
INSERT INTO report_static(static_name, static_text)
VALUES
('css', $css$
:root {
    --main-bg-color: #68B8F9;
    --main-font-color: black;
    --main-font-family: Monospace;
    --main-font-size: 15px;
    --secondary-bg-color: #a4d4fb;
    --main-bottom: -20%;
    --main-right: 2%;
    --main-opacity: 1;
    --main-border-radius: 5px;
    --main-box-shadow: rgba(0, 0, 0, 0.35) 0 5px 15px;
    --main-position: fixed;
    --main-width: 500px;
    --main-height: 100px;
    --main-transition-property: top;
    --main-transition-delay: 500ms;
}

html {
    scroll-behavior: smooth;
    scroll-padding-left: 30%;
}

div h3 {
    scroll-margin-top: 60px;
    font-family: var(--main-font-family);
    font-size: clamp(16px, 2vw, 22px);
}

div p {
    font-family: var(--main-font-family);
    font-size: clamp(13px, 1.5vw, 18px);
}

.copyButton {
    padding-right: 5px;
}

.copyQueryTextButton {
    padding: 3px 7px 3px 3px;
}

td p {
    display: flex;
    font-size: clamp(12px, 1.2vw, 18px);
}

td p:nth-of-type(2) {
    display: flex;
    align-items: center;
}

.small_p {
    justify-content: center;
}

p i {
    font-size: clamp(10px, 1vw, 13px);
}

p a {
    text-decoration: none;
    color: #059FF5;
}

td {
    scroll-margin-top: 50px;
}

tr {
    scroll-margin-top: 50px;
}

#container {
    position: absolute;
    overflow: auto;
    padding-left: 10px;
    transition-property: left;
    transition-duration: 500ms;
}

#logo, #logoMini {
    display: block;
    margin-top: 1em;
    margin-bottom: 1.7vh;
}

#logo {
    width: 11vw;
    height: 3vw;
    min-width: 105px;
    min-height: 50px;
}

#logoMini {
    width: 40px;
    height: 40px;
}

#logo.hidden, #logoMini.hidden {
    display: none;
}

#logo:hover, #logoMini:hover {
    cursor: pointer;
}

title {
    display: flex;
    align-items: center;
    cursor: pointer;
}

.arrow {
    cursor: pointer;
    margin-right: 5px;
    transition: transform 0.3s ease;
    display: inline-block;
    width: 1.1vw;
    height: 1.1vw;
    min-width: 11px;
    min-height: 11px;
}

.arrow.up {
    transform: rotate(180deg);
}

#searchField {
    width: 100%;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    border: none;
    outline: none;
    background: none;
    font-family: var(--main-font-family);
    font-size: clamp(10px, 1vw, 13px);
}

#searchButton {
    border: none;
    background: transparent;
    cursor: pointer;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    padding: 8px;
    background-repeat: no-repeat;
    background-position: right 5px center;
    background-size: 16px 16px;
    vertical-align: middle;
}

#searchWrap {
    border-radius: 50px;
    outline: none;
    border: 1px solid #8898AE;
    font-family: var(--main-font-family);
    height: 35px;
	box-sizing: border-box;
	padding: 0 0 0 8px;
	line-height: 35px;
	display: flex;
}

#searchDropdownContainer.hidden {
    display: none;
}

option:first-child {
    font-style: italic;
}

#dropdownSelect {
    width: 100%;
    border-radius: 50px;
    outline: none;
    border: 1px solid #8898AE;
    font-family: var(--main-font-family);
    font-size: clamp(10px, 1vw, 13px);
    height: 35px;
    box-sizing: border-box;
    padding: 0 0 0 9px;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
}

#pageContent.hidden {
    min-width: 35px;
}

#pageContent {
    position: fixed;
    z-index: 999;
    background-color: #F4F7FA;
    left: 0;
    top: 0;
    max-width: 19vw;
    height: 100%;
    overflow-y: auto;
    overflow-x: hidden;
    font-size: clamp(12px, 1.1vw, 18px);
    opacity: 1;
    padding-left: 20px;
    padding-right: 20px;
    transition: width 500ms;
    font-family: var(--main-font-family);
}

#pageContent.hidden div.level1 {
    display: none;
}

#pageContent div.level1 {
    font-weight: 600;
    cursor: pointer;
}

#sections {
    padding-top: 2vh;
}

.chapter {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.chapter.activeSection {
    border-radius: 6px;
    border: 1px solid #FFC83B;
}

#pageContent div.level2 {
    font-weight: 100;
    padding-left: 1em;
    padding-top: 3px;
}

#pageContent div.level3 {
    padding-left: 1em;
}

#pageContent div.hidden > div {
    display: none;
}

#pageContent a {
    display: block;
    text-decoration: none;
    color: inherit;
    background: none;
    border: none;
    padding: 3px;
}

select {
    margin-top: 8px;
    border: 0;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    padding-right: 20px;
    background: transparent;
    background-repeat: no-repeat;
    background-position: right 5px center;
    background-size: 16px 16px;
    padding: 8px;
}

#commonstat {
    display: flex;
    flex-wrap: wrap;
}

#commonstat div {
    margin-right: 10px;
}

table {
    margin-bottom: 10px;
    font-family: var(--main-font-family);
}

table tr.header {
    color: #FFFFFF;
    font-size: var(--main-font-size);
    font-family: var(--main-font-family);
    background-color: #647d9a;
}

table, th, td {
    border: 1px solid #B5C2D247;
    border-collapse: collapse;
    padding: 4px;
    font-size: clamp(11px, 1.1vw, 18px);
}

table tr td.table_obj_value, table tr td.table_obj_name {
    font-family: var(--main-font-family);
}

table tr td.table_obj_value {
    text-align: right;
}

table tr td.table_obj_name {
    text-align: left;
}

table tr td.fullScreen, td.halfScreen {
    width: 85%;
    font-family: var(--main-font-family);
    font-size: clamp(8px, 0.9vw, 12px);
}

.lineSvg:hover {
    cursor: pointer;
}

.lineSvg line:hover {
    opacity: 1;
}

table tr td.halfScreen {
    width: 42%;
}

table p {
    margin: 0.2em;
}

table tr.new td.switch_bold {
    font-weight: bold;
}

table tr:target, td:target {
    border: medium solid limegreen;
}

table tr:target td:first-of-type, table td:target {
    font-weight: bold;
}

table tr.active td {
    background-color: #CCF1FF;
}

table tr.active td {
    background-color: #CCF1FF;
}

table tr.active td {
    background-color: #CCF1FF;
}

table tr.active td {
    background-color: #CCF1FF;
}

table tr.active td:not(.hdr) {
    background-color: #CCF1FF;
}

div.warning {
    display: inline-flex;
    padding: 10px;
    max-width: 300px;
    border-radius: 2px;
    margin-bottom: 10px;
    background-color: #FF827B;
    font-size: 12px;
    color: white;
    font-family: var(--main-font-family);
}

div.notice {
    display: inline-flex;
    padding: 10px;
    max-width: 300px;
    border-radius: 2px;
    margin-bottom: 10px;
    background-color: #CCF1FF;
    font-size: 12px;
    font-family: var(--main-font-family);
}

a svg:hover {
    cursor: pointer;
}

svg:not(#logo, #logoMini) rect:hover, svg circle:hover, svg:not(#logo, #logoMini) path:hover, a.copyButton svg:hover > rect {
    stroke: #059FF5;
    fill: #D9FFCC;
}

/* ----------- Differential report styles ----------- */

td.int1, .int1 td:not(.hdr), table tr.new_i1 {
    background-color: #FFEEEE;
}

td.int2, .int2 td:not(.hdr), table tr.new_i2 {
    background-color: #EEEEFF;
}

table tr.int1:not(.active) td:not(.hdr) {
    background-color: #FFEEEE;
}

table tr.int2:not(.active) td:not(.hdr) {
    background-color: #EEEEFF;
}

table tr.int2 td {
    border-top: hidden;
}

table tr.previewRow {
    background-color: white;
}

table:not(.pgprototals) tr.grey {
    background-color: #eee;
}

table tr.previewRow {
    background-color: white;
}

table tr.previewRow p, table tr.previewRow a, table tr.planRow p, table tr.planRow a {
    display: inline-block;
}

table tr.previewRow p, table tr.planRow p {
    width: 95%;
}

table tr.planRow a {
    float: right;
}

table tr.previewRow a {
    float: left;
}

.queryText, .queryTextId {
    font-size: 13px;
}

table tr.new_i1 td.switch_bold, table tr.new_i2 td.switch_bold, .new td.switch_bold {
    font-weight: bold;
}

.label {
    color: grey;
}

table tr:target, td:target {
    border: medium solid limegreen;
}

table tr:target td:first-of-type, table td:target {
    font-weight: bold;
}

table tr.parent td {
    background-color: #D8E8C2;
}

table tr.child td {
    background-color: #BBDD97;
    border-top-style: hidden;
}

table tr.active td {
    background-color: #CCF1FF;
}{static:css_post}
$css$
),
('logo', $logo$
<svg id="logo" width="102" height="29" viewBox="0 0 102 29" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<path d="M34 6.32002V0.720023H36.296C36.6587 0.720023 36.9867 0.80269 37.28 0.968023C37.5733 1.12802 37.8027 1.34936 37.968 1.63202C38.1333 1.90936 38.216 2.21602 38.216 2.55202C38.216 2.88802 38.1333 3.19736 37.968 3.48002C37.8027 3.75736 37.5733 3.97602 37.28 4.13602C36.9867 4.29602 36.6587 4.37602 36.296 4.37602H35V6.32002H34ZM36.28 3.47202C36.5413 3.47202 36.7627 3.38402 36.944 3.20802C37.1253 3.02669 37.216 2.80802 37.216 2.55202C37.216 2.29069 37.1253 2.07202 36.944 1.89602C36.7627 1.71469 36.5413 1.62402 36.28 1.62402H35V3.47202H36.28Z" fill="#053172"/>
<path d="M40.5758 6.40002C40.2025 6.40002 39.8585 6.31202 39.5438 6.13602C39.2345 5.95469 38.9891 5.71202 38.8078 5.40802C38.6318 5.09869 38.5438 4.76002 38.5438 4.39202C38.5438 4.02402 38.6318 3.68802 38.8078 3.38402C38.9891 3.07469 39.2345 2.83202 39.5438 2.65602C39.8585 2.47469 40.2025 2.38402 40.5758 2.38402C40.9491 2.38402 41.2905 2.47469 41.5998 2.65602C41.9145 2.83202 42.1598 3.07469 42.3358 3.38402C42.5171 3.68802 42.6078 4.02402 42.6078 4.39202C42.6078 4.76002 42.5171 5.09869 42.3358 5.40802C42.1598 5.71202 41.9145 5.95469 41.5998 6.13602C41.2905 6.31202 40.9491 6.40002 40.5758 6.40002ZM40.5758 5.55202C40.7838 5.55202 40.9731 5.50136 41.1438 5.40002C41.3145 5.29869 41.4478 5.16002 41.5438 4.98402C41.6451 4.80802 41.6958 4.61069 41.6958 4.39202C41.6958 4.17336 41.6451 3.97602 41.5438 3.80002C41.4478 3.62402 41.3145 3.48536 41.1438 3.38402C40.9731 3.28269 40.7838 3.23202 40.5758 3.23202C40.3678 3.23202 40.1785 3.28269 40.0078 3.38402C39.8371 3.48536 39.7011 3.62402 39.5998 3.80002C39.5038 3.97602 39.4558 4.17336 39.4558 4.39202C39.4558 4.61069 39.5038 4.80802 39.5998 4.98402C39.7011 5.16002 39.8371 5.29869 40.0078 5.40002C40.1785 5.50136 40.3678 5.55202 40.5758 5.55202Z" fill="#053172"/>
<path d="M44.7437 6.40002C44.4024 6.40002 44.0904 6.32802 43.8077 6.18402C43.5304 6.03469 43.317 5.86669 43.1677 5.68002L43.7277 5.11202C43.8344 5.24002 43.9757 5.35736 44.1517 5.46402C44.333 5.56536 44.5224 5.61602 44.7197 5.61602C44.917 5.61602 45.069 5.57602 45.1757 5.49602C45.2824 5.41602 45.3357 5.31469 45.3357 5.19202C45.3357 5.08002 45.2797 4.99469 45.1677 4.93602C45.0557 4.87202 44.8744 4.80269 44.6237 4.72802C44.3624 4.64802 44.1437 4.56802 43.9677 4.48802C43.797 4.40802 43.6477 4.29069 43.5197 4.13602C43.397 3.97602 43.3357 3.77336 43.3357 3.52802C43.3357 3.32002 43.3917 3.13069 43.5037 2.96002C43.621 2.78402 43.789 2.64536 44.0077 2.54402C44.2264 2.43736 44.4824 2.38402 44.7757 2.38402C45.0904 2.38402 45.3704 2.44002 45.6157 2.55202C45.8664 2.65869 46.0557 2.78136 46.1837 2.92002L45.6317 3.48802C45.541 3.40269 45.4237 3.33069 45.2797 3.27202C45.1357 3.20802 44.981 3.17602 44.8157 3.17602C44.6397 3.17602 44.5037 3.21069 44.4077 3.28002C44.3117 3.34936 44.2637 3.43202 44.2637 3.52802C44.2637 3.63469 44.317 3.71736 44.4237 3.77602C44.5357 3.83469 44.717 3.90402 44.9677 3.98402C45.2397 4.06936 45.4584 4.15202 45.6237 4.23202C45.7944 4.31202 45.941 4.42936 46.0637 4.58402C46.1917 4.73869 46.2557 4.94136 46.2557 5.19202C46.2557 5.41069 46.1944 5.61336 46.0717 5.80002C45.949 5.98136 45.773 6.12802 45.5437 6.24002C45.3197 6.34669 45.053 6.40002 44.7437 6.40002Z" fill="#053172"/>
<path d="M48.6881 6.36002C48.2988 6.36002 47.9948 6.24536 47.7761 6.01602C47.5575 5.78669 47.4481 5.45869 47.4481 5.03202V3.31202H46.7601V2.46402H47.1601C47.4161 2.46402 47.5441 2.31469 47.5441 2.01602V1.20002H48.3521V2.46402H49.2481V3.31202H48.3521V4.92802C48.3521 5.31202 48.5335 5.50402 48.8961 5.50402C49.0188 5.50402 49.1628 5.46669 49.3281 5.39202V6.24002C49.2588 6.27202 49.1655 6.29869 49.0481 6.32002C48.9308 6.34669 48.8108 6.36002 48.6881 6.36002Z" fill="#053172"/>
<path d="M51.7039 8.00002C51.3306 8.00002 50.9866 7.91736 50.6719 7.75202C50.3573 7.58669 50.1306 7.40269 49.9919 7.20002L50.5999 6.62402C50.7013 6.75736 50.8506 6.88002 51.0479 6.99202C51.2506 7.10402 51.4639 7.16002 51.6879 7.16002C52.0293 7.16002 52.3013 7.05336 52.5039 6.84002C52.7066 6.62669 52.8079 6.33869 52.8079 5.97602V5.63202H52.7999C52.6986 5.78136 52.5386 5.91736 52.3199 6.04002C52.1013 6.16269 51.8533 6.22402 51.5759 6.22402C51.2719 6.22402 50.9893 6.14136 50.7279 5.97602C50.4666 5.81069 50.2586 5.58402 50.1039 5.29602C49.9493 5.00269 49.8719 4.67202 49.8719 4.30402C49.8719 3.93602 49.9493 3.60802 50.1039 3.32002C50.2586 3.02669 50.4666 2.79736 50.7279 2.63202C50.9893 2.46669 51.2719 2.38402 51.5759 2.38402C51.8533 2.38402 52.1013 2.44536 52.3199 2.56802C52.5386 2.69069 52.6986 2.82669 52.7999 2.97602H52.8079V2.46402H53.7119V5.97602C53.7119 6.36002 53.6266 6.70402 53.4559 7.00802C53.2853 7.31736 53.0479 7.56002 52.7439 7.73602C52.4399 7.91202 52.0933 8.00002 51.7039 8.00002ZM51.7999 5.38402C52.0826 5.38402 52.3199 5.28269 52.5119 5.08002C52.7093 4.87736 52.8079 4.61869 52.8079 4.30402C52.8079 3.99469 52.7093 3.73869 52.5119 3.53602C52.3199 3.32802 52.0826 3.22402 51.7999 3.22402C51.5119 3.22402 51.2693 3.32802 51.0719 3.53602C50.8799 3.73869 50.7839 3.99469 50.7839 4.30402C50.7839 4.61869 50.8799 4.87736 51.0719 5.08002C51.2693 5.28269 51.5119 5.38402 51.7999 5.38402Z" fill="#053172"/>
<path d="M54.8073 6.32002V2.46402H55.7113V2.96002H55.7272C55.8286 2.81069 55.9806 2.67736 56.1833 2.56002C56.3859 2.44269 56.6099 2.38402 56.8552 2.38402H57.0473V3.34402C56.9033 3.31202 56.7939 3.29602 56.7192 3.29602C56.4366 3.29602 56.1966 3.40002 55.9993 3.60802C55.8073 3.81602 55.7113 4.08536 55.7113 4.41602V6.32002H54.8073Z" fill="#053172"/>
<path d="M59.4664 6.40002C59.0931 6.40002 58.7491 6.31202 58.4344 6.13602C58.1251 5.95469 57.8798 5.71202 57.6984 5.40802C57.5224 5.09869 57.4344 4.76002 57.4344 4.39202C57.4344 4.02402 57.5224 3.68802 57.6984 3.38402C57.8798 3.07469 58.1224 2.83202 58.4264 2.65602C58.7304 2.47469 59.0611 2.38402 59.4184 2.38402C59.7811 2.38402 60.1064 2.46669 60.3944 2.63202C60.6878 2.79736 60.9171 3.02669 61.0824 3.32002C61.2478 3.60802 61.3304 3.93069 61.3304 4.28802C61.3304 4.42669 61.3171 4.56269 61.2904 4.69602H58.3784C58.4158 4.93602 58.5411 5.14402 58.7544 5.32002C58.9678 5.49069 59.2238 5.57602 59.5224 5.57602C59.9171 5.57602 60.2664 5.42936 60.5704 5.13602L61.1064 5.72002C60.9571 5.90136 60.7384 6.06136 60.4504 6.20002C60.1624 6.33336 59.8344 6.40002 59.4664 6.40002ZM60.3944 4.01602C60.3411 3.76002 60.2291 3.55736 60.0584 3.40802C59.8931 3.25336 59.6798 3.17602 59.4184 3.17602C59.1464 3.17602 58.9198 3.25069 58.7384 3.40002C58.5624 3.54936 58.4398 3.75469 58.3704 4.01602H60.3944Z" fill="#053172"/>
<path d="M63.9834 6.41602C63.5087 6.41602 63.0927 6.33069 62.7354 6.16002C62.3834 5.98402 62.1114 5.77602 61.9194 5.53602L62.5754 4.90402C62.9594 5.30936 63.418 5.51202 63.9514 5.51202C64.2714 5.51202 64.5247 5.43736 64.7114 5.28802C64.898 5.13869 64.9914 4.95736 64.9914 4.74402C64.9914 4.58936 64.9407 4.46402 64.8394 4.36802C64.7434 4.26669 64.6207 4.18669 64.4714 4.12802C64.3274 4.06402 64.122 3.99202 63.8554 3.91202C63.482 3.79469 63.178 3.68269 62.9434 3.57602C62.714 3.46936 62.5167 3.30669 62.3514 3.08802C62.186 2.86936 62.1034 2.57869 62.1034 2.21602C62.1034 1.92269 62.1834 1.65602 62.3434 1.41602C62.5034 1.17069 62.73 0.97869 63.0234 0.840023C63.322 0.696023 63.6634 0.624023 64.0474 0.624023C64.4474 0.624023 64.8047 0.69869 65.1194 0.848023C65.4394 0.997357 65.6874 1.17069 65.8634 1.36802L65.2154 2.00802C65.0714 1.87469 64.9034 1.76002 64.7114 1.66402C64.5194 1.56802 64.3087 1.52002 64.0794 1.52002C63.7754 1.52002 63.5407 1.58669 63.3754 1.72002C63.21 1.85336 63.1274 2.01869 63.1274 2.21602C63.1274 2.37069 63.1754 2.49869 63.2714 2.60002C63.3727 2.69602 63.4954 2.77602 63.6394 2.84002C63.7887 2.89869 63.994 2.96802 64.2554 3.04802C64.6287 3.16536 64.93 3.27736 65.1594 3.38402C65.394 3.49069 65.594 3.65336 65.7594 3.87202C65.9247 4.09069 66.0074 4.38136 66.0074 4.74402C66.0074 5.04802 65.9247 5.32802 65.7594 5.58402C65.594 5.83469 65.3567 6.03736 65.0474 6.19202C64.7434 6.34136 64.3887 6.41602 63.9834 6.41602Z" fill="#053172"/>
<path d="M72.5563 6.74402C72.6842 6.74402 72.8016 6.73069 72.9082 6.70402V7.56002C72.8016 7.58669 72.6736 7.60002 72.5243 7.60002C72.1616 7.60002 71.8283 7.53869 71.5243 7.41602C71.2202 7.29336 70.9616 7.13869 70.7482 6.95202C70.5402 6.76536 70.3829 6.57602 70.2762 6.38402C70.1269 6.40536 69.9669 6.41602 69.7962 6.41602C69.2362 6.41602 68.7269 6.28802 68.2682 6.03202C67.8149 5.77069 67.4576 5.41869 67.1963 4.97602C66.9349 4.53336 66.8042 4.04802 66.8042 3.52002C66.8042 2.99202 66.9349 2.50669 67.1963 2.06402C67.4576 1.62136 67.8149 1.27202 68.2682 1.01602C68.7269 0.75469 69.2362 0.624023 69.7962 0.624023C70.3563 0.624023 70.8629 0.75469 71.3162 1.01602C71.7749 1.27202 72.1349 1.62136 72.3963 2.06402C72.6576 2.50669 72.7882 2.99202 72.7882 3.52002C72.7882 4.06936 72.6469 4.57336 72.3643 5.03202C72.0816 5.48536 71.7002 5.83202 71.2202 6.07202C71.3269 6.24802 71.4976 6.40269 71.7323 6.53602C71.9723 6.67469 72.2469 6.74402 72.5563 6.74402ZM69.7962 5.50402C70.1589 5.50402 70.4922 5.41602 70.7962 5.24002C71.1003 5.06402 71.3403 4.82402 71.5163 4.52002C71.6922 4.21602 71.7803 3.88269 71.7803 3.52002C71.7803 3.15736 71.6922 2.82402 71.5163 2.52002C71.3403 2.21602 71.1003 1.97602 70.7962 1.80002C70.4922 1.62402 70.1589 1.53602 69.7962 1.53602C69.4336 1.53602 69.1003 1.62402 68.7962 1.80002C68.4922 1.97602 68.2522 2.21602 68.0762 2.52002C67.9002 2.82402 67.8122 3.15736 67.8122 3.52002C67.8122 3.88269 67.9002 4.21602 68.0762 4.52002C68.2522 4.82402 68.4922 5.06402 68.7962 5.24002C69.1003 5.41602 69.4336 5.50402 69.7962 5.50402Z" fill="#053172"/>
<path d="M77.6408 6.32002H73.9688V0.720023H74.9688V5.40002H77.6408V6.32002Z" fill="#053172"/>
<path d="M39.766 9.6C40.7633 9.6 41.6727 9.78333 42.494 10.15C43.33 10.5167 43.99 11.052 44.474 11.756C44.958 12.46 45.2 13.296 45.2 14.264C45.2 15.188 44.9727 15.98 44.518 16.64C44.0633 17.3 43.4327 17.806 42.626 18.158C41.8193 18.51 40.9027 18.686 39.876 18.686H38.468L38.49 17.916L45.948 25H42.67L35.19 17.52V16.816H39.282C40.338 16.816 41.1667 16.6033 41.768 16.178C42.3693 15.738 42.67 15.1073 42.67 14.286C42.67 13.45 42.3693 12.8047 41.768 12.35C41.1667 11.8807 40.338 11.646 39.282 11.646H36.158V25H33.738V9.6H39.766ZM52.1095 25.242C51.0242 25.242 50.0489 25.0073 49.1835 24.538C48.3182 24.054 47.6362 23.394 47.1375 22.558C46.6535 21.722 46.4115 20.776 46.4115 19.72C46.4115 18.6787 46.6535 17.74 47.1375 16.904C47.6362 16.0533 48.3182 15.3933 49.1835 14.924C50.0489 14.44 51.0169 14.198 52.0875 14.198C53.1289 14.198 54.0529 14.4253 54.8595 14.88C55.6809 15.32 56.3189 15.9433 56.7735 16.75C57.2282 17.542 57.4555 18.444 57.4555 19.456C57.4555 19.7493 57.4335 20.0647 57.3895 20.402H47.5335V18.73H55.6735L55.2995 19.324C55.2262 18.3267 54.9109 17.542 54.3535 16.97C53.7962 16.398 53.0555 16.112 52.1315 16.112C51.1049 16.112 50.2762 16.442 49.6455 17.102C49.0295 17.762 48.7215 18.6273 48.7215 19.698C48.7215 20.754 49.0369 21.612 49.6675 22.272C50.2982 22.932 51.1269 23.262 52.1535 23.262C53.3855 23.262 54.3829 22.712 55.1455 21.612L56.9055 22.778C56.3922 23.5553 55.7175 24.164 54.8815 24.604C54.0455 25.0293 53.1215 25.242 52.1095 25.242ZM61.9499 19.742C61.9499 20.402 62.0966 20.996 62.3899 21.524C62.6832 22.0373 63.0792 22.4407 63.5779 22.734C64.0912 23.0273 64.6559 23.174 65.2719 23.174C65.9026 23.174 66.4746 23.0273 66.9879 22.734C67.5012 22.4407 67.9046 22.03 68.1979 21.502C68.4912 20.974 68.6379 20.38 68.6379 19.72C68.6379 19.06 68.4912 18.466 68.1979 17.938C67.9046 17.41 67.5012 16.9993 66.9879 16.706C66.4746 16.4127 65.9026 16.266 65.2719 16.266C64.6559 16.266 64.0912 16.42 63.5779 16.728C63.0792 17.0213 62.6832 17.432 62.3899 17.96C62.0966 18.488 61.9499 19.082 61.9499 19.742ZM61.8179 14.44V17.102H61.3339C61.5099 16.6327 61.8032 16.178 62.2139 15.738C62.6392 15.2833 63.1526 14.9167 63.7539 14.638C64.3699 14.3447 65.0372 14.198 65.7559 14.198C66.7092 14.198 67.5819 14.4473 68.3739 14.946C69.1806 15.43 69.8186 16.0973 70.2879 16.948C70.7719 17.7987 71.0139 18.7227 71.0139 19.72C71.0139 20.7173 70.7719 21.6413 70.2879 22.492C69.8186 23.3427 69.1806 24.0173 68.3739 24.516C67.5819 25 66.7092 25.242 65.7559 25.242C65.0519 25.242 64.3919 25.1027 63.7759 24.824C63.1746 24.5453 62.6686 24.1933 62.2579 23.768C61.8472 23.328 61.5539 22.8733 61.3779 22.404H61.8839V29.84H59.6619V14.44H61.8179ZM74.8481 19.742C74.8481 20.402 74.9948 20.996 75.2881 21.524C75.5814 22.0373 75.9774 22.4407 76.4761 22.734C76.9894 23.0273 77.5614 23.174 78.1921 23.174C79.1601 23.174 79.9594 22.8587 80.5901 22.228C81.2208 21.5827 81.5361 20.754 81.5361 19.742C81.5361 19.0673 81.3894 18.466 81.0961 17.938C80.8028 17.41 80.3994 16.9993 79.8861 16.706C79.3728 16.4127 78.8081 16.266 78.1921 16.266C77.5614 16.266 76.9894 16.4127 76.4761 16.706C75.9774 16.9993 75.5814 17.41 75.2881 17.938C74.9948 18.466 74.8481 19.0673 74.8481 19.742ZM72.4721 19.742C72.4721 18.774 72.7068 17.8647 73.1761 17.014C73.6601 16.1633 74.3348 15.4813 75.2001 14.968C76.0801 14.4547 77.0774 14.198 78.1921 14.198C79.3214 14.198 80.3188 14.4547 81.1841 14.968C82.0494 15.4813 82.7168 16.1633 83.1861 17.014C83.6701 17.85 83.9121 18.7593 83.9121 19.742C83.9121 20.7247 83.6701 21.634 83.1861 22.47C82.7168 23.306 82.0494 23.9807 81.1841 24.494C80.3188 24.9927 79.3214 25.242 78.1921 25.242C77.0628 25.242 76.0654 24.9927 75.2001 24.494C74.3348 23.9807 73.6601 23.306 73.1761 22.47C72.7068 21.6193 72.4721 20.71 72.4721 19.742ZM88.0907 14.44V16.684H87.9587C88.1054 16.0973 88.4647 15.5767 89.0367 15.122C89.6087 14.6673 90.3567 14.44 91.2807 14.44H93.0847V16.464H91.5447C90.5474 16.464 89.7627 16.706 89.1907 17.19C88.6187 17.6593 88.3327 18.488 88.3327 19.676V25H86.0447V14.44H88.0907ZM99.6027 25C97.0361 25 95.7527 23.7093 95.7527 21.128V11.734H98.0407V20.49C98.0407 21.1207 98.0701 21.6047 98.1287 21.942C98.2021 22.2647 98.3781 22.5213 98.6567 22.712C98.9354 22.888 99.3681 22.976 99.9547 22.976H101.539V25H99.6027ZM101.539 14.44V16.464H94.0807V14.44H101.539Z" fill="#053172"/>
<rect y="1" width="26" height="27" fill="url(#pattern0_1_7009)"/>
<defs>
<pattern id="pattern0_1_7009" patternContentUnits="objectBoundingBox" width="1" height="1">
<use xlink:href="#image0_1_7009" transform="matrix(0.000874126 0 0 0.000841751 -0.00393357 0)"/>
</pattern>
<image id="image0_1_7009" width="1153" height="1188" preserveAspectRatio="none" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABIEAAASkCAYAAAD0VxpEAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAQwiSURBVHgB7N1/jN31fef79/ZmCUM8hILJjR1bnAUxLumtPMW9Ae/V4gMkvZUYNzQVUZ1KtbNSCP3jFgKs9kdWsi21yt0Vv3y3EuDsKjOVtm6CEux6kJrlR84QqQNRDTPaFIdBkOP1YKfBUDtjYcJqpXve58zXczyeH+fH9/v9vD7f7/MhHc34RxLHnvme7/f1ef/4JwYAAAAA+bpi/uUqi37c/vk1y/xnkv/cSv+9vagv8XOn519L/dg/nln0n60v+u9b/J8HgGD+iQEAAABA7yptH9s/v6bt8ysWvcooCYPq8z+u20KIVF/083UDgAwQAgEAAABYSsVagU37x2uW+DlkIwmMko/H5j+fWvRrANAxQiAAAACgfJKKnOH5j5ttIdRJXtDXHgZ5OHTMFiqJkp8HgPMIgQAAAIBiqthC0OOfX2MLoU/FUAbtlUPT85/X5z8CKCFCIAAAACBeSaDj4U5SzZOEPmWdvYPOJOFQUkE01fZzAAqKEAgAAADQV7GFcGezEfQgO+3h0IRROQQUCiEQAAAAoCOp5Ekqewh7oKJmrUAoaSurGYDoEAIBAAAAYVQar6q1wh7/PAl8gFgkLWQEQ0AkCIEAAACA7LVX91SN6h4UV80WWsmSQdQARBACAQAAAOmq2EKFT9UIfFBudVsIhWrGfCEgKEIgAAAAoHce7lQbr222UO1D4AMsLxk6fchoIQNyRwgEAACwtMoqP3ZX2OoP/PUufu20sZ5ZnYc8VbuwygdA7wiFgBwRAgEAgKJKAprKos/dNfMf23/NrLNQJ0/1VT73h6czi35uuY/oXrKpy6t8qkaVD5AHv67VbCEUon0MSBEhEAAAiFFl0ctDnfbAp2JYrG4LlUbJ61jb5/VFn5dREvp83hYqfgCEVbeFUMg/Ui0J9IEQCAAAKEqCnGRl9jW2UIVRMeShPRjyj8eW+Lm6xY3QB4hPzRYCIaqEgC4RAgHxq7R9bG9jSH7+47Z0m8NSLQ9ptEHUF/148XyL9h8v1cbQ/ut1Yz4GUHQVWwh6Nrd93u+1CPmp28VhUX3Rzyup2kJ7V9UAxKxurTBozJglBHSEEAjQkwQxw22fL25zaH+VxeIWhbothEh1u7C9IfkxAB3JBqWKEfaUTXvVkL88JJqyhWGwWas0XnfaQrUPX3NAMbXPEvKPdQNwEUIgIF+LA57NthDuJC+kp24Xnk6fWeLnCIuA9FVsYZiuf141HryxvPZAKAmIkp/rRXuLl4c/FQNQRjVbqBCqG4AmQiAgfcyxiMtSMy/qi14Alpc8cLdvUCLwQRqSYMg/TtjK1UMVo9oHwPJqRiAENBECAb1rf/BJgp6KEfQUUfLgUbeL2xioJELZ+LXPH7a9krFqrWsfkKf262/dqPYB0J2aEQihxAiBgNW1V/Ykcyw4ZUSi/WFkev7zutFqhuJIQp+kyqdiAAAUQ80IhFAyhEDAhZLAp2oXBj5AL+rzr7TmXAB5SAY4e+hDhQUAoCwOWmuo9KgBBUYIhLKr2ELg4x8JfJCHpHqIcAgqqsbKbAAAnN+PeSDE2nkUEiEQyoThpVDXHg5N2MKqUyBt7S1edxrXQgAAllK3VmXQmNEuhoIgBEKRJaFPEvgwxwexSuYMJdtxqBpCL/z6t8vYngQAQC9q1gqDRg2IGCEQiqZqhD4oh7q1wiAfRl0zgiEsrdJ47TTavAAASEvdWvdee43qIESIEAixq9iFW2sIfVBmdSMYAsEPAAB5qRnVQYgMIRBiVLVWOwNba4DVLW4lqxmKqL3Vq2oAACBPdaM6CJEgBEIMGGAKpKtmC8Onk5AI8UmujUnVDwAACO9g47XPOHiDKEIgqGKAKZCful0YCtUMyqrWujbuMq6NAACoqlurMshDIdrzIYMQCEpoZwB01KwVCB0yZgsp8Ovjvda6RlYMAErkiiuuaL46/XE/Tp8+3Xwt93NL/TqwirrRKgYhhEAIjeAHiENSIUQLWb6qjddu4/oIIFJJQJO8KpVK8+eTj9dcc80FP04+Lv5cUXsgVK/XL/i5Y8eOnf/5xb8v+b0opVFrtYpNGRAIIRBC8ODHW7x2G61eQKym7MJKobohLUnVz33G9RGAoPZAx1/+uYc57T/fHvjgYkkwlIRE/vHMmTPnQ6L2X0Mh1YytYgiEEAh5qhpzLICiIhTqX9VaQ5592DPXSABBLA53/KMHPO0/l1brFTozNTV1PhTyCqMkKKKqqBDq1moTGzUgJ4RAyFpyou0PNcMGoCza28f8I0eZy6saLV8AcpKEOMPDwxcFPEnIg7gkIZF/9JCo/ceIRt0Ig5ATQiBkpWo81ABYULOFSqGagZYvAJlZHPRs3rz5gqAH5eFBUFIxNDExcT4cos1MVt1aYVDNqKpGRgiBkCYeagB0wu882wOhMh1Vcp0EkJqkXcvDniToSYIfYCVJEOTBUBIUUTkkpW6tqqAxIwxCygiBkIaqMccCQO/q1gqDklCoiMeTFWtVR3KdBNA1wh7kpVarXdBW5j9GUHUjDELKCIHQD3+Y8RPtqgFAemq2MEuoZnGrGq2xALrQHvB44FOtVgl7EJSHQf5KqoaoGAqiboRBSAkhELpFKwOAPNUtziqhqhH+AFiFhzse8njY48GPvxjMDHXJXKEkGPJqIWYM5aZuDJBGnwiB0CnCHwAKaqY9S6hqhD8AlpBU+Gzbto3AB4VDtVDu6kYYhB4RAmE1FWs90OwyANBSt1YYNGbh28Yqjde3jPAHgNn5zVxJ6OPVPgQ+KJNk0PShQ4cIhbJVN8IgdIkQCMupGqfZAOLhdeg1a1UJHbT82sYqRlAOlF57W5d/9PAHwIL2UMjbx/zHSFW98fqate6BgBURAmGxqhH+AIhfzRYqhOqWPlpkCyAZtrv4o1dsJFUbH//4xy+o4Gj/tW75zIzFczN8A89Sv97+gOSfL/WfRTj+tXLnnXcyuBnoUVIdlIRCXN9S4yGQh0F1A5ZBCIRE1Qh/ABST16AngVC/9eiEP8KSgMYfyP3ln19zzTUX/HzyecytOe2hUPLyMMk/tv9a8jn655U9HvbQ2gVkw4OgJBCidSwVo9ZqE6sbsAghECrGHAvMS+PBiNNqiKtb65QsGS7djV3WCssrhiCSa1SyPtsDniTwSQIeXMzDoCQQ8o9nzpxpPmQlP6Yt42JJpQ+hD5A/vyZ5GDQ2Ntb8iL7ssVYYBJxHCFReFWOORfTaT7TbH4CSsnR/QFr8+9pvZPMqX29/wGgPido/T1oikt+bfGw/0QZSVrfOBktXjUrJXCVblPyjt9u0Bz3IRhIG+cuvx0lIlHwsOn9vTEIf/0joA2jw6097lRD3gz2pG8Oj0YYQqHxoZYhAEugk62PbWxqSXyvrw1D7qXVysu2n2ot/npsEdKluFwdCFSMsz1T7BiUPe5LghwdwLe0VQ9PT04UJiNrbu/wFQF97hRD3el2rN163Gi1ipUcIVB6EP0KSU25/0PEHn/bAh5Pu9LTPxEhOtxe3RdC6hiXUrTU7qGpcL1Pj17dkgK4/eCeBD+LWHghNTEycP7VXlFT7fP7zn6fFCygAAqGejRrzgkqNEKgcqtaa+1Mx5KZ9bkXSzsBDj572E+7FQREhEdC7ZJAu25PKyUOhpHIoGfQa4npKtQ9QDgRCXasbLWKlRQhUbMON16PGHItMtbczeMtW8jknjMXQ3vLgDzNJOFSWORlAJ5LrYPKwzTUQS2mvGErWQ2fxsOZfg17t41U/hI9A+SSB0MGDB7lXW13daBErHUKgYvI7b59jcZ8hVbQzoN3igCh5oGG1KYqO0AdpSa6Z7cFQLw9tSfCza9cuvhYBnDc6OtocKu2BEFY0arSIlQYhUPH43J89xhyLvrVX+BD4oFtLzcmgeggxS1Zm+4M2oQ+y5NdKP8lPgqHlqoUIfgB0Klk7v2/fPg7rllc3WsRKgRCoOGj96pM/4LTPr/CHHCBti8MhKoegKgnCaatBaMl10k/z/WMS/jDjB0Av/DriYRDzg5blZVNfM6qCCosQKH60fvUoCX2SdgYecBBSctrdb0sE0I9ke9LOnTup9gEAFJ63iyUDpXGRPdaqDELBEALFrWps/epY8nDjlT6caiMGyel3Mm8oqyGqKDe/Nno7DZUVAICy8vurvXv3Uh10sboxOLpwCIHiRPVPh1gNi6LJa7sOio3gBwCApVEdtKQ9RlVQYRACxadqVP8sK6n28eDHP9LKgDJIa7sOio3gBwCAziWzgzwUQlPdqAoqBEKgeFD9swwebICLJWFQezCEcvLros/4IRgHAKB7yWYxbxej+rppj1EVFDVCoDhUjeqfCxD8AN1pbyPzGxmqhYrNr5H33nuv3XfffQQ/AACkxKuCCIOa6kZVULQIgbRR/dOG4AdIlwdBHggl1ULc0MTNr5F+bfTwh2skAADZ8fsnnxtEqxhVQTEiBNI13Hg9bSWv/mlfV8xDDZCtpNyZFrK4UPUDAEAYyVaxkodBdaMqKCqEQJrubbwesxLzwMcrfrzyh4caIIxk4PShQ4cIhQT5dXL37t0E5AAABEYYZD5jwCuCSv0MGwtCIC0Va83+qVoJcZoNaCMUCo+2WAC42Nz7v7S5c7+0tKy/6nIDeuH3SsmK+ZK22Y9aKwyqG2QRAumoWkmHP3OaDcSpvX3MPzJTKDuE5ACK5MS7v2h+PNn46AHO2fkA58S7c/M/3/rowY7/evJ7E+0/n4fByz5qgwMfbX6+pvHRf9z+82sGLml93vzxJed/j7/8c0Kl8il5GFRvvL7WeB00SCIE0uDDn/dYifBAAxRPUh3klUIeCrF9rH+VSqU5E41rJQBlSSWOBzXNYOfch82f8zDHf/7EqV80g568wxslSWC0rhEI+efrrhxsflx/1WDz59zQhqvPB0wohpKHQXuModGSCIHC8jt6H/5ctZJg1g9QHu1VQv5C5zz88QpJv1YCQEjNMOe9X5wPcrxax8OdE+cDn/IGO1nxyqEkLBrasHbRx6sN8SlxGFQ3hkbLIQQKp1Tbv2j5AsrNq4I8CEqqhGgdWxrXSgB5S6p4Zo6/0wh75pphz8LHXxDwCEpCIg+G1q+9vFlV5B8JiPSVNAzy0nBvDxs1SCAECsO3f+2xViVQYSXr3b3ta3h42AAg4W1j7aFQ2RH+AMiaV+4kQc/M8VPng58TbbN2ED8PglqB0NrzIRHhkJ6SbhPzzWFfMwRHCJS/Rxuv+6zAmPcDoBtlrhKi7QtAmpLWLQ93Xm8EPa3Ah6AHF4dDQxuvZmC1gBKGQXWjPSw4QqD8FH7+D+EPgDS0B0JFXUPv10gPf/x6CQC98GDnlZlZwh70LJkx5KHQlqFPUTUUUMnCINrDAiMEykel8fqBFXT+D+EPgKwka+i9d74IbWNcLwF0y6t7ZmbfabxONdu4Xm+2dDGrB9lIgiEPhfzFxrJ8HTx40L72ta+VpSp6j7E9LAhCoOxVrVUBVLi7fR5mAOQp9rYxv17u2bOH6yWAZS0OfI7MzFLdg+A8CNq00auFNtjQxrVUC+XAK4K8MqgEYZCXfP+e0R6WK0KgbPkA6MesgJI2Bh5mAITSXiGkfJPkw56/9a1vNef/AMBqxidfs/3jPyL8gSyfJeQzhaqbryUUypAffj322GPNMKjg6tYKgoo5A0AQIVB2dlurxK1QfHipB0A8zABQ4rODPBDyMmqVQMivkx7+sPELQC+8Cmh88qgdbrwAZe2h0I0+W4iB06kq0bwgnxNUyAIKNYRA6fPSGN8AtssKhPXFAGKRrJ/3UCjEYOmkVdZbvwCgX14R9M3xlwmDEA0PgXye0LZGKOQtZMwUSkdJ5gWxRj4HhEDp8gDIB0APW0Fwkg0gZn6j5DdNeQVCd955pz366KNUS0bK57HMnWsN2z0534rjP3f23MIA3rlzH/Y8kNcfhAYHLjn/4zUDH73g4Wjd/On54KKfBxxhEGLlQVB1+Nrzg6bRHz9k2rdvX7NdrKCYE5QxQqD0VKxAG8AY+gygaLIMhAjMNSWhjgc6/koCnJPvzjV/vvV5K+xRnb/iJ+rtYVHrx5c0f7z+qsHzv+avdVdeTnhUAv616m1i/mJuEGLTXiVUHb7O0JsStIjVG69bjSAoE4RA6ahYgQIgTrIBFJ3fPPmNkwdC/ZZVMyg/nCTkmWmuzJ6zE6d+0faxvCu0/SHLq4pawdDg/Mrnta0fN36eeR3FQBiE2Pk1qVklxCyhnhV8i5iXOvlUbOYEpYwQqH/e+uUr4CsWOU6yiyG5EWyeere1MZxonHy71s992Pp8/iQ8sbjtoRdrlmhjaH9TX9c4uV74+cH5n5tvgWj855r/eVohkCOvCvKy6m63jPm10gPz4eHCdADL8uva4qDHf8yDb++SoKj1cfB8SOStGlx/48NGMRSBB0Lbt95AINQDbxEr8BaxPdYKg5ASQqD++J2/VwBFf/zLSbY2v6k7O3/avbidwR+I/NcWBzpF0Jqf8dHzIVHysJLM1UhOuj044mYBaehk7bxfJ5NrJtI3M/tO81r3+vFTjc9PNX9c1oqeUNrDIA+H/LV+7eXM8ogAYRCKgkCoe37fcuuttxa1KoiB0SkiBOpd1VoVQFGnJn6S7dU/tH6FlZxye5jjDz5eqfP6/I+5ketccrK98Plgs9pooS2CeRnoXDI/yD8muGamy69vr8zMNq97R2beLnULVyw8CGoFQoRDqmgTQ9EkgZDPEeI+bnWPPfZYsyqogIOjGRidEkKg3uxsvEYtYpxk569ZvfPeL86fcNPOEEYSBvmDi8/KuPAjIREu5idqXhnkN1NcM3vn18Bmlc9sK/A50gh/CHyKIakc8lBo08bGx41rCYYEJGHQgRem+F5DYSRhEEOlV1bgwdF1Y2B03wiBuhd9AMRJdvba2xkIe+KyVBsEczKA3njQ0wp83qatq4T89J5gKDxWy6OIki1jO24f5tqygoIOjq5bqyIo3VWvJUII1J2oAyCqf7LhDzbNB5xG4PN6c3Ap7QxFxZwMYGX+sDkx/ZbVpt4i9MFF2iuGqsPXEq7njDAIReXXki81wiDmBy2twFVBPiOIzWE9IATqXNQBkG+vefrpp6n+6ZM/0CQn2wwsRTvmZKCMkhYvD308/KHiEd3y6+SmjWubVUM8wOWDMAhF5u1iI42XX1NwoYLOCtpjbA7rGiFQZ6IOgO69997mNz26lwwtPTJzohn+8ICDbhEOoWg8+JmYftNq0z9lrg9Sl7R4EAplrzb1pj3y1A+5t0Eh+bXj7pGbuI4s4lVBX/7yl5uzDgtkjxEEdYUQaHVVa62Bj45X/fjsH58BhM4kDzc+y4dTbWSFIaqIjV8bx1862qz48eAHyEsSCvkgWA+GaB9LH2vlUXReHcTsoAvt2bOnWRVUIKON15cNHSEEWtmwtQKg6NbA33nnnc0AyOcAYWXtg0t5uEFISVvE0MZWQEQpM0JKQvHDkz/h2ggZybBpnynENTJd+8dfbr6AokpWzXu7GFpVQbfeemuRhkb7oGjfHFaofrcsEAItL9oA6NFHH2X48wqSBxtv8ao1PtLKAGXt8zKoGEIePPAZbwQ/XB+hzquC/NpY3XwtLR8pYV4QysCvFV4Z5BWGXDfMvva1rxVpdEjdWCG/KkKgpVWsFQBVLCLe/uXDn30INC7U3srAMGfErL2VzFskvGqIGxj0y6+JB16Yar64PiJWzUCoWSH0KQLzPvnG0wefGKdFDIXnlUFfGbmp9PdSBVslXzeCoBURAl2sYhEGQD73xwMg2r8WMMMCZeE3Lh4GtR58aCND53ww7IEXprlGonD8uuin/LSN9Yd5QSgLtooVbmh03QiClkUIdKGKRRgAsf1rATMsgJZkbkayZYdhqkhQ9YOySYZLsza6N7SIoUz8GnH3yGdKfa0o0NDouhEELYkQaIGX0HgAFE0vlVf9+PyfXbt2Wdl54OMVP175w0MNcLH22ULMzignv076iT4BOcqMQKh3Hgbd88j3qApCKSQr5ss6RNqrgbwqqADtYT4k2oOgKcN5hEALnm687rRIMP+H02ygH8mDEAOni4+WL2BpBEK9oUUMZVLmMKhA7WEEQYsQArXsbrz2WCQ8+PEAyIOgMuI0G0hfMleILTvFQEgOdMeveSPzM0G4/q2OFjGUTZnDoIK0h3kQ9OXG66CBEMgiC4B27tzZnP9TtgHQyQPNeONmg5MnIHvtlUKEQvEg/AH659c9HxLrg6WZp7YyqoJQNmUNgw4ePNhcJV+A9rBdjdeYlVzZQyBv/3raIrF79+5mElsmflNx4PkpZv0AgXm7WCsUYtC0IsIfIBtsDOrM/vGXmy+gLDwMuv+LtzQrqMvCA6Bbb72VIKgAyhwCVRqvV601EFqeD4C+7777rCxo+QK0+QORr15mJX1YhD9APvyBb8ftw83qICojl8bgaJSR3wPt3vnZ0lwXTp8+3WwNK8Bm6l1W4iCorCFQxSJZBV+2DWCEP0B8vCqoGQoxTyg3hD9AONXh62zk5l9rfsTFqApCGXnV4FdGbirNPVBB5gTtspIGQWUNgbwCSH6tlgdAP/jBD0qxAYzwByiOpHXMK4WoEkqfz+B4+KkfEv4AgSWzQQi/L0ZVEMqqTGFQQdbI77ISBkFlDIEebbzk+6p885cHQEXfAEb4AxQbVULp8evkw9950WZmTxkALcwOWhpVQSijpH10x23FP8gvyJygXVayIKhsIVAUm8DKEAAR/gDllMwS8kohrxjC6vwkfe/Yc1wvgQj4de1LjYe/Mq6RXg5VQSirsmwS8zlBXhHkG8QitstKFASVKQTyKPZVE1f0AIjwB0AiWUPP6fnSvN3LT9B97g+AuDBI+mJUBaGs/PDr/rtuKfy1oABzgn6z8SrFTVdZQqCKRTAIusgBkJ/+fLPxxn948qgBwGLtbWP+0FT2FfQe/PjDEnN/gPiVbWDsSqgKQpklLWJFvhZEHgSdbrxutRIEQWUJgeQHQRc1AGKDDYBeeCDkD05lmyM0M/uOPfydH1ItCRQQc4MWUBWEsipDi5gPjP693/u9ZptYhEoRBJUhBJKfA1TUAMg32HjrF6c9APqRzBEqcltFEpjzUAQUn1/T7h75TOnDIA+7fd4Z94koo6K3iEU+MNqDIG8Nq1tBFT0E2tV4fcuEFTEAYogpgKz4TdND94xYkfAgBJRTWYbGroRxASg7vwb4q4giD4Lq1qoIqlsBFTkEqlirDewKE1W0AIiTbABZ8gemJ+7/QmFOzRj8DMARBrWqxx9+6oeMDkAp+TVg987PFrI6MPLNYXUraBBU5BDopyY8CLpoARAn2QCyVLQAiGsmgMXKHgYxNBplV+Qh8l/72tfsscceswjVrdUaFuWAo+X8b1ZMPgfoThNVpADIT2z+/Om/tW/85Q9s7hynNwDSV6QAiGsmgOX4NaE2/ZaNTx5tbkgc2ni1lYn/f/btSe7IzNsGlM3M7CmbaFwDivj9/zu/8zvNjxMTExYZ7yryP/y3G68PrCCKGAJ5+POEibriiitscnKyEAGQn2T/yX/6a5t87ZgBQBaKFABxzQTQibKHQd4SM7Rhrf34p/9AWI7SSb7/T777i+b3vl8DiqJarTY/RhgEfbLxurnxGrOCKFoIVGm8DpjoHCAPgLwC6Nd+7dcsZpxkA8hDkQIgn/vz7/7z33DNBNCxModBlU9eaduGr7WZ2XcaD8NzBpRNUauCPAjyYohDhw5ZZCrzr+j+4EspWgj0aONVNVGPP/74+VK4WPmbsfdrc5INIEtFCYB8tsWDTzxj333xvxsA9CIJg7xFatPGtXbV5R+zMvCH3+1bP938nPYwlFF7VZBXyH30n37EimB4eLj5+v73v28ffBBVh9Xw/MfoSpkWK1IIdG/j9W9M1O7du+2+++6zmPlJ9oOPP8NJNoBM+Y3/t/71F6MPgLz9655Hv2f1n/2jAUC//EHwuy/+uJBtIiuhPQxl51VBz/7dG43v+7WFGRrtnTFeHPHtb387tiCoOv8x6iCoKNvBKia8Dt4DoD179lis/CTbt9j4Aw0AZMkfap68/wuNG/64S58f/s6LrH4HkKkibxJaSrOy8vHx5gMxUFa+QdBfRVGv1+3WW29tfozMLot4RlBRQiDZdfD33ntvrOvwmlhjDCBPD91zh1WHr7NYEZoDyFNzo9Ztw4V6KFzN/vGXmy+grIo0M9FFGgT5yvhbG68oT/yK0A4muw7eex1HR0ft0ksvtRgxyBRAnh744i3n5z/EyIOff/XEM83ZaQCQhw//5/9qzssp0/Bobw8bHPio/bj+s+b/f6Bs/Nls/KWjzRlBv/HPPmmx8+VJd955Z3NY9OnTpy0S/oDvw359UHQ0f+hE7JVAFWtVAcnxqee+CSzGVfC+/euRp160w40bCgDIQ+zlzR6aewsYAIRUtAqBlXjlpS8roVodZeZtofffdUshZoRFWhFUb7x+0yILgmIPgSTbwDzNfPXVV6MMgHhDBZC32AMg5v8AUFOWeUF+v+oHl7WptwwoqyKFv5EGQX4T+JsWkZjbwXwb2B+YoG984xtRroJPNtm8+4v3DQDyUB2+1v7tl26zGPnDx1cf+a5NTPPwAUCLD09uXpsax71FaBdZjlc//PZvDTU/Z408ysrbw/wwyr8fYv9+j7Q1zP/SfUHV9y0SsYZAlcbrr6zViyfFN4H9m38ju6l+Wcn8H3qrAeTFV/4+dM9Is6c9NknVZP0fWP8OQJM/GE7+/bHmvKAtmz5lV13+MSsqnxO0/qpBO/LG29zLorT8+/1k4/7Evx9ivLdKRBoE3Tz/MYrV8bG2g33LWmvZpFSr1eYcoNiwZQFA3mIuXfaqyQefeKY5Pw0AYlGGFjHGGgDFaQ+LtDVsl0WwOj7GSqBdjdceE+Pzf55++ulmchmTvWPPMssCQK68XPlb//qLUd6cUDUJIFZJi1iRt4j5/7dtw9c2w3rGG6Csku1hay//WNTf65FWBFWt1Rb2MxMWWyVQpfH6gQkOg/7pT38a1SBoP8H2WRZ+QwAAeXronjusOnydxYaqSQBFUYYtYgztB+JfvuEirAiqN163zn+UFFsl0KPWStek+BwgTylj4SWy//I/PsUsCwC58xuR37/lNyw2VE0CKJJkkKzz+SFF9M9//ZrmRwZGo8z8698r4/z7PNY18hFWBHlrULXxetJExRQCVRqvUROza9cue+yxxywW9EoDCGXHbcP2//ze/2Ux8arJr/+Xv7H/9ndvGAAUjT8g+uDooY1rC1kV5A++voRg8rX/QRsvSuvku3PNVlBvlSQIyo30xrCYQqBXrfUXKcPbv771rW9FMweIAAhAKH4T/vAfj1hMkrZZTpEBFFlzfkgjCPKPvl465q1CS6l88srmGnl/CPb/j0AZJXOCKv/7rza/J2Lkz9y+iOnb3/62ffDBBxYB3xh2pvF6ycTEEgLtMsFtYK+++mo0c4AIgACE4qfL/9+ffD6q0yfaZgGUzY9/+jN79u/eKOTg6GRgNEEQysyr4ZLK5ljbQD/5yU/a7/zO78QUBP2OtdbG101IDCFQxVor4aXKbWKaA0QABCCkJx/4QlSnTlwzAZSVByS1RlBysnH98yAo1taRpfj/l5GtN9ixRrhf/xkBP8rLK5z9ez2ZmxUbD4JuvvlmGxuT38SeqDZehxovmT62GEIguWHQw8PD9ld/9VcWAx5mAIT0wBdvsermeDaBcc0EgIV18kWbFeStbt4a5u2+XvkElJV//dem3rStjSAoxrDXu3H85TOCIiA3KFo9BKqY2DBo70X8wQ9+EMUcIB5mAITkg6BjWkvKNRMAFhR5VhCbwwCzd3/xftQDo70ww5/Jv/99ydnLi0kNilYPgbwKaNiEPP74482BVOp4mAEQkp8c/6c/+bzFgmsmACwtmRUU82ahpTRXZg981CZfO2ZAWXnI60HQlk2fsqsu/5jFxtvC3MTEhEVAZlC0cgi0q/HaY0J8HfyePXtMHQ8zAELyh4Rv/esvRvOwwDUTAFbmD4oHXphqfh7rQNml/Ma1n2SFPErPv7+/++KPmwd4MQ6F9wKNM2fO2EsvyS3hWooHQd+2wPOBlEOgp01oGHQs6+C9x9k32vAwAyCUf/el26J5SCAAAoDOefuUt4gVqSrIFxd4e9jk3/8PNoeh1HwovIsx6PWNYfV63aanp03cpY2Xb5fyqdbB1puphkC7TGwl/KOPPhpFG9iX/8N3WGkMIBifAbTjdqku3mURAAFA95qzgl46amsv/1hhVsl7Gwwr5IGFOVkxBkH+rO7zgX72M/mh715V4mFQsPlAqiGQVBVQLG1ge8eebZazAkAIXkb80B+PWAwIgACgd946layS94fFIgyN9somgiAg3hXyl156abMiyDeGnT4ts419Od4W5oOM6haAYgi021olUhK8/evAgQPybWD7x18+36sNAHmLaQ4QbbMAkA5fJV+kodFJEHRkZra5OQkoKx8I7yFvdfg6i4k/s995552xBEFVC9QWphYCVRqvx0yoCugb3/hGM1FU5gGQvwAglFjmAHkA9NVHvkvbLACkpGhDoz0I+u3fGpp/CJ4zoKw85K1Nvdn8foip2s+DIG8N+/a3v20ffBBs7E4ngrWFqYVA95pQFZAPg/6rv/orU+YnFXvHnjMACGX71huas4Bi8P/+5Q9omwWADHgLyczsO/Z//LNPRl8V5A+827d+ulkJ4Q/CQFl5Rdzk3x+zrb9+TVTf15/85CebL68IEhekLUwpBKo0XgdNyKuvvirdBuatDP/qiWfoWwYQTHMO0D0jUZwQ0TYLANmq/+wfmzN1itIe5q0wXkHqVUFAWXkQFOP39fBwa1HJxMSEiatazm1hSiHQo42XzEqZe++91/7gD/7AVDHTAoCCJx/4QjMIUkfbLADko2jtYclw3GRrElBG/n0dYxDkbWERrI73qhOv6qhZTlRCoErjNWoivA3siSeekK4C+vp/+Rv775xKAAjIW8C8T1ydP4z8+dN/awCA/HhoUpTtYUmYRRCEMos5CIpgdXzVWtVAuUyzVgmBpKqAHn300eYXiyo/zf7uiz82AAgllnXwPjft3/3nvzEAQP6KtD2MIAiIMwiKaHW85yFjlgOFEKhiQlVA3jvoVUCqGAQNQMF//fc75N/8vV32nke/Zx/+z/9lAIAw/KFx/KWjtvbyj9nQxqstZgRBQJxBUCQbwyqW05BohRBIqgpocnJStg2MQdAAFHgbmA/LVNYMgB75XnOYIQAgLA/ja42HRhf7nCCCICDOICiSjWHVxmufZSx0CFQxoSqgXbt2NV+qHmwEQL56EwBCiaUN7KuPfNfq//CPBgDQUZQ18gRBQJxBUAQbw7wa5Uzj9ZJlKHQIJFMF5NU/Bw4ckK0C8jlA45NHDQBCiqEN7OHvvNi8KQEA6CnKGnmCICDOIMjbwjwE8q1hom5uvJ60DFfG/4qFU7FWuZMEXwnvW8EU+YkJq40BhOZtYOrr4P1amawmBgBo8pbdP/yzA1abetNi5u+L/gLKLGnB94+xePrpp2Wf/a1VDXSfZShkJdCuxusPTIB/ARw8eNAU+TfTn/ynv2YOEICgYmgD88CcTWAAEAefE/Tf/u6N5ucxzwmiIgiIryLIN4aJD4r2bqnMqoFChkAHrJVyBecr4ZP+QDWPPPUibyoAglNvAyMwB4A4+X2uX7v/+a9fY7EiCAJaQZBvsv7t3xqyj/7Tj5g68UHRlzZeflNbswyECoF2zb+C8yqg0dFRUzQ++ZrtH/+RAUBIMWwD87aCmMqQAQALfvzTnzVbw7Y2gqBY5wQRBAHW3Mo6+ffHogmCvBDkzJkz9tJLmc5h7lVm1UChQqCnjSqgFfnDzN6x5zjVBhBUDG1gPgh68rVjBgCIlz88xj4wmiAIaH0vH/uHf2wGQTG4+eab7fvf/7797Gc/MzGZVQOFCIF2GVVAq6INDICCJx/4gl11+cdMlQ+BZnA+ABRDMldky6ZPSb/3rIQgCGhtATz57i/kK8mdzwfyIEh0PpBXq/wHS1mIEMjXwldMgGoVEG1gABRs33qD/f4tv2GqvGLy6//lb5rDRQEAxeBB0Hdf/HGzGug3/tknLUYEQYAv7DjV/BjD4HefDeRhkFcEifFqoOnG6yeWorxDoErj9ZgJ8Gngjz0m8Ue5AG1gABR4G9junZ+TLcmfe/+X9i//41PNkmMAQPH4XBEX6+Yw/3N7JUTyIAyUURKExvB97NVAExMTVq/XTYyn4WOWorxDIK8Ckii9+da3vtVsB1NDGxgABQ988RbpN+w/f/pvmQMEAAUX++Ywb4UhCELZ+fdxLJV93iX05JNPmphK4zXReNUtJXmGQJXGa9QEeBXQnj17TM3M7Dv2jb/8gQFASEMbrrZ/+4e3mipvmf3zg39rAIDi881hfo+89dPXRLFtaDE/UPGqJipXUWb+PbBl6FPNSnNl3hYmui3Ml2p921LyK5afqonYuXOnKXrw8WcMAEJ76I/vMFXeMvvwUz80AEB51Kbesq8+8t3me0BsvALiyft/v3HAstaAMnvwiWeaga663bt32xVXSCwyb1e1FLer51kJJLEWXnUjmG+3qU2/ZQAQ0o7bhu3//j91V3r+4Z8d4DQVAEoo5hXyXsG09devaf75mfuJsvJFHpN//z/kv4d9QLTgkOhU18XnVQl0p4lsBPNkT42faviaYwAIyUt0d9yutzEx4WF5jKfAAIB0+HvAPY98L8r3An+PfeL+L8i3wwBZSr6HfcGHsvvuu09xi/i9lpK8QiCJ/iuvAtq1a5ep+WbjwUb9GwFA8d09cpPszanfNHgIBAAoN38/8KrQGNpKFkuCoNgqmYA0+ffwg0+Mm7pHH33UxHhXVdVSkEcIVLFWJVBwilVA/gZ2ePKoAUBIfmM6svUGU+QhuZ8aAQDg/H3hq433hdrUmxYbf799kiAIJecbwx5+6kVT5suk/CUmlVwlj5lAEmvhVWcBffk/PEVvMIDgnnzgC3bV5R8zRayDBwAs5vNF/tvfvdEMVYY2Xm0x8ffbqy6/rDkjCCgr3/ynvjreM4SxsTET8muNl++w/8D6kEcI9JgJDIT2ci61vj5fc0wVEIDQtm+9wX7/lt8wRUdmZu0bf/kDAwBgKb5YRf1BcimbGsHV4MBHOeRAqamvjvcQaGJiwur1uonwAdGvN159DRTOuh1MZiC0YCmX7R//kQFAaF8ZuckUec/43rHnDACAlTz8nRejnBvnyxjuFn0PBvLiq+OVh70LjpTpe95y1iGQxEBoHwbtKZ4SrwJiyw2A0JSHQX+TbWAAgA55CBRjEOTvwztu093MCWQtmf2ouijJi0nEsoSq9dlplWU7WKXxesIEPP3003bFFcE70s5LTreZBQQgJA9/7v/iLZLDKb0N7OGnfmgAAHTKh826LUMbLCb//Nevab7vnXx3zoAy8ufiY//wj/bbvzVkis6cOWO1Ws2E/EPj9ZL1KMtKoKoJEEzubHzyKKfbAIJTrQLykyDawAAAvYi1Iuihe0ZkK3OBPNSm3pL93r333nulikoaPm99yDIEutcE+D+YEg9/xhkGDSAw5ZXwB16YIigHAPQsxiDIq3KfuP8LBEEoNf++rU29aWo8APIRM0Kq1kdLWFYh0LCJrIW/8847TQkzLgAoUB1E6dfHGE9wAQBaYgyCPAB66I/vkGzTBvKy9y+ek3xe/vzn+yq+yULPQUdWIZBE+Y3aJG//YmYlPIDQlKuAfDAgAABpiDEIGtpwtd1/178woKxUB0X7mBmxjePbrEdZhUBVE6C2Fv6bnG4DELB752dNEW1gAIC0xRgEbd/6aVbHo9SaleHP6H3finUZSVUCVa21GSwotbXwVAEBUOAbUxS3ptAGBgDISoxBEKvjUXYHnp9qbs1TsnPnTqUB0f4HqVoPsgiBdpoA/wdSwjBoAApUq4C8UlKt7BcAUBwxBkEPfPGWxsHNpwwoK98Wq3R/6AHQ8LBUONtTNVBWlUBBeQWQUisYG8EAKNi+9QbJrSPjk69RKQkAyFyMQRCr41Fm/hzt4wKUiBWb9DQXKO0QyJOoigWmNhD6lZlZ5lwACO4rovMF9o//yAAAyENsQVCyOp6NYSgrD4GUqoF8LpBQS5iXJXX9h0k7BJLYm6Y2EJoHHAChqVYB+Y04ITkAIE+xBUH+/r37jzTbuYGseQCkVA1UhJawLCqBgvJkTmkgtLc58IADIDTFKiDFEl8AQDl4CBTTuIbq8HVsDENpqVUDxd4SlmYI5AFQ8Lqoz39eohjpPKqAAISmWgXEMGgAQEh7xp6NKgjyEMjf04GyUasGElsVX7UupRkCBU9fvALIV8OrOMIsIAACVKuAGAYNAAjNg6CZ2XcsFvffdQuDolFKStVA3hImNIKmYl3OZU67EigotVlAbAQDEJpqFdCDjz9jAAAo+Ooj34smCGJQNMrKA6Dxl3Ser2OuBkorBKqaQCuYUm8ep9wAFChWAfmstJhOXQEAxeYPl344EUsFvx/uPHTPHQaUTW3qTVOxbVtP29mz0tWk6rRCoODpi7eCKVUCfTOijQMAikl3Ixiz0gAAWjwAuueR70UTBG0Z2sCgaJTOkZm3myNXFPiGMKFV8V0lUmlWAgWl1grmX6AAENKI4PBI7+dmVhoAQFESBMWytMBDoOrwtQaUSW3qLVMh1BLmlUAdJ1JphED+P1ixwO69915TwVp4AKH5CaG/lDRXwj/PSngAgC5/r/rqI9+NJgja/UefY1A0SkVpLpBXAwnp+A+TRgi0ywLzVjClf4DDkz8xAAjp7pHPmBoflk9ADgBQNzN7yh556kWLAYOiUTYe0Kq0hH3+88EXpLfLNQQKPhFJaTK3P+CofFECKCc/EVSsAtrPrDQAQCR8wcvDkQRB/r5/9x3MB0J5qLSEeTGK0Fygaqe/sd8QqGJdTqLOgtJWMAZCAwhNcVAk10YAQGy8hTmWA4wdtw/bjtukWlOAzCi1hAnNJt7c6W/sNwSqWmBqrWAMhAYQkp8Gqg2E9iogP1EFACA2HgKNR/Ie5odAQxvWGlB0Si1hQiFQxTocDt1vCBS8CU5pK5h/ITLvAkBIVAEBAJCuPWPP2szsO6bO5wI99McjzAdCKai0hG3e3HEBTh46qo6JvhJIqRUsllMCAMVEFRAAANn46iPfi+Kw1+8F7r/rXxhQdEfe0KgEinFDWD8hUNW62EWfBW8FU6kE8pI0HnQAhLRl6FOmhiogAEAR+L3+PY0gKIbV8du3fpr5QCi8meOnJL4ffTC0UBDUUVlSPyFQ8JVcSq1gE9NvGgCE9BWxVjCqgAAAReLvaw8+MW4xYD4QymBiWqMlTCgEyrwSKPhq+M9/PvhIovMOT/7EACCU7VtvaJaAK6EKCABQNL4EJobV8cwHQhm8flxjVpdQCFTp5Df1GgJ5G1jw/6cqlUB+KqAynRxAOflqWCVUAQEAiiqW1fF+OHT3HXoLI4C0qMwFEhoO7TlNZbXf1GsIVLXAPADy/jsFrxAAAQhoy9AGG9pwtSmhCggAUGQeAtWm9MdB+CHRdrGlEUBaVOYCxTYcutcQKHgf1p13Bh9JdB6tYABCUru5owoIAFAGe//iuSg2ht1/1y1yLeNAWmZmw7eEeXGKL60SUVntN/QaAgWPurZtCz6SqIlWMAAhKa6FpwoIAFAGsWwM87lAu3d+1oAimpk9ZQpi2hDWSwhUscAhkKdsKn/JtIIBCGnH7TI9yE1UAQEAyiSWjWHeOv7AXbcYUDQqBRlClUC/utpv6CUEqlpgSqvhaQUDENK2zdeZEqqAAABlE8vGMJ8PtGXoUwYUic8FUiA0HDqTSiBWw8+jFQxASGpr4akCAgCUlW8MO/DClKnbvfNzrI1Hofj9J8OhL1Cx1pawZfUSArEafh6tYABCUpsFNE4ABAAoMd8YpjCkdiWsjUcRqQyHFpJqCFSxwCGQ0mr42tRbBgAh+E2c9/crIQQCAJSZVyM8+Pgz8oOivS2sOnytAUWhMBzaZwIJBUErZjbdhkDBq4CEyqzsyBtvGwCEcPeI1ine+ORrUazJBQAgS7EMit79R59jbTwK48QpjXtQoRAo1UqgqgWmMg/IZwGpp/wAiutGscGO+8d/ZAAAII5B0ayNR5GcfE8jBBKbC7SsbkOg4EOhVeYB0QoGIBS1gdBUAQEAcCEfFF2betOUeVv5jtt0uiyAXqlsCBNaE3/NSr/YTQjkJUXB5wGp8IQfAEJQGwh9ePInBgAALrT3L56TPyTx9nLawhA7lQ1hQiFQZaVf7CYEYivYPP8iU5/8D6CY1AZC+8nLETYlAgBwkdag6HHpERK0haEo5s6F/z77+Mc/biIqK/1iNyFQ1QLbti14N1oTq+EBhKI2EPrAC68aAABYmm8t2v/My6aMtjAUgcKGMKGZQKkNhg6ewKj8pTIPCEAoSgOhvSryMGvhAQBYkc8HOvDClCmjLQyxOynQeim2HWzZP0w07WDeCqbyl8pqeAAhVIevlbpBmyAQBwCgI/vHX5aeD0RbGGKnsCZeaCaQ6zsEGrZVSoqyplIFxGp4AKFUN19nStRPNQEAUOHPD/c88j3p5wjawhCzs+c+NAUxDIfuNASqWGAq84AUeg0BlI9XACltBWMtPAAA3fH3TfX5QLSFIVavz/7ccIHKcr/QaQhUtcCYBwSgzLYIzQJyrIUHAKB7Ph9oXHieHm1hiNXZ96kE6lSnIdBmC8j/IlX+MlkNDyCEHbfrlGf7SSZr4QEA6M3DT70oXU1LWxhipPI9VaR2sKBXAeYBASgzL8se2nC1qfjmuHYpOwAAyvx5Yu/Ys6aMtjDESOFZXWxD2JI6CYGCD4X2zWAKmAcEIASlKiB3ZIYNiQAA9MPfS70iSBVtYYjR3DlCoDYfX+4XOgmBKhbY5s1Bu9HOYx4QgBC2bb7WVDAQGgCAdPh8IOX2am8Lqw7r3IMAqzkpcI8qFAL96nK/0EkIVLXAVNrBmAcEIG9+A6ZUjs1AaAAA0rN37DnpcRP333VLsyoIiMGcwJr4j3/84yair0qgoGU4HgAppGkzx08xDwhA7rYLrYVnIDQAAOny99a9f6E7H8gPou6+4yYDYnBW4Hn9V3/1V01EZblf6HQmUDA6W8F+bgCQtxuFVsMzEBoAgPT5yIkDL0yZKp9NuEXofgRYjsJMIKFKoGWtFgJdYQyFbmIQKoC8qbWCcR0EACAb+xsHLcoz9x744i0GqFPo3BFaEd/zdrDgw3hUhkK/fpzNYADypdQK5qeUDIQGACAb6mvjhzZcbTtu09pWCix28t05w3nxhkAKQ6H9osxQaAB5U9oKNjH9pgEAgOx4xa1yW9jdIzdJVSgDWNWSQdBqIdA2C0hmKDQBEICc+UpWlW0cXgF0ePKoAQCAbCm3hfl9ye6dnzVA1dy5Dyw0oXYw11MIFDSB0RkKTSsYgHxVN19nKl5hIxgAALnwDoQHHx83VT6vkCHRUDX3fvgV8TGQbgdTaAVzR17nAQhAvpRawQ5P/sQAAEA+/AB6v/BGzt07PydTrQygeyuFQJ7ABK0EUhkKfYIBUwBypNYKdoRKIAAAcuUhkOpICp8LxJBoKFJoB3NCLWGVpX5ypRAo+DAehb88hkIDyJtSK9iB53UHVAIAUGR7RnW3hXkIxJBoqDlLO1hHVqsECkqhHYwACEDebhTqtZ+YfssAAED+lNvCGBINxEs2BFKZB8RQaAB58oGLKidr3gamuqEEAIAyUG4LY0g0EKeVQqBrLCCVPjqGQgPI0/atN5iKcdbCAwAQ3MPfedFU+ZBoALIqS/0klUCrYCg0gDwptYIdmXnbAABAWP5+fOAFzRl9DImGEpUK9iuuCD5eeUXLhUBXGJvBmpgJBCAvtIIBAICleFuY6vvy3SM3sTIeaBNrCBQ8zlVoB5s5zjwgAPnx1fAqaAUDAECHbyzeO6a5LcwDoLvvuMkAxGGlSqCgFNrBOAUHkCel4Yq0ggEAoEW5LWzH7cM2tGGtAdAnWQmksxmMVjAA+fA2sKENV5sCWsEAANDkbWFeFaTogS/eYgD0LRcCBR3Io9JDN3OcEAhAPpSqgGgFAwBAkwdAjzyluS2MlfFAHCTbwdgMBqBsRoRWw9MKBgCArsONwxqv2lXEynhAn2Q7mMJQaEc7GIA8+EBFPz1TQCsYAAD69o49J9kWxsp4QJ9kJZDCeng2gwHIC61gAACgG35gozokmpXxgLalQqDg0a3CTKC5cx8YAOShuvk6U0ErGAAAcfAQSLF61wMgqoEAXUuFQKyHN28FoxIIQD5uFKkE8gpIWsEAAIiDt4PtHXvWFHkIRDUQoEmuEkhlM9iJUzwIAcje0Ma1zf55BYcnXzMAABAPr+CtTb1pajwAuvuOmwzIk8o9db1eN2VylUAqm8GoBAKQhy3XawyEdrSCAQAQn0ee+qHkkOgdtw/LPJQDWLBUCBR0KrNKJZDihRRA8VSHrzUF3gbGRkQAAOKjPCR6987PGgAtVAItg4chAFlTWg3/ysysAQCAOKkOifb7HKUtqACWDoEqFpBCJRCDUQHkQemm6PDkTwwAAMRJeUi0r4wH8rDmsksMF6gv9ZNyIdDmzUG70ZpOEgIByIHKani/cTxCJRAAAFHz2X6K7+dUAyEvgwOXmoLYBkNXLDCFSqC59z80AMiabwZTwEBoAACKYe/Yc6aIaiBAh1wIVKlULDTmAQHImm/LGNpwtSmYmNZbLQsAALrnYy32j79saqgGAnT8iolRqASiHQxA1pRuhKgEAgCgOHxItOKmY6qBkLVBgZlAp0+fNnWLQ6Cgq7kUqoDciXfnDACytG1YYx7QzPFTDMMHAKBAPADa/wzVQCgfhZlAYiFQfamfXBwCBS3DUQmBFJNzAMUytEFkHtAbDIQGAKBoDjw/JTnigmogIDypmUAKrWDu5HucigPIjg+E9plACmpTbxkAACieh7/zoqmhGghZWnfVoIUWYzvYNRYQlUAAymCTyEBoVsMDAFBcqivjqQZCkcXYDhaUQiWQz8cAgCypzANiIDQAAMXGpjCUyeBlHzWsTqodTKESaO7cBwYAWdpyvcaND6vhAQAoNj/wGZ88amqoBkIWBgfCh0D1et3USYVA11wTtButae79Dw0AsuLzgFROKV6n8hEAgMLzaiC1cRdUAyELCjOBhNSX+wWpdjAFDIUGkCWVeUC+Fl5xawgAAEiXv+cfeGHK1FANhCI6duyYqWsPgSoWmEQ7GEOhAWRIZR7QKwyEBgCgNDwEohoIRcdMoAssO6GaEGiRk+9SCQQgO0Mb1poChkIDAFAeHgBRDYSiWyMwE0hoO1hHIVBQCpvB3Il35wwAsuDzgNZfdbkpIAQCAKBcqAZC0SncZ4utiF+STCWQSggEAFlRmQc0c/xUcz4AAAAoDw+A9j+jtzKeaiAUidB2sPpyv9AeAgVNYRRawRztYACy4qddCmZmf24AAKB8Djw/JXcQRDUQ0qBSbS/kzHK/IBMCqZg7x2BoANnwdjAFtam3DAAAlNM3x/WqgXbcNmxAP9ZcdokpEKoE6mgmUNAQSKUdjO1gALLg2wqGVNrBZk8ZAAAop8OTR+WqgarD11HJgb4MDlxqCmKbCVT6EIgZGQCyolLmzDwgAACwd+xZUzOy9QYDeqUSIgqFQPXlfqE9BLrGAlKYCXT2/Q8NALLAPCAAAKDCt4QemZk1Jd4S5pXTQC/WDIRvBxOrAtJfEa9g7twHBgBZGNrAPCAAAKBjv9hsIA+AmA2EXikEiELzgJz+TCCV7WAAkAXmAQEAACVUA6FIFNrBYqwEKv12MNbDA8iCbwVTuKHxWUDMAwIAAAnFaqDq5msN6Na6qwYttDNnzpgQ/RDommuCjiRqmjvHTCAA6dtyvcg8oONUAQEAgAWK1UAMiEasxNrB6sv9ApVAbVgPDyALmzZqtIKp3eQBAIDwxiePmhJfpqGyVRXxWEc7WLsV/yAyg6EVVsQDQBa8HUyBn/YBAAC0O9wIgdTaxe8eucmAbijMBBKqBKqv9ItJCFSxwBRCIGYCAUib97YrDIX2SseZ2XcMAABgsW+KzQbyaiAGRKNTCgGQEwqB4qgEAoAi0tkKRgAEAACW5tVAaqMxWBePTim0golZcUJ1EgIFL8NRWBHPTCAAaRvaQCsYAADQd+CFKVPCunh0avCyS0xBbO1gDOQxtoMBSN+WTSqbwagEAgAAy/MQSOlQ3AOgkZvZFIbVrbuSdrBFaAcDgFDWXzVoCo68QSUQAABYngdAatVA1eFrDViNQsVYLOvhnUQIpLIZjHYwAGlSGQo9c/wU1zcAALAqtWog1sWjE0Mbw99vi4VAHVUCVSwglRDo7DkekgCkR2UotNraVwAAoEmzGug6A1YyOBB+JtCZM2dMCO1gABCCzlDoWQMAAOjE+ORRU+JzgRgQjZUobAejHQwAoDMUevaUAQAAdMIriJUOkBgQjdWsFwiBTp8+bULqK/2ixHYwhfXwjpYJAGlSGQo9M8tmMAAA0Ln94y+bEgZEYzkKAZCbmpJpo1w1jWJFPABkgKHQAAAgVkdm3paqBmJANJaj0ArmhCqB6qv9BtrBACADDIUGAAAxY0A0YjB4Wfih0E5oJlDHlUAAgBQxFBoAAMSsNvWWVDUxA6KxFJWDV6EQaHq130AIBAAZWL9WozSVodAAAKBXStVAHgBtuZ6WMFxIYSaQ2GawOGYCXXFF+JFEtEwASJNKJRBDoQEAQK88BFKqBtpx+7AB7dYJLGKJaT28IwQCgAwwFBoAAMTO7yMmpt8yFT4gmpYwtFP4ejhz5owJqa/2G2gHA4CUeVmqwhsSFY4AAKBfhydfMyU7bqMaCAsUDl6F1sM7BkMDQN5UVlXSCgYAAPqlty6euUBoGdqoMX5BrB1s1USKEAgAUqazGextAwAA6JdvClPhLWEEQXCDA5eagpjWwztCIABI2ZZNG0zBSdrBAABACsZfOio1Z9CDIEDl4PX06Y6ylzx01JdGCAQAKRscuMRC8xs1ZgIBAIA0+H2FB0EqRrbeYMD6tRojGIRmAnU0oZoQCABSJrEZjHlAAAAgRbWpN02FL+GgJQwKlUBiQ6HrnfwmQiAASJEPqFPYDDYze8oAAADSojYgujp8naHcFO65hVrBXL2T30QIBAApUhlQd+IUrWAAACBdSgOiR26mJazsFKrvp6enTQgzgQAgbyoD6qgEAgAAaVMaEO1VILSElRfr4ZfEdjAAyJvKgDpmAgEAgLR5AHTkjbdNBVvCyov18EuiEggA8qZQCeQ3aEprXAEAQHEceP5VU8GWsPJSqb4XCoHqnf5GQiAASBGbwQAAQJH5gGiVwybfEuYvlA/r4S9S7/Q3EgIBQEq8N53NYAAAoOh8NpCKbZuvNZQP6+EvUu/0NxICAUBKFKqAHJvBAABAlmpTb5qK6jAhUBkp3HeLrYc/1ulvJAQCgJQMXnaJKaASCAAAZMlbwk68q3Ho5MOhFSqxkR+V6vsY18O7j5gAsQQNAHqiUgnETCAAAHQ1H2AHPmrrrrr8/OdrBi5pfr7+qsHm71kzsPCQ6x/9xxf99wxc/CC8VDBz9tyFCyP88+bPnfvw/M+ffHeu8eNftv34Fxf8eCnjk0ft7pGbTEF187V2eFKnRQ3ZUrnnjnE9vCMEmsdAMQD9GtoY/g2JzWAAAITlzxXr5gcWr2uEOh7srJv/uaWCm7T/t9PmwdLJ+XDJP57wwMjvN87p3G8078EIgUpDZTOY2EyguCqBAKAIktO7kKgCAgAgHx64ePjgD6R+D+Cfr7vy8sK1JsWwgcuHQz/8nRcN5cBmsIucttgqgQCgCPzGL7S59z80AACQLg9BfPbM0Ma1zdDH21GYQ6MjCapU5hQhWwqVQN7NJDTWpqs0KgmB6gYA6JnOengqgQAA6Fcz8Gk8aG4Z+hSDhyPh1UAHXpBqz0FGFGYCibWCnenmN1MJBAApkBkKfZwQKE/JQE+3rq1Uvv3n2y0+oUxmLHByCQBheRWJhwiEPvHatFFjTgyypXLweuZMV7lL1nqqBApKZao2JYQAeqWyHt43faB//n7gm1g2bby6ubHFe88HGx+TwZ7J70lTMmSzuZGl8fnJ9+bsxKlfnP9IlRcApMvDnurwtc3whyUx8bux8e+J4lM5eI11KLSjEggAUsB6+Pj4KZLPcfKgx2c8rLuyNdQz680tK/15WuuBl38Q8X9fD4iOzLzd+PwU4RAAdCkJfkZuvoFqn4JhLlA5sBlsSfVufjMhEACkQOEEkfXwy2sf6JmEPTGe+iZh45a2007/N/cgyIOh1mvWAAAL/Nrpwc+O24YJfgrOAwJCoGJT2Qym0s00j8HQAJC3dayHl1G2DS7+/83//7YHQx4E1abemq8Y4usCQPn4tdGrfTz82UKbUGls2bTBatNvGYqLSqCLdP0HkagEUlmtto7yQQA9WidRCVTOeUBscLlYeyjk72sTjRviVihElRCAYvP3AK/4oeqnnLzNG8XGZrCLdB2mEAIBQAoUWovKUvGRhD5+ulv0Kp80+Ndm8kCUBEIHnp/i0ANAofh7w90jn6Hqp+SG2BBWaH5Po3Dfd+zYMRMybV1iJhAA9ElltszJgj7Us7Y3Pe2BkFcFjU8etcONFwDEivAH7ZKQgBmJxaRQee9qtZoJ6bkdLHgpjlcDXXHFFRbS+qsG7YgBQHdU3pBOvDtnRcHa3uwlLWNfGbnJXmkEQvvHf0R1EIBoEP5gOd4SNvc+8/CKyA8EFcS8GcwRAgFAnwYvu8QUxFwJ5Kd21c3XNd7c1zeCn+uo9slRc6Xu1k/bSOM1PvkaYRAAaX7N2r3zs4Q/WNamjWtZilBQvt1Vgdg4mzgHQwNAzBQG1LnYHtzZ3KJnhDAIgKhk4PPdIzcZsJI1AxwkFdV6gW28HgAJVQKdtj4GQ0tUAoWm0tIBIC4KVSuxPKwT/MSBMAiAku1bb7D777qFKlF0hK+TYvJ/VzaDXaSnPwwhEAD0yTdVhabcCkbwE68kDNo//nJziDRhEIA80fqFXhACFZNK5f30dNfLuLLU0x+GdrA2XDAA9ELh2jH3/oemJDmt8aGdrHGPn7dfjDRO4r/ZCIPYJgYgD0nrF+8f6NbggMasRqRL4dDV1et1E1K3HshUAh07dsxC44IBoBe+hSI0lQGIyVYvr/zhxr1YWifyn2tubHvkqR9SFQQgE1T/oF9z57QOxpCO9Ws1RrfQDlYwawYuNQDolkYl0C8tFNq9yqU6fF3z39lbxA68IHUjBCByfm156J47OERAX0LeEyE7KpVARQqBglOYCaSy5hlAPNaLDJSfmT1lefOb9R23bW5+5Ia9XPzf+4Ev3tIM/vaOPUdVEIC++TXFW8CAfhECFZPCQaMHQEKzjD0A6ukP0x4C1RuvigXCdjAAMVK5buR1w5Os6PWHf5UBfQjHb8ieuP8L9shTL1pt6i0DgG75+4pX/1BJirSEOBhDtoY2alQBKYywadPzH0amEkhhwNLgACfZALqjUkF48r1sKzGY9YPleDXcQ/eMNNvD/AUAnfLrhwfJKlW1KAbljanozSaRg8citIK59hCo9HOB/MHGX5QQAuiUwlBol9V1y8Mf3/DFCS1W41t8vF9/7188x/sogFUx/wdZ8PcfWpSLZ2ijRghUq9VMSPwhkMqqNa8G4uYVQKcUbl7TvtlJWr78xc05uuFDo/1G7Z5HvsdNOIBlbd96Q3PbIJA27luKiaHQS6pbj9pDoKANbioh0BpawgB0QaGEPa2yZ8IfpCFp73jw8XHmMgC4iFcN+gsAOqVQke4zjIWGQrtUKoGCUvkL3bRxbeOm9R0DgE6su2rQQpt7/0Prh7+x+qnsSOMFpMGDoCfv/33b+xfPMjAawHkEQAC6pTIUWqwKqGZ9WLwdLBiVEIhKIADdUKiY6XUoNPN+kKXWxp8R2zv2rB2ePGoAyo0ACEAvVIZCT0xMmJC69UFqMLS3hFUqFQtp/Vq2EwDonMJg6G7nmBH+IE/J3A+CIKC8CIAA9ErlflWsEmja+iAVAilUAw0OaKx7BhAHiUqgDmcCEf4gFIIgoLx8zhwBEIBe0Q62pL7+MDLtYG56etqGh4ctpKENnzAA6ITCUGh34t25FX+d8AcKCIKA8qkOX2sPfPEWA4BeDQm0g3mxisoiq3nFCYEUKoHWXEYlEIDOqFwvlmsHI/yBmvvvusVeP/4OW8OAEvCDkt1/xBp4AL2jFWxJ/ofpKziRmwkUmsrJPgB9gwOXmoKz5y4MgQh/oMrbJ31r2B/+2QE78W5vA80B6PP76Sfu/4JEy3QM/DBnrvFe7u3d/nnyvp5U+p5cVPHrv3e1eYCLn2nat5mun/983fzv8X8nX47DcxDUDG3QaAUTGwp9zPrETKAl+AWQm1MAqxkUqQRKrld+7fK5C6x6hzJ/2PCHw3se+R7vtUBBPfTHdxAotPFr3czxd5rhjgc7Hur4zzVDnw4CnV4csd75v10SELU+H2xeu9ddOf+x8XP8+yIPWzZRCbSEmvXpI4t+XG+8KhaIyl/uOkIgAB1Q2QzmN2Q+eNNfnLoiBv7w4A+JX/rTAwagWPwwQmGGRwj+njwz22p5nTl+qtn+evK9X2QS8mTJn4OSZ6GVwiS/5/B/6yQg2jL0KasOX2dAWlQqgYo0FNotDoGCluLoVAIN9pWeAygHlcDlr/90F+EPouMPDg/cdYs9/NSLBqAYtm+9oVSbwDzwOTLzdjPwOTIzW7pDZA+3/P93wsMvQiCkZb1IxZmPrCnSUGi3OATyffPB1nOp/OWuo7wRQAcUghfCH8Rsx+3DzYemAy9InbAB6IE/rH2l4AGQhx7jLx1thj616Tejq/ABYqKyGt43mAupWwqFO1KVQM6DoEqlYiGtbxucBgDLGRwggMHSkiGfizFD4WJeNTAx/RZt2EDkijoHyCtdvNqn9Zo1APlQWXBSq9VMSCqJ1FIzgYLyfrvQIdDQhk8YAKxmHYFxaXhA4QM9fbDn3LkP7cQp//GHzZ9PNrl0O9zTH5Z8G4tXcyXzFNavvfz8x7LM1EgGRfvGME7VgTgVbQ6QX4u8QrE29Vaz5QtA/pgHtKRU/jBylUBnzpyx0NaIbPwBAOTHb/p9gKcHPa8fP9X4fG4+9Mlmc0snlS/+UOWBkA/b9JshlVOxtDU3291xE/OBgAglmymLwCt99o//iIqfHilUglFVWhwqwXLRNoO5xSFQ8P+HCnOB/ALmJ5OcSAJYCfPD4rV4g4vqQM/Wn/Gdxmn0m80fJ5tYqsPX2rbN1xaq9cLnA/mMDW+5ABCP3Ts/azFLqn78xb0/oMEPvRTmXnoApLK8al4xK4FkhkNfeXnjjYDyTwAogqJscEk2sfjr4e+82AyBPAzyAKUIgdDunZ+jLQyIiG8Di7VCkfAnfWsG6KZAOmgFW1LdUsprPrLMf/EVFojKX/SmjWvpAQawIob86kpCn2SQZ1Fv8JPNWv7yBzF/IBtpvGJFWxgQj1i3gRH+ZEehcuMk7WCFsGWTRrg8MTFhQlJbU/aRJX4uaAikUm61hq0/ABAND0N8w1TRQ5+VJBVC+8dfbgZB/ooxqKQtDIhDjNcYb6195KkfMjcGEEcl0JJqlpKlQiD/f1qxQLwdzIOgK64IlkM1eSUQACyHKqDwPPDwzS2sF7+Q/114EDQ+eTTaMMiHzH71ke8ZAE2xDYP26+LesecY+Jwxhfeaufc/NMTNv44UvpY8kyjiZjC3VAgUfD2XB0HDw8MWEmviAUCLV/dMNCtETjQrRSjjX1l7GOQPazG1iSWtbYcbf3YAemIKgLzty6+FvGdkb41AO9jZcx8Y4jYkUowhFgC5TEMg/y/faQFNT08HD4FYEw9gJWwGy4fftI+/dLRZ8eNzfriJ756HQXvGnm0+BD1x/xeiqQq6/65bGmHfW/ybA2L8GhJDqOzXjr1/8Wzz/QP5GBQYDD13jkqg2KkMmxebB+QZTWpzc5abCRSUwlwg1sQDQBhJxc/hyZ9Qup8iD4N+9+ujzRP8GE7x/T14x23DzfAKgI4Yrh9+aPDg48/QKpwzhcHQPLvFb8vQp0xBrVYzIamWJS1XCRSUSukVa+IBLGeQasHUtYYa/4iKn4x5qOJ/x15po14V5CEQG3wAHTFUAXkLrG8YDHnd8DDEnyM2bby6uTZ9/drLm1Uy6+YPmZdbQHP23C+bf25/zcyeOv8xlvdFhcU6vF/Ezb8/hjZcbQrE2sFS2wzmlgqB6haYyoYw1sQDWM7gwKWG/iXDnb3lixu3/DTb646fkm8PoxoI0KJeBeSh8cPfedHylDy0+jYjf3a4cWhDKtfV6vB1F/zYn0l8a6Jfv1WrZBXeTzxIQ7yUAiCVTGJezVK0XDtY0DXxMpVAzPwAgNS1z/mh3Sscb5P4wz87YA/dc4dM//1SqAYCNKhXAXlYnFdg7NdMb1nxlz+05tEG1Qqarm5eE/36/cp89axKy5tCK5g78e6cIV7V4WtNQZGHQruPLPPz9cYr2GRmlTXx668aNABYyjquD13zwOfAC9PNjzzQa/B/B1/Fvmfn52Qf7qgGAjRsE3k4W0oeAZAHP/6AOnLzDcEDj+YK7a2fbly3P51r+LUS7ouQBq+oUyA2FLpmKVsuBPKes6DruVgTDwDx85DBqziS7V7Q5NvDnGoQRDUQEJ5/HypKVsBnwcMeD308/FGtmPQWPb9239MI9ENWBam0yZ9kGHjUVL7PijwPyC0XAgVvgFNYE0+iDQC9YdZPfJSDIKqBgLA8BFGcH+aHC1nMAEquOf5SaXNaif/b+Iy3kEGQytcHG+HipRIAeUeSWAhUs5QtFwIF/3+tMIjJL/p+QeNiAmCxGG4KQ0g2fDHrJ06+UWdo41qZwYztqAYCwvG2IzV+f+5r4NMUW/jTzp9Zdu/8bLPFNwSFw3PeH+KmshperBXMpZ7N/Irl9D/ULZX0TaUvEYCWQYE1qCqSlq/f/fpo8+aTAChe/m/pD1WKhx9JWwaAfHm4UN2sNw/owcfHU71WeRXCf/36jmZ7VawHPf7/YXugak6Fv7OTDIWOmkoIVKvVTEjdMtjeLtsOxoYwANCWhD9UZ1zIb4TXXXm5bdrYqqZJTkcXLxtINpj4393Zcx82H2b885Pv/SLo32frdH3cnrz/9+UehLwlxb/eAORH5cGsnbeGzsyesrR48OOvIvCW3sOTRy1vCs9Mc+c+MMRLaT28kNTnAbmVtoMFXRPvg6EVrF9LCAQA7Qh/FnhI4jctHk545Whaq4L979VnXfjHIzNvNx92kh/nwf/39j/zsj1w1y2mJFnL7H8nAPKhNifMg+o054Mpb0fsRagH6cGBSyy0ufc/NMTJ398VDp58JI1YJVDNMvCRFX6tbgE3hPk/gAdBlUrFQqIdDMBSyjg43m+8Dzw/Vfphz36T4jcrO27bnFros9z/hqsOX3f+5z0Imjn+jtWmf9psu8vy38H/rb0FRG0jjv99EAIB+fBWMLVrwD0pzrwpWgDkQj1IK1RxeCUt4qTyzC1WBeQy+QOtFAJJrIkPHwLpDccEgDx5+PPNxqlriPJyJQoDQ/09yV/JkNZkC9vE9FuZzPF58Iln7K//dJdUW5jPBfIqAFoQgeyptYKNT76W2rUuWa1eNKGujQrvEydOEQLFyiuqFYgNhfbOrJplYLVKoKCOHTtmofkFzV/cbAIoG8KfBX4S7ltX1FYkt9qjNtgDX7ylGQiNN/6tvEomrYckf+9Tawvz92SvUOLrEsieWkji2yfT4NfyoswAWswrRvPmWyUVnGSjc7RUCi/EWsEyK0uSDoG8HGvnzp0Wmg/4nHs//wsqAITAzJ8LxTIwNAmE/N9sYvrN5sNSGmGQYltYqMGnQJm0t6UqSLsKqKjGA1wbBwcuNQVz55gJFCOVeUBOrB0ss7KklUKg4H8DKsOhNzXS7RCpOgDkifDnYl5h4+1fMWmuUt/66ebLH5rSCIO8/erJ+3UeBpMbRr5OgeyojURIqwrIFbENLBFiZprKPBee1+Kk8vXjVUA+l1hIzTIiXwmkYMjX/HLiCKDAPPhhzsoCPyX2m5L2ocwxSsIgr+bxf+NewyB/qPDTZaUHJ58NxLp4IDsqMzpcmlVAaoOu05Tm31M3VKo4uIeJk8q1Zno6k23s/cjsJudXVvg1j8HqFpBXAimkcd4OBgDtlAbl9sPnyPzu10ft4e+8yM1TG6/+iT0Aarfj9mF74v4v9HWjpRYSKj2gAkWkNBQ6zSqgIgv199Q8MA9s5vgpQ5xUgtmDBw+aEA+AMgtCfmWVX69bYAotYSrDzgDoWDMQdwjkJ4VffeR7zdcJBileIFkIUDQ+CPWhe0Z6noXhXydKlTdKMwSAovHvLZV2MD+sSPN9qqjDg0NVAbnBgUsstLlzHxjio1SZV5Z5QG61ECj4ei6Fsiy/ceZGE0ARNLc9jb/crP7xG2tcTG0ORto8BHronjt6el9Ta7/ygdUA0qd0HUx70LEHJUWrfPX/TyGrpRS+XmZmqQSKkUrFYZnmAbnVQqDgd3sqiRwtYQBiV5t60/7wzw40QyAsb/Cy8CeaWfNWNw+CuuUPTuNCM/K2bS5Oyx6gROXBzK85WWwCLNo8sW823teDVQGJVM/S0h4nlWtNmeYBOdrBOqTUFw0A3Uhavx584hlavzpQ9EqghJdgP3DXLdatw5OvmQrem4FsqHxvTUy/aVko0hZMbwM7HDCcV3nPnDnOZrDYeHjIPKAl1S3jHIZKoA6tX0slEID4+I2uV//Q+oWl+MDobgcs+6Ywla+n1g0kQRCQNpUH+9rUW5YFD4CKUA3kBzsPP/VDC0mlenbu3IeGuCi9f4vNA6pZxjqpBAraHKeyIcxXBQNALJLqH7Z+YTW7/+hzXZfyZ/Vg1osir3sGQlCahXnkjbctK94aHfMBib/P39N4nw/9Hi9TCTRLJVBsVN6/BecBZToU2q0WArm6BSaxIawk7QEAOqO8XYTqn/6cfHfOysQf9kZuvqGr/8z4S0dlwkUqgYB0rbtKo/rd38Oyvs7sHXsuyjZp/3t58PFxiT+7wnp4//vgwCs+zANaVuZlSZ2EQMH/VhT+Yfwmeb3ImyIALIXqn3SUMTzrtiXMv74mpjWqgVgVD6RLpfo9j4pDf9/0MCWm90z/s371ke/KbMNaf9WghUYVUHz8uVqlyEJwHpBECMRcoHm0hAFQ5cEF1T/p8IeCsg3Q7iVIURoQzfszkJ4tmzRaNPIKOfx/x0OVGIIgtQDIKWxQnnufeUCxUari9XYwIblUv9AO1gWV8lgAaOdzDb4qMBegSJTWoOdlcKC7EMgHROu0hDEXCEjL4IDGoN88DzViCIL8cMIPe5QCIJX18FQCxUdpHpCYXMqSqATqwqaNnDQC0NGcCfDEeDMEQrqKtD64U70cdOi0hDEXCEiLQotGiKpWD1c8ZFGsBPWQw4dAq/3ZWA+PXt0o8r49MZH5DOZu5RJ8dFoJxIYw8wvdJwwAnMIq0onpN6W2NBWJ0sybvPQSetUaX4MKWN4ApEOnsiNMtUuycUupGtQPJb70p5rhlEorLuvh4zK0ca3MrF2xSqC6CYVArm6BKbSErRMYfAZAw1larwrPK6zKVA3USzm9t4QpYHkDkA6Ve90Tp8IFHh627Bl71vY2XiGDl/ZlD6rWr9W47tIOFpct12u0gnmRSRnnAblOQyA2hBk3mQC0rBm41JAdvwH3E9gy6LX1wkMylWHktIQB/RsUeV9RmHtzePJokKogv676IUQMyx4UKoFYDx+fbjeSZkVl5Eyb3NaUdRoCMRdoHjeZANzcufA3HIOXaQzvLDIPgcqwKayfhxyVaqChjbSEAf1SOexUqexIqoJ+9+ujmYdBHmSMT77WDH9iqURlKDR6oTIU+tChQyYmt8AjmnYwmTXx3GQCMJO4OWNjYfaaw7cfH7ci84ecw32FQCKVQCLl5UDMFNrBFCs7FodBaR4OJJU/v/vvRxv/G89FdfCgMI9NaVsaVqe0zbOs84DcRzr8fVQCzVt3JQ9dAFAmfoP58FMv2gN33WJF9M0+t8v5348/xIQ+EfZBk/5noC0A6J1CZcfJd+dMVRIGOX+Y3b71hua1p9swxP97fPmAL3dQb/lazpDI1uSQ86PQPZVWMJ83LNYOluvsm05DoLq1NoRdYYH44Cb/x6pUKhaSygUPQFgKN6mDA+Fv1sviwPNTtqlxkz/SuOEvEn/4ONxni4OHLl6Or3C65wc1c+/TGgD0SuF9Ze7cBxYDv34mAY6HZx4E+Yyc1gzRCyuqfHuVhxUn35tr/meKEFbrtA5SCRQTldEqYlVALrd5QK7TEMjVG69hC8jTutAhkF/wOGkEoEDhxLZMvBqolxNfVX4SvXfsOUuD34QrhEB+c8l8CKB3Cu1gJyOcw5YMyY+1qqcXKu+FPJPFw5+jVb5uJiYmTEzNctTpTCAXfD3XsWPHTIHCJHwAYamcVBIE5ac1H+iZwgyK3pvi7ImZ4xonsZuo1gWid0K4HQwLVOakEvzHQ2nBkuA8oLrlqJsQiLlA84pyCgygd3Pvf2gKaAnLl4cmvjI49iDIh5CmeWKtcvp9o9DASSBGLBxApwYHwm8oVTmAQGe2DV9nCjxT8DEzQmqWs25CoLoFppLYcdIIQKVcfQ0hUO5iD4I8ANrf5zDoxfzvQqEkP2nZBhCvGNvBykjhULwolbllseV6jUogwVaw3HfVR1UJ5ImdD4gObWjDJwwAFPDAG0YSBMVWhp5FAJQ48sbbpoCWbQDIlt97SGySe48QKBY+N1DlnvXgwVxnMHci95yl20qg4AmMQumWwtA8AGHNndMYRKhQjl1WHgR9tREEHXhBasXokrxKZ+/Ys5kFQO7I6xotYbRsA71T2PjETCB9KtfZmePMA4qFymp4JzYPyG8i65azbkIgF/xOd3o6+Hzq82sgAZSXyjYKKoHC8q+Dh7/zYqbhSr88rPrDPzvQ9yr41aicyNKyDQDZUqm4JDCMB6vhlxWkN63bECh4AqMyHJqbTACsJUXCQ6Df/fqo3HwCr1LyACiPP9eRGY12MIZDA0C21q/VGCDOZrA4KK2GP3Qo9/E7q6lZANFVAslsCBNZiwggHIWWMDa56PCgxYMghaqgpFXNq5TyCiv9f0chBGM4NABkS6ESyN9zOIyLA6vhV1SzAAiBesTgSQDAUpKqoPGM26+W4jfEyf9+iLXtr4hUA627knAUALKiELRTBRQPldXwPltYJUuYV7NAM5e7DYHqFphvB1MYDs1MIAAKa2zXM6heklfE7Bl7Nrcw6Hz48+/DViK9LjKkU+nUEQCKRuE5SOEeDJ1RWQ3PPKAFH7HueFJVb7wqFpAneJVKxULyBNxLztXmPwDIz9y5Dw1YSRIGeTAzsvWG5iut7Tse/PhJ6P7xHwWp+lmKysmsyrwKACiaIZG5qAyFjoPSanjmAS3oNgRynlhVLKBjx46ZAm8JIwQCyuusQC/6moFLDfr8vcKDIH/5CapXqvi6VP+8m5sj/++ZmH7LZo6fstr0m3LzEGZmT5mCLdczHBoAsjAoct/Bevg4bG8cfqkQqwTy4pqaBdJLCOSNdDstIJVevi2bNjRuwt8yAAhl8LJLDHHxahl/+eYulwRBXiG0blF7n4c8Z8992Gyz8hXs6kMwk+HQ6wMPLF9HmyTQE/8eDn1qPzjA+5oy1sOjGzcKrYb3sTJCgrWCuV5CoLoFppLiMXgSKDeFSkC2g8UvaaE6YsXgw6HXbw37dUnLNtAb33oZPARiu5801sOjU946GPpQKCHYCnbQAup2MLQLXobjg6EVkjyVnlgAAFQwHBoAikuhEshboqFPqTWb1fAX6iUEqlugVWbtFFrCPNnktAIoL/XWHCAEb1tTMLSRLZ5AjNYMcG+tTOHZZ+7cBwZ9PvtQgeBq+LoF7q7qJQRywf8Wp6enTYHKyjsA+TsrsB1MpcwWSKic0NKyDXRPYe02B6zaFNbDqywhwPL8/tQ3gymgCuhivYZAwRMYlTSPeRwAACzwOTwKVXK0bANxWs9gd1kqB08nTjHvTZ1SS7bgPKDgf6BoK4FkNoSJJJwA8qcydJZqIKg58sbbFhot20D3TrJxCStQOfxWqFjDyrYNX2cqqAS6WNQhEMOhAQDQo3KDrrLKGEDnqLLXNXjZJaaA9fD6VEamCK6Gr5nAfOV+QqDgf3gf8hQaJ41AeXESBSxNZS6QwuwKICYKFa6EQLpUrqmsh9fmnTIqz8djY2MmRqI3rdcQyNUtMJXh0Jw0AgiJG2aoOTIzawrWr+V7A+iGwjyvQbaDyVJoP2czq77tW28wFbSCLa2fEIjh0PM4aQTKae4cNyLAUmSGQ3NIA3RFYeulVxBQZa9pncDQbqqA9N0oMhTaswKFzqE2dRMYq+P6CYGC/x9QSfY2MRcIKCWV06jBAY0efaDdyffCt5VwSAN0R2XhwborqeJTpBDOzb0fPqjE8rwVTGVhycTEhImpmYioQyCVZO9GNoQBCIgTUyhSmAtERQHQHZVZd6yJ16QQrFMJpK06fK2pOHjwoImR2VUfdQjkk74VWsIYDg2Ul8qpKaDm9eMaN+q0hAGdU2lzZtadHpVnHZZyaNsi0grmxSLMA1pePyGQbwerW2AMhwYAQI9CO5ijJQzonLc5K7Q6M9Rdj8q1lPXwurwwQuXrRDQAktlV308I5II32jEcGkDZcWIKRSpr4nmYBLqjEOAyE0jP4GUa8wfZDqZr22adVrBDh2Q6rxJSf6B+Q6DgCYxKCLSFuUBAKZ1lQxiwJDaEAXFSqLQYYumKHJVgjplAupTmAQlWAkkNKCIESglvVkA5cSIFLE+iooBKOaArCjNXVLYLYYHGZjDuuVT596xKUYQHQD47WEjdBMbotIs+BPJ/YIUtYQyHBhAKW1SgSqEljPdnoDsnTqlsCCMIUqLw70EVkC6VgdBubGzMxNRMTL8hkMRw6ImJ4KOJmrZcr/PFDyAfJxlQCCxLZUMY80WAzqkMdVd6qIRXVYY/cJp7/0ODppGtN5gKwVYwuVSq3xDI0RI2b2gjw6EBAEioPExuomUb6JjKUHdaObUoVFSqvKfgQkqtYJ4LKHQJtfGimZqJSSMECl6Go5L2sSEMAIAFKg+THNIAnTshMBPIcV+tRaGikplAmmgFW5FGy9IiaYRAdQtMJe2jbBUonzmB7WCclkKVyoawwQGN1cZALBSCIJauaJGoBBIJKHGhbcPXmQq2gnUmjRCoZoH5cGiFljC/ODLEDigXTqWAlSmU798oUqYOxGJmlqHuWKDy73CCOYxy/GujulljNbwXhqiMiWlTM0FphEASw6Gnp6dNAdVAAAAsUGgJGxzgQRLohkrFxdAGqoEUKAyFdhy86VEJgJxgFVDNxFbDJ9IIgRzDoecxdwBA3gYHLjVAlUJbCZW6QHdk5nkxF0iCyn3GWYEWfFxIqRVMcB7QIROVVgjEcOh5nFgA5aJwKrXmMuadQNdJkfJ93p+Bzr0++3NTwGY/DYMi9xkqQ8uxYMv1Gl0w3gomWgkkKa0QqG6B+T+8zwYKjRMLoFzOnvvQACxP5WGS2SJA51QqgZjnpUGhEohWMD3V4Wtl3lsFA6C6CXRLLSetEKhmgXkApLAljJJzAAAWyFQC0a4NdGVm9h0LjeHQGhRmAilsY8WFqptpBVtBzYSlFQJJDIeemAjeldbEcGgAAFr89FZiLhBr4oGuqFQDqbSbICzWw+vZJjIU2otBBCuB5FKpdmmFQI7h0PM4bQQAYIHCuumhDZ8wAJ17/Xj4SiC3ZRMtYaHR5YDFlFrBDh48aGK8QKZmwtIMgRgOPW/L9bxZAWWhUOHAzRnUnRWY5aCy4hiIhUI7mGOoe3hrBB72qQTSotQKduiQ3BIuuVRqsTRDoLoFJjMceuNa+pcBAJinUFHg78u8NwOdU6jgcyxdCU+hnXaORRxSVFrBnGArmOxq+ESaIVDNBMi0hHFqAQBAk8oWvXVXUjUHdEpmnlcjvGXeJtgOpkOpFcyrgBSKQBapmbg0QyCJ4dDT09OmgFMLAABaVNbEb9rIAQ3QjVdm3jYF3FeHtU6g7ZwQSIdSK5jgPKCatXIRaWmGQC74XCCVSiBuNAEAaFFZE79mgHYwoBsyw6GHmLdZdmdZES9DqRVMMASS3gqWSDsECp7AqPQE3sibFQAATX6Cq3CKywEN0J0jb8yaAtrBwlJYQEElkAZawVZVswgULgRSGQ7tF0sGUALFx7YKoDMn3wv/vbJm4FID0LmZ46ckHr6ZCwQGQ2sY2fppUyHaCla3CBQuBHI6q+J5swIAwPnDZGhDVAIBXdNZFc9cICAkD2OrbAVbifxWsETaIZDEcOiJieCjiZq2bKIlDEA+FEq1gZXMCcxzGGQmENA1lVXx3oaC/NHZgIRaAOQdQGLkSpOWk3YI5BgOPY818QAAtChUAvnDDA80QHeOzGjMBfJKIL5/86cSntN+H962YZ2tYGNjcvOXPYCoWySyCIGCJzA6IRBlqwAAuLlzH5iCdVdSNQd044jImngPgDhgBcLwinNawVak0YrUoSxCoJoF5oOhFcrD/M2KFg0AADQqgdz6qwYNQOd8MLTKXKCqUCUCUCZKg9lFW8FGLSJZhEB1EyAzF4hNBgAASMwEcrSTAN1TqQbacj3zNvO25rJLTIHKe0hZjWy9wVQItoLVTWRBVqeyCIF8ODQtYfMIgQAAaFUTKKyaXkeFLtA1mblAG9cS5OZscOBSU6Dw/lFW3tmyZUgngGUrWP+yCIFc8DIclS+OG4W+YQAACOnke+EHe9IOBnRPpRLIjdysU5EAlAGtYKuKZitYIqsQSKISyGcDhebJKScWAACYnXh3zkJbI3KqDcREay4Qq+KBPNEKtqK6CcxE7lZWIVDNBLAqHgAAHWcFyvm9nQRA91SqgVgVD+SHVrBV1SxCWYVAdWvNBgpqenraFLAqHgAArwQK3w42OMDDI9CL2tSbpoBV8UB+tgmthT906JBiK5hcaVInsgqBHMOh51G2CgCA2UmBdjAqCIDezMyekhnOy6p4IB87bh82FQcPyo3eqRuVQBcJXoajUi5GJRAAAL7i9wNTsJ4NYUDXlOYCMRwayJ63Tyu9XwqGQDWLVJYhUM0C83IxhZIxP3XkhhMAUHYzx0+ZgjW0hAE9qU29ZQr83lppY1GRnRRo43VUcebvS7f9pqnwVjCFpU+LRNkK5godArmJieDb6pt4owIAlN3cOY1WEtbEA7058sasqVAaVovsMc8tfzcKPb+Ojo6amLpRCbQkj+rqFpjKXCBCIABA2anME+FEGeiNV/PJzAXazFwgICsesqp0sngFEK1g6coyBHLBy3BUQqAbOa0AAEBiQ9g6WrSBno2/dNQUqM0rAYpk+1aduVuCAZCLthXMZR0CSWwIU+gf9DcpTh4BZEXhwRroxFmBljDej4HeqayKdyNCD6pAkSithh8bk8tb6kYl0IqCh0AeAMm0hF1PSxgAoNxOKKyJH7jEAPRGaVU84xayp3LIRAVnfrwKSOWwxJc8qWz8blOzyOURAgUvw5meDr6tvmnLJlrCAADldlbg4ZGHCaB3SqvileaWAEWxbVhn3pZgAOSibgVzWYdADIduM7RhrQEAUGYKp8qDA5cagN6prIp3tISVAxWc+fBQtUor2ErqRiVQR4IPh1ZJEIc2XG0AioWKAqA7Cm0kay7jYQLoh8pwaEdLWPYkwntmueVC6fuJVrDs5BECBS/D8S8gf4XmFy+CIABAmZ0996GFRvsI0B8Pc4/MzJoCWsKA9Oy4fdhUHDp0yARF3wrm8giBaiZgYiJ4QVITpxUAgDKbO/eBAYjfkZm3TQUtYcVH5XX2PExVKlgYHR01MXWjEqhjdRMYDq0yF2jTRuYCAUiXypYWoBMqm2aoHAD6o1IJ5KqbdQbZFtFJkes2snX3yE2mwp/dVZ7f29SsIPIIgVzNAlPpJ7xxiA1hANI1d44QCPE4+374djAA/fNKIJVQd6hxyEq1fXbmJNp4Bw3ZulHoe2jfvn0mqBCtYC6vECh4L5YniadPBy9Iap48cvoIACgrldCS1gKgfxPTOlvCtnDQmpmzVBwXntpsLcGB0HWjEqhrErVcKiVlnFQAxUGoC3RHpX2RdcNA/2pTb5qKHbfpDLRF+gjus7VdaK6WB0AKS50WkZxS3atShUDT09OmYGgjG8IAAOWlEASxbhjon7eEyQS7je9pDlqzIbEifuBSQzb8e0dpuPrYmGTX1agVSF4hkPdhBQ+CVMrKtlxPuSqA9DBjBbFhjhVQHOMvHTUV1WEGRGdBIehbcxnVm1mpbr7WlBw8eNDE1E2kqCUteYVALvhcIJUQyIfXcQIJIC2s3EZszgqEQLQWAOlQagkbufkG7rEzcFZiMDTX7KwoVQH5WniFOb6LSE6p7keeIVDw9My/oFT6C4c2sCoeKIJ1bKsAuqbSPgKgf2otYWpVDUWgcthEwJc+D9eUhqofOiQ5ekeuNKlfeYZANRMwMRG8IKmJclUAQFmxbhgoFqWWMKWqhqJQmAnkBgcIgdK243adgeperCHYClazVjtYoeQZAtVN4C9QpiWMSiAAQEmxbhgoFqWWMK9qoGIkXSqzB9cQAqVum1DlnOBaeCc5pbpfeYZAjrlA84Y2XM0bFIBUnBQ5oQMAlJNSS5hjXXy6VIb5U8GZLg9MlWYt7dsnOXqnZgWUdwgUfC6Ql5kpDJvyAIhqICB+DCoEuqfwQMFgaCBdB17QWZ5DS1i6lGY+IT3bhb5P/Bl9akpuAVfNCtgK5vIOgWomQKkaCACAsmEwNFA8R2ZmTUVr2O2nDOlRmAtEeJ8e/x5RCkv37t1rggrZCuZCVAIFL8NRGQ6tNIkdQG/WCJxKnXh3zgB0Z3DgUgOQHm8JUwqCWMKSrrMCFZy0g6VHLSQVnQdUuK1gibxDIBe8zkul1IwTCiB+gwOXGIDunBQILtdcxvcukDYPglSM3HwD7UMpUjhwWkN4nxqlrWAeAHk7mJhREyheyUqIEGjaAvMvNJ25QLSEAQAAIH5Kc4H8PtuDIKRDYasjcxjTMbRxrdQz6NiYZNfVISuwECFQzQRQDQSgKNgOBgBQ4PO+tFrCdNZfx05hJhAVnOn40m2/aSq8MGN0dNTE1K3ArWCutCGQylygTRvZEAbEjCGFQJwGB2gTAbJQm3rLVPj8TQ5c06HQxkslUDpuFPqeOHhQMmupWcGFCIG8D6tugakMn9q2maF1APrDpiXERuFEmVkhQDbGXzoq9b7EgOh0zJ37wBQQBPXH18Ir/R2KtoIVditYIkQI5IL32Km0g/lNKBczIF4K379z5z40AAAUeAA0Ma1TDcSA6HQohPduDVWcfVFaC+/DoAW3gtWNSqDMBE9gvP+QuUAAAABAug5PvmYqGBCdjrPvaxw4MUqjd35w6S2SKvbt22eCJP9QaQsVAtVMgMpcIEIgIE4qJ4u0gwEAlPiqeK2WMAZE94tKoPjdPXKTKRGdB1TogdCJUCFQ3VqzgYJSKT+7USiRBdA5lcGyZ88RAgEAtCiti2dAdDoUgqD1axmj0SulgdD+HO7tYGJqJjC7OA+hQiBXs8BUQiAvzaNXGYiPyqrSOUIgREZlwCiA7IxPHjUl24VmocRK4dBpcIA18b1gIHRHCj8QOhEyBArei+VzgVQSyOpmylSB2AwOXGoKaAdDbFRmS7CYAciOV40cmZk1Fb6Rl0PX/swcP2WhDW34hKF7agOhR0dHTVDNSqLUlUBOZS7Q0MarDQAAACiK2pTOljAPgHbcNmzonULlsUoVdkzUBkILbgRzo1aSVjAXMgTyRmHmAs3bRiUQEB2FKgKVQY0AACw2/tJRqWpVQqD+nDglMBOICs6uKVUBOdGtYIesREKGQC74xDjmAgHo1RqBvnSVthoAABbzAMiDIBV+r82A6N6dPUcrb4yUQqCpqanmS0zdSrIVLBE6BArei+U9icwFAtALheCWAbsAAGW1qTdNidqa7Ji8PvtzU8Ca+M5Vh6+VCs1Eq4BqVjKhQ6CaCWAuEIBeUL0HAMDKjsy8LTUgmnXxvVOpPt60ca2hMyNbP21KROcB7bWSKX07mFMpSdtyvc7ALgCrGxQ4iTrJTCAAgDilAdGuOnydoXsqcwipBOqMVwApdZr4RjCVDpw2HgTUrWRCh0A+GLpmgR08qNECONRItaksAOKx7qpBC21OpD8fiJHCphugDNQGRI/cfAP33D1SCIKoBOrMjts3m5KxsTETJNmflrXQIZCbtsA8kTx9OviisqYt11OeCqBzSjfVQKdUVvzy/QPkQ3FANJvCenNWYU38wKWG1W3brFPx5s/boq1gNSshhRCoZgIOHdLYCrdlEy1hQCzWCQza4yEWMRrkBh4oHbUB0YRAvZk5fspCG6ISaFXbt94gNRB6717JsTujVsJWMEcINI+5QAC6pTATSOFEDgCA1agNiGZdfG8U2mgV7r/UKa2Fd6JVQBpVIAEohEDeh1W3wFS+MJkLBMRD4Xv1xLtzBgBADNQGRLMuvnsKlUB+/8Xz0vK8Asi34KkQHQhdb7w0BgMHoBACueApnFcCMRcIQKeUSmwBAIiB2oBo1sV3b+7cB6Zg3ZXchy1HLdwUHQhdsxJTCYEkerFUqoGYCwToUxlsy4p4AEAsPAA68ILGCIYEs4G6o1AJ5NYLbGhVdaNQsCk8EFpySFFeVEIgiVKsiYkJU8BcIECfymBbVlwjRgqVdAprjoEyUguBqsPX0VrUBZX7DoXlHIrUBkILVwHVrcRUQiDmArVhLhCgT+UNlu1gAICY+PuW0oBoRzVQ5/zfT+HeY/1aQqClqA2E9nlAgiSTqTyphEAueBkOc4EAdGrNQPh2MCoZAAAx2j/+sinxEIgD2M6dfC/8/cegwH2YGi8kUBoIfejQIcWB0P6wX9qB0AmlEKhmApgLBKATCjeLzANCrBRC1LPvf2gAwvB18UoHGf6eTjVQ5xQ2kw5t+IThQl+67TdNiWgVkAdAGlUfARECLaIyF2jb5msNgC62gwG9UwhRVTbcAGU1PnnUlBACdU7hEEplQYcKvy9VagXzCqCDByULbkrfCuaUQqC6MRfoPP9GpiwV0LVOYCsFlUAAgFj5gGiluXZ+371dbJ6KqhOnwt9/8Kx0oS1CG8Gc6EDoupV8NXxCKQRyzAVqU6UaCJClcOOhUI4N9IJKOgCK6+LVhuqqOntOo512cIAQKPGVkZtMiWgrWKnXwrdTC4Ek3gl0toRdbQA0rbsy/EMsm8GA3lFJB4Sn1hLmQ3XVKioUvT77c1MwtGGtofV1q3S44gGQ4EBoVzM0qYVAEo2DzAUCsBqFSqCz5wiBECeFdkoA4flwaLV18XeLVVQoUhmsTztYy47bteZZibaCjZrA6BkVaiFQ3QSmdSvNBaJkHtCj8n1JOxjQO75/AA1q6+KpBlqdyma3dTwnNe9JlUaIeAWQyrP0IgyEbqMWArlDFpjSXCDehAA9KjcdtIMhVpzeAkj4uniqgeKjEAStp6pU7mt1717JsTt1oxXsAoohEHOB2hACAXoGRdaSnnyPmSaI0xqBYZ7MBAJ01KbeMiVUA61uZvaUhbZm4FIruxvFvk6pAoqDYgjEXKA2NzbehABoURgK7agEQqxodQbQbvylo3LvaayLX9lZgX+voY3lHgztX6MMhO7IqOECiiFQ3ZgLdB5zgQA969eG/55U6ccHYsVMIECH5rr4T9O6ugKF+5Cyr4hXWwsvOhDaR83UDRdQDIEcc4HasCUM0KIwE4hWFsSKgw0AS/EQSK0aaMdtWluXlJwUCNI9pCtrUKe2Fl54IPSo4SKqIZDEUcChQ8GzqKZNJS91BNQMDoSfCTQnsp4V6JbKYHWCVECLB0DeFqbEQyCqgZY2d+4DU1DWaiC1dkXhgdASo2bUqIZAEv9YXg2kYNvm6wyADolKIIZCA32ZO8dMLUDNgee1WsI8AKIaaGkzx8MPhnZDG8p3WO4VQCNCIZBXAfk8IEEMhF6GaghUN4G5QAcPagSH/gY0tOFqA6BBofz2xClCIMRJpXydweqAHp8zo7YunmqgpakE6WX8t1FbCy/aBuZGDUtSDYFc8F4sTzVV5gKxphLQoPIASysLYrXuqkELjcHqgK794y+bEqqBluZBukKYrtJinCe1tfCirWAMhF6BcgjEXKA21WGGQwMKVG425s4xEwhxUji1JUQFdB2ZeZtqoEgoVAOtFzhYyJPaWnivAmItfHyUQyCJXiyV8jbawQANg5eFHwrteIhFrMp4agugO1QDxWFmNvxcoDUDl1qZsBa+I3VjIPSKlEOgugnMBVIJgfzNh5YwIDyVQJZ2FsRKYbseISqgzauB1N7nqAa62FmBdjClqpisKa6FZyB0nJRDICcxF0ilxM2/8QGEJTEUmgdYREwhSD3x7pwB0MamMH0K9yMKc+bysuN2ra8/0VlAbtSwIvUQiLlAbagEAsJTuNmgigExUzhJZzMYoG/8paNy36tUA13opECgXpZ/Dz+ErG7WmhEruhVs1BgIvSr1EEiil29qSuMkwiuBeOMBwtJ4gGUoNOI0tHGtKSBIBfR5AHTgBaqBlM2d+8AUlKElTG0tvLeBiQ6EphWsA+ohUN0EkryDB3XmSm25nmogICSFVpaZ2XcMiNGgyABPtusBcfAQiGogXSrt6WsGiv3v4SHXyNYbTMm+fftMUL3xqhlWpR4CuQkL7PTp0zrVQJuYCwSEQhUD0B+V01qCVCAOVANpOytSmVz0NfFqI0G8DUzl2XgR2SFFamIIgWomYGIieBbVtE2sFxQoE5UqBobaIlYqAzyZCQTEg2ogXSqVQEX/t2AtfMdqho7EEAJJ9GKptIT5KSpvOkAYQxs0KoF4gEWshjYKtFMeP2UA4kE1kDaNDWHFnQm0fesNrIXvzKgxELpjMYRAp03gH1Sp5E1tMjxQFuvX0soC9GNw4BILTWWQKYDOqYVAjmqglrPnwh9MFbkdTK0KSHQWkJP9gymKIQRywXe0+1wglTV4rIoHwlA4aaKKATFTGKzOTC0gPl4NND551JRQDdRCi3p2fDO02uYzpYVJbabmX+hQLCGQxD+qzlyg6wxA/hROmqhiQKz8gUnh1JwHFiBO+8dfNjVUA/lw6PCVQEVtB9suthFMeC08VUBdiiUEkogcVSqB/M1G4TQVKJt1VwpUAs1SCYQ4qbxvzRynnRKIkc+eqU2/ZUqoBmImUFYU18Lv3Su5fKturXlA6EIsIZDPBQpeDeQhkLeFKaAlDMiXTBXDKVpZECeVkva5cxorjQF078Dzr5qaslcDsawiG3eLzQLy52DRKqCaoWuxhEBOohdLZUB0dZjh0ECeVFZbM88EsRraqLFdj8HqQLyOzLzdeM2akrJXA50VCNbV5ub0S7EKSHgtvGR5krqYQiCJlrBDh4LPqG7ysno2EgD5GRy41BQwzwSxGtoQPgTyE2tOrYG4MRtIi0I7mCvS379aACS8Ft4fzOuGrsUUAkmU4KhMRG/NBdI4VQXKQOWU6eR7VAIhTgo36FQBAfGjGkiLysKKwQFCoKyIzgJyo4aexBQC+TCemgXmSajKXKDqMFvCgLwotINRxYBYqSw0mHufeUBAEVANpOOsyHW1KMOhfSOYUnubP/eqLEdapG4inUIxiikEchJzgVRawrZcv8EA5EPhxu4krWCIlMxmMCqBgEKgGkiHTDvYwCVWBF8RGwjtXTCiA6GZBdSH2EKgmglQSUN9yCZzgYB8KJQZq5RcA91SaV9mPTxQHFQD6VCoUi7C37taFZATbQWT6BCKWYwhUPBeLJW5QK66mS1hQB4U2sHYDIZYrV+rcVPLYHWgOKgG0jF3jlb1NKjNAvJh0KJVQP4wXjf0LLYQyAUfEO29kSqr4rcMfcoAlAMPsIiVTCUQ7WBAoVANhETsM4G2DG1ovpSwFr64YgyBJAbyTExIjCeybZsZDg3koSgDB4EQFG5sZ46fMgDFoloNdPcdWnNdskalcv+2i1UBecGD6EDomlEF1LcYQ6CaCVBaFU81EJA9hZlA3GQhRj6/ToHK8FIA6ZKsBrp9WG62S5bmzoXfELZeoG2/V/61otYKtm/fPhMlW54Uk1jbwYLPBfJ0VGVVvFrpIFBECqXdrIdHjDaxGQxAhhSrgdzdI5+xsjjL/Ulf7hbbCOZzgHwekKB64zVq6FuMIZAL3hLGXCAAeVM4aQO6NbRRIwTyB0UAxaRYDTSy9dPco+dozcClFiPFKiDRjWCOWUApiTUEqpmAQ4ckxhM1K4EYQAdkR6Wkm0ogxIih0ACyplsNVI7ZQArttoOXXWIxUqwCEp0FxFr4FMUaAkkM5FH6BmFVPFB8Z1nBiggptCx7gEqIChSbYjVQa+MT1UB5GIywEsgPGbeJPcP58y1r4Ysv1hDIk8C6BaY0F0il3B4AgITKzDqqgIDioxooHIWQfU2ElUDeBqbWzUErWDnEGgI5iV4slZawkZu1ekmBIlG5sWC7EWKj0grGPCCgHKgGCuMsMwt7ojYLyIdBi1YB+QN33ZCamEMgWsLaeIo8JLKBBSiaGEuMAQVbNolUAh2nEggoA6qBEIvtjQBIZeZkQrgK6DFDqmIOgSRWcx08KJFFNdFzDABQsuV6jfelmdlTBqAcVKuBqsPFnd85d+4DC21wIK4lOV8RCwaFZwHVjYHQqYs5BJKYEO4zgVSqgYr85gIAiMvQxrUSsw58VgWtlEB5qFYD3X/XLVZUc++HbweLaVOyYhXQvn37TBSzgDIQcwjkJkzAxITEH4NV8QAAGZtEWpSZBwSUz96x50yNP/TvuG3YALUqIK8AUupuaVNvvEYNqYs9BKqZAKVV8Sql9wCActs2fJ0pUKwIAJAtr/4bnzxqanw2EAe25cYsoK5IJlNFUIQQKPiOdg+BVFbFqwzhBACUG/OAAISkOBvIAyCqgcpNsQrIt4KJku1Ri13sIZBjVXwbVsUDAEJTmQfkZmbZDAaUkVcDHXhBYo/MBTwEKlo1kMJg6Bj46A6qgDo2aqyFz0wRQiCJq/vUlMabDKviAQChbbleZTX8qeZgaADl5NVAateAIlYDnRUYDO3UApbF7h75jCnxKiClsSaLMBA6Q0UIgUZNgFIZHavigXRxwgV0R2Vb5ZE3mAcElJkHQIrVQD4bSD2wQLq8CshfSoTXwteMKqBMFSEE8mE8dQvMZwKpVAOxKh5Il8oJFxALlRvdI68TAgFl5yGQYkWgWlUIsuUDodUIt4IxCyhjRQiBnMRAHlbFA8gSp4aIgdJJJ0OhAahWA41s/TTV+yXh928jYiGQd7GIVgHVja1gmStKCCTxhXLwoM7Xa3Uz1UAAgPypVKP6PCAfDAsAutVAWpuikA3Ff2fhKiBmAeWgKCGQx/usim/DyQKQnrlzDJYFOrVN5BBiZvbnBgBOtRqoNSeGe/YiowqoK3UTmfdbdEUJgTx5kbiyq0xY37b5OgOQDpXTw3W0g0Gc3+yqtC3Wpt4yAEhQDVR8iod2VAF1ZcyQi6KEQI65QG18JhAnC0B6FG4cBwcuMUCZ0vsO84AAtPP38UeeetHUeDWQ4tDgbqgcUqmFfIpVQMIbwdyoIRdFCoEkBvJorYrXWkMIxEzhdImB71CncrPLPCAASzk8eVTy2nD/XbfwHl9AVAF1ZdRYC5+bIoVAdROYC6S0Kp5KIKBY1gxwgwhdfuIpsxr+DVbDA1ja3rFnTY0HQDtuGzYUh2oVkMrokiUwEDpHRQqBnEQfIavigeI5KXByuH4tM4GgS+nggXlAAJZzZObtxksvKPYQiPv24lCsAhobkx25M2pUAeWqaCFQzQQorYofuTnuHmNAxcl35yw0ZgJB2bZhnYUEig94AHTsH3/Z1HgAdPcdDIkuAsUqIJ8DpDS2ZBEGQueMECgDWqvimQsEFAXbwaDKH16qIqvhCYAArEa2Guj2YZkNi91Q+DMrzXpiFlBXaibyDF8mRQuBPHmpmYBDhySWlTXL8yktBfqncHNBCARVKgGQoxUMQCcUq4Hc7p2fNcSLKqCuUQUUQNFCICcxkEdl6JYHQEMb1hqA/mi0gxHoQpNSK9jENCEQgNV5NdD45FFT41X8sS13WUO7+nlUAXWlbqyFD6KIIVDNBCjNBaoK3ZwDsZo794GF5qEulX1Qo9QK5hV7rIYH0CnVaiDFIGElCvcmEgs8qALqFhvBAilqCCSxKl6lGmibUJk+ECuVB8t1V9ISBi1KrWCvMA8IQBf8vV0xCPJqoOow9++xoQqoK3WjCiiYIoZATmIgj8qqeE+lYxwyByg5+/6HpmDTRto7oUWpFezw5E8MALpx4IUpm3v/l6bm/rtuiab6V+E5Yy7wfRpVQF2jCiigooZANROgUgnk1C5KQGz8tFDhJpHh0FDiN70qlUD+/clmMADd8muHB0Fq/Pq647Zhi8EagbDqbOC2fcUqoLEx2ZnLdWMjWFBFDYEkBvJorYqPa8AcoGjuXPgQaP1VgwaoUHpvmZh+0wCgF6rVQB4CxVANNCgwGHruXLhKIKqAulazVhCEQIoaArEqfhHvLWagLNCfmdlTFtrQhk8YoELpppfV8AB65QHQ/mf0ZgP5vXsM1UAKzxghQzzVKiAPgkTRChZYUUMgJzGQR2pLGAOigb4obJ5YRyUQRPjJpx8wqDjyxtsGAL068PyU5HZBDxjUZ3sqLK0IFQJRBdS1UaMKKLgih0A1E6DUErZtM6vigX6cOBX+5tBP2xj0DgVqVUCKrRwA4rJ37FlTtHvnZ02ZQiXQ2UAt+4pVQP78SRUQVlL0EEhiVfzUlMawOZ/dQEsY0LuT72mcEA5tYEMYwlMKgZgHBCANR2belhww71WXqvM9VQ6mTrw7Z3lTrAJywmvhR40qIAlFDoGcxEh0lblAHgDx8Aj0buZ4+JlAjg1hCM0fSJQq0mrTzAMCkI7943qzgZxixYlTuScJUQ2q+G/ibWBUAWE1RQ+BaiZAai7QMC1hQK9U1sQrzWFBOW2nFQxAQXk1UG1Kr7rQ3/uVrr2JwcvCbwZzebeDUQXUNa+KqBsklCEECt4S5mmsSiI7crPexQqIiUJL2NBGKvoQjtqNL61gANL2yFM/lAyXvzJyk9xoB4Wh0C7vod5UAXXtMYOMoodAHgBJDORRaglT7SkGYqDQEuYP4cz3Qihq7yG0ggFImwcKB17QmOnZzt//1VbGr18bPgTKOwCiCqhrNRPp0EFL0UMgJ5G+KLWE0UoC9O714++Ygi3XE+YijB236zyAjE++RisYgEx4CKR4ffEQSOkgSGEm0EmqgNSrgCTm9GJBGUIgifRFaVU8lUBA71Q2hG3ZRJiL/Hkr4tCGq02FzwMCgCx4AKRYDeQB0N136IQQ668atNDm3v/Q8kIVUNfq1toKBiFlCIHqJjKESqUlTG2rCxATlQ1hbPpDCF+67TdNhZf/0woGIEseAuXdatQJr8hUuZdXmAmU5wEdVUBdYyOYoDKEQI6WsEW2bb7WAHRPaUMYc4GQJ3/gUHrveGVm1gAgS/5+/8hTL5qi3Ts/a6H5fYjCvciJU/mEQFQBda1uVAFJKksIREvYItVhQiCgV0feeNsUUA2EPHkrsVLweHjyJwYAWfO20yOCobMfBoUe8aDSHpzXTCCF4G0xqoDQi7KEQDUTWBXvAdDUlEZvMVUEQO9OipSGM+QdefqKUAm8V+QpPpQBKKb94y+botCtSSqHUSfenbOstUI3vfsuqoDQi7KEQK5mAlTmArkqLWFAT1QePhnyjryozZIbnzxqAJCXIzNvy1YDbQ/YnqSwHt7lMRPo7pHPmBqqgNCrMoVAEumLf7OqUOxpBWLgN4MKqOhDXraLvV8QAgHI296x50yRV2mGuhdQqATyuU1Zz2r090CqgLpSN6qApJUpBJKYC+QtYT4bSIH38fIACXTPbzZUtoVQ0YesqQ3C9NN4xW09AIrNrzuKbWF+jd5x27CFoDATaGb2HcuaUjt0giog9KNMIZDPBKqZgImJCVPgARCDZYHevCJTDURLGLKltg6XKiAAofjKeIUNoYt5CJT3wa7KZrCs5zR6FZBSO3SCKiD0o0whkJNIX1QqgZxaiT8QC5WWsG2brzMgSzcKBY1+En+YEAhAIB4AeRCkxsOYvKuBVDaDvX78lGWJKqCuUQUUgbKFQKyKX4QHSKA3KgMi/caPaiBkRe0E9BU2ggEIzEMgxZZUr9rM83qtcu8xM5tdCEQVUNfqJtJ5g5WVLQTy6L5uAsbGxkwBD5BAb/wGUOUmkFXxyIraCehfPj9tABCSVwM98tSLpuj+u/6F5WVoo0YlUJbteVQBdc0fcOsGeWULgZzElrCDByWKkpqqw1QDAb1QmQvEpj9kQW0t/MzxU7kMAAWA1dSm3pJcGe/39Hkd7qpsBsvqfcHb69SqgDz8YRYQ0lDGEIiWsEVGbuYBEuiFylwgv0mhog9pU5sZd+CFVw0AVChuCnN5DPP3+w6FgCSrAKi5ce32MBvXVuKdJFQBIQ1lDIFq1toUFtyhQxJFSbSEAT2qTb9pKmgJQ5rU1sL7aW9t+i0DABV+EFSb0rkPSPj9QNb39UMbNbYLZzUPaERwFpCHP94KJqpuVAFFpYwhkKMlbBFawoDuZVmG3C1awpAmtbXwE43AVXEtM4Bye+SpH0pem7K+hqscPJ04lf5sRg9/1N4DHVVASFNZQ6CaCdDaEnatAegeLWEoGrUqILd//EcGAGp8QYTiyvisq4GKvBlMMQCiCghpK2sIJFGC4wHQ1JTGGwcPkEBvlErBqehDGtTeC3z4quI6ZgBwHgIpVgPt3vk5y4KPkRjaoLEZLO3h3IqHIM6HQVMFhDSVNQTy8puaCVCZC+SYKQJ0zyuBVG7+fMi735wB/VBbiTs+edQAQJXfAyhWA3mgkcWAf5kqoONUAQmoG1VAUSprCOQk0helb2pmigC9mRAZWNs6ndMY1og4bRcbhukVQIcJgQCI801hihWLWYT61c0aVcczsz+3NClXAQmjCihSZQ6BZFrCfDaQApV1j0BsVOYCOcVTLMSDKiAA6M3esWdNTRbVQCqbwdK+99q987OmhiogZKXMIVC98ZKo3VRqCaMaCOie2qp4WsLQC//aUTsIIAQCEAsPJdKeUZOGNMN9f49QmQf0eortYB6UKY7FoAoIWSlzCORoCVuE4dBA93wegNKN347bhg3o1o7btb5uxidfYyA0gKh4W5iaNJe/qDwn+H3XzOw7lha1KlhHFRCyVPYQqGYClFrCFE+CgRjUpjTmAjkPgagGQjf8ul/dfK0p+cvnpw0AYqJaDZRWq/g2kS2kabaCqc3CS1AFhCwRArU2hQU3MTFhKmgJA7o3/pJO24oHQGoP9NCmNkvKH6LSPOUFgLzsHXvO1PghbxpVPCr3FmkGbVQBda1uVAFFr+whkBszAbSEAXFTawkjzEWnFDeiMAsIQKy8jVWxLazfsL86rHO4NDObzjwg/ztRrAL68pe/bMKoAioAQiCRLWGe+PpLAS1hQG+UWsLSOvVD8akFQKyFBxC7Ay9MNQ+HlPS7OEJlNXxah26qK+F9RIjKmJAl1I0qoEIgBBJqCRsbkyhKaqKKAOiet4Qp3fSxLh6dULvef1PwBB0AuuH3Ah4EqelnccSNIgdLac0DogqoJ1QBFQQhUIvEljCl1JcKAqB7zdOpN9IbVtgvqoGwGsWBmGkO/ASAUBSrgXpdHKHUJTAx/ab1S7UKyMeDqHSGLKFuVAEVBiFQi0RLmIdAtIQBcTvw/KumZDtVfViB2kBM1sIDKAoPgPY/o1XZ6AHQyM3d3xco3Uu8frz/eUCqldLiG8H2GVVAhUEI1FIzkZawQ4ckipKaaAkDuudVDEonfyNbP02giyX5kE+1r4394z8yACiKA89PyQXbvQx43iayFcz/LvvdHOkH3VQBda3eeD1mKAxCoBYPgCQadw8elChKaqKNBOiN2hyAu0c+Y8Bi/cyGyAJVQACKaO/Ys6ak21ZxrwLqZ6B0ml5JYSD07p2fNUXiVUDSfzh0jxBogcxcoNOnJYqSaAkDelRLoV89TVQDYTH/evBrvJLDkz8xACgarxBOY5tVmrpph9o2rLEVzPW7hVVxDp7zAIhZQMgTIdCCURPBljAgbjPHTwne8FENhAVq8xC8AkjtewYA0rJfbOthp9VAHphURVrBXL/LN9Tm4DkPf7wVTBhVQAVECLTAy29qJoCWMCB+ai1hXg00tGGtAYpbUVgLD6DIYq0GUnoO8CqgfmYuqq6E37dvH1VAyB0h0IVoCVuEljCgN2oDot0DX7zFALVw36uADk8eNQAoshirgZQqZ/pZDe/PMmpz8JyHP489Jj1vmSqggiIEutCoiaAlDIibB0Bq1UDdDoNEMamVw1MFBKAMYqsGUjsI9r+/Xvn/T5Xh1u3Eh0HXjSqgwiIEuhAtYUvgoRHojVoI5NRmwSBfakMxW7OA+pvxAACxiOlwaLvQIbCHZ71uj1RsgXbMAkJIhEAXmzABai1hQxuuNgDd8Wqg2nR/myzS5t/PSjd2yJfajfArfdzYA0Bs+p1rk4WlDofUgpPxPlqGWQnfk7pRBVRohEAXGzURSi1h1WGdzQBATA48/6qp+YpoWTSypbgWfv/4jwwAyiSGaqAdt282Jb1WjPqhl9r7nvPDfqqAEBIh0MXqRkvYRZgLBPRGcQaA6oBEZEutFXB88jWqgACUTgyt4ts2X2cq+mkFU1wJ77785S+bsJpRBVR4hEBLoyVskdYJMrOBgF6obQRxqqtSkQ3/t962WauikyogAGWk2iqe3OerzY7rtRVM9T7HK4CEV8I7qoBKgBBoaTUTodQSplhOCcTAq4EUKx5U++SRPr+5V2oBPMIsIAAlptgqnlQDqVXP9NIKpjoM2onPAho1oedgZIcQaGk1a7WFBafUEkb7CNA7xTXYHuzyfV0Oajf1/Qz5BIDYKbaK+z3Bk/d/QawKqLe2YdUqoH379lEFBAmEQMuTKMFRagnzU2RawoDeHG489KptBHF3MyS68PzGXm0t/GFCIAAlp9gqrlb179vUuqW8Ev6xxx4zYaMmUgSB7BECLa9mIrS2hOkMigNiozgM0gOg3X9EW1iRbRe7GVasigOAvKm2iqvwv5teZic99Md3mCJvA6MK6P9v7/5j7KrvO/+/SVPwUIYYbK8YxxZjUIeSKvI49LvB/ap4nMBuIkw8TkQUp1JmrP0GzB9b/wBpUwVpZqTNdiPxw+5+pQD9w3cqFdSiwrg4aroJ8TWV1klV4hkpDcSr4DMLAVZAYHAUDN0oe17nzvFcj2fse2fOuef9Oef5kD6dsXGDsWfuPed13j/gBSHQ4upGS9h5tt3MljBgqRQCeawGUrg70O9raDCyoZDP00BoqoAAYM4Tz/p7OOTFj5bQLqeHHn3r1pg3Cn+cr4SvGVVAlUIIdGG0hM1DSxiwdAqAPFYDychXbqMtrIQG4gDI09/rj5zNwACAIh35gc9WcQ+WskHS60p458OghSqgiiEEurC6OeGpJcxbawEQEoVAHsu/aQsrJ29zEVgLDwBzPD8cKtJSNkh6HQY9OTnpvQpIAVBkqBRCoAurGy1h59my8XoqBoAl0gWf15koagtjW1h56GLY05DPpW55AYAy89oqXqR2N0jq/e4up1VAO3bsMMcia7SCoWIIgS7usDmgljAvw8SSlrDfpSUMWCrNRPF6M+z1SRrat/PTvgK9Z46/aACAc1ENdK6lzI7zGgCpAiiAYdCRoXIIgS7OTQmOp5YwbzcXQGjGxr9rHink9bpZA+3xNhD6eeYBAcCCqAaac6zNtfCqYva4El6czwKKjCqgyiIEurh6fFxMZVY1kBdqMaAlDFg6rYb1elOszRr33nmLIVx6jfZU0cVaeABYHNVAc9r9c9h/5x+ZR6yEh2eEQK05aA4oBPIUBLEuHliexxzfGKvajyHw4fL0d8daeAC4OKqB2p8dpzmGHlvYFf4cOHDAHIuMKqBKIwRqTd2cOHbsmHkx0O+n1QAIkaqB6pM/M6/233kL84ECpCpNT61grIUHgIujGsjs8WenWv61uj7xOp5CVUDvvOOikWQx+wyVRgjUmro5GZrlacUgLWHA8j305D+6ffKn7+9H9n+e7/PADMQBkKe/M9bCA0BrqlwNpBb5k6+80fKv97rIQlVAzlfCT5ijmbcoBiFQ61xMZdYLi6eWMNZJA8ujsmfPT/50gTXylVsN4fA0IFMX9ayFB4DWKAB66MnnrIraWQuvaxOvw6B37dplzlEFBEKgNtTNicOHXWytT3h9AQZCohDI842yNm94Xb+Kc+nCWFWaXhxhFhAAtEUz1KoWnrc7O05Vyh6pAsjTw/oF1IyV8DBCoHbUjZaw8zRuOD5qAJYuhCd/CoEYFO2fp2BeX9cMhAaA9o2Nf9eqpJ0NkroW8Tqv0PlKeGEjGBKEQO1x0RKmQWOeUmZVCQBYnvrkS25XxqdGhm6zvnWrDX55CoGOTfkdeg4AnmlxhPdrgqy0UwWk8OerTiuTA1kJHxlghEDtqpsTrlrCWBUPZGJs/HvuB0I+uv8LbAxzSm1gnv5unjn+ogEAluaxNqpjQtZOFRDDoJcsMlbCowkhUHvq8XExwVUvNF5WD2oLDS1hwPJ5HxIt6cYwgiB/PLXr6Wu5Kk+xASAPqgYq+1y1dquAvM4ipQoIoSEEap+LEhwFQJOTfm4WGRoLZENP/tpZkVoEXYixOt6fLRuvMy+eeNZ3mAkAIXjwyedKvTK+nSogr8OgqQJCiAiB2lczJzwNH+tbt4YbQiAjD/6N//WwCoIeJQhyQ1VAnv4ujk29ZACA5VEA5L1CeKnaqQLyPAx669at5hzDoHEeQqD2ReZkNpAqgTy1hDEbCMiGSsBDuOhT+PvA7tsNxfNUIq82sKqtNwaAvKhCuIyvqa1WAXkeBq0KIOdtYLqYrBkwDyHQ0hwzBxQAjY+7WFiWGOj304oAhC6Uiz4NIx4ZutVQHF0g6+/Bi7LPsACATivbyvh2qoC8DoPWfVgAK+F3GLAAQqClOWBOTExMmBfeNtMAIVMJeCgXfXds/hhBUIE8DebX122dVjAAyJQqhOuTP7OyaLUKSBXHXodBHzx40HsVUM0YBo1FEAItjXqw6uZAvV530xImXl+ogRCF0hYmBEHF2fnpfvPi2NTPSj3EFACKMvaX3yvF66tahlutAnrgHp8t5wp/RkdHzTlmAWFRhEBL52JLmCiJ9mLnp/zcjABloCHR3reFpQiCOq9v/erkSakXzxx/0QAA2VMA9Ni3W9+m5dXY+Pda+nVe28AkgDYwVsLjggiBlq5mTnhqCdOAaE+tCUAZ3Petbwfz9E9B0OP372RrWId8+VObzAvNeNATXgBAPp54djLo19kjx3/S0rxDhT9eHyxrGDQr4RE6QqClc9MSpi1hagvzgmogIFu6YArp6Z8qU7Q+nhlh+fuEo9CdtfAAkL9WK2k8euzIP7X061QF5PVhElVAKANCoOVxs5rr8GE33WnJgGiqAIBs6elfSFuXFAQ9QhCUK2/D+PU1CgDIV/Jg6Eh4bWGtbj29Y/ONbmeMKgByPgw6MqqA0AJCoOVRH5aLqcyeyhIVAG27mQHRQNYefPK5INbGpxRQEATl5w5HF8lqTwjpaxMAQqZAJZR5gdJqcKV7iK9u+6R5pPDnwAE3C6IXs8+AFhACLY8CIBePPrUhzFNL2ED/dQYgW5oLdN+3jgS1HUQB0F99fSevCTnYstHPn2lIVWoAUAajte9aKFpdCe99GLSnjcwLqFmjQAG4qN8yLNd0fIbNgenpaRseHjYP9AKuJ8OvvXXaAGTnrXd/ZR/8n1/bH/7+tRaKy377w/bv/qAv+Vxr77F8qgL6d/9Pn3mh1cUf/OuvDQDQGboeELUGe6YHV3/2xNGLvkfo3uG//H+fMY/0oH3fPvdFNjvMSYcK/KMSaPlUCeTiG04Doj0l1N7flIBQafbKE98Pb/6KnvDde+cthuXb0n+9eaFtLyFVpwFAWYTQFqYWrwd2337RX6f2ca927dplztWMYdBoAyHQ8il1cTEgWgHQ+LibWdVsCQNyFNo8gNTOT/cnK+SZE7R0+rMbcNQK9szxFw0AUIz7vvVt90G8Hgxf6CGQ7hm8XhccPHgwhGHQ7leWwRdCoGy46b+cmPDTCqrk/yZH64uBMmnMB/p2kMN4081hfetWG9rn6XVVX39q/QUAFCMZuvxt/9vC9BBooYUGCn/0zzwKZBg0K+HRNkKgbNTNSUuYelY9pdV3OZ3wD5SBLvzGxsMZDNlMF32P3/9lXiOWwNPq3B8RAAFA4dQmHkIgv//OW857AOR9GDQr4VFGhEDZOWhOeGoJU/mnKoIA5EODlrU6PlS6+NOsANrDWqM/J0/z1h5/dsoAAMUbG/+e+7awZD7QPdvO3huoMsjTg41merBeq9XMOVbCY0nYDpatYXNAA6K/9rWvmRfaBsBGICA/Pz71evIx1GHsvddcbVv6r7Nfvve+nXzlTcPiBuI/pwEnQ6FPvvxmEC0IAFAFp+P30On//fbZbZxeKQD6+IZr7EfxvcHI0G1uHxZv3bo1hJXw3zTM1xuflfFRj+FA08fPzH7U2R6fL8VnU9PPpb/292b//3tn//dKuXHtEkOWjlrjC6hwR48etYGBAfNATyW27n/UAORrNL6Y8vpErVUqaVewwLaphT26//Nuwj61Ij5z/AUDAPhx7xdvCWI5i5ZbaEagR2oDGx0dNec2WDVnAfXaXMizsenz5uAma+k2cH2cnv1Yt4B92JClw+YkBFJLmJcQKB0QTTUQkC+1hfWtX+32oqoVGg6pqqDdDz0V5NDrPHlrBeM1HQD80fbQLRuvc99m7fVahWHQbqThThr26GPv7M93WpqqDsz7+TQMOmaOZgS3gplA2aqZE9oS5qmEkXXxQP5C3hjWTBeuf/eN4WSdLDPF5njaCqYBpIR0AOCPrgX0IIWK2qVRFZDzNrAoPu5TqjYp2BmIz974HIrPqfi8bY0um4etMXIlrfbxRL8n/Z6ftsbv90R8Rm0uNHKLEChbesWomwN68WJANFA9ujEvSxWNqoL+6us7F1wpW0WeWv2O0AYGAG6FsjbeGw2CDmAYtKqAQp5T00rg02thUvgzYo0wSP9d+u/pNYcYDJ09zVkaNAfOnDljw8PD5sFlv/1hBkQDHaLhkKrU0HBIfe+FTOGxBiGvXdWdDI3Wf1sVqTpKcx68GPvL7yWv6QAAn7Q0Ih3CjNbs2LEjhCqgXRaOXmsEPhrCvCc+/3X2DFtjULPH6p6s6L/rZmuEXQPWyAgmzQkqgbI3YU7SWa021PFiYKOPjTZAFSgwufuhvy1NOfi2zR9LqoK0Ur6KPLWCHTn+E9oMACAAmg9E625r1AameUDObTWf5lf3qBJG1T2qhlGrlKpjVCTRa9U0YHNVT/qz6LWCUQmUvTPx6bFG8le4DRs2uBkQveojlyfVCa+9ddoA5O+td39lv4iPl5Xiy6WqJrWWqi2qauvkVQXkZcinbiqi//22AQB8U8XmsamXkvfN0CuD86TwR1VAztXiU/Ssj16bW7d+tzXm3/zX2Y/DNlfdo/KzFYb50rBs2Bqr6KesoOIRVsTnY8AafY2FW7lypb39tp+L9frkz+y+R75tADpHM3VGhm6zstHTzbHx7yXhcpmpnP/oQ3ebB6oA2rr/UQMAhKOs1wFZ2bp1q6vuiQVE1qgCiix/vTbXprVx3o/L2rpVlMga4d6YdRiRcD7q1kj1Cv9GUV+rXtS8VAOlA6JpJQA655nZIb5luwBUZcyj+z+ftCc9duSfSlvyPrDxOvPi2NTPDAAQFl0H9K1fw7beBWgQtPMASA5aNgFQGuSkoU5vfK6d/ZgedE6vzVVRKQiqWYdQCZSfUWv0/BVOAdDRoy4KkxJqJdAB0FllfxJY1jDogXu2uQmC7n7oqdJXXgFAWenBiR7IokFtYKoCcj4LKIrPhgv8896mj2nIo88/0vR58z+DXzVrhEGR5YwQKD+91hj+5IJawtQa5sHJl9+0L3/jcQPQeVUoCVcY9MzxF0sTVqgVTBWURVO49rmv1wwAECZV0D4SB0FeZswVbdeuXSGshNdGqXRuTG/Tz/caykh/1wqCDliOGAydH/0FDpiTb9Curi4GRANIhim/Ft/Ml2VY9EJU8q6wSxu19KQj5AHSemL7hVs+bh6oFaw+9ZIBAMJ0+r33k2twL+8rRZqcnLR77rnHAqAhy712bjUPFT3lpYHaGrDdazkOjiYEytdV1vhLLJxe6L72ta+ZF3oCcWR2TgmAzqpCECR6ndF/Y7pN7JfvfZBcAIfk7m2fTEItDx588h+TrxsAQLi0OVTvhX/4+9dalW3evDmZnQo4pblNg/E5Fp/XLWOEQPl6MT67zcGKvDNnziSVQL29veaBbs6e+P5ksroSQOcpCNLTwIGN15d+baxaqRQG7fx0f/za0x1f/H4QTJix/4u3uGkFe+jJ5wwAEL4fn3o9eW/5+IZrrIrGxsZsYmLCAOdU8aUsYSY+P7AMEQLl60x8brRGkle4mZkZ+9KXvmReKAB6/uTPDUAx1JJ5/F+mbXP8NNBD0NAJaauYqoPkF7NPRD1SWH7Xtk+aB7SCAUC5KAhSNdCqK3/HqkRDoHfs2GFAQNLOomOWEUKg/KnOcNgceP3112337t22YkXhhUmJvnVrbPwfnjcAxVFZ+LH45n5L/3WVCYJE/626+FV1UDo7yFu72ED8d+KlZY9WMAAoFz2MPf4v/6ty7/8aBv3iiy8aEJgBa8wJOmwZIATKXxSfveakJczTgGi1oDAgGiiego8qBkGpdHZQGgh1d13mokLorjtutt5rrrKinf7V+/Znjx81AEC56H3u5Ctv2B2bP2ZVoE1g3/zmNw0IlLqLBqwRBJ2xZSAE6owua/yFFU4D0FQN5AUDogEfdCF45AcvJPMBqrw6Vv/taYWQWsZuWL/a7JJLkoqpTs8w+9Mvb3Uxr+m7/3ySVjAAKCk9jK3CoGi1gakKiGHQCFyvNdrD/tqWEQQRAnXGZHxcrOZSS5i3AdH1yZeSGywAxVLIoe9JrSVHo2VMM4T+3R/02fC//4OkSuiG+McKZvIOhTythn/syA8t+t9vGwCgnKowKHrfvn1Wr9cNKAF9o94cn3FbIkKgzlBKN2CN5K5w7gZE/59fJ8NpARRLQ4i9DCL2SAGZLpDTUEgzezZ/rDFUU8GQ1tBnFQwNbLzOzVPZP3viKJscAaDkyjwoWpvA/vRP/9SAEum1ZcwIusTQKcPxOWQOrFy50k6dOpV89EDzJj53fy35CKAYOz/Vb/d+8RbD8uh1TPMVGh/fTI4+11DlV9sYrPzo/s+7qMjS3La7H3rKAADlp4cdj8TvP2VqC1f716ZNm5J2MKCERuMzZm0qfthAdUzE5+H4FJ686MXw4MGDNjIyYh6o/HTbzTfaE9+fNACdp5XpBEDZ0OtZGt4stNkrCYR+8e7Z0DvduPXqvAH5XlrymNkGANWhhxVj49+NH0R8wcpC9zwEQCix0fjMxOdAO/9PVAJ1lv5y9pgD/f39duLECfPi5Mtv2pe/8bgB6Ky+davt8fu/bMBCPvf1WlsVTACA8Gk5wr13hv9wSOHPhg0bDKiATdaYQ9ySDxk6acKcmJycdDUcrW/96mToKoDOUQBUpqd9yNarbbawAQDK4Yln4/uEyZ9Z6LZu3WpARTxtbXQcEQJ1Vn32uDA21nb7YK4YSAt0jvr9H7hnW9K+BCzkRydfMQBANY395feCfhCg+xzawFAhvdbG/GFCoM5b0gTvPKgSSPOBvNAMjDINogO8KuPgR2SvPvmSAQCqSbPr7vvWEQuRwp/R0VEDKmYwPntb+YWsiO+8F+OzOz4rzIGuri4bGBgwL06/9749f/LnBiAfBEBoFavhAaDa3nr3V8m1uVbHh0RtYK+//roBFXRzfP46Phes9KASqPP0F1I3Jw4caGuQeO60ppr2FCAf+t4iAEIrtBo+3WAGAKgubYkMqS1M28A0+xSoKM0Fevhiv4gV8cU4aI1yrcKpHUxtYV6qgVgXD+RD31uPEgChRSdfeTP5mK6877m629auvvLsxyu6zg/rfxk/LVZwpPPaL07bq2++m/zvnHzlDQIlAAiIXve1sKVx1lkoaAMDEsoZBuwChSesiC+O9rP3mwMKgI4ePWpe6GmD1hIDyM7o0G22bfONBrRClUA9cWCYVWio1/WTL7+RtPvqKBgCAPiRBj+6Vgj1gdGuXbusVqsZAIvis2Gxf0gIVJzR+IyYE6dOnbLe3l7z4u6H/pbZQEBG7v3iLUmrJeCFQiFtH3vm+ItJ4AQA6DxVe+r6ILSKn4Uo/FEIBOCsffFZcPYLIVBx1K/3tjmh0smRETeZVHJTcPdDTxmA5blr2yeTA3hFIAQAnaXA565t/zb44KeZhkFrxAWqZ+XKlcnp7+9Pihquvfba5Mf6PP1nslDBg1oI048akzI1NZXMlEpHpgROs4g32AJDogmBiqUerAFzQN8cqgZKv0k8oBoIWB4CIIRGgdBfHPlh8tof0iBSAAjBHZtvTNq9yhT+pHQTPzY2RjtYiaXBjsKejRs3nv08z24WBUGHDx9OPgY6cHzBaiBCoGINWCMIckGbwvbs2WNeHDn+Exsd/54BaJ/Ku9UGBoRK7wGPPzvF/CAAWCaFP1+NHwpVYTmEQiCFQWmFB8KlgEezaxX46HOdIqVBowKhgL6+IltgNhAhUPHUEuai/MbbgGhtk/nc/TW2ygBt0sXeyNBtBpSBWsS0oviZ+AAAWqeKn5GhWyu5GZQwKBxphU9z4JO2cnkV2NfXVpu3KYwQqHij5mhAtEIgL+vi5bEjP0wOgNb0rVttj9//ZQPKJm0VIwwCgAsr48yfpdLN+vj4OPOCnFCwo3tNhTwKfNLPQ6S5QeqkURjkXN0aQdBZhEDFU8R5yqgGWhDVQEDr9KTvr76+M9n2AZRVffJn9tCT/8jMIACYR+//mgXIRtDzBdrKE6yF5vfoPtNzdc9S6etJg8mdf11tis/ZoUaEQD48HZ9Bc+Ltt9929Q1KNRBwcQqAHtn/+eBKvnfs2GGDg4M2NDRkQDt4bwCAOVVu/WqXgqC0OohAaHmKGNbskaqCFDKqMsgplSuNpj8gBPJhwBwNiPa2Ll5Pez/39ZoBWFioAdCuXbvObvHQxYJeewiD0A69P4yNf5dNkgAqTYsgqP5ZGm180kk3QOlmHudqDnr0eShze4qga1mn7WH6wr4q/QEhkB+si78A1sUDC1Ppt1rAQg6AmhEGYSmoCgJQRXrvf+Ce261v3RpDNhQIqTro2LFjZwOisgdDuufTaQ550h8T9LTPcRB0dkA0IZAfe+PzsDnhbV28tsPc/dBTBuBcj9+/M7iLP70x6g3yQgiD0C6tkr/vW99mVhCASlD71wO7b2cOYAekQZA+Tk9Pn/Nj79IQp/njtddee/ZzQp587Nu3z2Nr2EFrZA6EQI4wIPoiqAYCzjU6dJtt23yjhaSVAKhZGgZt376dixRclAKg+751JA6E3jQAKCu1fqkFDMVTGKTKoeaPMzMzZ2cNNc8cWmz+UPrzi83RSSt15n+e/nqFOuk/S0Od5l+HYmzatMlbUBjFZ4M+IQTyRXGhm/Ibb+viqQYC5mj7h05I2g2AmqVbJTSvrGrDBtG+B//mOXvi+/6f0AJAu0J8/weqSOGegiBn7YSaC/TObxk8OROfYXNC5Y7Dw8PmhfqeFQS99tZpA6osxAvAgwcP2te+9jVbqrTsWv87em1Kn3YBC/nD3288FaV6FECZEAAB4dC16ooVK+wf/uEfzJGfxmeSEMiXyBrDoXvNAaWXCoE8lRKqdK0+9ZIBVRXiBaDWsO7evduyojBI/5s6V111FSXPWJDmZQhBEIAyIAACwnPzzTcn16uOqoGm4/MdQiB/lHMMmhOXXHKJfeYznzEv+tavsSPHX7DT771vQNXcsfnG4GYAKLD57Gc/a3nQG+rExERSHTQ1NZU8bfm93/s9A1IKgnpWddsxHh4ACBgBEBAuPag8fPiwObEiPo8yE8gfVwOiPa6LZxUwqqhv3Wp7dP8XgtoCogBo69atHX36kc4O0lYxTzPNUKxnjv/Exsa/ZwAQGgIgIHyqXHdUDXQVlUD+aC5QlzXawgp35swZ6+rqcnUzpXXYT/3jj+2Df/21AVWgeViH/tMXgwqA1E6qCqDXX3/dOimdHZS2i6lCiPlBuGH9GuvuusyO/2TaACAU2gL2H3f8vwYgbO+//77V63Vz4q+pBPJJZTdvmxO6gXr7bTe/nQTVQKgKBUCP7P988jEUCoBUAbTYKtQipBVCWjU/OOim4xYdxnsHgFCoAvjx+79sAMKnAEjXxk5sJQTy66g5qQaSWq2WtFd4cfpX79vn7q8lH4GyIgDKjwIhhUFbtmyx/v5+Q3WwPh6AdyG+/wO4MEctYVtpB/NLNevD5oS+YD2ti7/stz+ctIOx9QVlpdav//Yn2633mqstFHqd2Lx5s/sASPR7/M53vmOPPvro2baxmZmZ5J9dc801hvLS+vjnT75ir7112gDAowfuuT1pYwVQHj/96U+TkQUOjH/I4FV99rigEjZHfYwJ9UmHNCMFaMfIV25N5l+FJIQKoIXo96xqRwXdmzZtSp7U7NixI9k6ptc9R4P8kJEHdm/jCTsAlzQEWpsNAZSLp8pzQiDf3OySk7GxMfNEAZCCIKBstAZ+oP96C8muXbu8PN1YtnT1/N69e5NgS6GQwiEFQ3od1D8ry39rVen9Q60WPEgA4InCaTaBAeX0kY98xLxgJpBvrtbFy9GjR11tCmM2EMomxFWw+/btswMHDlgV6amOhk7ro4bob9y48ew2Mn2Eb088O2kPPvmcAYAHf/eNYaoUgZJyNByawdABGI3PiDmhdolDhw6ZJ2x7QVmEGACpMmZ0dNRwvuYwKD3pqvprr7327K9Jf5419sVgUDQAD1TdrkpgAOWk8QMbNmwwBwiBAuBqXbxoXbynJ9xUA6EMBvqvS+aUhIQAKDv6cxwZcZP3V4reO/74G0/Yq2+9awBQBFX//NXXd9KiCpSYpxCImUD+aSJp3RzRsFRPmA2E0PWtW20jX7nNQqLXAQKg7KSVQeg8vYeMDN1qAFAUVQFXIQBS6M5DW6B4hEBhcDWRWbM/vG3LYVMYQqWnfw/csy2or1+tVNfQZGRDc9bUaoviaBMPDxMAFEHXAds232hlpdBHLbd3P/SUbd3/KJWXqCxPG3R/yxCCKD4D8ek1B86cOWNdXV2uBkRf9tsftg/+9df2/MmfGxAKXfhpQ1FIQyC1FWvnzp3J6wCWT3OANHB/xYoVhmJ9fMM19t1//p92+j2eUgPoHM0B6lu/xsrk+ZOvJIP3//+n/4c99ORzdvxfpu212eBHr7FHfvBCcu2u112gKhQC6UGqA+PMBArHcHzcTGTWTKBTp04xGwhYIlX+qP8/pABIb15ale6tEjBUaQDEQGg/6pM/s/se+bYBQCfoGkAbwUKna28FO3oYqwCo1WvxOzbfaF/d9kk2oqESNErBSSX9ViqBwqHVJfqqcfG4mGogYHn+23/cbjcE9ORPAZDWWr7++uuGbDz99NPJann40XvN1ckNzGtvnTYAyFvIVUB6rTxy/AV77Mg/2Z89fjSp9olefzu5Fm/VyVfetGNTLyUPxspWDQXM99d//df2gx/8wBygEigwo+ZoXbyqgLQpzBOqgRACXfSFNH8kDYA89TKHTpvAQh2srdfXY1M/s5++/Kb98r0Pkp+7ouvSJNTsW7/a+taFfSGvGxvNrgCAPIVYBZTO90krfrJEVRDKTtfS9XrdHGBFfGDUe3Vq9qMLtVrNhoaGzJPHjvwwOYBH2gCiEwq1fqkFjAAoO3v27EkG7IdGgzz/In5trcdPbS8UtOsC/qa+j9rOT/cHGwiNjX/XnomfcANAXkaHbgtmIHQy4+f7U0nLbN50jaQ/F8IglImup6+66ipzghAoQLpz2GNOaJaFZgN5QjUQvAotABIFQBoGjWyo/evEiRMWEr2WKljX09926SJeX/OfiEOhkC7oFXhpgw3vIwDyEEoVkMIftXtlXfVzMel7R5m3pqFaDh8+bIODg+YEM4EC9KI1ZgO5oFRTc4E8DTZlNhA8Upmz2sBCsmvXLvvOd75jyIZeJ//+7//e1UD9izn5yhu2+6Gn7PhPpm0ptAVGlUMKkLQZRjMfNPvBO/0eeR8BkJeB/uvic715pQBcm7006+e1Ata5p+8dmjnEvCCUwTe/+U1PD1WZCRSoo9ZYGe+CQiBtuPGEaiB40rdutT26/wtB3PymxsbGgp1Z45UqgEIaBK3g5sG/ec6ypjYxzcTyXhnE+wiAvDx+/0637bKq+hkb/15SEemF3i9UFUSbGObT12l312Xur7E3bNjgabQClUCB0iPZYXNCX9BUAwEL08XKn//Jdlv9kd+xUBAAZe/hhx/2VAZ8UWr/0lPgPPz41OvJNhgNkfZ8Ma/3kbdmfpX8fgEgK3rtu2vbzeaRXvsVAKkSxxP9fnRNn1aV6oafMKh6FPgopPzv//w/kxlVqlTTe/Uf/v615plm6I6Pj5sjVAIFjGqgi+ApLoqmC5RH9n8+qAuVgwcP2t69bjpOSyG0QdCdHIrsfU6WLjg/9/WaAUBWvG4IDW2xSqgz59Aavf+efPmNJPx77Renk/Cn+Z5OQeC9d94SxNwoR1vBUpsIgcI1YI0gyA2FQAqDPHni2Ul78Mns2xmAi9Gb06NxABTSdqSJiQnbsWOHITseh+dfSBFbsbwHQXc/9LdUlQLIjAZCewstQt+se1PfumT2IoFQeBTsvPaLRuDz05fftJOvvJnMI7zQQ/yQrrHVMaNWMGcuIQQKm+4ses0Jj9VAoqe4nvqaUQ0P7L7d9dDH+TSsTk8qNOwd2VAApNdET62yF6L5P0vZAJYFXbyPDN1mHunp490PPWUAsFxqBXv86182T0IPgOYjEPJL92M/it9TFfaoukfBT7v3aKFV2WvJitrBHKnHZ+uHDSE7GJ+HzQmVuel4qwYaGbqVC3h0lKoaQgqA9JRCFUAEQNk6dOhQMAHQUlfAZ0XVR1fMlnZ7oxsKPXWktRjAct30u+vME92AlykAEgX36Up7VYrcEAdvWzZed/a1HPmaX9mz1LBnIfo71EPWUP4edX3tLACSKf0fQqCw1eIzEh83+4Y1UNZbCKQXjJvipwGU86MTvLe2zKc3KFUAOdpYUAojIyPuXgsX4+UpsNp3teHD4/eP5neU7UYJQOdpNbwnu0v+kFRtRTppm7NCId0T6KxdfWVQLfueNAc9p9/7IP74Zhz4vGG/fO/93Lov9D6seVohURWQQ3X9H9rBwjdqjSDIDY+zgSjnRyeE9galyp9NmzYRAGVseHg4qQIKwZH4wnh0/LvmyejQbe4GPeqCd+v+Rw0AlkrVC0cfutu8KFsb2FLo70RBUN+61QRDTfSep41sJ2eDHVX0/DIOexT0KPzpZGVsSAOgm6kCyGkIpAFFESFQ+FQFdMocVQN5nQ3EcE/kSRcQj9/vq8//YhQAaRYQsqP2rxMnTtjKlW5ekhelp6Nf/s9PmDe64Purr+901+/PewiA5VAV0AO7t5kHqtb44288QZvrIhQENQKi1bPB0OqzgVHo9HefVOy8OfvxrdP2WnxOz/5cp0OeC9F1wAP33B7cn7vjh6y66N+kT2gHC5+GeGg2kJtqIL+zgW5j1S9yoTepR/d/wUKipxMEQNlS8KMAPIQASBeB933r2+aRLj61pczb95TmfBECAVgqjSfw4i+O/JAA6AL0kETS2ULNFAb1XH1l8lHXfz2rupPPu7sujT+/8uyvuaLrsqTFOY/5Nc0tV6/Nfp5+VKjT+PHps79W/0whT0h/5xruvf/OW4Kc46TxKE6r7I+ln1AJVA5UA7WoyO03KKfQthSI3pxGR0cN2Xr66adtcHDQvNMFoeZAeN+a6G2+Fi1hAJbj8ft3uqhoCOU9oIyWc61Ylb8vhT5679eIhRCpEEKzNp3Sb6yuT6gEKgdVAx2Oz5A54bUaSC8qR37wAk8/kAm9UREAQTQIOoQASO771pEgLiYV2GsGgJfvL32/s2QAwFJ5aWnRim4CoGLw535hobZ/pVT943QOkEQ2GwDJhwxlMWrO6GbTG13Eh5osw5+Rr9waVAB08OBBAqAc7NmzJ5g/V1VDnnzlTQtB2hbmiad2DgDh8PTa8fizUwZ4o/szzQMMee6S4zYwqTf/gBCoPCKb95dbtLQayBu9yIR04w6ftAVMM0JCMTExYXv37jVkS4OgQwmAtAUmtHZYVd0sNJOhKKoEAoB2abCwB6pESefdAB405mp+PrmuDnH+T0oBkDaCOTbe/ANCoHJxV3rjtRpo/51/ZMBShdarrAHQjstTg6UAKJRB0Ap/Ql0F7On3raf5IV+kAijGDet9VDccm3rJAC+0MU/VP6FX2eo62/kDwcioBCq1ujmsBhofHzdvVMHBE10shcIfT8NqL0ZlqTt27EjWVSI76SYwBUHe6clvqAGQeKsG8vJEH0A4tEHKg/okIRCKp4cpD+y+PT7bgn+wkl5nO3deVQYhUPm4K73xmoyGdCMPH3Tzp3LVUOiNSRsKHPcnB+vQoUPBBEDaAhP6MHxPIVZIbaAAfPAw50TvA54CdVSTHqb+3X8eLsV7qR6wBnKdXZ//E4RA5VM3Z9VA+sbQQFpvVHrIkGi0qrGxYJuFQm9MejJBAJQ9BUBsAussVQN5CbKoBALQDl0/eKh2YLMhilSW2T/NArnOrlmjHewchEDl5LIayGM7iqqBmO+Ai9EbV2ir4DUDSD3KyJZWwQ8PD1sIQtoE1govQ61D3lwCoPN6nFw7UAWEoqSbv8q0YXPfvn0uFyAtYMFcgBConOrmrBpIAZDHaiAFQHfdTlsYFpf0Ld9ze1ABkN6YtA0M2VIAxCaw4nj579FrAhsmAbTKy+tFmR4KIAwKfR6/f2epqn9Ei48OHDhgAajbAlVAQghUXu6qgfTN4rEaaOen+xkSjUXde+ctQT35D+iNKShqAQslANL635AHQS/G0zwLWsIAtMrLUGhWw6NTFPgo+FH7V9mqZ3WdHcr1oF0gDyAEKq+6UQ3UMoZEYyH6uti2+UYLhb6/AnpjCkK6BSyUFjDN/7nvW9+2svIy08JLewcA/zxUAilED31BAMKQDn4u49zVwAKgul0gCyAEKjeX1UAeB2gxJBrzKQAKKRxU+9fevXsN2dH2rxMnTtjAwICFQpvAyjAIejFeKoFuWE8lEIDWeKgEogoIedO91N99Y7h0rV+pwAIguWAOQAhUbnVzWA2kbyKPGBKN1ED/dUEFQApWNQga2dmzZ08SAIWwBj6lQdBlDoDEy5awLRtZEw+gNR6uLV8r+XsDipNu/Xo0sAUq7QgwAKrZRTIAQqDyc5e41Go1l9PUGRIN0RvYyFdus1AoANq6davLeVshUujz9NNPJ1WLagULhYYml20Q9GI8PNHW+wUPDQC04oqu4l8rXn3rtAFZSuf+qPqnTFu/5gswAJKL3v8TApVf3ZxVA4nXaiCGRFdbugo+lJu7NADy2GIZorT6Z3Bw0EKiUERVQFXhZcNNz9XMBQJwcR6qI6gEQlaSh+bbPlnauT/NAg2AarbIRrBmhEDV4C5xUSWQx2ogGRkKpwoE2dGb2iOBlbLu2LGDACgDmvlz6tSp4Kp/pOyDoBdy8mUfIRCVQAAuxsvrBJVAWK7m8KcKIzQ0ZiHAACiyFu/7CYGqoW4Oq4H27dtnHikEYFtY9Yx85dagAiC9OU1OVqP9Jy8Kf7T5Syek2T/N7vvWkdLPAZrv9HtnDABC0O2gFQxYrnTjVxXCH41XUJW9xpcESAFQ1MovJASqDnfVQLqB9boyXi92ZR1uhvPpTW2gP5xBrypPDfTNqXCq9BkZGUkqfxT+hLT5a77HjvzQTWtUJ1Ut9AIQrisuv9Q8oB0MS3HH5htLvfFrPlXXb9q0yW23ykXUrdEK1pIPG6qiPnsGzBGV2Q0NDblrwdAL3cjQrXb3Q08Zyi20VfCB9icXTmHP9u3bbXh4OLiWr4VoCLRCoCr65a8+MAAIQXfXCvPg9HvFb1VEGHQPpIfhOlVqe1ZxQsBjFrQdpq01wYRA1aJqoAFzRCV3qgbSk3lvNOleL4BV2bhTRaGtgh8fHycAaoPCHg171qDn/v7yDC9UJUxVAyBPeLIOIBSnf0UIhAuravgjur7eu3dvyJt2W24DSxECVUvdHFYDaRirqoE8zuRQQHBs6iXaD0ootFXwekKhNyhcmIIfVfuo6ifkVq/F6LVo90NPcUEPAACWrcrhj5Sgwr4enwPWJkKg6nFZDaQht5rP4Q1tYeUU4ip4lagG/IQiVwp7tmzZknwsY/DTbGz8e5UPpXuY1wYALeOhARaijgfN/Nmy8bpKhj+6ptaSosBnbEbWZhtYihCoeurxmYjPoDmSroz3eANHW1i5hLYKXgGQthSwCn6Oqn3U3lWmGT+tUAvY8ydfsarrdjJoFQAuxsO1BvOAkNI18Labb0zGIej+pqpKdG3ddhtYihComrSb3VUIJEpjT5w4YR7RFlYeIa2C11OKgIfUZapK1T4LqfIg6Pl6rvbx/cuNFQAgBAp8FPwoAKpi1U+ziYmJpAOlBNX1CoBqtkSEQNUUxUe72feYI+nKeA1y9Ya2sHIIbRW8glF9X1SRKn2ag5+qVPss5OQrb9iDf/OcoeGmG3w8vaTFAgDglYKfm/o+WtlZPwvRdbVm0ZaAbg5GbRkIgaprND5D8XF1Z+V1ZbzQFha2EFfBB96n3BZCn4Wp+vC+b33bMKdv3WoDAADnSoOfxqluu9d8qqhX9Y9Gj5RAFJ8dtkyEQNWlGjhVA7nazZ4O6Tp06JB5RFtYmPRGGFoAVOZV8OlMnzTw0eeEPudLN4HxejOnb/3qYNo5AQDIW9rqpQHPvD+eT8FPyZarKACKbJkIgapN9XDqvXJ196XqB1UDeZz7oXLKB+65PWkLoxUgDHpDfGD37RYK9SqXLQDq7e1Nvp83btx4NvTBhen15b5vHSEAmufLn9pkABAKD6/hBAPlonuRgY3Xx+HP2jj4uZ5Wr0Uo9NFD1ZK0f6U01zeTlhRCoGpzWQ0knodE961bY3fd/kl78ElmdHgX4ip4lauGTBU9aeCTtnhR5dO+sb/8rp185U3DuT7R91HzgIcAAIBO0DWs7j1U7aN2aNq8Lk7zNHU9XbK5mhoEnVmiRQgEfTFpNlCvOeJ5SLTs/HS/1ad+Zs+f/LnBL1VthbYKPqRy1bStSyet8lHVD5ZnbPy7Vp98yXCuOzbf6Ob7mc1gAIA8pKFPOttHn1Pt0zrdP6qivkTtXzJhyxwEPR8hEPQdomTR3RAefQNv377d7U3lyNBtzOtw7N4v3pK8cYZAb1QKgLyvgk/bujTLJw1/kC2tgX/m+AuGcyn8+WpAc70AwBPNRdT7C/xRwJMOdFalD6HP0pRs+HMzlTNl3iZACASpWaMaaMAcSYdEP/300+aRbkpYG++TLna0yS0UXgMgNnZ1li7QuUhfmL6nmWsBIDSvOXlQqNfQbZtvtL/gQUOh0iofhT03rF9tn4jDH97blq+k1T8SWWMQdOb/YYRASKkaaMCc0ZBcJboeh0RLunWKGzc/FP6EtAlMQaeXnmVV+gwODhL6FIAAaHH6ntbNCwBg6RoPL29LqiqfeHaSbbc5I/DJX4mrfySKz1bLYBPYQgiBkKrPngFzRt/cGhLt9YZUgcPzJ19hPpADenMNbRV8kVsL0pk+artU+MM8n2JoBhBPZhem72m1dgJAiHoc3vSnr6s6un7VDDpdw5585Q1D+xT29Fx9ZRz0xIFPHPb0XN0df1xD4JOzElf/SGQ5BkBCCIRm6jc8Zc4o5dXN8sMPP2xeMR+oeKFtAkvfvDpNwY8Cn6GhoSQAotqnONow9dCTzxEALULfy/qe9shLiwcA37ovv9Q8a8yiaWyb0jXsj2Yfav705TcJhebRdabCHYU8a1dfSdhTkJJX/4hSrVwDILnEgHOpLMHlSq6jR4+6bQsTPU1hPlAxdLP4V1/fGcwbsdq/Nm3aZJ1C8OOPLrbv+9YR1sBfgJ5Se53txes9gFbcsfljyfzIEOlBhYIgvU8pGHr1zXfttV+8m/x82eg6srvrsqRyS9eSPavioCc+PcnnVxL0OKCKn6IeoHZQGgDlPieCEAjz6e7w1OxHV3TzqrYwz9Rj/WD8ZB+d9cDu222g/3oLQboKvhODoBWaqtVreHiY4McRBUBUDl6Y2jo9t3YSAgFohffXsqXQe9drs+fVt07HH08nP6dwyFNIlAY7V8RHlTuNzy+d/fzS5OdVyaOfZxuXb6r6UfWP9y26y9SxAEhoB8N8+gI8GJ8Rc0bVE2oLGxlx91s7a+en+5OnJrR3dI4urgiA5ijs2bNnT1L5wwp3f47Erw0Kisv4JDUrGqJZtpsmANVUxnBhbQuVMXqPO/3e+2dbZ/XjX76nn/vgvPc/hUgXo8qcZo2Ap9Fqd8VsiKOjz9PfI8Kn62UtUNGioJLraAAkhEBYyKg1Vsb3mjMqAVRlg+eb2/133mI/ffkN2jw6ILRNYDt27MgtAKLqx78H/+Y5e+L7PjbBeaUL9wfu2WYAUAYeB0N3QhrKEMZgqdLlKSUd/NwsssYa+I5eIH7IgIXtMqeUCHumNz3dxPDGly9VC4S0NSivVfAKfzQvS2fv3r0EQA6pTP7L//lxAqAWaBA0r50AyiKtVgHQGrV+bdiwocybv5pF1uEKoBQhEBZTnz3u6MVBg8E8azzNvp0e45yEVi2Qxyr45vDH88D0qlPw88ffeILKwBYo1A0lAGI7GIBWVLUSCGhXOjKhU3MzHYisA1vAFkMIhAtxWw2kdNj7C0TfujW2/84/MmQrXRsdys1i1psMent77dChQ4Q/zqn6R4OD1QLG/J+LU1un101gALBUVDYCF6ZqH1XLq/qnxGvf54uswABImAmEC4niM2YOh0TrBUPzVbxvC9NqUA28e+zIDw3ZGPnKrUGtgleLVlY0FJ2WL98U+Kj6R4fwpzWhzfYCgFZQDQ4sLl35XpG5P83U+qUAqND/6N8y4ML0hbo7PivMmddff90uueQS99UQN/WtS24Gf3zqdcPy6EbxC7d83EKgSrXPfvazmbyxaRD63//939uXvvQlW7HC3bciZmlt+J/8t7+z+tRL9sG//tpwcZrt9WCAg6C1BVJ/zwCwmN5rrgrmmgXopFqtZjt37ky2fp05c8YqZDw+n41P4f/RtIPhYnQH63YSs9psQigd1KyLOzbfaFi6kKoFslwFr3Xvqnhj3btfCn/U+qXzKrNiWqaKvkf3f8EAoIy6u3hoAzTTPZuuj3ft2lWVuT/N1F0zbE7QDoZW1KyxMn7AHNILiW6SvbfIsDp+6ULbBJbFKvh09g9zf/xS+PPYkX9KPqI9CoA024t2CQBlxTwgoEHhj5akVGjmz3wqqMh2Q8wyUQmEVrmtBtLNtl5YvNPNjp56c1HQntCqBbJYBa+qHwY/+9Vc+UMA1L40AAr5tfDVt04bAFxIz6puA6osrfzRqWgApI4azf9xFQAJIRBapbtat3vZNVQshBeX0DZbFS20aoEsVsGnq99VCQRfCH+WrwwBEAC0gkpHVBXhTyKKz6b41M0hQiC0Y9QKXGV3MVm04HQCN0GtCe3PKYtV8ENDQ0kAxPYvPzTUXdv9Pvf1GuHPMvHaB6BKenitQ8UQ/pw1YY0AKDKnCIHQDtdDorWFSfOBQsDN0IWFVjGl9q/lBkCDg4PJtgT4oLDnwb95zj53fy0JgRj4vDy85gGomu6uSw2oAsKfc2hGyQ4reAX8xTAYGu1Sslk3p0Oi9cKjigxtVPIuvSnazUahczRmJ4Vzs6jqM1WhLWcVfDoEGsVS1c8T35+0+uRLyQpwZIMACEAVUQmEstPDy/HxcYKfBt0IqBphwgJACISl0Bf4ifi47FnZu3evbdy4MYihugRB50oDoL51aywECn6WuwpeARAtYMVR8HPkBy8kwQ+tXtkjAAJQVbzuoYx07asH7pqBuZwHoCUTWWMAdGSBIATCUkTWKHV72JwKZW28EAQ1hBYAib7OljuHShVADIHuLIKfziAAAlBVDIVG2aja5/Dhw0n1D+HPObQ4adSct3/NRwiEpdIKpKH49JtDaYuOKixCoJukv/r6Trv7ob+1k6+8aVUTYgCkTWATE8ur+BwZGWENfIeovasR+vyc4KcDyh4AKUgEgMWwHh5loLBH7V663qXl6zwKfVQU4W79eysuMWDpBuLjOmVRqWII84GaaRit5pJURYg3iyqDVdvhcqj659SpU4Z86CY9DX6OTb1Eu2UH9a1bHYe6Xyj1k/Cx8e/aM8dfMABYyE1965KHW0CIqPq5qMgCa/+aj0ogLEfdGiVwblOWkOYDpe794i3JzZM2EpVdiAGQNoEtNwASVQEhW6rwUSVdOtiZao3Ou2PzjTYydJsBQJXRBovQqItCVT/M+rmoINu/5iMEwnKNxmd7fHrNKc1tUVtYSHNX7tr2SevuioOgb/+wtDeyekr2wO7bg6oWSNsMl0uh5PDwsGF5VN2jKp+TL8fBz9TPCH0KptctHQCoOtrBEII0+FHlD+1eFxXU9q+LIQTCcqXfEG7bwtIbdw2KDsnOT/fblv7rSjkweuen+pOKp5Do62i5m8BSobUoekHo45OC3HvvvMW2bb7RAABUAsEvgp8lqVvjfjeykiAEQhbq5rwtTC08+/bts4cfdrvQbEFpu9RDTz6XtLiUgcIfhUChyWITmKgibXBw0HBh6UwftXelw5wJffzRa9QD99we1FB3AMgblUDwJJ3xowHPWVzLVkjQw58vhBAIWRk1521h6nHVDXhoVRjJTdbubcmMoJDnBIV8s6hNYFk9LWEW0MIU8CjoUeCj4IeZPv6F2NIJAJ3A6yKKpJk+CnyOHTuWfGTGz5JoS49mQERWQoRAyIr7tjAJcVB0SrM21G4RYnuYhsXuv/OWIC+KFACNjo5aVlgJf26Vj1q7FP6wvSsszP8BgMX1XE07GDpHIY+6HlTto4+0eS2bqn9GrcRYEY+sqVzOdanNypUrk/lAIQ2Kni+UqiCFPiNfudUG+q+3EOnpSRaDoFP9/f3BzabKggKeH8VBz09ffnO20ucNQ5hU0TcydGtSBVRl933riNWnytGiCyBbuvY5+tDdBuQlDX1U6aPAR59T7ZMJVf/smv1YalQCIWuj5rwtTC+SGvCrm3EFQiFKq4LGxr+XVFF4pLk/yZazQEui1TOtOUBZqkIVkAKfky+/QVtXCSn4UQDEwFOz0+99YACwEOYBIWuEPh1R+uqfZoRAyFoQbWHpxjCtjg+VbsQe3f95O3L8J/bYkX9y006jG8W7tv3boCsF0k1gWb/BbtmyxcpGIU8S+NDWVVoKchXohjjQHQA6rbtrhQHLoetQhT1TU1NnQx/kpm4l2/zVCkIg5KFuzreFiV5UQ9wYNt+2zR9LTtFhkEKptEIpdAoI89ieEHILYipd087Grmqg+gcA2sPrJdrRHPgo7KHKp2NKu/mrFYRAyMuoOW8LE20MU0tYGTY2FRUG6SZRg5/LEP6IgsG8nriEGAKlQ5zrky8l4Q+VPtVA9Q8ALI2HdjCFCHqgNTg4mFQhayYhiqW/EwU+usYk8Clc3SpY/dOMEAh50SuaJuq6n4KrzU8KgkJbHb+YNAxSlcaR4y8kw0uzrtbQDeK2m2+0gf7rSjUgVpvAFAzmJZQZVGnwc+T4i/HXz8+o9qkYqn8AYOk8zEJMq0vSLVF6CKW5hNu3b08CoTJUJns1P+xJP8+jwhxti6wR/tSt4tgOhrztjU8Q/Va1Ws2GhoasjNJASNuZlrqZSTeEWzZelwQ/fevWBDvweTHj4+M2PDxsedEF16lTp8wzfZ2o4ufID14g+KkgfY/vv/OPgt3m10l3P/SU26H8AIqleY1FPyBT+KPZhovRNYnCIAVDGzduTD4PdVlKUdJwZ3p6OvmcsMe9tPWL0iujEgj50zeb2sIGzLm9e/eefSMsG12MpBckaZWHNje9+ua79tovTp93w6+Ap7vrMutbv9p6ru5O/n/LFvo005u2/v6rSH/3T3x/Mgl/WN1eTfreVtuXTpm/zwGgE7xUAl3sn+tMTEyc/bm0QkgfdT2cfl5FquZJN3LpY3PQkx4Eo24Vb/1aCCEQOkHfeGoLc/2IoXl1fJnLZHVx0hwKVV26KS7vnmyvPd93P/S3SSCIalJl3/47b6H1CwAy0nN18a+nCi3alc6oaQ6GRNfEzefaa69NPqpyKP0YijS8SYOcmZmZs+1bzaEPc3pKITJavxZFCIROiKzxTfi0OZcGQVodT790+aWr4DvxRMfrBcXj93+58M1y6DyFwHdt+7eEwQCQMQ+VQFlec7RS+ZKGQc0nvY7W5x/5yEfO/rqF/n9b+T00mx/UpKFX88+nwU7zQSXoL1pbqmn9ugBCIHSKHiu4XxsvaTBAEFRunQyAmv+dHr+mNEj8E3EY8BdHfmjPHH/BUF6EPwCQH7XRe5DXltPF0B4FJ2rx2WeEPxf1IQM6ZzQ+nX1XWqIiAgJ0Tlrx1em/X89fT2oHGhm6zf7uG8N2x+YbDeWi0EfDSj0MLC0DBqcDWEh31wrzgKoXVEw9PpqErs4TvvhbQAiETkrXxgfxzUkQVE5FBUCiVaHeEQaVC+FPPn75HiEQgPN5ma/GtSsqQsUFW2dP3dAy2sHQaZE1VvQFsTae1rBySQOgTpdJp4r69y5FGgZ9ddsnkzax50/+nJlBgdA8im0332h3/OGN1rdujQEAOqNnVbd5QCUQSk5f4Gr7qhmW5BIDiqFhXe7nA6UUABEEha3oAEg0HPHtt9+2EKn95djUz+zxZ6dYJe+UAh8FPwqAWPWer899vUYoCuA8937xFtv5qWLXqus6Z9OmTQaUEEOfM0IlEIoyGp8t8Sn2nbJFVASFzUMAlP4+6vW6DQwMWGiS6pLNH0uOQqAnnp2kOsiBtOpHq95p9wKAYvWtK34wNFVAKCHCn4wRAqEo6XygE/FZaQFQEKQnKwqC+vuDyK5gjb+3HTt2uGnFOnz4cJAhUDNVnKhVTJ4/+YodOf4CgVCHKfC5Y/Pv2ZaN11P1AwBOeHg9Zh4QSoTwJyeEQChSZI0p7k9bIPR0RUFQrVazoaEhg28eh3vra2dkZCRpDSsDhRFpBYoqhBQG1SdfSsIhZEc3FgrfVPFT5XYvvQaX5XsHQPn0XF38YOjp6WkDAkf4kzNCIBRtwhqDokcsIMPDw0mwoJt5+OR1u5tuYsfHx23PnmBGYrVMIYVOOg9BQdDJV95MQiEFRKzVbo+CnoGN18ch21oqfqwx52LXrl124sQJAwBv9BpNJRCwLIQ/HUIIBA9GrTEfaMACMjo6mnwkCPJHN4sKgLz2xR84cKCUIdB8aZVQGgopCDr5cqNa6Kcvv8mA6Xmaq31u6vsom72aKDjdu3cvVUAA3PKyGYwQCAEi/OkwQiB4kc4H6rWAKAhS4HDo0CFuTpxIbxY9D0bUBZp+n1VrKUwrhTRcWlQZlARDr7yZhEOvvnW6Um1ka1ddmYRkfetXJ8NEGey8sLGxsbOhO6+zALzq7lphHjAYGgEh/CkIK+LhSa8FNCi6GSvkfWi+WfRON7OnTp3ipnYBCoZeffPdRjgUnzQsCrmdrDnw6bm6O/mcgc4Xt2/fvqRyLqXXWH3fFI0V8QDmuyN+wDEydKsV7aqrriIIgnfa1jIen5oR/hSCSiB4ElmjIuioBSadP/Pwww/b4OCgobN0saObRQ1dDoV+zwqt9DWDc6UVQwP915/z881hkMKh1946ndyI68ev/eLdQkOiZBZE12VxyLMmCXnWrr4y+agfKwBCe/T9oa1+9XrdACAEHtrB9NpJAATH6taYBVs3FIoQCN7ULcBB0ZKuIlclCnOCOsfbCvh2qMJh+/btwa+M7xQFLWnL1PyAKKVQ6LXZCg19PP3eB2fDIYVGcvq991sKjNJgJ5Ve4K+NP17R1RgA2hMHPN1dPoaBloW+l/U9zVwLACHxEPjzugmHlEqq6kfLgOoGFwiB4NGoNVrCgpycqxBIT681J4j2sHzpz1k3iyE/9Uq3HdEWlg1dhFN5E64QZnoBwEK8VAIBTtTjc9ho+XLpQwb4tNcCTosVTqg9bGJiwpAPtX953gDWqrSSCag6fU8PDw9zEwMgSKyHB84Oet46exj47BQhEDzTnXFkgUpv7nVjg+zoz3XTpk3nDIsNnUJDzQcCqqiM39MAqkez7Io2PT1tQAHq8dENzwYL/EF+VRACwTMlx0qRIwuYbmw2bNjA05kMHDx4MLlZDHH+z8WojZAgCFWjasmyfk8DqA4vc+G41kQH6Y1bF65XGVU/wSEEgneRNSqCgn5R0ZuygiDd5NPq0L50+1rZZ4UoCNJMFKDs0o1+oc700nBxAEh5qAISQiDkLLJG8KPQZ5M15rhyYxMgQiCEQElzKYam6CZfT7250W9dWv1TlVXRmonC1wfKTFU/obd/tbJdDkB1dF9+qXnAg0bkILK54EftXqNGu1fwCIEQinp8dlkJ6CmNbvS1FYonNotLh2tXcVOQvj5oDUMZpaEur30AyqTnah9bKWmtRUbq1gh+VO1D8FNChEAISc0aL0ilUKvVzraIcUM0J20TUQBUleqfhTAjCGXS3NK5HL29vQYA3qxdXXwIRBUQlkFfPHVrDHdOZ/yMWqMbAyVECITQjFqJgiDRzb5ujqreAqSLF4UeCsbYEtSgrw1VjHFhh5BVraUTQPX0rCo+BKIKCG2KbG6d+wZjuHOlEAIhRKNWsiAobRFTAFK1MKg5/FHoQeBxLlWM0T6DECn00dduFVs6AVRLd1fxM4FmZmYMuAC9EdesMV5D1T7N69x5k64YQiCEajQ+pUtL5odBZb7xJ/xpnb4OGCiOUDS3dPJkGkAVeKgE4mER5klDH7V4KfBR8LNr9ue46K64DxsQruHZj0NWMmkYJPo4MjJSmlkYuilUmKEKF4Kf1unPSl8Lqq4o09cDykXf1wqA+N4GUCVrCYFQvMgaVT1T8ZmY/TGwICqBELphK2FFULN0gHQ6NyjEmyv9nvXfof+GdDU0N4lLk/45UhUET9JtfsywAlA1HgIgIQSqlHSQs2b67LC59i5V+miuT2TABVAJhDIYnv1YuoqgZrrJSgerqiJk+/btNjg4aF7pRjCt+pmYmODGMENppRhVQSha2vqlcBIAqshDK5hwnVVqk7NHVT51Y2sXlokQCGUxPPux1EFQSjdc6U2XgiCdLVu2FB4G6AJEgc+xY8cIfjpAXwMKgjRTaWioEl/6cELf29r6RVUfgKqjEggZ0htqFJ9jNtfeFRkzfJCxSwwol5pVJAhaiEKg/v5+GxgYsI0bNyYf86RKHx2FPgojuAApjv7uH374YdfVYQhf0eGPXtOOHj1qRfuD3X9uACB3bftkcop2ySXc1gUmskbIM23nBj5A7qgEQtkMW+MFdMQqSCGMjqpwUgqFFBCkR+GQ6POVK1cmZyG6wUuP/jf1cWpq6mybF1t/fNHf0Y4dO0o3SBw+UPkDAAtjKDQuIK3s0UUzYQ/cIARCGY3OfqxkEDQfgU21pK2ChEHIAuEPAFxYz6puKxohUKEia4Q9zUHPpNHGBccIgVBWo7MfCYJQSYRBWA7CHwBoTffll1nRCIFy847NBTz6mIY8zT/HmySCQwiEMhu1xgvzwwZUVBoGaZaKwqC850QhbLqR0EY/wh8AaE3P1cW3g01PT1sB0hBk5ezptTBETR/Tz6cX+HkCHpQWIRDK7oA1XsgPWeMNCqgkDe7WUUWQtolt37590XlQqB59bYyNjSUfAQCtURVQhSuBDlpjIUuzNAxaOe/z9J99ZN6vbfdCZKFgpjkBixb4PFrgnwGVRgiEKtCU5Cg+T1s4TymAXOhCUS1iCoNUFbRnz55keDiqJ2350iB55oYBQPs8zAOSgkKgaIGfS9ukADj2IQOqQW9IW42nAEBCF4xqE9u0aVNy1ALETIFqULWPNslt2LAhqQojAAKApfGwGUwKat+lVQoIFJVAqJIoPpus0Ro2aAASCgFUHSSqDtLntIuVi4KfY8eOMesHADLkYR6QFPQQhycIQKAIgVA1uvvZYY2h0WwOA+ZJZwdJGght2bKF7WIBSoc8N/+dAgCys3Z18SGQgv0Cwn2eJgABIwRCVY0am8PQmnp89lkFZ0o1hweaG6RQSBVCbBjzK634IfgBgPz1OGgHK6illyogIGCEQKgybQ7T0OijxsBoLGzMGoGhaKbUCavoljldZOqonUgUBOmoSkgBEa1jxdDTX/29HD58OJnxRKsXAHROd9elVrSZmRkrQCH/UgDZIARC1UXWuLlXRRBzgpDSnbSqf2pNPxfZXBBUefMrTRQIKQxKQyHax/JDtQ8A+NC3bo0VzdFmMACBIAQCGm9kzAlCKrLFN8mp/HmXNYaLo0kaSKSVQgqBFAY1B0NUC7UvrfSZmpo6u8q9ytU+VDoB8KT78susaIRAANpFCATMGbVGe1jlZr/grIM2Ny9qMbXZjwRBF6CLUh0FFykFQzqqGtq4cePZoAgNCjj0Z5aGPgrVWN9+LkIgAF70rV9tHhACAWgXIRBwLt1xqQpkND5DhqrQnaXm/xxo8dfXZj8SBLUhDYbmtzCl7WP6qHBIFUNlrxxKw57p6emz85YIfAAgHN1dK8yDgsJxEnkgYIRAwPmi+AxbYyuU2sN6DWWmO2+1A0bWntrsR4KgZUoDkOaqIVEIlFYPpefaa6895+e9UsiTVvYo6EkDMP13FvTUFhlau+pKe/Wtdw1Ada11sBlMCnqAEBmAYBECAYurWSMI0k3+gKGMmrd/LUVt9qMGizPwJmPpPJwLXeCmgZA+picNh9LAqLmiaKHgaP7PLRTS6PfSfEThTvPPNQc/AIBy61nVbR4UVAkUGYBgEQIBFxZZoz1srzWqgrjRL4fIGtU/WTw+q83+7zBLqgBpUAQAQCd5qASiCgjAUnzIALRCs2I2xWfcEDpV/2ywbAKgVDpLKjIAAFB6HiqBqAICsBSEQEDrImvMCtplvAGGqG6NIG/U8hFZIwiiLAUAgJLrcVAJxGYwAEtBCAS0r2aNMGHMEAI9JttnnQloImt8bRw0AABQWh7awTSbDgDaRQgELI2ChVFrtBXRIuaXwhj9HbW6+j0rmiG1zwAAQOl42QzGIgIAS0EIBCxPZI0WsaWsGEd+6taoyFEYU0jDvDWCJwVQkQEAgNLw0AomhEAAloIQCMjGhDVu+JkXVKy6Ndq+vMzmiYyB4gAAlEr35ZeaBwWFQPSgAYEjBAKyVTPCoCJENhf+1M0XVSING18TAACUQt+6NeYBlUAAloIQCMhHzQiDOqFujT/jDeYv/JmvZo2QiqogAAAC1n35ZVY0AiAAS0UIBOSrZoRBeajbXOVPzcIRGVVBAAAErW/daisaIRCApSIEAjqjZo0wiEqQ5amb37avdtSMrwUAAILkoRJoZmbGChIZgKARAgGdVbdGJUi6Wj4yXIxm6ozF5yoLP/xpFlnja2GT8XUAAEAwPMwEmpz0sP8CQIgIgYBiRDYXBmm9/IShmYKfujVCH4U/o1bcqve86SqOlkEAAALgoQpIaAcDsFSEQEDxFAApCEqDgLpVVz0++2yuda5u1VGzxn/zQQMAAC6xGay0D+WAyiAEAvyIbC4ISAOhslcIpRU/Cn7Sdq8DVt0LjCg+e22uXRBAE558Ayha9+WXmgfvvFPYpRIhEBA4QiDAp8gagZAqhC6xuQqRMjSA679B/y1p2FX14GchkZ07OwqAIz2rrjQA1dRztY/vf2YCAViqDxuAENRtrjVqZXwGZs/G+PTP/pxHCnZ0lTJlc/8NhD2ti6wRBo3OniEDAACFWbu6+BCowCogACVACASER+/8E3Zuq5iCoF6bC4ZWzv5cJ0XWCHymZz/WjUHHWYmMMAgAgML1rVttRSu4CogECggcIRBQDpOzZ/4MobRKqHf26PNrba5yqHfer9eP37Hz3+Cjpo8zs/88mneQv8jODYO22Pl/hwAAICcetoPNzMxYgQiBgMARAgHlRsN4OUXWCIN6rVH9NWKEQShOPT7HrPF1CACl5mEmEEPyASwHg6EBIFyRNQaIpwO2y75NDn7oSfCYzW31qxsAlJyqgDxUAhUcAlEJBASOEAgAyqFujW1yCoR0cx4ZkL26NUIfhT+jNnczwE0BgNLrW7fGPGAmEIDlIAQCgHKJrHFznlYHacU8F2xYjsguXvXD1xiA0uu+/FLzgO1gAJaDmUAAUF51m7thH47P9vgMGnBxusNQgKgWw7oBAFzMA5IC28FIn4ASoBIIAKqhZo12MVVz7LLGzT0Xc2imr4eDNtfutdccBkAeBqJ2d/moBgDQWWtXFx8CqQqowEogrhuAEqASCACqRRdwtdkjA9aoEmLdfDVR8bMEHgbDAui8nlXFh0AFzwMCUAKEQABQbXWbu/nvnz1qGxuIz0pDGekOQivdswx+IgOAklu7qtuKNjMzYwWKDEDwCIEAAKnJ2VOb/bECoQFrVAnpI6FQmFTtU7e54CcyAEDbPMwE8tASCyBshEAAgMWkodCB2R+nlUID8dk4+zn8Ueijv7fDsx/rBgBYFrWBemgFJQQCsFyEQACAVs2vFFJlUBoMpTOFCIY6r7nSh9AHAHLQ46AVTAqeCRQZgOARAgEAlioNH3TSaiGCoXylVT5TNhf4ROZDZAwXB1BSax0MhZYCN4MBKAlCIABAlhYKhkRBUO/sx41GONSKyBpBz7T5C3wAoFI8zAOSgtvBCp1KDSAbhEAAgE5IW8km5v28gqC0eqg3PtfOfuy1agyiVmgWWePPZsbm/pyi2X+GeXQD1Nvba0W6oosV8UDVrF1dfAikKqCCK4F4XwJKgBAIAFCkdLhBfYF/phCot+mjThoSWdPPefWOzYU8OjNNn6eHC+oAeRgOC6Czehy0gzEUGkAWCIEAAF6l828uZqXNBUUL/Viubfq815b2e2kObKYX+PnI5tq1IgMAlMZaB4Ohp6enrWCRAQgeIRAAIHTNFTcoTmQMhgZQUh5mAlEJBCALHzIAAAAAwILUAuqhDdRBCBQZgOARAgEAAADAIvrWrTEPJidb6ZAGgAsjBAIAAMEoeDMOgArqvvxS88DB6x8vwEAJEAIBAIAsdGRi6czMjBXNw4BYAJ3jYR6QOGgHIwQCSoAQCAAAAAAWsXZ18SGQqoCoBAKQBUIgAAAAAFhE37rVVjQn84AIgYASIAQCAAAAgEV42AzmoRUWQDkQAgEAgCzwhBhAKXmYCcR6eABZIQQCAABZ6EgIxHYwAJ2kKiAPlUAMhQaQFUIgAAAQDA8hUM8qH5uCAOSvb90a88DBTCBCIKAkCIEAAAAAYAHdl19qHlAFCSArhEAAAAAAsAAvlUDMBAKQFUIgAACQhcgAoGQ8zANSFZCDSiDWkwElQQgEAADQhu6uFQagGvrWrbaiOZgHJPSjASVBCAQAAILhoCXCrnAyIwRA/jxUAs3MuCjCIQQCSoIQCAAAAAAW4GEmEJVAALJECAQAALLADQKAUlm76krzwMlmsMgAlAIhEAAAyAIhEIBS6XESAjmpBAJQEoRAAAAAbejuKn5GCID8UQl0jsgAlAIhEAAACIaHwdAeBsUCyF/Pqm7zgJlAALJECAQAALIQGQCUiIdKIA/B9yxCIKAkCIEAAAAAYB4PlUBOQiACIKBECIEAAAAAYB4Pg6GdhECRASgNQiAAABAML60RXgbGAsiPh+/z6elpc4BKIKBECIEAAEAWIgOAkuhbv9o8cBJ8zxiA0iAEAgAAAIAm3V0rzAMnIdDbBqA0CIEAAAAAoEnfOiqBmrjoSQOQDUIgAACQlchy9s47PkZTeBgYCyA/a1f7+B5nOxiArBECAQCAYHgJgQCUm4egd3Jy0pzghRcoEUIgAAAAAGjS3XWpFc1R6B0ZgNIgBAIAAFmpzNNiDzeIAPLTt26NFW1qasqcoBIIKBFCIAAAkJWO3Ch4mJHRffllBqCc9P3t4XvcyTwgIQQCSoQQCAAAAABm9azqNg8chUCRASgNQiAAAJAVnhYDCN5aJ9v/nMwE4nUdKBlCIAAAkJUZq4grumgHA8qq52ofIZCT7WCRASgVQiAAABAUZgIByNPa1cWHQKoCohIIQB4IgQAAQFa4WQAQvL51q61oTqqAJDIApUIIBAAAskIIBCB4Hir9ZmbcdNdWps0XqApCIAAAEJTp6Wkr2lon24MAZK9v3RorGpvBAOSFEAgAAGSFSiAAQfOyGcxRCMTrOlAyhEAAACAr3CwACFqPkxCImUAA8kIIBAAAguJhY84VXSsMQPl4qQRyshlMCPeBkiEEAgAAWenIzYKHm6Puyy81AOXT42TeF5VAAPJCCAQAALLCE2MAQetbz1DoJu8Yr+tA6RACAQCAoHioBPIyNwRAtrq7iq/yYzMYgDwRAgEAgKxE1gGOZmUAKBnWw5+DF1ughAiBAAAAAFRe9+WXJado09PT5kRkAEqHEAgAAKBN3V3F3ygCyJaHKiBxNBTaTRoFIDuEQAAAICuRdYCHVgkP1QIAsuVl6x/r4QHkiRAIAAAAQOVRCXSeyACUDiEQAADIUmQ58/KUfC0bwoBS8VDhp9c3KoEA5IkQCAAABIXtYADy0LdutRXNURWQuPrNAMgGIRAAAACAyutxUN03MzNjjpC4AyVECAQAALIUWc68VAJ5uGEEkB0PLZ6OKoGoAgJKihAIAAAEhXYwAFnrW198K5gwDwhA3giBAABAlqatIrq7fKyTBrB83V0rzAM2gwHIGyEQAAAIThRFVjQPm4QAZMPDUGjx8No2qzKBPlA1hEAAACBLtBAACM7a1T5mfDkKgSIDUEqEQAAAIEuVCYEYDA2UB+vhzxMZgFIiBAIAAFnqSAjk6Gk5gBLw0N7pbOh9ZABKiRAIAABkqTKVQMwEAsqjb90aK9rU1JQ5EhmAUiIEAgAAwZmeLn5mKdvBgHJY66S101GFo6u+NADZIgQCAABZigwAAuJlvpejmUAM+AdKjBAIAAAEx8PsDAZDA+XgpRLI0UygyACUFiEQAADIUmQd4GyAKoCA9azqNg8cVQIV328LIDeEQAAAAEtAJRBQDn3rix8K7WzjITOBgBIjBAIAAFmKrANYEQ8gK2sdVAI5e02j1BIoMUIgAACAJejuYkU8UAY9Vxdf1UclEIBOIQQCAABZiyxnHmYCdV9OCASETt/HHr6Xp6fdjOF5x6gEAkqNEAgAAATHy2BogiAgbH3rip8HJI6GQlMFBJQcIRAAAMha7gmNl9YJWsKAsHlZD++oHWzGAJQaIRAAAMgarQQAguBlPbyjEIhKIKDkCIEAAEDWch9u4aUdjDXxQNg8rIfX65mX1zQjBAJKjxAIAAAEx81MoK5LDUC4PKyHdzQPSKjkBEqOEAgAAGQtsg5gQxiA5WI9/HmoBAJKjhAIAABkrSPpjKP2CQABYj38eVgPD1QAIRAAAMhaZW4imAkEhIv18OehCgioAEIgAACQtY6EQB5aKGgHA8LFevjzTBmA0iMEAgAAWatMOxiDoYFwsR7+PJEBKD1CIAAAkLXIOmBmZsYAYKlYD38e2sGACiAEAgAAQfJw48RMICBcrIc/D0OhgQogBAIAAFmLrAN8tIOtMABh8jAY2lErmF5QqQQCKoAQCAAA5CH3hMZDCHTF5cwEAkLkZSi0o/XwBEBARRACAQCAPFQiBOruYjsYECIvrZyO2sEYsgZUBCEQAADIQ2Q5cxECsSIeCFLfutXmgaN2sLoBqARCIAAAkIdKVAKJl7YSAK1bu9rH962jEIh2MKAiCIEAAEAecm8tcHTzBCAwHiqB9BrmaD18ZAAqgRAIAADkIbKKYE08EB4PrZzONoNFBqASCIEAAEAecn+87eUGau2qbgMQFg/r4aempswJWsGACiEEAgAAeehIj4OjVgoAgehbz1DoedykUQDyRwgEAADyEFkHeAiBaAcDwuJlmLuj9fCRAagMQiAAAJCHylQCsSYeCIuHVjBxVMlIOxhQIYRAAAAgDx25u/HQTtHddakBCEffeh8hkKNKIEIgoEIIgQAAQB4i64CZmdw30V/UFV0rDEA4PAS3zgIghqsBFUIIBAAA8hJZzjy0U3iZLwKgNR7awaanp80JN78RAJ1BCAQAAPKSe0LjIQS64nLawYBQaIaXhzlejjaD0QoGVAwhEAAAyEtkOfMxE4jB0EAovAyFdhQC1Q1ApRACAQCAvOQ+sMfLdjA2hAFh6Fu32jxgKDSAohACAQCAvESWMy8rlqkGAsKwdrWPGV5OQqDIGAoNVA4hEAAAyEvuNxdeWiquIAQCguChEkjhtZMAe8oAVA4hEAAAyEslBkPL2lXdBsA/D62btIIBKBIhEAAAyEvuNxhu2sGYCQS4p+9TD4OhGQoNoEiEQAAAIC8dSWg83FD1rPIxZwTA4rxsBpuactOFRSUQUEGEQAAAIC+RdYCHaiDawQD/ui+/1DxgKDSAIhECAQCAPEWWM0etFQAcu6lvnXnAUGgARSIEAgAAecr9bmdmZsaK1rfu3xgA3zxsBhMnlUB1A1BJhEAAACBPkeXMQyXQFU7aTAAsjs1g52AeEFBRhEAAACBP05YzHzOBGAwNeOZlM9j0dO4via0iBAIqihAIAADkKbKcsSYewMV42QzmpBJIvwmGQgMVRQgEAADylPuNhpfB0N1dhECAV142+DkJgY4ZgMoiBAIAAHnK/Y7HSwjkZegsgPP1rfdRCeTk9apuACqLEAgAAOQp90og2sEAXAybwc7BPCCgwgiBAABAniLLOQhSCOQhCOphODTgloeZQE4CoMg6MKsNgF+EQAAAIG+VqAbyMnMEwLm0vc9DpZ6TzWBTBqDSCIEAAEDecn/87eEJ+xVdKwyAP33raQVrUjcAlUYIBAAA8jZjOZuZyf1fcVFebjQBnIv18OeoG4BKIwQCAAB5q8SGMFbEAz6xGews9c0yFBqoOEIgAACQt9wH9rgIgS6/jA1hgEMeNoNpbpmDSiACIACEQAAAIHe533i4WRNPNRDgioZCr3Wwuc9JK9hhA1B5hEAAACBvkeXMyQ2Wi4oDAHO8zOqamnKxlItKIACEQAAAIHfvWM4tYV4qgXocVBwAmHNT3zrzwEFQrRfJugGoPEIgAADQCZHlSCGQhyBo7WpCIMATL9V5zAMC4AUhEAAA6ITceyE8DIfuuZoQCPCE9fBnMQ8IQIIQCAAAdEIl1sR7GEALoEHzgDxs7KvX6+ZA3QDACIEAAEBn5N6rNT09bUXrWdVtAHy46Xd9zANyMBRar7+0gwFIEAIBAIBOqFvOPFQCqerAQ+UBgDgEuoGh0LOOGQDMIgQCAACdkHslkJsNYcwFAlxgKPRZEwYAswiBAABAJyihiSxHDm60Ejes93HjCVSZ5gF5mNGlcNrBa1PdAGAWIRAAAOiUXO+EPLSDSQ/DoYHC3cBWsFRkOQfwAMJCCAQAADol18nNeuLuoSVsLcOhgcJt6b/ePHAwFLpuANCEEAgAAHRKJdbE9637NwagWF7mATlYD3/YAKAJIRAAAOiU3EMgB0/dWRMPFMzLPCBxEALVDQCaEAIBAIBOiSxnXtbEe7kBBaropt/1sxq+4BbVunVgMyOAsBACAQCATsl9Q5iX4dBeWlGAKhrov848cDAUetwAYB5CIAAA0EnHLEde1sSzIQwozk19PiqBjh3L9eWuFXUDgHkIgQAAQCdVYk38DeupBAKK4CUAkoLnAUXGangACyAEAgAAnRRZjjR/gw1hQHXdsflG80CvQwW/FrEVDMCCCIEAAEAnVWJNPBvCgGJ8ou+j5oGDrWATBgALIAQCAACdFFnO22o8rIlnQxjQeZ5Wwxc8Dygy5gEBWAQhEAAA6LS65cjLXKCbnFQkAFXhZTW8FFwJVDcAWAQhEAAA6LRpy5GXDWF969cYgM654w99zAPSaxDzgAB4RQgEAAA6rW45chMCrWNDGNApagPrW+cjeC24FUzttswDArAoQiAAANBpuaY0fjaEUQkEdMqWjdeZFxMThWYwhSZQAPwjBAIAAJ0WWc7DoT1UA2k4NEEQ0BleWsGk4HlAVAEBuCBCIAAAUIS65Wh6OtexQy1jODSQP0+tYKyGB+AdIRAAAChCri0LXuYC3bCeuUBA3nZ+ut+8GB8ftwJpIHSuVZYAwkcIBAAAipBrSuPgaXziE31+VlYDZeVpHhCtYAC8IwQCAABFyDUE0mBoDYgumtpUdADk46Y4aPXyPeZgNTwhEICLIgQCAABFUEJTtxx5aQnzVKUAlM0dm/0MhC54NTytYABaQggEAACKMmU5mprK9X++ZQP9hEBAHrSBb5ujEKjg1fA1A4AWEAIBAICi1C1HXuYCaWuRblYBZGvAUZWd2sAKfM1RBRCtYABaQggEAACKUrcceQmBFAD1rWNLGJC1r277pHnBQGgAoSAEAgAARdHT69wG92gwdMFDWs+6y9HNKlAGngZCS8Gr4Qv9lwMICyEQAAAoUq6TVAse1HqWblhpCQOy42kgdMGtYJHlXFUJoFwIgQAAQJFybWPw0hImOz/VbwCWTxVAngZCF/w6c9gAoA2EQAAAoEi57nEnBALKx1t7ZcGtYAcMANpACAQAAIqkuUB1y4naNLzMBVI72E19HzUAS6cqoE84+j4quBWsbo12MABoGSEQAAAoWq6Dew4f9tMtwYBoYHnUBsZA6Ll/vQFAmwiBAABA0eqWo4kJP9uTGRANLI+nWUBSq9WsIKqiZDU8gLYRAgEAgKLVrXFDk4vJyclkXbwXzAYCluYOZ1VAagMrsN1UAZCfFzYAwSAEAgAAHuTWs6UASEGQFwqBqAYC2qPw56sMhD7nX28AsASEQAAAwINc2xoKvlk7hwKgbTf7amkBvPM2C0jhcoGtYJHl3EYLoLwIgQAAgAd1y7G1QXOBPLWEDfRfZwBao/DH2yyggmeNjRkALBEhEAAA8EAJTW49W95awjQgmnXxQGu0Vc9TFZCMjRWWw+i1sm4AsESEQAAAwItcd7kXeNO2INbFAxfnsQrIwUDoyABgiQiBAACAFzXLkW7cPLWEUQ0EXJzHsLTgGWO0ggFYFkIgAADgRe5tDgcPHjRP7nBW4QB4ou8Pb1VAqgAqcCB03agCArBMhEAAAMCTXFvCDhw4YJ5s2/wx1sUDC9D3hbeV8FJwkMxaeADLRggEAAA8qVmO1A6mtjBPdn6q3wCcS98X3oZBS4FbwSLL+fURQDUQAgEAAE9ybwnzNiBaN7tUAwFzFP54nAWkNrACB0IzCwhAJgiBAACAN7n2W3gbEK0AiGogYM4j+z9vHrEWHkAZEAIBAABv6ta46cmNtwHRVAMBDaoA8tgGVnAVEGvhAWTmtwwAAMCXM/HRSqDcymMmJydt9+7dtmLFCvPgst/+sH3wr7+250/+3ICquqlvnY0O3WYe7dixo8gKwh2WczAOoDqoBAIAAB7VLUe6mTt8ONdFZG2jGghVpuqfkaFbzaOCq4BqRhUQgAxRCQQAADyK4rM7PrmV6igIGh4eNi9UDXTZhz9sx38ybUDVKAD6+HU95hFVQADKhEogAADgkW56Ji1HGhDtbl38p32uxQbypDlAA/3Xm0dUAQEoGyqBAACAV1fF5zOWo5mZGfvSl75knvSs6rb//s//04AqGOi/zv70y58yrwquAtpnhEAAMkYlEAAA8KpmOZuYmHC1Ll5UEXFT30cNKLtkDtBXfA6CloKrgOrGWngAOaASCAAAeKUtYQPx6bUcdXV12cDAgHmim+Mjx18woKz0Nf7I/s/b6o/8jnlVcBXQLqMKCEAOqAQCAACe5b7C68CBA+6qgbQq+47NNxpQRtqC98A9t7uef0UVEICyohIIAAB49np89lqOzpw547IaSEHQU//4Y/vgX39tQJn8l//wmeTr2yuFP7t27aIKCEApUQkEAAA8i6wDT8Q9VgOpWuKu2z9pQJmMDt3mdhNYamxsjCogAKVFJRAAAPBugzVmA+VG1UA9PT128803mycfv+4ae/7kK/baW6cNCJ1Wwe/8dL95llYBFYgqIAC5ohIIAAB4V7MOUDWQR/d+8RYDQqcASMe7ffv2WYFqRhUQgJxRCQQAALxTn9aA5bwlTO1gGzZssP5+X5UKq65sbE96/uTPDQiRWsC8VwCJhkF/85vftALtsMbrHQDkhkogAAAQgmPWAaOjo+bRzk/1u96kBCxGAdC2ADbdqQ1Ms4AKVDPawAB0AJVAAAAgBJPx+ZrlzGs10GW//WG76YaP2t8+92MDQqDB5rX/9EXb/PvXWgjUBlav161AVAEB6IhLDAAAIAxHLecB0dLb22unTp0yj554dtIefPI5AzxT1doj+z8fTPWawp+tW7dagQ7GZ68BQAdQCQQAAEJxVXw+YznzWg0kbAuDd33rVtuf/8n2YAIgfb9/9rOfTT4WJIrPPUYVEIAOYSYQAAAIRc06RLOBCrwpvKCRoduSVhvAG82uenT/F4KaX6U5QJoHVORvwZgFBKCDqAQCAAChOGMd2BImCoC6urpsYGDAvFEA9PEN19iR4y8Y4MW9X7wlWQGv+VWhmJiYKHolfBSfXQYAHcRMIAAAEJIBa8wGyt3KlSuT2UD66NFjR36YHKBIqvp54J7brW/dGguJqn80B6jgKiAFQDUDgA6iEggAAIREPVq747PCcnbmzBm31UByU986O/nKGxa9/rYBRbhj8432wO5tQbV/pRxsA6tZoxUMADqKSiAAABCaA/HZYx2gKqATJ04kG8M8Ov2r9+2Pv/GEvfrWuwZ0iloS773zFtsWh0Ah0hwgzf0q2AZjFhCAAlAJBAAAQqPZQMPWAaoGmpmZscHBQfNI81e29F9nx6ZestPvvW9A3lSB9uf/cXvyMURq/9qxY4cVTBVAEwYABaASCAAAhEhzgQasQ44ePeq2LUzUFnb3Q08llUFAHkKv/hEnc4Aia1QBAUAhqAQCAAAhuio+n7EOmZ6etuHhYfNq1ZW/w8Yw5Ear3zX75+PXXWMh27Vrl/3gBz+wgmkY9IsGAAUhBAIAACHSTVRHBkSLKgeuuuoqu/nmm80rDeftWdWdtIYBWVDL1+jQrfaFWz4e1Or3hWgO0COPPGIFq8XnmwYABaIdDAAAhKpjA6LF+8r41BPPTtqDTz5nwFKp9euubZ9MKoDK4ODBg7Z3714rWBSfrcYwaAAFoxIIAACEqmMDopN/2Zkz9v7779tnPtOxLrQlSVt2nj/5cwPaofBn+N//gf2X//CZYAc/zzc5OZm0gen7t2D74lM3ACgYlUAAACBkHR0QnfwLnQ+JTj1z/Cc2Nv49Ay5G4Y+qfnT0eVk4GQQtNWvMAgKAwhECAQCAkGl3+9PWQb29vXbixAn3bWFCEIQLKWv4I44CoMhoAwPgCO1gAAAgZBoQrWEfHRkQLe+8804QbWFyw/o1NtB/nR3/l/9lp99jfTwamtu+/vD3rw1+6PN8+h797Gc/ay++6GIJF21gAFyhEggAAIRuND4j1mGhtIXJq2+9a7sfeir5iOoqc+VPsx07dtjExIQ5UDPawAA4QwgEAABCp76sU7MfOyaktjBRADQ2/l0GRleQhjyrImzbzTeWOvwRDYGu1WrmQGS0gQFwiHYwAAAQOq396YnPzdZBIbWFiW7+79j8seRzgqBqUPgzOnRrsu794xuuKV3b13xjY2N24MABc4I2MAAuUQkEAADKoD8+J6wAIbWFpY4c/4k9duSfaA8roaq0fM2nAGh0dNScOGiNWWUA4A4hEAAAKIuOr4uX0NrCUrSHlYfCnoGN19u2zb+XVP9UjbMAKIrPpvi8YwDgECEQAAAoiwFrBEEdNzg4aE8/3dFN9Zl57MgPk4PwVGnWz2IczQBKbTDmAAFwjBAIAACUSSHVQKJZJHv27LEQURUUDoKfOQ4DIM0BcjOUCAAWQggEAADKZMAKqgYStYX19/dbqJgV5FMa/GzZeJ2tXXWlVZ2GsmsNfL1eN0dqxjp4AAEgBAIAAGVTWDVQqPOBmp3+1fv2xPcnaRErkCp8+tatoeJnAVEUJQHQ5OSkORIZc4AABIIQCAAAlM2AFVgNpE1h2hgWOlUD/UUcBD1z/AVD/tLhzls2bkgqfwh+zqcAaOvWrclHRxT8KACKDAACQAgEAADKqLBqINm7d689/PDDVgaEQflJ27z61q2u5Favdqj1SxVAagVzRi1gNQOAQBACAQCAMhqwAquBJORB0QtRGPTEs5N2bOolZgYtkVq8bur76Gzws4ZqnxYdPHgwCVYdGovPqAFAQAiBAABAWRVaDSShD4pejAZIP3P8RXv+5CuGxaWhT+PQ4rUU+/btSwJVhybis8MAIDCEQAAAoKwGrOBqIA2K1nwgfSwjVQQdOf5CcqpeHZQOc260dhH6LJfTAdCpyBgEDSBQhEAAAKDMCq8GKnsQlDr5yhv2zP94wZ4/+fPk87LTqnYFPX3rG6GPAiBkw/H8H4nis9UYBA0gUIRAAACgzAas4GogUUuYgqCQV8e3Q1VBPzr5ShII6YReJdQc+PRc3U2VT44ct3+lVAHksjwJAFpBCAQAAMqu8GogKcvq+KVQCHTy5Tdmq4TeTCqFTv/qffNGYU/f+jVJ0HNDHPg0Pr+SwKcD1P61a9eupArIsX3xcZ1QAcDFEAIBAICy643PKXNgeHjYDh06ZLAkBFIYpFDo1Tfftdd+cTr5udfiwCiPyiEFOd1dl1lPHPQo7OlZ1R1/7LYr4p9T2KOfQzG0/Wt0dNRr+1eKTWAASoEQCAAAVMFofEbMAYKg1iSB0C/ePVsx9FobwVDPbKCTfiTg8Umhj6p/JiYmzDkCIAClQQgEAACqQMN4Ts1+LJyqHkZGXGRSQCEU/CgAcl79I+PxGTYAKInfMgAAgPI7Ex+VlHzGHNDck0suuSSZEwRUSbr6/Zvf/KadOXPGnKvHZ4cBQIkQAgEAgKr4gTUGRPeaAwqCpqenbXBw0IAq0OyfnTt32osvvmgB0Aawz1ojQAaA0iAEAgAAVTJtjlo7JicnCYJQego81fr1yCOPhFD9IwqAtsbHfa8aALSLmUAAAKBqtOJ5jznS39+frI9fudLFyCIgE5r3s2/fPqvVahaQyBoBUGQAUEKEQAAAoGpcDYlO9fb2JkGQPgIhU/ij1q8DBw6EMPi5WWQEQABKjhAIAABU0XB83O1pJwhC6FT1MzY2lgyADkxkBEAAKuBDBgAAUD01a2z+cUU3zps2bUrWZwMh0dyfrVu3JrN/CIAAAAAAAN70xuft+PzG4xkdHf0N4N3Ro0d/MzAw4PJ7qMVzwpy1hgIAAAAA8rHXHN+gDg8P/+btt9/+DeBNCcIfAiAAAAAAqKCj5vhGtbe39zenTp36DeBBScIfnZoRAAEAAABA5fSa47YwnZUrV/7mwIEDvwGKcujQobKEPzoHDAAAAABQWYMWwM2r2sOoCkKnqBVRs6kUQobw/dHiGTUAAAAAQOWpOsD9Tazaw55++unfAHk5ceLEb/bu3Vu28EdnrwEAAAAAYI35IKcskBta3aRTFYQslWjez/yjds8BAwAAAACgSa85nw/UfFQVVKvVfgMsVUlbvprPqdnvawAAAAAAzuN6bfxCh1lBaIeCn5INel7sHDU2gAEAAAAALiKI+UDNR5UcqugAFqN2r5LO+lnosAEMAAAAANCyExbWTW9yaBFDMwU/JW/3mn/UzskAaABYxCUGAACAhfRao52k1wIUh0F26NAhGxgYMFRLvV63Y8eOWRwGWhRFViFRfHbEZ9IAAAAAAGhTvwU0KHqho7kvqgZBuaUVP6oEC+nrM8PztDH/BwAAAACwTMMW1s0wYVBFVGzGz4UO7V8AAAAAgMwEtzHMLhAGMTMoTOlWr8HBQYKfxjlljWo9AAAAAAAyNWph3SBf8KQDpFkt71ta7VOBde7tHm3/ov0LAAAAAJCb4FbHt3KGh4dpFXPixIkTvzlw4EAS+lDts+DRjK5BAwAsCdvBAAAA2lOLz5CVkDaK7d2717Zv3558jvxpe9fhw4dtcnLSJiYm7J133jEsqm6N7V/8IQHAEhECAQAAtK9mJQ2CUlotPzw8bFu2bCEQypDCHq1v1xp3HUKflugPacwalXgAgGUgBAIAAGifZpEctYoMpVUgNDg4mARC/f3M4W2VAh4FPQp9FP7oEPq0bSI+u4zqHwDIBCEQAADA0lQqCEqpKkihkA5VQnMU7ijkmZqaSj4q/FGrF5Ysskb4UzcAQGYIgQAAAJZOQdAhq/CgWlUG6SgU2rhxYyUqhdIKn+npaQKffBy0xjY+qn8AIGOEQAAAAMtXs5LPCGrVypUrzwZDqhRKf6yPoVGwo5BHYU/6OS1duarHZ198Jg0AkAtCIAAAgGxoaO0ew4LSIEgf1UJ27bXXJj/W50W0lCnISVu49DENetKfo7KnoyJrDH6uGQAgV4RAAAAA2RmNz4ihbQqCFAo1n+ZwSKFRqxToSBr0SBrw6BDwuKG/HLV+HTBavwAAAAAAARqNz284HM4Fz6H49BoAAAAAAIHToOi3Laybcg6nE+dofAYMAFAI2sEAAADy0WuNG95eA1C3xtyfugEAAAAAUEK98TlhYVVqcDhZnqNG5Q8AAAAAoEI0+DaUm3YOJ4tz1Ah/AAAAAAAVtdeYE8Qp/zlqhD8AAAAAACTtYacsrJt6DqeVc9QIfwAAAAAAOMdKoz2MU46jyrZRY/g5AAAAAAAXNGxUBXHCPGn4o0ATAAAAAAC0oDc+NQsrAOBU9xw1Wr4AAAAAAFiWYaMqiOPzUPUDAAAAAEDGeo2qII6fc9So+gEAAAAAIFeDRlUQp5hzwqj6AQAAAACg40at0YoTUojACe/oa0zb6gYMAAAAAAAUptdoEeNkfwh+AAAAAABwqjc+T1tYQQPH1yH4AQAAAAAgIAPWmNsSUvjAKe4Q/AAAznGJAQAAIDTD8Rkybu5xvnp8js1+rBsAAAAAACiFAWus8g6hKoWTX7WPWgX3Glu9AAAAAAAovV5jgHSVzlGjzQsAsAS0gwEAAJRHrzUqQrbPfo5yiOJzOD6T8ZmIzzsGAMASEAIBAACU07AxNyhUkZ072ycyAAAyQAgEAABQbr3xGYzPHqM6yKvI5ip96kboAwDICSEQAABAdQxYo0JoixEIFUWtXAp7pmxugxftXQCAjiAEAgAAqKYBa1QIMT8oX5E1gh6FPpOzh9AHAFAIQiAAAAD02lwgNGBYquYqH1q7AADuEAIBAABgvoHZs8UIhRajwCeyc1u7Jg0AAMcIgQAAAHAxA/Hpt0YopI+9Vi2RNQKeaZtr6SLwAQAEhxAIAAAA7VppjTAoDYbSH6+0cL1jc+1czWFPZMzwAQCUBCEQAAAAspKGQb2zZ+Psz6U/LlJkcy1c000/nmz6eQAASo0QCAAAAJ2y0uZCIZv9mP6cXLvIr0+l1TrNZpp+Lpr366JF/n8AAKik/wu5Is1aG8yNKAAAAABJRU5ErkJggg=="/>
</defs>
</svg>
$logo$
),
('logo_mini', $logo_mini$
<svg id="logoMini" class="hidden" width="26" height="27" viewBox="0 0 26 27" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<rect width="26" height="27" fill="url(#pattern0_338_6981)"/>
<defs>
<pattern id="pattern0_338_6981" patternContentUnits="objectBoundingBox" width="1" height="1">
<use xlink:href="#image0_338_6981" transform="matrix(0.000874126 0 0 0.000841751 -0.00393357 0)"/>
</pattern>
<image id="image0_338_6981" width="1153" height="1188" preserveAspectRatio="none" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABIEAAASkCAYAAAD0VxpEAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAQwiSURBVHgB7N1/jN31fef79/ZmCUM8hILJjR1bnAUxLumtPMW9Ae/V4gMkvZUYNzQVUZ1KtbNSCP3jFgKs9kdWsi21yt0Vv3y3EuDsKjOVtm6CEux6kJrlR84QqQNRDTPaFIdBkOP1YKfBUDtjYcJqpXve58zXczyeH+fH9/v9vD7f7/MhHc34RxLHnvme7/f1ef/4JwYAAAAA+bpi/uUqi37c/vk1y/xnkv/cSv+9vagv8XOn519L/dg/nln0n60v+u9b/J8HgGD+iQEAAABA7yptH9s/v6bt8ysWvcooCYPq8z+u20KIVF/083UDgAwQAgEAAABYSsVagU37x2uW+DlkIwmMko/H5j+fWvRrANAxQiAAAACgfJKKnOH5j5ttIdRJXtDXHgZ5OHTMFiqJkp8HgPMIgQAAAIBiqthC0OOfX2MLoU/FUAbtlUPT85/X5z8CKCFCIAAAACBeSaDj4U5SzZOEPmWdvYPOJOFQUkE01fZzAAqKEAgAAADQV7GFcGezEfQgO+3h0IRROQQUCiEQAAAAoCOp5Ekqewh7oKJmrUAoaSurGYDoEAIBAAAAYVQar6q1wh7/PAl8gFgkLWQEQ0AkCIEAAACA7LVX91SN6h4UV80WWsmSQdQARBACAQAAAOmq2EKFT9UIfFBudVsIhWrGfCEgKEIgAAAAoHce7lQbr222UO1D4AMsLxk6fchoIQNyRwgEAACwtMoqP3ZX2OoP/PUufu20sZ5ZnYc8VbuwygdA7wiFgBwRAgEAgKJKAprKos/dNfMf23/NrLNQJ0/1VT73h6czi35uuY/oXrKpy6t8qkaVD5AHv67VbCEUon0MSBEhEAAAiFFl0ctDnfbAp2JYrG4LlUbJ61jb5/VFn5dREvp83hYqfgCEVbeFUMg/Ui0J9IEQCAAAKEqCnGRl9jW2UIVRMeShPRjyj8eW+Lm6xY3QB4hPzRYCIaqEgC4RAgHxq7R9bG9jSH7+47Z0m8NSLQ9ptEHUF/148XyL9h8v1cbQ/ut1Yz4GUHQVWwh6Nrd93u+1CPmp28VhUX3Rzyup2kJ7V9UAxKxurTBozJglBHSEEAjQkwQxw22fL25zaH+VxeIWhbothEh1u7C9IfkxAB3JBqWKEfaUTXvVkL88JJqyhWGwWas0XnfaQrUPX3NAMbXPEvKPdQNwEUIgIF+LA57NthDuJC+kp24Xnk6fWeLnCIuA9FVsYZiuf141HryxvPZAKAmIkp/rRXuLl4c/FQNQRjVbqBCqG4AmQiAgfcyxiMtSMy/qi14Alpc8cLdvUCLwQRqSYMg/TtjK1UMVo9oHwPJqRiAENBECAb1rf/BJgp6KEfQUUfLgUbeL2xioJELZ+LXPH7a9krFqrWsfkKf262/dqPYB0J2aEQihxAiBgNW1V/Ykcyw4ZUSi/WFkev7zutFqhuJIQp+kyqdiAAAUQ80IhFAyhEDAhZLAp2oXBj5AL+rzr7TmXAB5SAY4e+hDhQUAoCwOWmuo9KgBBUYIhLKr2ELg4x8JfJCHpHqIcAgqqsbKbAAAnN+PeSDE2nkUEiEQyoThpVDXHg5N2MKqUyBt7S1edxrXQgAAllK3VmXQmNEuhoIgBEKRJaFPEvgwxwexSuYMJdtxqBpCL/z6t8vYngQAQC9q1gqDRg2IGCEQiqZqhD4oh7q1wiAfRl0zgiEsrdJ47TTavAAASEvdWvdee43qIESIEAixq9iFW2sIfVBmdSMYAsEPAAB5qRnVQYgMIRBiVLVWOwNba4DVLW4lqxmKqL3Vq2oAACBPdaM6CJEgBEIMGGAKpKtmC8Onk5AI8UmujUnVDwAACO9g47XPOHiDKEIgqGKAKZCful0YCtUMyqrWujbuMq6NAACoqlurMshDIdrzIYMQCEpoZwB01KwVCB0yZgsp8Ovjvda6RlYMAErkiiuuaL46/XE/Tp8+3Xwt93NL/TqwirrRKgYhhEAIjeAHiENSIUQLWb6qjddu4/oIIFJJQJO8KpVK8+eTj9dcc80FP04+Lv5cUXsgVK/XL/i5Y8eOnf/5xb8v+b0opVFrtYpNGRAIIRBC8ODHW7x2G61eQKym7MJKobohLUnVz33G9RGAoPZAx1/+uYc57T/fHvjgYkkwlIRE/vHMmTPnQ6L2X0Mh1YytYgiEEAh5qhpzLICiIhTqX9VaQ5592DPXSABBLA53/KMHPO0/l1brFTozNTV1PhTyCqMkKKKqqBDq1moTGzUgJ4RAyFpyou0PNcMGoCza28f8I0eZy6saLV8AcpKEOMPDwxcFPEnIg7gkIZF/9JCo/ceIRt0Ig5ATQiBkpWo81ABYULOFSqGagZYvAJlZHPRs3rz5gqAH5eFBUFIxNDExcT4cos1MVt1aYVDNqKpGRgiBkCYeagB0wu882wOhMh1Vcp0EkJqkXcvDniToSYIfYCVJEOTBUBIUUTkkpW6tqqAxIwxCygiBkIaqMccCQO/q1gqDklCoiMeTFWtVR3KdBNA1wh7kpVarXdBW5j9GUHUjDELKCIHQD3+Y8RPtqgFAemq2MEuoZnGrGq2xALrQHvB44FOtVgl7EJSHQf5KqoaoGAqiboRBSAkhELpFKwOAPNUtziqhqhH+AFiFhzse8njY48GPvxjMDHXJXKEkGPJqIWYM5aZuDJBGnwiB0CnCHwAKaqY9S6hqhD8AlpBU+Gzbto3AB4VDtVDu6kYYhB4RAmE1FWs90OwyANBSt1YYNGbh28Yqjde3jPAHgNn5zVxJ6OPVPgQ+KJNk0PShQ4cIhbJVN8IgdIkQCMupGqfZAOLhdeg1a1UJHbT82sYqRlAOlF57W5d/9PAHwIL2UMjbx/zHSFW98fqate6BgBURAmGxqhH+AIhfzRYqhOqWPlpkCyAZtrv4o1dsJFUbH//4xy+o4Gj/tW75zIzFczN8A89Sv97+gOSfL/WfRTj+tXLnnXcyuBnoUVIdlIRCXN9S4yGQh0F1A5ZBCIRE1Qh/ABST16AngVC/9eiEP8KSgMYfyP3ln19zzTUX/HzyecytOe2hUPLyMMk/tv9a8jn655U9HvbQ2gVkw4OgJBCidSwVo9ZqE6sbsAghECrGHAvMS+PBiNNqiKtb65QsGS7djV3WCssrhiCSa1SyPtsDniTwSQIeXMzDoCQQ8o9nzpxpPmQlP6Yt42JJpQ+hD5A/vyZ5GDQ2Ntb8iL7ssVYYBJxHCFReFWOORfTaT7TbH4CSsnR/QFr8+9pvZPMqX29/wGgPido/T1oikt+bfGw/0QZSVrfOBktXjUrJXCVblPyjt9u0Bz3IRhIG+cuvx0lIlHwsOn9vTEIf/0joA2jw6097lRD3gz2pG8Oj0YYQqHxoZYhAEugk62PbWxqSXyvrw1D7qXVysu2n2ot/npsEdKluFwdCFSMsz1T7BiUPe5LghwdwLe0VQ9PT04UJiNrbu/wFQF97hRD3el2rN163Gi1ipUcIVB6EP0KSU25/0PEHn/bAh5Pu9LTPxEhOtxe3RdC6hiXUrTU7qGpcL1Pj17dkgK4/eCeBD+LWHghNTEycP7VXlFT7fP7zn6fFCygAAqGejRrzgkqNEKgcqtaa+1Mx5KZ9bkXSzsBDj572E+7FQREhEdC7ZJAu25PKyUOhpHIoGfQa4npKtQ9QDgRCXasbLWKlRQhUbMON16PGHItMtbczeMtW8jknjMXQ3vLgDzNJOFSWORlAJ5LrYPKwzTUQS2mvGErWQ2fxsOZfg17t41U/hI9A+SSB0MGDB7lXW13daBErHUKgYvI7b59jcZ8hVbQzoN3igCh5oGG1KYqO0AdpSa6Z7cFQLw9tSfCza9cuvhYBnDc6OtocKu2BEFY0arSIlQYhUPH43J89xhyLvrVX+BD4oFtLzcmgeggxS1Zm+4M2oQ+y5NdKP8lPgqHlqoUIfgB0Klk7v2/fPg7rllc3WsRKgRCoOGj96pM/4LTPr/CHHCBti8MhKoegKgnCaatBaMl10k/z/WMS/jDjB0Av/DriYRDzg5blZVNfM6qCCosQKH60fvUoCX2SdgYecBBSctrdb0sE0I9ke9LOnTup9gEAFJ63iyUDpXGRPdaqDELBEALFrWps/epY8nDjlT6caiMGyel3Mm8oqyGqKDe/Nno7DZUVAICy8vurvXv3Uh10sboxOLpwCIHiRPVPh1gNi6LJa7sOio3gBwCApVEdtKQ9RlVQYRACxadqVP8sK6n28eDHP9LKgDJIa7sOio3gBwCAziWzgzwUQlPdqAoqBEKgeFD9swwebICLJWFQezCEcvLros/4IRgHAKB7yWYxbxej+rppj1EVFDVCoDhUjeqfCxD8AN1pbyPzGxmqhYrNr5H33nuv3XfffQQ/AACkxKuCCIOa6kZVULQIgbRR/dOG4AdIlwdBHggl1ULc0MTNr5F+bfTwh2skAADZ8fsnnxtEqxhVQTEiBNI13Hg9bSWv/mlfV8xDDZCtpNyZFrK4UPUDAEAYyVaxkodBdaMqKCqEQJrubbwesxLzwMcrfrzyh4caIIxk4PShQ4cIhQT5dXL37t0E5AAABEYYZD5jwCuCSv0MGwtCIC0Va83+qVoJcZoNaCMUCo+2WAC42Nz7v7S5c7+0tKy/6nIDeuH3SsmK+ZK22Y9aKwyqG2QRAumoWkmHP3OaDcSpvX3MPzJTKDuE5ACK5MS7v2h+PNn46AHO2fkA58S7c/M/3/rowY7/evJ7E+0/n4fByz5qgwMfbX6+pvHRf9z+82sGLml93vzxJed/j7/8c0Kl8il5GFRvvL7WeB00SCIE0uDDn/dYifBAAxRPUh3klUIeCrF9rH+VSqU5E41rJQBlSSWOBzXNYOfch82f8zDHf/7EqV80g568wxslSWC0rhEI+efrrhxsflx/1WDz59zQhqvPB0wohpKHQXuModGSCIHC8jt6H/5ctZJg1g9QHu1VQv5C5zz88QpJv1YCQEjNMOe9X5wPcrxax8OdE+cDn/IGO1nxyqEkLBrasHbRx6sN8SlxGFQ3hkbLIQQKp1Tbv2j5AsrNq4I8CEqqhGgdWxrXSgB5S6p4Zo6/0wh75pphz8LHXxDwCEpCIg+G1q+9vFlV5B8JiPSVNAzy0nBvDxs1SCAECsO3f+2xViVQYSXr3b3ta3h42AAg4W1j7aFQ2RH+AMiaV+4kQc/M8VPng58TbbN2ED8PglqB0NrzIRHhkJ6SbhPzzWFfMwRHCJS/Rxuv+6zAmPcDoBtlrhKi7QtAmpLWLQ93Xm8EPa3Ah6AHF4dDQxuvZmC1gBKGQXWjPSw4QqD8FH7+D+EPgDS0B0JFXUPv10gPf/x6CQC98GDnlZlZwh70LJkx5KHQlqFPUTUUUMnCINrDAiMEykel8fqBFXT+D+EPgKwka+i9d74IbWNcLwF0y6t7ZmbfabxONdu4Xm+2dDGrB9lIgiEPhfzFxrJ8HTx40L72ta+VpSp6j7E9LAhCoOxVrVUBVLi7fR5mAOQp9rYxv17u2bOH6yWAZS0OfI7MzFLdg+A8CNq00auFNtjQxrVUC+XAK4K8MqgEYZCXfP+e0R6WK0KgbPkA6MesgJI2Bh5mAITSXiGkfJPkw56/9a1vNef/AMBqxidfs/3jPyL8gSyfJeQzhaqbryUUypAffj322GPNMKjg6tYKgoo5A0AQIVB2dlurxK1QfHipB0A8zABQ4rODPBDyMmqVQMivkx7+sPELQC+8Cmh88qgdbrwAZe2h0I0+W4iB06kq0bwgnxNUyAIKNYRA6fPSGN8AtssKhPXFAGKRrJ/3UCjEYOmkVdZbvwCgX14R9M3xlwmDEA0PgXye0LZGKOQtZMwUSkdJ5gWxRj4HhEDp8gDIB0APW0Fwkg0gZn6j5DdNeQVCd955pz366KNUS0bK57HMnWsN2z0534rjP3f23MIA3rlzH/Y8kNcfhAYHLjn/4zUDH73g4Wjd/On54KKfBxxhEGLlQVB1+Nrzg6bRHz9k2rdvX7NdrKCYE5QxQqD0VKxAG8AY+gygaLIMhAjMNSWhjgc6/koCnJPvzjV/vvV5K+xRnb/iJ+rtYVHrx5c0f7z+qsHzv+avdVdeTnhUAv616m1i/mJuEGLTXiVUHb7O0JsStIjVG69bjSAoE4RA6ahYgQIgTrIBFJ3fPPmNkwdC/ZZVMyg/nCTkmWmuzJ6zE6d+0faxvCu0/SHLq4pawdDg/Mrnta0fN36eeR3FQBiE2Pk1qVklxCyhnhV8i5iXOvlUbOYEpYwQqH/e+uUr4CsWOU6yiyG5EWyeere1MZxonHy71s992Pp8/iQ8sbjtoRdrlmhjaH9TX9c4uV74+cH5n5tvgWj855r/eVohkCOvCvKy6m63jPm10gPz4eHCdADL8uva4qDHf8yDb++SoKj1cfB8SOStGlx/48NGMRSBB0Lbt95AINQDbxEr8BaxPdYKg5ASQqD++J2/VwBFf/zLSbY2v6k7O3/avbidwR+I/NcWBzpF0Jqf8dHzIVHysJLM1UhOuj044mYBaehk7bxfJ5NrJtI3M/tO81r3+vFTjc9PNX9c1oqeUNrDIA+H/LV+7eXM8ogAYRCKgkCoe37fcuuttxa1KoiB0SkiBOpd1VoVQFGnJn6S7dU/tH6FlZxye5jjDz5eqfP6/I+5ketccrK98Plgs9pooS2CeRnoXDI/yD8muGamy69vr8zMNq97R2beLnULVyw8CGoFQoRDqmgTQ9EkgZDPEeI+bnWPPfZYsyqogIOjGRidEkKg3uxsvEYtYpxk569ZvfPeL86fcNPOEEYSBvmDi8/KuPAjIREu5idqXhnkN1NcM3vn18Bmlc9sK/A50gh/CHyKIakc8lBo08bGx41rCYYEJGHQgRem+F5DYSRhEEOlV1bgwdF1Y2B03wiBuhd9AMRJdvba2xkIe+KyVBsEczKA3njQ0wp83qatq4T89J5gKDxWy6OIki1jO24f5tqygoIOjq5bqyIo3VWvJUII1J2oAyCqf7LhDzbNB5xG4PN6c3Ap7QxFxZwMYGX+sDkx/ZbVpt4i9MFF2iuGqsPXEq7njDAIReXXki81wiDmBy2twFVBPiOIzWE9IATqXNQBkG+vefrpp6n+6ZM/0CQn2wwsRTvmZKCMkhYvD308/KHiEd3y6+SmjWubVUM8wOWDMAhF5u1iI42XX1NwoYLOCtpjbA7rGiFQZ6IOgO69997mNz26lwwtPTJzohn+8ICDbhEOoWg8+JmYftNq0z9lrg9Sl7R4EAplrzb1pj3y1A+5t0Eh+bXj7pGbuI4s4lVBX/7yl5uzDgtkjxEEdYUQaHVVa62Bj45X/fjsH58BhM4kDzc+y4dTbWSFIaqIjV8bx1862qz48eAHyEsSCvkgWA+GaB9LH2vlUXReHcTsoAvt2bOnWRVUIKON15cNHSEEWtmwtQKg6NbA33nnnc0AyOcAYWXtg0t5uEFISVvE0MZWQEQpM0JKQvHDkz/h2ggZybBpnynENTJd+8dfbr6AokpWzXu7GFpVQbfeemuRhkb7oGjfHFaofrcsEAItL9oA6NFHH2X48wqSBxtv8ao1PtLKAGXt8zKoGEIePPAZbwQ/XB+hzquC/NpY3XwtLR8pYV4QysCvFV4Z5BWGXDfMvva1rxVpdEjdWCG/KkKgpVWsFQBVLCLe/uXDn30INC7U3srAMGfErL2VzFskvGqIGxj0y6+JB16Yar64PiJWzUCoWSH0KQLzPvnG0wefGKdFDIXnlUFfGbmp9PdSBVslXzeCoBURAl2sYhEGQD73xwMg2r8WMMMCZeE3Lh4GtR58aCND53ww7IEXprlGonD8uuin/LSN9Yd5QSgLtooVbmh03QiClkUIdKGKRRgAsf1rATMsgJZkbkayZYdhqkhQ9YOySYZLsza6N7SIoUz8GnH3yGdKfa0o0NDouhEELYkQaIGX0HgAFE0vlVf9+PyfXbt2Wdl54OMVP175w0MNcLH22ULMzignv076iT4BOcqMQKh3Hgbd88j3qApCKSQr5ss6RNqrgbwqqADtYT4k2oOgKcN5hEALnm687rRIMP+H02ygH8mDEAOni4+WL2BpBEK9oUUMZVLmMKhA7WEEQYsQArXsbrz2WCQ8+PEAyIOgMuI0G0hfMleILTvFQEgOdMeveSPzM0G4/q2OFjGUTZnDoIK0h3kQ9OXG66CBEMgiC4B27tzZnP9TtgHQyQPNeONmg5MnIHvtlUKEQvEg/AH659c9HxLrg6WZp7YyqoJQNmUNgw4ePNhcJV+A9rBdjdeYlVzZQyBv/3raIrF79+5mElsmflNx4PkpZv0AgXm7WCsUYtC0IsIfIBtsDOrM/vGXmy+gLDwMuv+LtzQrqMvCA6Bbb72VIKgAyhwCVRqvV601EFqeD4C+7777rCxo+QK0+QORr15mJX1YhD9APvyBb8ftw83qICojl8bgaJSR3wPt3vnZ0lwXTp8+3WwNK8Bm6l1W4iCorCFQxSJZBV+2DWCEP0B8vCqoGQoxTyg3hD9AONXh62zk5l9rfsTFqApCGXnV4FdGbirNPVBB5gTtspIGQWUNgbwCSH6tlgdAP/jBD0qxAYzwByiOpHXMK4WoEkqfz+B4+KkfEv4AgSWzQQi/L0ZVEMqqTGFQQdbI77ISBkFlDIEebbzk+6p885cHQEXfAEb4AxQbVULp8evkw9950WZmTxkALcwOWhpVQSijpH10x23FP8gvyJygXVayIKhsIVAUm8DKEAAR/gDllMwS8kohrxjC6vwkfe/Yc1wvgQj4de1LjYe/Mq6RXg5VQSirsmwS8zlBXhHkG8QitstKFASVKQTyKPZVE1f0AIjwB0AiWUPP6fnSvN3LT9B97g+AuDBI+mJUBaGs/PDr/rtuKfy1oABzgn6z8SrFTVdZQqCKRTAIusgBkJ/+fLPxxn948qgBwGLtbWP+0FT2FfQe/PjDEnN/gPiVbWDsSqgKQpklLWJFvhZEHgSdbrxutRIEQWUJgeQHQRc1AGKDDYBeeCDkD05lmyM0M/uOPfydH1ItCRQQc4MWUBWEsipDi5gPjP693/u9ZptYhEoRBJUhBJKfA1TUAMg32HjrF6c9APqRzBEqcltFEpjzUAQUn1/T7h75TOnDIA+7fd4Z94koo6K3iEU+MNqDIG8Nq1tBFT0E2tV4fcuEFTEAYogpgKz4TdND94xYkfAgBJRTWYbGroRxASg7vwb4q4giD4Lq1qoIqlsBFTkEqlirDewKE1W0AIiTbABZ8gemJ+7/QmFOzRj8DMARBrWqxx9+6oeMDkAp+TVg987PFrI6MPLNYXUraBBU5BDopyY8CLpoARAn2QCyVLQAiGsmgMXKHgYxNBplV+Qh8l/72tfsscceswjVrdUaFuWAo+X8b1ZMPgfoThNVpADIT2z+/Om/tW/85Q9s7hynNwDSV6QAiGsmgOX4NaE2/ZaNTx5tbkgc2ni1lYn/f/btSe7IzNsGlM3M7CmbaFwDivj9/zu/8zvNjxMTExYZ7yryP/y3G68PrCCKGAJ5+POEibriiitscnKyEAGQn2T/yX/6a5t87ZgBQBaKFABxzQTQibKHQd4SM7Rhrf34p/9AWI7SSb7/T777i+b3vl8DiqJarTY/RhgEfbLxurnxGrOCKFoIVGm8DpjoHCAPgLwC6Nd+7dcsZpxkA8hDkQIgn/vz7/7z33DNBNCxModBlU9eaduGr7WZ2XcaD8NzBpRNUauCPAjyYohDhw5ZZCrzr+j+4EspWgj0aONVNVGPP/74+VK4WPmbsfdrc5INIEtFCYB8tsWDTzxj333xvxsA9CIJg7xFatPGtXbV5R+zMvCH3+1bP938nPYwlFF7VZBXyH30n37EimB4eLj5+v73v28ffBBVh9Xw/MfoSpkWK1IIdG/j9W9M1O7du+2+++6zmPlJ9oOPP8NJNoBM+Y3/t/71F6MPgLz9655Hv2f1n/2jAUC//EHwuy/+uJBtIiuhPQxl51VBz/7dG43v+7WFGRrtnTFeHPHtb387tiCoOv8x6iCoKNvBKia8Dt4DoD179lis/CTbt9j4Aw0AZMkfap68/wuNG/64S58f/s6LrH4HkKkibxJaSrOy8vHx5gMxUFa+QdBfRVGv1+3WW29tfozMLot4RlBRQiDZdfD33ntvrOvwmlhjDCBPD91zh1WHr7NYEZoDyFNzo9Ztw4V6KFzN/vGXmy+grIo0M9FFGgT5yvhbG68oT/yK0A4muw7eex1HR0ft0ksvtRgxyBRAnh744i3n5z/EyIOff/XEM83ZaQCQhw//5/9qzssp0/Bobw8bHPio/bj+s+b/f6Bs/Nls/KWjzRlBv/HPPmmx8+VJd955Z3NY9OnTpy0S/oDvw359UHQ0f+hE7JVAFWtVAcnxqee+CSzGVfC+/euRp160w40bCgDIQ+zlzR6aewsYAIRUtAqBlXjlpS8roVodZeZtofffdUshZoRFWhFUb7x+0yILgmIPgSTbwDzNfPXVV6MMgHhDBZC32AMg5v8AUFOWeUF+v+oHl7WptwwoqyKFv5EGQX4T+JsWkZjbwXwb2B+YoG984xtRroJPNtm8+4v3DQDyUB2+1v7tl26zGPnDx1cf+a5NTPPwAUCLD09uXpsax71FaBdZjlc//PZvDTU/Z408ysrbw/wwyr8fYv9+j7Q1zP/SfUHV9y0SsYZAlcbrr6zViyfFN4H9m38ju6l+Wcn8H3qrAeTFV/4+dM9Is6c9NknVZP0fWP8OQJM/GE7+/bHmvKAtmz5lV13+MSsqnxO0/qpBO/LG29zLorT8+/1k4/7Evx9ivLdKRBoE3Tz/MYrV8bG2g33LWmvZpFSr1eYcoNiwZQFA3mIuXfaqyQefeKY5Pw0AYlGGFjHGGgDFaQ+LtDVsl0WwOj7GSqBdjdceE+Pzf55++ulmchmTvWPPMssCQK68XPlb//qLUd6cUDUJIFZJi1iRt4j5/7dtw9c2w3rGG6Csku1hay//WNTf65FWBFWt1Rb2MxMWWyVQpfH6gQkOg/7pT38a1SBoP8H2WRZ+QwAAeXronjusOnydxYaqSQBFUYYtYgztB+JfvuEirAiqN163zn+UFFsl0KPWStek+BwgTylj4SWy//I/PsUsCwC58xuR37/lNyw2VE0CKJJkkKzz+SFF9M9//ZrmRwZGo8z8698r4/z7PNY18hFWBHlrULXxetJExRQCVRqvUROza9cue+yxxywW9EoDCGXHbcP2//ze/2Ux8arJr/+Xv7H/9ndvGAAUjT8g+uDooY1rC1kV5A++voRg8rX/QRsvSuvku3PNVlBvlSQIyo30xrCYQqBXrfUXKcPbv771rW9FMweIAAhAKH4T/vAfj1hMkrZZTpEBFFlzfkgjCPKPvl465q1CS6l88srmGnl/CPb/j0AZJXOCKv/7rza/J2Lkz9y+iOnb3/62ffDBBxYB3xh2pvF6ycTEEgLtMsFtYK+++mo0c4AIgACE4qfL/9+ffD6q0yfaZgGUzY9/+jN79u/eKOTg6GRgNEEQysyr4ZLK5ljbQD/5yU/a7/zO78QUBP2OtdbG101IDCFQxVor4aXKbWKaA0QABCCkJx/4QlSnTlwzAZSVByS1RlBysnH98yAo1taRpfj/l5GtN9ixRrhf/xkBP8rLK5z9ez2ZmxUbD4JuvvlmGxuT38SeqDZehxovmT62GEIguWHQw8PD9ld/9VcWAx5mAIT0wBdvsermeDaBcc0EgIV18kWbFeStbt4a5u2+XvkElJV//dem3rStjSAoxrDXu3H85TOCIiA3KFo9BKqY2DBo70X8wQ9+EMUcIB5mAITkg6BjWkvKNRMAFhR5VhCbwwCzd3/xftQDo70ww5/Jv/99ydnLi0kNilYPgbwKaNiEPP74482BVOp4mAEQkp8c/6c/+bzFgmsmACwtmRUU82ahpTRXZg981CZfO2ZAWXnI60HQlk2fsqsu/5jFxtvC3MTEhEVAZlC0cgi0q/HaY0J8HfyePXtMHQ8zAELyh4Rv/esvRvOwwDUTAFbmD4oHXphqfh7rQNml/Ma1n2SFPErPv7+/++KPmwd4MQ6F9wKNM2fO2EsvyS3hWooHQd+2wPOBlEOgp01oGHQs6+C9x9k32vAwAyCUf/el26J5SCAAAoDOefuUt4gVqSrIFxd4e9jk3/8PNoeh1HwovIsx6PWNYfV63aanp03cpY2Xb5fyqdbB1puphkC7TGwl/KOPPhpFG9iX/8N3WGkMIBifAbTjdqku3mURAAFA95qzgl46amsv/1hhVsl7Gwwr5IGFOVkxBkH+rO7zgX72M/mh715V4mFQsPlAqiGQVBVQLG1ge8eebZazAkAIXkb80B+PWAwIgACgd946layS94fFIgyN9somgiAg3hXyl156abMiyDeGnT4ts419Od4W5oOM6haAYgi021olUhK8/evAgQPybWD7x18+36sNAHmLaQ4QbbMAkA5fJV+kodFJEHRkZra5OQkoKx8I7yFvdfg6i4k/s995552xBEFVC9QWphYCVRqvx0yoCugb3/hGM1FU5gGQvwAglFjmAHkA9NVHvkvbLACkpGhDoz0I+u3fGpp/CJ4zoKw85K1Nvdn8foip2s+DIG8N+/a3v20ffBBs7E4ngrWFqYVA95pQFZAPg/6rv/orU+YnFXvHnjMACGX71huas4Bi8P/+5Q9omwWADHgLyczsO/Z//LNPRl8V5A+827d+ulkJ4Q/CQFl5Rdzk3x+zrb9+TVTf15/85CebL68IEhekLUwpBKo0XgdNyKuvvirdBuatDP/qiWfoWwYQTHMO0D0jUZwQ0TYLANmq/+wfmzN1itIe5q0wXkHqVUFAWXkQFOP39fBwa1HJxMSEiatazm1hSiHQo42XzEqZe++91/7gD/7AVDHTAoCCJx/4QjMIUkfbLADko2jtYclw3GRrElBG/n0dYxDkbWERrI73qhOv6qhZTlRCoErjNWoivA3siSeekK4C+vp/+Rv775xKAAjIW8C8T1ydP4z8+dN/awCA/HhoUpTtYUmYRRCEMos5CIpgdXzVWtVAuUyzVgmBpKqAHn300eYXiyo/zf7uiz82AAgllnXwPjft3/3nvzEAQP6KtD2MIAiIMwiKaHW85yFjlgOFEKhiQlVA3jvoVUCqGAQNQMF//fc75N/8vV32nke/Zx/+z/9lAIAw/KFx/KWjtvbyj9nQxqstZgRBQJxBUCQbwyqW05BohRBIqgpocnJStg2MQdAAFHgbmA/LVNYMgB75XnOYIQAgLA/ja42HRhf7nCCCICDOICiSjWHVxmufZSx0CFQxoSqgXbt2NV+qHmwEQL56EwBCiaUN7KuPfNfq//CPBgDQUZQ18gRBQJxBUAQbw7wa5Uzj9ZJlKHQIJFMF5NU/Bw4ckK0C8jlA45NHDQBCiqEN7OHvvNi8KQEA6CnKGnmCICDOIMjbwjwE8q1hom5uvJ60DFfG/4qFU7FWuZMEXwnvW8EU+YkJq40BhOZtYOrr4P1amawmBgBo8pbdP/yzA1abetNi5u+L/gLKLGnB94+xePrpp2Wf/a1VDXSfZShkJdCuxusPTIB/ARw8eNAU+TfTn/ynv2YOEICgYmgD88CcTWAAEAefE/Tf/u6N5ucxzwmiIgiIryLIN4aJD4r2bqnMqoFChkAHrJVyBecr4ZP+QDWPPPUibyoAglNvAyMwB4A4+X2uX7v/+a9fY7EiCAJaQZBvsv7t3xqyj/7Tj5g68UHRlzZeflNbswyECoF2zb+C8yqg0dFRUzQ++ZrtH/+RAUBIMWwD87aCmMqQAQALfvzTnzVbw7Y2gqBY5wQRBAHW3Mo6+ffHogmCvBDkzJkz9tJLmc5h7lVm1UChQqCnjSqgFfnDzN6x5zjVBhBUDG1gPgh68rVjBgCIlz88xj4wmiAIaH0vH/uHf2wGQTG4+eab7fvf/7797Gc/MzGZVQOFCIF2GVVAq6INDICCJx/4gl11+cdMlQ+BZnA+ABRDMldky6ZPSb/3rIQgCGhtATz57i/kK8mdzwfyIEh0PpBXq/wHS1mIEMjXwldMgGoVEG1gABRs33qD/f4tv2GqvGLy6//lb5rDRQEAxeBB0Hdf/HGzGug3/tknLUYEQYAv7DjV/BjD4HefDeRhkFcEifFqoOnG6yeWorxDoErj9ZgJ8Gngjz0m8Ue5AG1gABR4G9junZ+TLcmfe/+X9i//41PNkmMAQPH4XBEX6+Yw/3N7JUTyIAyUURKExvB97NVAExMTVq/XTYyn4WOWorxDIK8Ckii9+da3vtVsB1NDGxgABQ988RbpN+w/f/pvmQMEAAUX++Ywb4UhCELZ+fdxLJV93iX05JNPmphK4zXReNUtJXmGQJXGa9QEeBXQnj17TM3M7Dv2jb/8gQFASEMbrrZ/+4e3mipvmf3zg39rAIDi881hfo+89dPXRLFtaDE/UPGqJipXUWb+PbBl6FPNSnNl3hYmui3Ml2p921LyK5afqonYuXOnKXrw8WcMAEJ76I/vMFXeMvvwUz80AEB51Kbesq8+8t3me0BsvALiyft/v3HAstaAMnvwiWeaga663bt32xVXSCwyb1e1FLer51kJJLEWXnUjmG+3qU2/ZQAQ0o7bhu3//j91V3r+4Z8d4DQVAEoo5hXyXsG09devaf75mfuJsvJFHpN//z/kv4d9QLTgkOhU18XnVQl0p4lsBPNkT42faviaYwAIyUt0d9yutzEx4WF5jKfAAIB0+HvAPY98L8r3An+PfeL+L8i3wwBZSr6HfcGHsvvuu09xi/i9lpK8QiCJ/iuvAtq1a5ep+WbjwUb9GwFA8d09cpPszanfNHgIBAAoN38/8KrQGNpKFkuCoNgqmYA0+ffwg0+Mm7pHH33UxHhXVdVSkEcIVLFWJVBwilVA/gZ2ePKoAUBIfmM6svUGU+QhuZ8aAQDg/H3hq433hdrUmxYbf799kiAIJecbwx5+6kVT5suk/CUmlVwlj5lAEmvhVWcBffk/PEVvMIDgnnzgC3bV5R8zRayDBwAs5vNF/tvfvdEMVYY2Xm0x8ffbqy6/rDkjCCgr3/ynvjreM4SxsTET8muNl++w/8D6kEcI9JgJDIT2ci61vj5fc0wVEIDQtm+9wX7/lt8wRUdmZu0bf/kDAwBgKb5YRf1BcimbGsHV4MBHOeRAqamvjvcQaGJiwur1uonwAdGvN159DRTOuh1MZiC0YCmX7R//kQFAaF8ZuckUec/43rHnDACAlTz8nRejnBvnyxjuFn0PBvLiq+OVh70LjpTpe95y1iGQxEBoHwbtKZ4SrwJiyw2A0JSHQX+TbWAAgA55CBRjEOTvwztu093MCWQtmf2ouijJi0nEsoSq9dlplWU7WKXxesIEPP3003bFFcE70s5LTreZBQQgJA9/7v/iLZLDKb0N7OGnfmgAAHTKh826LUMbLCb//Nevab7vnXx3zoAy8ufiY//wj/bbvzVkis6cOWO1Ws2E/EPj9ZL1KMtKoKoJEEzubHzyKKfbAIJTrQLykyDawAAAvYi1Iuihe0ZkK3OBPNSm3pL93r333nulikoaPm99yDIEutcE+D+YEg9/xhkGDSAw5ZXwB16YIigHAPQsxiDIq3KfuP8LBEEoNf++rU29aWo8APIRM0Kq1kdLWFYh0LCJrIW/8847TQkzLgAoUB1E6dfHGE9wAQBaYgyCPAB66I/vkGzTBvKy9y+ek3xe/vzn+yq+yULPQUdWIZBE+Y3aJG//YmYlPIDQlKuAfDAgAABpiDEIGtpwtd1/178woKxUB0X7mBmxjePbrEdZhUBVE6C2Fv6bnG4DELB752dNEW1gAIC0xRgEbd/6aVbHo9SaleHP6H3finUZSVUCVa21GSwotbXwVAEBUOAbUxS3ptAGBgDISoxBEKvjUXYHnp9qbs1TsnPnTqUB0f4HqVoPsgiBdpoA/wdSwjBoAApUq4C8UlKt7BcAUBwxBkEPfPGWxsHNpwwoK98Wq3R/6AHQ8LBUONtTNVBWlUBBeQWQUisYG8EAKNi+9QbJrSPjk69RKQkAyFyMQRCr41Fm/hzt4wKUiBWb9DQXKO0QyJOoigWmNhD6lZlZ5lwACO4rovMF9o//yAAAyENsQVCyOp6NYSgrD4GUqoF8LpBQS5iXJXX9h0k7BJLYm6Y2EJoHHAChqVYB+Y04ITkAIE+xBUH+/r37jzTbuYGseQCkVA1UhJawLCqBgvJkTmkgtLc58IADIDTFKiDFEl8AQDl4CBTTuIbq8HVsDENpqVUDxd4SlmYI5AFQ8Lqoz39eohjpPKqAAISmWgXEMGgAQEh7xp6NKgjyEMjf04GyUasGElsVX7UupRkCBU9fvALIV8OrOMIsIAACVKuAGAYNAAjNg6CZ2XcsFvffdQuDolFKStVA3hImNIKmYl3OZU67EigotVlAbAQDEJpqFdCDjz9jAAAo+Ooj34smCGJQNMrKA6Dxl3Ser2OuBkorBKqaQCuYUm8ep9wAFChWAfmstJhOXQEAxeYPl344EUsFvx/uPHTPHQaUTW3qTVOxbVtP29mz0tWk6rRCoODpi7eCKVUCfTOijQMAikl3Ixiz0gAAWjwAuueR70UTBG0Z2sCgaJTOkZm3myNXFPiGMKFV8V0lUmlWAgWl1grmX6AAENKI4PBI7+dmVhoAQFESBMWytMBDoOrwtQaUSW3qLVMh1BLmlUAdJ1JphED+P1ixwO69915TwVp4AKH5CaG/lDRXwj/PSngAgC5/r/rqI9+NJgja/UefY1A0SkVpLpBXAwnp+A+TRgi0ywLzVjClf4DDkz8xAAjp7pHPmBoflk9ADgBQNzN7yh556kWLAYOiUTYe0Kq0hH3+88EXpLfLNQQKPhFJaTK3P+CofFECKCc/EVSsAtrPrDQAQCR8wcvDkQRB/r5/9x3MB0J5qLSEeTGK0Fygaqe/sd8QqGJdTqLOgtJWMAZCAwhNcVAk10YAQGy8hTmWA4wdtw/bjtukWlOAzCi1hAnNJt7c6W/sNwSqWmBqrWAMhAYQkp8Gqg2E9iogP1EFACA2HgKNR/Ie5odAQxvWGlB0Si1hQiFQxTocDt1vCBS8CU5pK5h/ITLvAkBIVAEBAJCuPWPP2szsO6bO5wI99McjzAdCKai0hG3e3HEBTh46qo6JvhJIqRUsllMCAMVEFRAAANn46iPfi+Kw1+8F7r/rXxhQdEfe0KgEinFDWD8hUNW62EWfBW8FU6kE8pI0HnQAhLRl6FOmhiogAEAR+L3+PY0gKIbV8du3fpr5QCi8meOnJL4ffTC0UBDUUVlSPyFQ8JVcSq1gE9NvGgCE9BWxVjCqgAAAReLvaw8+MW4xYD4QymBiWqMlTCgEyrwSKPhq+M9/PvhIovMOT/7EACCU7VtvaJaAK6EKCABQNL4EJobV8cwHQhm8flxjVpdQCFTp5Df1GgJ5G1jw/6cqlUB+KqAynRxAOflqWCVUAQEAiiqW1fF+OHT3HXoLI4C0qMwFEhoO7TlNZbXf1GsIVLXAPADy/jsFrxAAAQhoy9AGG9pwtSmhCggAUGQeAtWm9MdB+CHRdrGlEUBaVOYCxTYcutcQKHgf1p13Bh9JdB6tYABCUru5owoIAFAGe//iuSg2ht1/1y1yLeNAWmZmw7eEeXGKL60SUVntN/QaAgWPurZtCz6SqIlWMAAhKa6FpwoIAFAGsWwM87lAu3d+1oAimpk9ZQpi2hDWSwhUscAhkKdsKn/JtIIBCGnH7TI9yE1UAQEAyiSWjWHeOv7AXbcYUDQqBRlClUC/utpv6CUEqlpgSqvhaQUDENK2zdeZEqqAAABlE8vGMJ8PtGXoUwYUic8FUiA0HDqTSiBWw8+jFQxASGpr4akCAgCUlW8MO/DClKnbvfNzrI1Hofj9J8OhL1Cx1pawZfUSArEafh6tYABCUpsFNE4ABAAoMd8YpjCkdiWsjUcRqQyHFpJqCFSxwCGQ0mr42tRbBgAh+E2c9/crIQQCAJSZVyM8+Pgz8oOivS2sOnytAUWhMBzaZwIJBUErZjbdhkDBq4CEyqzsyBtvGwCEcPeI1ine+ORrUazJBQAgS7EMit79R59jbTwK48QpjXtQoRAo1UqgqgWmMg/IZwGpp/wAiutGscGO+8d/ZAAAII5B0ayNR5GcfE8jBBKbC7SsbkOg4EOhVeYB0QoGIBS1gdBUAQEAcCEfFF2betOUeVv5jtt0uiyAXqlsCBNaE3/NSr/YTQjkJUXB5wGp8IQfAEJQGwh9ePInBgAALrT3L56TPyTx9nLawhA7lQ1hQiFQZaVf7CYEYivYPP8iU5/8D6CY1AZC+8nLETYlAgBwkdag6HHpERK0haEo5s6F/z77+Mc/biIqK/1iNyFQ1QLbti14N1oTq+EBhKI2EPrAC68aAABYmm8t2v/My6aMtjAUgcKGMKGZQKkNhg6ewKj8pTIPCEAoSgOhvSryMGvhAQBYkc8HOvDClCmjLQyxOynQeim2HWzZP0w07WDeCqbyl8pqeAAhVIevlbpBmyAQBwCgI/vHX5aeD0RbGGKnsCZeaCaQ6zsEGrZVSoqyplIFxGp4AKFUN19nStRPNQEAUOHPD/c88j3p5wjawhCzs+c+NAUxDIfuNASqWGAq84AUeg0BlI9XACltBWMtPAAA3fH3TfX5QLSFIVavz/7ccIHKcr/QaQhUtcCYBwSgzLYIzQJyrIUHAKB7Ph9oXHieHm1hiNXZ96kE6lSnIdBmC8j/IlX+MlkNDyCEHbfrlGf7SSZr4QEA6M3DT70oXU1LWxhipPI9VaR2sKBXAeYBASgzL8se2nC1qfjmuHYpOwAAyvx5Yu/Ys6aMtjDESOFZXWxD2JI6CYGCD4X2zWAKmAcEIASlKiB3ZIYNiQAA9MPfS70iSBVtYYjR3DlCoDYfX+4XOgmBKhbY5s1Bu9HOYx4QgBC2bb7WVDAQGgCAdPh8IOX2am8Lqw7r3IMAqzkpcI8qFAL96nK/0EkIVLXAVNrBmAcEIG9+A6ZUjs1AaAAA0rN37DnpcRP333VLsyoIiMGcwJr4j3/84yair0qgoGU4HgAppGkzx08xDwhA7rYLrYVnIDQAAOny99a9f6E7H8gPou6+4yYDYnBW4Hn9V3/1V01EZblf6HQmUDA6W8F+bgCQtxuFVsMzEBoAgPT5yIkDL0yZKp9NuEXofgRYjsJMIKFKoGWtFgJdYQyFbmIQKoC8qbWCcR0EACAb+xsHLcoz9x744i0GqFPo3BFaEd/zdrDgw3hUhkK/fpzNYADypdQK5qeUDIQGACAb6mvjhzZcbTtu09pWCix28t05w3nxhkAKQ6H9osxQaAB5U9oKNjH9pgEAgOx4xa1yW9jdIzdJVSgDWNWSQdBqIdA2C0hmKDQBEICc+UpWlW0cXgF0ePKoAQCAbCm3hfl9ye6dnzVA1dy5Dyw0oXYw11MIFDSB0RkKTSsYgHxVN19nKl5hIxgAALnwDoQHHx83VT6vkCHRUDX3fvgV8TGQbgdTaAVzR17nAQhAvpRawQ5P/sQAAEA+/AB6v/BGzt07PydTrQygeyuFQJ7ABK0EUhkKfYIBUwBypNYKdoRKIAAAcuUhkOpICp8LxJBoKFJoB3NCLWGVpX5ypRAo+DAehb88hkIDyJtSK9iB53UHVAIAUGR7RnW3hXkIxJBoqDlLO1hHVqsECkqhHYwACEDebhTqtZ+YfssAAED+lNvCGBINxEs2BFKZB8RQaAB58oGLKidr3gamuqEEAIAyUG4LY0g0EKeVQqBrLCCVPjqGQgPI0/atN5iKcdbCAwAQ3MPfedFU+ZBoALIqS/0klUCrYCg0gDwptYIdmXnbAABAWP5+fOAFzRl9DImGEpUK9iuuCD5eeUXLhUBXGJvBmpgJBCAvtIIBAICleFuY6vvy3SM3sTIeaBNrCBQ8zlVoB5s5zjwgAPnx1fAqaAUDAECHbyzeO6a5LcwDoLvvuMkAxGGlSqCgFNrBOAUHkCel4Yq0ggEAoEW5LWzH7cM2tGGtAdAnWQmksxmMVjAA+fA2sKENV5sCWsEAANDkbWFeFaTogS/eYgD0LRcCBR3Io9JDN3OcEAhAPpSqgGgFAwBAkwdAjzyluS2MlfFAHCTbwdgMBqBsRoRWw9MKBgCArsONwxqv2lXEynhAn2Q7mMJQaEc7GIA8+EBFPz1TQCsYAAD69o49J9kWxsp4QJ9kJZDCeng2gwHIC61gAACgG35gozokmpXxgLalQqDg0a3CTKC5cx8YAOShuvk6U0ErGAAAcfAQSLF61wMgqoEAXUuFQKyHN28FoxIIQD5uFKkE8gpIWsEAAIiDt4PtHXvWFHkIRDUQoEmuEkhlM9iJUzwIAcje0Ma1zf55BYcnXzMAABAPr+CtTb1pajwAuvuOmwzIk8o9db1eN2VylUAqm8GoBAKQhy3XawyEdrSCAQAQn0ee+qHkkOgdtw/LPJQDWLBUCBR0KrNKJZDihRRA8VSHrzUF3gbGRkQAAOKjPCR6987PGgAtVAItg4chAFlTWg3/ysysAQCAOKkOifb7HKUtqACWDoEqFpBCJRCDUQHkQemm6PDkTwwAAMRJeUi0r4wH8rDmsksMF6gv9ZNyIdDmzUG70ZpOEgIByIHKani/cTxCJRAAAFHz2X6K7+dUAyEvgwOXmoLYBkNXLDCFSqC59z80AMiabwZTwEBoAACKYe/Yc6aIaiBAh1wIVKlULDTmAQHImm/LGNpwtSmYmNZbLQsAALrnYy32j79saqgGAnT8iolRqASiHQxA1pRuhKgEAgCgOHxItOKmY6qBkLVBgZlAp0+fNnWLQ6Cgq7kUqoDciXfnDACytG1YYx7QzPFTDMMHAKBAPADa/wzVQCgfhZlAYiFQfamfXBwCBS3DUQmBFJNzAMUytEFkHtAbDIQGAKBoDjw/JTnigmogIDypmUAKrWDu5HucigPIjg+E9plACmpTbxkAACieh7/zoqmhGghZWnfVoIUWYzvYNRYQlUAAymCTyEBoVsMDAFBcqivjqQZCkcXYDhaUQiWQz8cAgCypzANiIDQAAMXGpjCUyeBlHzWsTqodTKESaO7cBwYAWdpyvcaND6vhAQAoNj/wGZ88amqoBkIWBgfCh0D1et3USYVA11wTtButae79Dw0AsuLzgFROKV6n8hEAgMLzaiC1cRdUAyELCjOBhNSX+wWpdjAFDIUGkCWVeUC+Fl5xawgAAEiXv+cfeGHK1FANhCI6duyYqWsPgSoWmEQ7GEOhAWRIZR7QKwyEBgCgNDwEohoIRcdMoAssO6GaEGiRk+9SCQQgO0Mb1poChkIDAFAeHgBRDYSiWyMwE0hoO1hHIVBQCpvB3Il35wwAsuDzgNZfdbkpIAQCAKBcqAZC0SncZ4utiF+STCWQSggEAFlRmQc0c/xUcz4AAAAoDw+A9j+jtzKeaiAUidB2sPpyv9AeAgVNYRRawRztYACy4qddCmZmf24AAKB8Djw/JXcQRDUQ0qBSbS/kzHK/IBMCqZg7x2BoANnwdjAFtam3DAAAlNM3x/WqgXbcNmxAP9ZcdokpEKoE6mgmUNAQSKUdjO1gALLg2wqGVNrBZk8ZAAAop8OTR+WqgarD11HJgb4MDlxqCmKbCVT6EIgZGQCyolLmzDwgAACwd+xZUzOy9QYDeqUSIgqFQPXlfqE9BLrGAlKYCXT2/Q8NALLAPCAAAKDCt4QemZk1Jd4S5pXTQC/WDIRvBxOrAtJfEa9g7twHBgBZGNrAPCAAAKBjv9hsIA+AmA2EXikEiELzgJz+TCCV7WAAkAXmAQEAACVUA6FIFNrBYqwEKv12MNbDA8iCbwVTuKHxWUDMAwIAAAnFaqDq5msN6Na6qwYttDNnzpgQ/RDommuCjiRqmjvHTCAA6dtyvcg8oONUAQEAgAWK1UAMiEasxNrB6sv9ApVAbVgPDyALmzZqtIKp3eQBAIDwxiePmhJfpqGyVRXxWEc7WLsV/yAyg6EVVsQDQBa8HUyBn/YBAAC0O9wIgdTaxe8eucmAbijMBBKqBKqv9ItJCFSxwBRCIGYCAUib97YrDIX2SseZ2XcMAABgsW+KzQbyaiAGRKNTCgGQEwqB4qgEAoAi0tkKRgAEAACW5tVAaqMxWBePTim0golZcUJ1EgIFL8NRWBHPTCAAaRvaQCsYAADQd+CFKVPCunh0avCyS0xBbO1gDOQxtoMBSN+WTSqbwagEAgAAy/MQSOlQ3AOgkZvZFIbVrbuSdrBFaAcDgFDWXzVoCo68QSUQAABYngdAatVA1eFrDViNQsVYLOvhnUQIpLIZjHYwAGlSGQo9c/wU1zcAALAqtWog1sWjE0Mbw99vi4VAHVUCVSwglRDo7DkekgCkR2UotNraVwAAoEmzGug6A1YyOBB+JtCZM2dMCO1gABCCzlDoWQMAAOjE+ORRU+JzgRgQjZUobAejHQwAoDMUevaUAQAAdMIriJUOkBgQjdWsFwiBTp8+bULqK/2ixHYwhfXwjpYJAGlSGQo9M8tmMAAA0Ln94y+bEgZEYzkKAZCbmpJpo1w1jWJFPABkgKHQAAAgVkdm3paqBmJANJaj0ArmhCqB6qv9BtrBACADDIUGAAAxY0A0YjB4Wfih0E5oJlDHlUAAgBQxFBoAAMSsNvWWVDUxA6KxFJWDV6EQaHq130AIBAAZWL9WozSVodAAAKBXStVAHgBtuZ6WMFxIYSaQ2GawOGYCXXFF+JFEtEwASJNKJRBDoQEAQK88BFKqBtpx+7AB7dYJLGKJaT28IwQCgAwwFBoAAMTO7yMmpt8yFT4gmpYwtFP4ejhz5owJqa/2G2gHA4CUeVmqwhsSFY4AAKBfhydfMyU7bqMaCAsUDl6F1sM7BkMDQN5UVlXSCgYAAPqlty6euUBoGdqoMX5BrB1s1USKEAgAUqazGextAwAA6JdvClPhLWEEQXCDA5eagpjWwztCIABI2ZZNG0zBSdrBAABACsZfOio1Z9CDIEDl4PX06Y6ylzx01JdGCAQAKRscuMRC8xs1ZgIBAIA0+H2FB0EqRrbeYMD6tRojGIRmAnU0oZoQCABSJrEZjHlAAAAgRbWpN02FL+GgJQwKlUBiQ6HrnfwmQiAASJEPqFPYDDYze8oAAADSojYgujp8naHcFO65hVrBXL2T30QIBAApUhlQd+IUrWAAACBdSgOiR26mJazsFKrvp6enTQgzgQAgbyoD6qgEAgAAaVMaEO1VILSElRfr4ZfEdjAAyJvKgDpmAgEAgLR5AHTkjbdNBVvCyov18EuiEggA8qZQCeQ3aEprXAEAQHEceP5VU8GWsPJSqb4XCoHqnf5GQiAASBGbwQAAQJH5gGiVwybfEuYvlA/r4S9S7/Q3EgIBQEq8N53NYAAAoOh8NpCKbZuvNZQP6+EvUu/0NxICAUBKFKqAHJvBAABAlmpTb5qK6jAhUBkp3HeLrYc/1ulvJAQCgJQMXnaJKaASCAAAZMlbwk68q3Ho5MOhFSqxkR+V6vsY18O7j5gAsQQNAHqiUgnETCAAAHQ1H2AHPmrrrrr8/OdrBi5pfr7+qsHm71kzsPCQ6x/9xxf99wxc/CC8VDBz9tyFCyP88+bPnfvw/M+ffHeu8eNftv34Fxf8eCnjk0ft7pGbTEF187V2eFKnRQ3ZUrnnjnE9vCMEmsdAMQD9GtoY/g2JzWAAAITlzxXr5gcWr2uEOh7srJv/uaWCm7T/t9PmwdLJ+XDJP57wwMjvN87p3G8078EIgUpDZTOY2EyguCqBAKAIktO7kKgCAgAgHx64ePjgD6R+D+Cfr7vy8sK1JsWwgcuHQz/8nRcN5cBmsIucttgqgQCgCPzGL7S59z80AACQLg9BfPbM0Ma1zdDH21GYQ6MjCapU5hQhWwqVQN7NJDTWpqs0KgmB6gYA6JnOengqgQAA6Fcz8Gk8aG4Z+hSDhyPh1UAHXpBqz0FGFGYCibWCnenmN1MJBAApkBkKfZwQKE/JQE+3rq1Uvv3n2y0+oUxmLHByCQBheRWJhwiEPvHatFFjTgyypXLweuZMV7lL1nqqBApKZao2JYQAeqWyHt43faB//n7gm1g2bby6ubHFe88HGx+TwZ7J70lTMmSzuZGl8fnJ9+bsxKlfnP9IlRcApMvDnurwtc3whyUx8bux8e+J4lM5eI11KLSjEggAUsB6+Pj4KZLPcfKgx2c8rLuyNdQz680tK/15WuuBl38Q8X9fD4iOzLzd+PwU4RAAdCkJfkZuvoFqn4JhLlA5sBlsSfVufjMhEACkQOEEkfXwy2sf6JmEPTGe+iZh45a2007/N/cgyIOh1mvWAAAL/Nrpwc+O24YJfgrOAwJCoGJT2Qym0s00j8HQAJC3dayHl1G2DS7+/83//7YHQx4E1abemq8Y4usCQPn4tdGrfTz82UKbUGls2bTBatNvGYqLSqCLdP0HkagEUlmtto7yQQA9WidRCVTOeUBscLlYeyjk72sTjRviVihElRCAYvP3AK/4oeqnnLzNG8XGZrCLdB2mEAIBQAoUWovKUvGRhD5+ulv0Kp80+Ndm8kCUBEIHnp/i0ANAofh7w90jn6Hqp+SG2BBWaH5Po3Dfd+zYMRMybV1iJhAA9ElltszJgj7Us7Y3Pe2BkFcFjU8etcONFwDEivAH7ZKQgBmJxaRQee9qtZoJ6bkdLHgpjlcDXXHFFRbS+qsG7YgBQHdU3pBOvDtnRcHa3uwlLWNfGbnJXmkEQvvHf0R1EIBoEP5gOd4SNvc+8/CKyA8EFcS8GcwRAgFAnwYvu8QUxFwJ5Kd21c3XNd7c1zeCn+uo9slRc6Xu1k/bSOM1PvkaYRAAaX7N2r3zs4Q/WNamjWtZilBQvt1Vgdg4mzgHQwNAzBQG1LnYHtzZ3KJnhDAIgKhk4PPdIzcZsJI1AxwkFdV6gW28HgAJVQKdtj4GQ0tUAoWm0tIBIC4KVSuxPKwT/MSBMAiAku1bb7D777qFKlF0hK+TYvJ/VzaDXaSnPwwhEAD0yTdVhabcCkbwE68kDNo//nJziDRhEIA80fqFXhACFZNK5f30dNfLuLLU0x+GdrA2XDAA9ELh2jH3/oemJDmt8aGdrHGPn7dfjDRO4r/ZCIPYJgYgD0nrF+8f6NbggMasRqRL4dDV1et1E1K3HshUAh07dsxC44IBoBe+hSI0lQGIyVYvr/zhxr1YWifyn2tubHvkqR9SFQQgE1T/oF9z57QOxpCO9Ws1RrfQDlYwawYuNQDolkYl0C8tFNq9yqU6fF3z39lbxA68IHUjBCByfm156J47OERAX0LeEyE7KpVARQqBglOYCaSy5hlAPNaLDJSfmT1lefOb9R23bW5+5Ia9XPzf+4Ev3tIM/vaOPUdVEIC++TXFW8CAfhECFZPCQaMHQEKzjD0A6ukP0x4C1RuvigXCdjAAMVK5buR1w5Os6PWHf5UBfQjHb8ieuP8L9shTL1pt6i0DgG75+4pX/1BJirSEOBhDtoY2alQBKYywadPzH0amEkhhwNLgACfZALqjUkF48r1sKzGY9YPleDXcQ/eMNNvD/AUAnfLrhwfJKlW1KAbljanozSaRg8citIK59hCo9HOB/MHGX5QQAuiUwlBol9V1y8Mf3/DFCS1W41t8vF9/7188x/sogFUx/wdZ8PcfWpSLZ2ijRghUq9VMSPwhkMqqNa8G4uYVQKcUbl7TvtlJWr78xc05uuFDo/1G7Z5HvsdNOIBlbd96Q3PbIJA27luKiaHQS6pbj9pDoKANbioh0BpawgB0QaGEPa2yZ8IfpCFp73jw8XHmMgC4iFcN+gsAOqVQke4zjIWGQrtUKoGCUvkL3bRxbeOm9R0DgE6su2rQQpt7/0Prh7+x+qnsSOMFpMGDoCfv/33b+xfPMjAawHkEQAC6pTIUWqwKqGZ9WLwdLBiVEIhKIADdUKiY6XUoNPN+kKXWxp8R2zv2rB2ePGoAyo0ACEAvVIZCT0xMmJC69UFqMLS3hFUqFQtp/Vq2EwDonMJg6G7nmBH+IE/J3A+CIKC8CIAA9ErlflWsEmja+iAVAilUAw0OaKx7BhAHiUqgDmcCEf4gFIIgoLx8zhwBEIBe0Q62pL7+MDLtYG56etqGh4ctpKENnzAA6ITCUGh34t25FX+d8AcKCIKA8qkOX2sPfPEWA4BeDQm0g3mxisoiq3nFCYEUKoHWXEYlEIDOqFwvlmsHI/yBmvvvusVeP/4OW8OAEvCDkt1/xBp4AL2jFWxJ/ofpKziRmwkUmsrJPgB9gwOXmoKz5y4MgQh/oMrbJ31r2B/+2QE78W5vA80B6PP76Sfu/4JEy3QM/DBnrvFe7u3d/nnyvp5U+p5cVPHrv3e1eYCLn2nat5mun/983fzv8X8nX47DcxDUDG3QaAUTGwp9zPrETKAl+AWQm1MAqxkUqQRKrld+7fK5C6x6hzJ/2PCHw3se+R7vtUBBPfTHdxAotPFr3czxd5rhjgc7Hur4zzVDnw4CnV4csd75v10SELU+H2xeu9ddOf+x8XP8+yIPWzZRCbSEmvXpI4t+XG+8KhaIyl/uOkIgAB1Q2QzmN2Q+eNNfnLoiBv7w4A+JX/rTAwagWPwwQmGGRwj+njwz22p5nTl+qtn+evK9X2QS8mTJn4OSZ6GVwiS/5/B/6yQg2jL0KasOX2dAWlQqgYo0FNotDoGCluLoVAIN9pWeAygHlcDlr/90F+EPouMPDg/cdYs9/NSLBqAYtm+9oVSbwDzwOTLzdjPwOTIzW7pDZA+3/P93wsMvQiCkZb1IxZmPrCnSUGi3OATyffPB1nOp/OWuo7wRQAcUghfCH8Rsx+3DzYemAy9InbAB6IE/rH2l4AGQhx7jLx1thj616Tejq/ABYqKyGt43mAupWwqFO1KVQM6DoEqlYiGtbxucBgDLGRwggMHSkiGfizFD4WJeNTAx/RZt2EDkijoHyCtdvNqn9Zo1APlQWXBSq9VMSCqJ1FIzgYLyfrvQIdDQhk8YAKxmHYFxaXhA4QM9fbDn3LkP7cQp//GHzZ9PNrl0O9zTH5Z8G4tXcyXzFNavvfz8x7LM1EgGRfvGME7VgTgVbQ6QX4u8QrE29Vaz5QtA/pgHtKRU/jBylUBnzpyx0NaIbPwBAOTHb/p9gKcHPa8fP9X4fG4+9Mlmc0snlS/+UOWBkA/b9JshlVOxtDU3291xE/OBgAglmymLwCt99o//iIqfHilUglFVWhwqwXLRNoO5xSFQ8P+HCnOB/ALmJ5OcSAJYCfPD4rV4g4vqQM/Wn/Gdxmn0m80fJ5tYqsPX2rbN1xaq9cLnA/mMDW+5ABCP3Ts/azFLqn78xb0/oMEPvRTmXnoApLK8al4xK4FkhkNfeXnjjYDyTwAogqJscEk2sfjr4e+82AyBPAzyAKUIgdDunZ+jLQyIiG8Di7VCkfAnfWsG6KZAOmgFW1LdUsprPrLMf/EVFojKX/SmjWvpAQawIob86kpCn2SQZ1Fv8JPNWv7yBzF/IBtpvGJFWxgQj1i3gRH+ZEehcuMk7WCFsGWTRrg8MTFhQlJbU/aRJX4uaAikUm61hq0/ABAND0N8w1TRQ5+VJBVC+8dfbgZB/ooxqKQtDIhDjNcYb6195KkfMjcGEEcl0JJqlpKlQiD/f1qxQLwdzIOgK64IlkM1eSUQACyHKqDwPPDwzS2sF7+Q/114EDQ+eTTaMMiHzH71ke8ZAE2xDYP26+LesecY+Jwxhfeaufc/NMTNv44UvpY8kyjiZjC3VAgUfD2XB0HDw8MWEmviAUCLV/dMNCtETjQrRSjjX1l7GOQPazG1iSWtbYcbf3YAemIKgLzty6+FvGdkb41AO9jZcx8Y4jYkUowhFgC5TEMg/y/faQFNT08HD4FYEw9gJWwGy4fftI+/dLRZ8eNzfriJ756HQXvGnm0+BD1x/xeiqQq6/65bGmHfW/ybA2L8GhJDqOzXjr1/8Wzz/QP5GBQYDD13jkqg2KkMmxebB+QZTWpzc5abCRSUwlwg1sQDQBhJxc/hyZ9Qup8iD4N+9+ujzRP8GE7x/T14x23DzfAKgI4Yrh9+aPDg48/QKpwzhcHQPLvFb8vQp0xBrVYzIamWJS1XCRSUSukVa+IBLGeQasHUtYYa/4iKn4x5qOJ/x15po14V5CEQG3wAHTFUAXkLrG8YDHnd8DDEnyM2bby6uTZ9/drLm1Uy6+YPmZdbQHP23C+bf25/zcyeOv8xlvdFhcU6vF/Ezb8/hjZcbQrE2sFS2wzmlgqB6haYyoYw1sQDWM7gwKWG/iXDnb3lixu3/DTb646fkm8PoxoI0KJeBeSh8cPfedHylDy0+jYjf3a4cWhDKtfV6vB1F/zYn0l8a6Jfv1WrZBXeTzxIQ7yUAiCVTGJezVK0XDtY0DXxMpVAzPwAgNS1z/mh3Sscb5P4wz87YA/dc4dM//1SqAYCNKhXAXlYnFdg7NdMb1nxlz+05tEG1Qqarm5eE/36/cp89axKy5tCK5g78e6cIV7V4WtNQZGHQruPLPPz9cYr2GRmlTXx668aNABYyjquD13zwOfAC9PNjzzQa/B/B1/Fvmfn52Qf7qgGAjRsE3k4W0oeAZAHP/6AOnLzDcEDj+YK7a2fbly3P51r+LUS7ouQBq+oUyA2FLpmKVsuBPKes6DruVgTDwDx85DBqziS7V7Q5NvDnGoQRDUQEJ5/HypKVsBnwcMeD308/FGtmPQWPb9239MI9ENWBam0yZ9kGHjUVL7PijwPyC0XAgVvgFNYE0+iDQC9YdZPfJSDIKqBgLA8BFGcH+aHC1nMAEquOf5SaXNaif/b+Iy3kEGQytcHG+HipRIAeUeSWAhUs5QtFwIF/3+tMIjJL/p+QeNiAmCxGG4KQ0g2fDHrJ06+UWdo41qZwYztqAYCwvG2IzV+f+5r4NMUW/jTzp9Zdu/8bLPFNwSFw3PeH+KmshperBXMpZ7N/Irl9D/ULZX0TaUvEYCWQYE1qCqSlq/f/fpo8+aTAChe/m/pD1WKhx9JWwaAfHm4UN2sNw/owcfHU71WeRXCf/36jmZ7VawHPf7/YXugak6Fv7OTDIWOmkoIVKvVTEjdMtjeLtsOxoYwANCWhD9UZ1zIb4TXXXm5bdrYqqZJTkcXLxtINpj4393Zcx82H2b885Pv/SLo32frdH3cnrz/9+UehLwlxb/eAORH5cGsnbeGzsyesrR48OOvIvCW3sOTRy1vCs9Mc+c+MMRLaT28kNTnAbmVtoMFXRPvg6EVrF9LCAQA7Qh/FnhI4jctHk545Whaq4L979VnXfjHIzNvNx92kh/nwf/39j/zsj1w1y2mJFnL7H8nAPKhNifMg+o054Mpb0fsRagH6cGBSyy0ufc/NMTJ398VDp58JI1YJVDNMvCRFX6tbgE3hPk/gAdBlUrFQqIdDMBSyjg43m+8Dzw/Vfphz36T4jcrO27bnFros9z/hqsOX3f+5z0Imjn+jtWmf9psu8vy38H/rb0FRG0jjv99EAIB+fBWMLVrwD0pzrwpWgDkQj1IK1RxeCUt4qTyzC1WBeQy+QOtFAJJrIkPHwLpDccEgDx5+PPNxqlriPJyJQoDQ/09yV/JkNZkC9vE9FuZzPF58Iln7K//dJdUW5jPBfIqAFoQgeyptYKNT76W2rUuWa1eNKGujQrvEydOEQLFyiuqFYgNhfbOrJplYLVKoKCOHTtmofkFzV/cbAIoG8KfBX4S7ltX1FYkt9qjNtgDX7ylGQiNN/6tvEomrYckf+9Tawvz92SvUOLrEsieWkji2yfT4NfyoswAWswrRvPmWyUVnGSjc7RUCi/EWsEyK0uSDoG8HGvnzp0Wmg/4nHs//wsqAITAzJ8LxTIwNAmE/N9sYvrN5sNSGmGQYltYqMGnQJm0t6UqSLsKqKjGA1wbBwcuNQVz55gJFCOVeUBOrB0ss7KklUKg4H8DKsOhNzXS7RCpOgDkifDnYl5h4+1fMWmuUt/66ebLH5rSCIO8/erJ+3UeBpMbRr5OgeyojURIqwrIFbENLBFiZprKPBee1+Kk8vXjVUA+l1hIzTIiXwmkYMjX/HLiCKDAPPhhzsoCPyX2m5L2ocwxSsIgr+bxf+NewyB/qPDTZaUHJ58NxLp4IDsqMzpcmlVAaoOu05Tm31M3VKo4uIeJk8q1Zno6k23s/cjsJudXVvg1j8HqFpBXAimkcd4OBgDtlAbl9sPnyPzu10ft4e+8yM1TG6/+iT0Aarfj9mF74v4v9HWjpRYSKj2gAkWkNBQ6zSqgIgv199Q8MA9s5vgpQ5xUgtmDBw+aEA+AMgtCfmWVX69bYAotYSrDzgDoWDMQdwjkJ4VffeR7zdcJBileIFkIUDQ+CPWhe0Z6noXhXydKlTdKMwSAovHvLZV2MD+sSPN9qqjDg0NVAbnBgUsstLlzHxjio1SZV5Z5QG61ECj4ei6Fsiy/ceZGE0ARNLc9jb/crP7xG2tcTG0ORto8BHronjt6el9Ta7/ygdUA0qd0HUx70LEHJUWrfPX/TyGrpRS+XmZmqQSKkUrFYZnmAbnVQqDgd3sqiRwtYQBiV5t60/7wzw40QyAsb/Cy8CeaWfNWNw+CuuUPTuNCM/K2bS5Oyx6gROXBzK85WWwCLNo8sW823teDVQGJVM/S0h4nlWtNmeYBOdrBOqTUFw0A3Uhavx584hlavzpQ9EqghJdgP3DXLdatw5OvmQrem4FsqHxvTUy/aVko0hZMbwM7HDCcV3nPnDnOZrDYeHjIPKAl1S3jHIZKoA6tX0slEID4+I2uV//Q+oWl+MDobgcs+6Ywla+n1g0kQRCQNpUH+9rUW5YFD4CKUA3kBzsPP/VDC0mlenbu3IeGuCi9f4vNA6pZxjqpBAraHKeyIcxXBQNALJLqH7Z+YTW7/+hzXZfyZ/Vg1osir3sGQlCahXnkjbctK94aHfMBib/P39N4nw/9Hi9TCTRLJVBsVN6/BecBZToU2q0WArm6BSaxIawk7QEAOqO8XYTqn/6cfHfOysQf9kZuvqGr/8z4S0dlwkUqgYB0rbtKo/rd38Oyvs7sHXsuyjZp/3t58PFxiT+7wnp4//vgwCs+zANaVuZlSZ2EQMH/VhT+Yfwmeb3ImyIALIXqn3SUMTzrtiXMv74mpjWqgVgVD6RLpfo9j4pDf9/0MCWm90z/s371ke/KbMNaf9WghUYVUHz8uVqlyEJwHpBECMRcoHm0hAFQ5cEF1T/p8IeCsg3Q7iVIURoQzfszkJ4tmzRaNPIKOfx/x0OVGIIgtQDIKWxQnnufeUCxUari9XYwIblUv9AO1gWV8lgAaOdzDb4qMBegSJTWoOdlcKC7EMgHROu0hDEXCEjL4IDGoN88DzViCIL8cMIPe5QCIJX18FQCxUdpHpCYXMqSqATqwqaNnDQC0NGcCfDEeDMEQrqKtD64U70cdOi0hDEXCEiLQotGiKpWD1c8ZFGsBPWQw4dAq/3ZWA+PXt0o8r49MZH5DOZu5RJ8dFoJxIYw8wvdJwwAnMIq0onpN6W2NBWJ0sybvPQSetUaX4MKWN4ApEOnsiNMtUuycUupGtQPJb70p5rhlEorLuvh4zK0ca3MrF2xSqC6CYVArm6BKbSErRMYfAZAw1larwrPK6zKVA3USzm9t4QpYHkDkA6Ve90Tp8IFHh627Bl71vY2XiGDl/ZlD6rWr9W47tIOFpct12u0gnmRSRnnAblOQyA2hBk3mQC0rBm41JAdvwH3E9gy6LX1wkMylWHktIQB/RsUeV9RmHtzePJokKogv676IUQMyx4UKoFYDx+fbjeSZkVl5Eyb3NaUdRoCMRdoHjeZANzcufA3HIOXaQzvLDIPgcqwKayfhxyVaqChjbSEAf1SOexUqexIqoJ+9+ujmYdBHmSMT77WDH9iqURlKDR6oTIU+tChQyYmt8AjmnYwmTXx3GQCMJO4OWNjYfaaw7cfH7ci84ecw32FQCKVQCLl5UDMFNrBFCs7FodBaR4OJJU/v/vvRxv/G89FdfCgMI9NaVsaVqe0zbOs84DcRzr8fVQCzVt3JQ9dAFAmfoP58FMv2gN33WJF9M0+t8v5348/xIQ+EfZBk/5noC0A6J1CZcfJd+dMVRIGOX+Y3b71hua1p9swxP97fPmAL3dQb/lazpDI1uSQ86PQPZVWMJ83LNYOluvsm05DoLq1NoRdYYH44Cb/x6pUKhaSygUPQFgKN6mDA+Fv1sviwPNTtqlxkz/SuOEvEn/4ONxni4OHLl6Or3C65wc1c+/TGgD0SuF9Ze7cBxYDv34mAY6HZx4E+Yyc1gzRCyuqfHuVhxUn35tr/meKEFbrtA5SCRQTldEqYlVALrd5QK7TEMjVG69hC8jTutAhkF/wOGkEoEDhxLZMvBqolxNfVX4SvXfsOUuD34QrhEB+c8l8CKB3Cu1gJyOcw5YMyY+1qqcXKu+FPJPFw5+jVb5uJiYmTEzNctTpTCAXfD3XsWPHTIHCJHwAYamcVBIE5ac1H+iZwgyK3pvi7ImZ4xonsZuo1gWid0K4HQwLVOakEvzHQ2nBkuA8oLrlqJsQiLlA84pyCgygd3Pvf2gKaAnLl4cmvjI49iDIh5CmeWKtcvp9o9DASSBGLBxApwYHwm8oVTmAQGe2DV9nCjxT8DEzQmqWs25CoLoFppLYcdIIQKVcfQ0hUO5iD4I8ANrf5zDoxfzvQqEkP2nZBhCvGNvBykjhULwolbllseV6jUogwVaw3HfVR1UJ5ImdD4gObWjDJwwAFPDAG0YSBMVWhp5FAJQ48sbbpoCWbQDIlt97SGySe48QKBY+N1DlnvXgwVxnMHci95yl20qg4AmMQumWwtA8AGHNndMYRKhQjl1WHgR9tREEHXhBasXokrxKZ+/Ys5kFQO7I6xotYbRsA71T2PjETCB9KtfZmePMA4qFymp4JzYPyG8i65azbkIgF/xOd3o6+Hzq82sgAZSXyjYKKoHC8q+Dh7/zYqbhSr88rPrDPzvQ9yr41aicyNKyDQDZUqm4JDCMB6vhlxWkN63bECh4AqMyHJqbTACsJUXCQ6Df/fqo3HwCr1LyACiPP9eRGY12MIZDA0C21q/VGCDOZrA4KK2GP3Qo9/E7q6lZANFVAslsCBNZiwggHIWWMDa56PCgxYMghaqgpFXNq5TyCiv9f0chBGM4NABkS6ESyN9zOIyLA6vhV1SzAAiBesTgSQDAUpKqoPGM26+W4jfEyf9+iLXtr4hUA627knAUALKiELRTBRQPldXwPltYJUuYV7NAM5e7DYHqFphvB1MYDs1MIAAKa2zXM6heklfE7Bl7Nrcw6Hz48+/DViK9LjKkU+nUEQCKRuE5SOEeDJ1RWQ3PPKAFH7HueFJVb7wqFpAneJVKxULyBNxLztXmPwDIz9y5Dw1YSRIGeTAzsvWG5iut7Tse/PhJ6P7xHwWp+lmKysmsyrwKACiaIZG5qAyFjoPSanjmAS3oNgRynlhVLKBjx46ZAm8JIwQCyuusQC/6moFLDfr8vcKDIH/5CapXqvi6VP+8m5sj/++ZmH7LZo6fstr0m3LzEGZmT5mCLdczHBoAsjAoct/Bevg4bG8cfqkQqwTy4pqaBdJLCOSNdDstIJVevi2bNjRuwt8yAAhl8LJLDHHxahl/+eYulwRBXiG0blF7n4c8Z8992Gyz8hXs6kMwk+HQ6wMPLF9HmyTQE/8eDn1qPzjA+5oy1sOjGzcKrYb3sTJCgrWCuV5CoLoFppLiMXgSKDeFSkC2g8UvaaE6YsXgw6HXbw37dUnLNtAb33oZPARiu5801sOjU946GPpQKCHYCnbQAup2MLQLXobjg6EVkjyVnlgAAFQwHBoAikuhEshboqFPqTWb1fAX6iUEqlugVWbtFFrCPNnktAIoL/XWHCAEb1tTMLSRLZ5AjNYMcG+tTOHZZ+7cBwZ9PvtQgeBq+LoF7q7qJQRywf8Wp6enTYHKyjsA+TsrsB1MpcwWSKic0NKyDXRPYe02B6zaFNbDqywhwPL8/tQ3gymgCuhivYZAwRMYlTSPeRwAACzwOTwKVXK0bANxWs9gd1kqB08nTjHvTZ1SS7bgPKDgf6BoK4FkNoSJJJwA8qcydJZqIKg58sbbFhot20D3TrJxCStQOfxWqFjDyrYNX2cqqAS6WNQhEMOhAQDQo3KDrrLKGEDnqLLXNXjZJaaA9fD6VEamCK6Gr5nAfOV+QqDgf3gf8hQaJ41AeXESBSxNZS6QwuwKICYKFa6EQLpUrqmsh9fmnTIqz8djY2MmRqI3rdcQyNUtMJXh0Jw0AgiJG2aoOTIzawrWr+V7A+iGwjyvQbaDyVJoP2czq77tW28wFbSCLa2fEIjh0PM4aQTKae4cNyLAUmSGQ3NIA3RFYeulVxBQZa9pncDQbqqA9N0oMhTaswKFzqE2dRMYq+P6CYGC/x9QSfY2MRcIKCWV06jBAY0efaDdyffCt5VwSAN0R2XhwborqeJTpBDOzb0fPqjE8rwVTGVhycTEhImpmYioQyCVZO9GNoQBCIgTUyhSmAtERQHQHZVZd6yJ16QQrFMJpK06fK2pOHjwoImR2VUfdQjkk74VWsIYDg2Ul8qpKaDm9eMaN+q0hAGdU2lzZtadHpVnHZZyaNsi0grmxSLMA1pePyGQbwerW2AMhwYAQI9CO5ijJQzonLc5K7Q6M9Rdj8q1lPXwurwwQuXrRDQAktlV308I5II32jEcGkDZcWIKRSpr4nmYBLqjEOAyE0jP4GUa8wfZDqZr22adVrBDh2Q6rxJSf6B+Q6DgCYxKCLSFuUBAKZ1lQxiwJDaEAXFSqLQYYumKHJVgjplAupTmAQlWAkkNKCIESglvVkA5cSIFLE+iooBKOaArCjNXVLYLYYHGZjDuuVT596xKUYQHQD47WEjdBMbotIs+BPJ/YIUtYQyHBhAKW1SgSqEljPdnoDsnTqlsCCMIUqLw70EVkC6VgdBubGzMxNRMTL8hkMRw6ImJ4KOJmrZcr/PFDyAfJxlQCCxLZUMY80WAzqkMdVd6qIRXVYY/cJp7/0ODppGtN5gKwVYwuVSq3xDI0RI2b2gjw6EBAEioPExuomUb6JjKUHdaObUoVFSqvKfgQkqtYJ4LKHQJtfGimZqJSSMECl6Go5L2sSEMAIAFKg+THNIAnTshMBPIcV+tRaGikplAmmgFW5FGy9IiaYRAdQtMJe2jbBUonzmB7WCclkKVyoawwQGN1cZALBSCIJauaJGoBBIJKHGhbcPXmQq2gnUmjRCoZoH5cGiFljC/ODLEDigXTqWAlSmU798oUqYOxGJmlqHuWKDy73CCOYxy/GujulljNbwXhqiMiWlTM0FphEASw6Gnp6dNAdVAAAAsUGgJGxzgQRLohkrFxdAGqoEUKAyFdhy86VEJgJxgFVDNxFbDJ9IIgRzDoecxdwBA3gYHLjVAlUJbCZW6QHdk5nkxF0iCyn3GWYEWfFxIqRVMcB7QIROVVgjEcOh5nFgA5aJwKrXmMuadQNdJkfJ93p+Bzr0++3NTwGY/DYMi9xkqQ8uxYMv1Gl0w3gomWgkkKa0QqG6B+T+8zwYKjRMLoFzOnvvQACxP5WGS2SJA51QqgZjnpUGhEohWMD3V4Wtl3lsFA6C6CXRLLSetEKhmgXkApLAljJJzAAAWyFQC0a4NdGVm9h0LjeHQGhRmAilsY8WFqptpBVtBzYSlFQJJDIeemAjeldbEcGgAAFr89FZiLhBr4oGuqFQDqbSbICzWw+vZJjIU2otBBCuB5FKpdmmFQI7h0PM4bQQAYIHCuumhDZ8wAJ17/Xj4SiC3ZRMtYaHR5YDFlFrBDh48aGK8QKZmwtIMgRgOPW/L9bxZAWWhUOHAzRnUnRWY5aCy4hiIhUI7mGOoe3hrBB72qQTSotQKduiQ3BIuuVRqsTRDoLoFJjMceuNa+pcBAJinUFHg78u8NwOdU6jgcyxdCU+hnXaORRxSVFrBnGArmOxq+ESaIVDNBMi0hHFqAQBAk8oWvXVXUjUHdEpmnlcjvGXeJtgOpkOpFcyrgBSKQBapmbg0QyCJ4dDT09OmgFMLAABaVNbEb9rIAQ3QjVdm3jYF3FeHtU6g7ZwQSIdSK5jgPKCatXIRaWmGQC74XCCVSiBuNAEAaFFZE79mgHYwoBsyw6GHmLdZdmdZES9DqRVMMASS3gqWSDsECp7AqPQE3sibFQAATX6Cq3CKywEN0J0jb8yaAtrBwlJYQEElkAZawVZVswgULgRSGQ7tF0sGUALFx7YKoDMn3wv/vbJm4FID0LmZ46ckHr6ZCwQGQ2sY2fppUyHaCla3CBQuBHI6q+J5swIAwPnDZGhDVAIBXdNZFc9cICAkD2OrbAVbifxWsETaIZDEcOiJieCjiZq2bKIlDEA+FEq1gZXMCcxzGGQmENA1lVXx3oaC/NHZgIRaAOQdQGLkSpOWk3YI5BgOPY818QAAtChUAvnDDA80QHeOzGjMBfJKIL5/86cSntN+H962YZ2tYGNjcvOXPYCoWySyCIGCJzA6IRBlqwAAuLlzH5iCdVdSNQd044jImngPgDhgBcLwinNawVak0YrUoSxCoJoF5oOhFcrD/M2KFg0AADQqgdz6qwYNQOd8MLTKXKCqUCUCUCZKg9lFW8FGLSJZhEB1EyAzF4hNBgAASMwEcrSTAN1TqQbacj3zNvO25rJLTIHKe0hZjWy9wVQItoLVTWRBVqeyCIF8ODQtYfMIgQAAaFUTKKyaXkeFLtA1mblAG9cS5OZscOBSU6Dw/lFW3tmyZUgngGUrWP+yCIFc8DIclS+OG4W+YQAACOnke+EHe9IOBnRPpRLIjdysU5EAlAGtYKuKZitYIqsQSKISyGcDhebJKScWAACYnXh3zkJbI3KqDcREay4Qq+KBPNEKtqK6CcxE7lZWIVDNBLAqHgAAHWcFyvm9nQRA91SqgVgVD+SHVrBV1SxCWYVAdWvNBgpqenraFLAqHgAArwQK3w42OMDDI9CL2tSbpoBV8UB+tgmthT906JBiK5hcaVInsgqBHMOh51G2CgCA2UmBdjAqCIDezMyekhnOy6p4IB87bh82FQcPyo3eqRuVQBcJXoajUi5GJRAAAL7i9wNTsJ4NYUDXlOYCMRwayJ63Tyu9XwqGQDWLVJYhUM0C83IxhZIxP3XkhhMAUHYzx0+ZgjW0hAE9qU29ZQr83lppY1GRnRRo43VUcebvS7f9pqnwVjCFpU+LRNkK5godArmJieDb6pt4owIAlN3cOY1WEtbEA7058sasqVAaVovsMc8tfzcKPb+Ojo6amLpRCbQkj+rqFpjKXCBCIABA2anME+FEGeiNV/PJzAXazFwgICsesqp0sngFEK1g6coyBHLBy3BUQqAbOa0AAEBiQ9g6WrSBno2/dNQUqM0rAYpk+1aduVuCAZCLthXMZR0CSWwIU+gf9DcpTh4BZEXhwRroxFmBljDej4HeqayKdyNCD6pAkSithh8bk8tb6kYl0IqCh0AeAMm0hF1PSxgAoNxOKKyJH7jEAPRGaVU84xayp3LIRAVnfrwKSOWwxJc8qWz8blOzyOURAgUvw5meDr6tvmnLJlrCAADldlbg4ZGHCaB3SqvileaWAEWxbVhn3pZgAOSibgVzWYdADIduM7RhrQEAUGYKp8qDA5cagN6prIp3tISVAxWc+fBQtUor2ErqRiVQR4IPh1ZJEIc2XG0AioWKAqA7Cm0kay7jYQLoh8pwaEdLWPYkwntmueVC6fuJVrDs5BECBS/D8S8gf4XmFy+CIABAmZ0996GFRvsI0B8Pc4/MzJoCWsKA9Oy4fdhUHDp0yARF3wrm8giBaiZgYiJ4QVITpxUAgDKbO/eBAYjfkZm3TQUtYcVH5XX2PExVKlgYHR01MXWjEqhjdRMYDq0yF2jTRuYCAUiXypYWoBMqm2aoHAD6o1IJ5KqbdQbZFtFJkes2snX3yE2mwp/dVZ7f29SsIPIIgVzNAlPpJ7xxiA1hANI1d44QCPE4+374djAA/fNKIJVQd6hxyEq1fXbmJNp4Bw3ZulHoe2jfvn0mqBCtYC6vECh4L5YniadPBy9Iap48cvoIACgrldCS1gKgfxPTOlvCtnDQmpmzVBwXntpsLcGB0HWjEqhrErVcKiVlnFQAxUGoC3RHpX2RdcNA/2pTb5qKHbfpDLRF+gjus7VdaK6WB0AKS50WkZxS3atShUDT09OmYGgjG8IAAOWlEASxbhjon7eEyQS7je9pDlqzIbEifuBSQzb8e0dpuPrYmGTX1agVSF4hkPdhBQ+CVMrKtlxPuSqA9DBjBbFhjhVQHOMvHTUV1WEGRGdBIehbcxnVm1mpbr7WlBw8eNDE1E2kqCUteYVALvhcIJUQyIfXcQIJIC2s3EZszgqEQLQWAOlQagkbufkG7rEzcFZiMDTX7KwoVQH5WniFOb6LSE6p7keeIVDw9My/oFT6C4c2sCoeKIJ1bKsAuqbSPgKgf2otYWpVDUWgcthEwJc+D9eUhqofOiQ5ekeuNKlfeYZANRMwMRG8IKmJclUAQFmxbhgoFqWWMKWqhqJQmAnkBgcIgdK243adgeperCHYClazVjtYoeQZAtVN4C9QpiWMSiAAQEmxbhgoFqWWMK9qoGIkXSqzB9cQAqVum1DlnOBaeCc5pbpfeYZAjrlA84Y2XM0bFIBUnBQ5oQMAlJNSS5hjXXy6VIb5U8GZLg9MlWYt7dsnOXqnZgWUdwgUfC6Ql5kpDJvyAIhqICB+DCoEuqfwQMFgaCBdB17QWZ5DS1i6lGY+IT3bhb5P/Bl9akpuAVfNCtgK5vIOgWomQKkaCACAsmEwNFA8R2ZmTUVr2O2nDOlRmAtEeJ8e/x5RCkv37t1rggrZCuZCVAIFL8NRGQ6tNIkdQG/WCJxKnXh3zgB0Z3DgUgOQHm8JUwqCWMKSrrMCFZy0g6VHLSQVnQdUuK1gibxDIBe8zkul1IwTCiB+gwOXGIDunBQILtdcxvcukDYPglSM3HwD7UMpUjhwWkN4nxqlrWAeAHk7mJhREyheyUqIEGjaAvMvNJ25QLSEAQAAIH5Kc4H8PtuDIKRDYasjcxjTMbRxrdQz6NiYZNfVISuwECFQzQRQDQSgKNgOBgBQ4PO+tFrCdNZfx05hJhAVnOn40m2/aSq8MGN0dNTE1K3ArWCutCGQylygTRvZEAbEjCGFQJwGB2gTAbJQm3rLVPj8TQ5c06HQxkslUDpuFPqeOHhQMmupWcGFCIG8D6tugakMn9q2maF1APrDpiXERuFEmVkhQDbGXzoq9b7EgOh0zJ37wBQQBPXH18Ir/R2KtoIVditYIkQI5IL32Km0g/lNKBczIF4K379z5z40AAAUeAA0Ma1TDcSA6HQohPduDVWcfVFaC+/DoAW3gtWNSqDMBE9gvP+QuUAAAABAug5PvmYqGBCdjrPvaxw4MUqjd35w6S2SKvbt22eCJP9QaQsVAtVMgMpcIEIgIE4qJ4u0gwEAlPiqeK2WMAZE94tKoPjdPXKTKRGdB1TogdCJUCFQ3VqzgYJSKT+7USiRBdA5lcGyZ88RAgEAtCiti2dAdDoUgqD1axmj0SulgdD+HO7tYGJqJjC7OA+hQiBXs8BUQiAvzaNXGYiPyqrSOUIgREZlwCiA7IxPHjUl24VmocRK4dBpcIA18b1gIHRHCj8QOhEyBArei+VzgVQSyOpmylSB2AwOXGoKaAdDbFRmS7CYAciOV40cmZk1Fb6Rl0PX/swcP2WhDW34hKF7agOhR0dHTVDNSqLUlUBOZS7Q0MarDQAAACiK2pTOljAPgHbcNmzonULlsUoVdkzUBkILbgRzo1aSVjAXMgTyRmHmAs3bRiUQEB2FKgKVQY0AACw2/tJRqWpVQqD+nDglMBOICs6uKVUBOdGtYIesREKGQC74xDjmAgHo1RqBvnSVthoAABbzAMiDIBV+r82A6N6dPUcrb4yUQqCpqanmS0zdSrIVLBE6BArei+U9icwFAtALheCWAbsAAGW1qTdNidqa7Ji8PvtzU8Ca+M5Vh6+VCs1Eq4BqVjKhQ6CaCWAuEIBeUL0HAMDKjsy8LTUgmnXxvVOpPt60ca2hMyNbP21KROcB7bWSKX07mFMpSdtyvc7ALgCrGxQ4iTrJTCAAgDilAdGuOnydoXsqcwipBOqMVwApdZr4RjCVDpw2HgTUrWRCh0A+GLpmgR08qNECONRItaksAOKx7qpBC21OpD8fiJHCphugDNQGRI/cfAP33D1SCIKoBOrMjts3m5KxsTETJNmflrXQIZCbtsA8kTx9OviisqYt11OeCqBzSjfVQKdUVvzy/QPkQ3FANJvCenNWYU38wKWG1W3brFPx5s/boq1gNSshhRCoZgIOHdLYCrdlEy1hQCzWCQza4yEWMRrkBh4oHbUB0YRAvZk5fspCG6ISaFXbt94gNRB6717JsTujVsJWMEcINI+5QAC6pTATSOFEDgCA1agNiGZdfG8U2mgV7r/UKa2Fd6JVQBpVIAEohEDeh1W3wFS+MJkLBMRD4Xv1xLtzBgBADNQGRLMuvnsKlUB+/8Xz0vK8Asi34KkQHQhdb7w0BgMHoBACueApnFcCMRcIQKeUSmwBAIiB2oBo1sV3b+7cB6Zg3ZXchy1HLdwUHQhdsxJTCYEkerFUqoGYCwToUxlsy4p4AEAsPAA68ILGCIYEs4G6o1AJ5NYLbGhVdaNQsCk8EFpySFFeVEIgiVKsiYkJU8BcIECfymBbVlwjRgqVdAprjoEyUguBqsPX0VrUBZX7DoXlHIrUBkILVwHVrcRUQiDmArVhLhCgT+UNlu1gAICY+PuW0oBoRzVQ5/zfT+HeY/1aQqClqA2E9nlAgiSTqTyphEAueBkOc4EAdGrNQPh2MCoZAAAx2j/+sinxEIgD2M6dfC/8/cegwH2YGi8kUBoIfejQIcWB0P6wX9qB0AmlEKhmApgLBKATCjeLzANCrBRC1LPvf2gAwvB18UoHGf6eTjVQ5xQ2kw5t+IThQl+67TdNiWgVkAdAGlUfARECLaIyF2jb5msNgC62gwG9UwhRVTbcAGU1PnnUlBACdU7hEEplQYcKvy9VagXzCqCDByULbkrfCuaUQqC6MRfoPP9GpiwV0LVOYCsFlUAAgFj5gGiluXZ+371dbJ6KqhOnwt9/8Kx0oS1CG8Gc6EDoupV8NXxCKQRyzAVqU6UaCJClcOOhUI4N9IJKOgCK6+LVhuqqOntOo512cIAQKPGVkZtMiWgrWKnXwrdTC4Ek3gl0toRdbQA0rbsy/EMsm8GA3lFJB4Sn1hLmQ3XVKioUvT77c1MwtGGtofV1q3S44gGQ4EBoVzM0qYVAEo2DzAUCsBqFSqCz5wiBECeFdkoA4flwaLV18XeLVVQoUhmsTztYy47bteZZibaCjZrA6BkVaiFQ3QSmdSvNBaJkHtCj8n1JOxjQO75/AA1q6+KpBlqdyma3dTwnNe9JlUaIeAWQyrP0IgyEbqMWArlDFpjSXCDehAA9KjcdtIMhVpzeAkj4uniqgeKjEAStp6pU7mt1717JsTt1oxXsAoohEHOB2hACAXoGRdaSnnyPmSaI0xqBYZ7MBAJ01KbeMiVUA61uZvaUhbZm4FIruxvFvk6pAoqDYgjEXKA2NzbehABoURgK7agEQqxodQbQbvylo3LvaayLX9lZgX+voY3lHgztX6MMhO7IqOECiiFQ3ZgLdB5zgQA969eG/55U6ccHYsVMIECH5rr4T9O6ugKF+5Cyr4hXWwsvOhDaR83UDRdQDIEcc4HasCUM0KIwE4hWFsSKgw0AS/EQSK0aaMdtWluXlJwUCNI9pCtrUKe2Fl54IPSo4SKqIZDEUcChQ8GzqKZNJS91BNQMDoSfCTQnsp4V6JbKYHWCVECLB0DeFqbEQyCqgZY2d+4DU1DWaiC1dkXhgdASo2bUqIZAEv9YXg2kYNvm6wyADolKIIZCA32ZO8dMLUDNgee1WsI8AKIaaGkzx8MPhnZDG8p3WO4VQCNCIZBXAfk8IEEMhF6GaghUN4G5QAcPagSH/gY0tOFqA6BBofz2xClCIMRJpXydweqAHp8zo7YunmqgpakE6WX8t1FbCy/aBuZGDUtSDYFc8F4sTzVV5gKxphLQoPIASysLYrXuqkELjcHqgK794y+bEqqBluZBukKYrtJinCe1tfCirWAMhF6BcgjEXKA21WGGQwMKVG425s4xEwhxUji1JUQFdB2ZeZtqoEgoVAOtFzhYyJPaWnivAmItfHyUQyCJXiyV8jbawQANg5eFHwrteIhFrMp4agugO1QDxWFmNvxcoDUDl1qZsBa+I3VjIPSKlEOgugnMBVIJgfzNh5YwIDyVQJZ2FsRKYbseISqgzauB1N7nqAa62FmBdjClqpisKa6FZyB0nJRDICcxF0ilxM2/8QGEJTEUmgdYREwhSD3x7pwB0MamMH0K9yMKc+bysuN2ra8/0VlAbtSwIvUQiLlAbagEAsJTuNmgigExUzhJZzMYoG/8paNy36tUA13opECgXpZ/Dz+ErG7WmhEruhVs1BgIvSr1EEiil29qSuMkwiuBeOMBwtJ4gGUoNOI0tHGtKSBIBfR5AHTgBaqBlM2d+8AUlKElTG0tvLeBiQ6EphWsA+ohUN0EkryDB3XmSm25nmogICSFVpaZ2XcMiNGgyABPtusBcfAQiGogXSrt6WsGiv3v4SHXyNYbTMm+fftMUL3xqhlWpR4CuQkL7PTp0zrVQJuYCwSEQhUD0B+V01qCVCAOVANpOytSmVz0NfFqI0G8DUzl2XgR2SFFamIIgWomYGIieBbVtE2sFxQoE5UqBobaIlYqAzyZCQTEg2ogXSqVQEX/t2AtfMdqho7EEAJJ9GKptIT5KSpvOkAYQxs0KoF4gEWshjYKtFMeP2UA4kE1kDaNDWHFnQm0fesNrIXvzKgxELpjMYRAp03gH1Sp5E1tMjxQFuvX0soC9GNw4BILTWWQKYDOqYVAjmqglrPnwh9MFbkdTK0KSHQWkJP9gymKIQRywXe0+1wglTV4rIoHwlA4aaKKATFTGKzOTC0gPl4NND551JRQDdRCi3p2fDO02uYzpYVJbabmX+hQLCGQxD+qzlyg6wxA/hROmqhiQKz8gUnh1JwHFiBO+8dfNjVUA/lw6PCVQEVtB9suthFMeC08VUBdiiUEkogcVSqB/M1G4TQVKJt1VwpUAs1SCYQ4qbxvzRynnRKIkc+eqU2/ZUqoBmImUFYU18Lv3Su5fKturXlA6EIsIZDPBQpeDeQhkLeFKaAlDMiXTBXDKVpZECeVkva5cxorjQF078Dzr5qaslcDsawiG3eLzQLy52DRKqCaoWuxhEBOohdLZUB0dZjh0ECeVFZbM88EsRraqLFdj8HqQLyOzLzdeM2akrJXA50VCNbV5ub0S7EKSHgtvGR5krqYQiCJlrBDh4LPqG7ysno2EgD5GRy41BQwzwSxGtoQPgTyE2tOrYG4MRtIi0I7mCvS379aACS8Ft4fzOuGrsUUAkmU4KhMRG/NBdI4VQXKQOWU6eR7VAIhTgo36FQBAfGjGkiLysKKwQFCoKyIzgJyo4aexBQC+TCemgXmSajKXKDqMFvCgLwotINRxYBYqSw0mHufeUBAEVANpOOsyHW1KMOhfSOYUnubP/eqLEdapG4inUIxiikEchJzgVRawrZcv8EA5EPhxu4krWCIlMxmMCqBgEKgGkiHTDvYwCVWBF8RGwjtXTCiA6GZBdSH2EKgmglQSUN9yCZzgYB8KJQZq5RcA91SaV9mPTxQHFQD6VCoUi7C37taFZATbQWT6BCKWYwhUPBeLJW5QK66mS1hQB4U2sHYDIZYrV+rcVPLYHWgOKgG0jF3jlb1NKjNAvJh0KJVQP4wXjf0LLYQyAUfEO29kSqr4rcMfcoAlAMPsIiVTCUQ7WBAoVANhETsM4G2DG1ovpSwFr64YgyBJAbyTExIjCeybZsZDg3koSgDB4EQFG5sZ46fMgDFoloNdPcdWnNdskalcv+2i1UBecGD6EDomlEF1LcYQ6CaCVBaFU81EJA9hZlA3GQhRj6/ToHK8FIA6ZKsBrp9WG62S5bmzoXfELZeoG2/V/61otYKtm/fPhMlW54Uk1jbwYLPBfJ0VGVVvFrpIFBECqXdrIdHjDaxGQxAhhSrgdzdI5+xsjjL/Ulf7hbbCOZzgHwekKB64zVq6FuMIZAL3hLGXCAAeVM4aQO6NbRRIwTyB0UAxaRYDTSy9dPco+dozcClFiPFKiDRjWCOWUApiTUEqpmAQ4ckxhM1K4EYQAdkR6Wkm0ogxIih0ACyplsNVI7ZQArttoOXXWIxUqwCEp0FxFr4FMUaAkkM5FH6BmFVPFB8Z1nBiggptCx7gEqIChSbYjVQa+MT1UB5GIywEsgPGbeJPcP58y1r4Ysv1hDIk8C6BaY0F0il3B4AgITKzDqqgIDioxooHIWQfU2ElUDeBqbWzUErWDnEGgI5iV4slZawkZu1ekmBIlG5sWC7EWKj0grGPCCgHKgGCuMsMwt7ojYLyIdBi1YB+QN33ZCamEMgWsLaeIo8JLKBBSiaGEuMAQVbNolUAh2nEggoA6qBEIvtjQBIZeZkQrgK6DFDqmIOgSRWcx08KJFFNdFzDABQsuV6jfelmdlTBqAcVKuBqsPFnd85d+4DC21wIK4lOV8RCwaFZwHVjYHQqYs5BJKYEO4zgVSqgYr85gIAiMvQxrUSsw58VgWtlEB5qFYD3X/XLVZUc++HbweLaVOyYhXQvn37TBSzgDIQcwjkJkzAxITEH4NV8QAAGZtEWpSZBwSUz96x50yNP/TvuG3YALUqIK8AUupuaVNvvEYNqYs9BKqZAKVV8Sql9wCActs2fJ0pUKwIAJAtr/4bnzxqanw2EAe25cYsoK5IJlNFUIQQKPiOdg+BVFbFqwzhBACUG/OAAISkOBvIAyCqgcpNsQrIt4KJku1Ri13sIZBjVXwbVsUDAEJTmQfkZmbZDAaUkVcDHXhBYo/MBTwEKlo1kMJg6Bj46A6qgDo2aqyFz0wRQiCJq/vUlMabDKviAQChbbleZTX8qeZgaADl5NVAateAIlYDnRUYDO3UApbF7h75jCnxKiClsSaLMBA6Q0UIgUZNgFIZHavigXRxwgV0R2Vb5ZE3mAcElJkHQIrVQD4bSD2wQLq8CshfSoTXwteMKqBMFSEE8mE8dQvMZwKpVAOxKh5Il8oJFxALlRvdI68TAgFl5yGQYkWgWlUIsuUDodUIt4IxCyhjRQiBnMRAHlbFA8gSp4aIgdJJJ0OhAahWA41s/TTV+yXh928jYiGQd7GIVgHVja1gmStKCCTxhXLwoM7Xa3Uz1UAAgPypVKP6PCAfDAsAutVAWpuikA3Ff2fhKiBmAeWgKCGQx/usim/DyQKQnrlzDJYFOrVN5BBiZvbnBgBOtRqoNSeGe/YiowqoK3UTmfdbdEUJgTx5kbiyq0xY37b5OgOQDpXTw3W0g0Gc3+yqtC3Wpt4yAEhQDVR8iod2VAF1ZcyQi6KEQI65QG18JhAnC0B6FG4cBwcuMUCZ0vsO84AAtPP38UeeetHUeDWQ4tDgbqgcUqmFfIpVQMIbwdyoIRdFCoEkBvJorYrXWkMIxEzhdImB71CncrPLPCAASzk8eVTy2nD/XbfwHl9AVAF1ZdRYC5+bIoVAdROYC6S0Kp5KIKBY1gxwgwhdfuIpsxr+DVbDA1ja3rFnTY0HQDtuGzYUh2oVkMrokiUwEDpHRQqBnEQfIavigeI5KXByuH4tM4GgS+nggXlAAJZzZObtxksvKPYQiPv24lCsAhobkx25M2pUAeWqaCFQzQQorYofuTnuHmNAxcl35yw0ZgJB2bZhnYUEig94AHTsH3/Z1HgAdPcdDIkuAsUqIJ8DpDS2ZBEGQueMECgDWqvimQsEFAXbwaDKH16qIqvhCYAArEa2Guj2YZkNi91Q+DMrzXpiFlBXaibyDF8mRQuBPHmpmYBDhySWlTXL8yktBfqncHNBCARVKgGQoxUMQCcUq4Hc7p2fNcSLKqCuUQUUQNFCICcxkEdl6JYHQEMb1hqA/mi0gxHoQpNSK9jENCEQgNV5NdD45FFT41X8sS13WUO7+nlUAXWlbqyFD6KIIVDNBCjNBaoK3ZwDsZo794GF5qEulX1Qo9QK5hV7rIYH0CnVaiDFIGElCvcmEgs8qALqFhvBAilqCCSxKl6lGmibUJk+ECuVB8t1V9ISBi1KrWCvMA8IQBf8vV0xCPJqoOow9++xoQqoK3WjCiiYIoZATmIgj8qqeE+lYxwyByg5+/6HpmDTRto7oUWpFezw5E8MALpx4IUpm3v/l6bm/rtuiab6V+E5Yy7wfRpVQF2jCiigooZANROgUgnk1C5KQGz8tFDhJpHh0FDiN70qlUD+/clmMADd8muHB0Fq/Pq647Zhi8EagbDqbOC2fcUqoLEx2ZnLdWMjWFBFDYEkBvJorYqPa8AcoGjuXPgQaP1VgwaoUHpvmZh+0wCgF6rVQB4CxVANNCgwGHruXLhKIKqAulazVhCEQIoaArEqfhHvLWagLNCfmdlTFtrQhk8YoELpppfV8AB65QHQ/mf0ZgP5vXsM1UAKzxghQzzVKiAPgkTRChZYUUMgJzGQR2pLGAOigb4obJ5YRyUQRPjJpx8wqDjyxtsGAL068PyU5HZBDxjUZ3sqLK0IFQJRBdS1UaMKKLgih0A1E6DUErZtM6vigX6cOBX+5tBP2xj0DgVqVUCKrRwA4rJ37FlTtHvnZ02ZQiXQ2UAt+4pVQP78SRUQVlL0EEhiVfzUlMawOZ/dQEsY0LuT72mcEA5tYEMYwlMKgZgHBCANR2belhww71WXqvM9VQ6mTrw7Z3lTrAJywmvhR40qIAlFDoGcxEh0lblAHgDx8Aj0buZ4+JlAjg1hCM0fSJQq0mrTzAMCkI7943qzgZxixYlTuScJUQ2q+G/ibWBUAWE1RQ+BaiZAai7QMC1hQK9U1sQrzWFBOW2nFQxAQXk1UG1Kr7rQ3/uVrr2JwcvCbwZzebeDUQXUNa+KqBsklCEECt4S5mmsSiI7crPexQqIiUJL2NBGKvoQjtqNL61gANL2yFM/lAyXvzJyk9xoB4Wh0C7vod5UAXXtMYOMoodAHgBJDORRaglT7SkGYqDQEuYP4cz3Qihq7yG0ggFImwcKB17QmOnZzt//1VbGr18bPgTKOwCiCqhrNRPp0EFL0UMgJ5G+KLWE0UoC9O714++Ygi3XE+YijB236zyAjE++RisYgEx4CKR4ffEQSOkgSGEm0EmqgNSrgCTm9GJBGUIgifRFaVU8lUBA71Q2hG3ZRJiL/Hkr4tCGq02FzwMCgCx4AKRYDeQB0N136IQQ668atNDm3v/Q8kIVUNfq1toKBiFlCIHqJjKESqUlTG2rCxATlQ1hbPpDCF+67TdNhZf/0woGIEseAuXdatQJr8hUuZdXmAmU5wEdVUBdYyOYoDKEQI6WsEW2bb7WAHRPaUMYc4GQJ3/gUHrveGVm1gAgS/5+/8hTL5qi3Ts/a6H5fYjCvciJU/mEQFQBda1uVAFJKksIREvYItVhQiCgV0feeNsUUA2EPHkrsVLweHjyJwYAWfO20yOCobMfBoUe8aDSHpzXTCCF4G0xqoDQi7KEQDUTWBXvAdDUlEZvMVUEQO9OipSGM+QdefqKUAm8V+QpPpQBKKb94y+botCtSSqHUSfenbOstUI3vfsuqoDQi7KEQK5mAlTmArkqLWFAT1QePhnyjryozZIbnzxqAJCXIzNvy1YDbQ/YnqSwHt7lMRPo7pHPmBqqgNCrMoVAEumLf7OqUOxpBWLgN4MKqOhDXraLvV8QAgHI296x50yRV2mGuhdQqATyuU1Zz2r090CqgLpSN6qApJUpBJKYC+QtYT4bSIH38fIACXTPbzZUtoVQ0YesqQ3C9NN4xW09AIrNrzuKbWF+jd5x27CFoDATaGb2HcuaUjt0giog9KNMIZDPBKqZgImJCVPgARCDZYHevCJTDURLGLKltg6XKiAAofjKeIUNoYt5CJT3wa7KZrCs5zR6FZBSO3SCKiD0o0whkJNIX1QqgZxaiT8QC5WWsG2brzMgSzcKBY1+En+YEAhAIB4AeRCkxsOYvKuBVDaDvX78lGWJKqCuUQUUgbKFQKyKX4QHSKA3KgMi/caPaiBkRe0E9BU2ggEIzEMgxZZUr9rM83qtcu8xM5tdCEQVUNfqJtJ5g5WVLQTy6L5uAsbGxkwBD5BAb/wGUOUmkFXxyIraCehfPj9tABCSVwM98tSLpuj+u/6F5WVoo0YlUJbteVQBdc0fcOsGeWULgZzElrCDByWKkpqqw1QDAb1QmQvEpj9kQW0t/MzxU7kMAAWA1dSm3pJcGe/39Hkd7qpsBsvqfcHb69SqgDz8YRYQ0lDGEIiWsEVGbuYBEuiFylwgv0mhog9pU5sZd+CFVw0AVChuCnN5DPP3+w6FgCSrAKi5ce32MBvXVuKdJFQBIQ1lDIFq1toUFtyhQxJFSbSEAT2qTb9pKmgJQ5rU1sL7aW9t+i0DABV+EFSb0rkPSPj9QNb39UMbNbYLZzUPaERwFpCHP94KJqpuVAFFpYwhkKMlbBFawoDuZVmG3C1awpAmtbXwE43AVXEtM4Bye+SpH0pem7K+hqscPJ04lf5sRg9/1N4DHVVASFNZQ6CaCdDaEnatAegeLWEoGrUqILd//EcGAGp8QYTiyvisq4GKvBlMMQCiCghpK2sIJFGC4wHQ1JTGGwcPkEBvlErBqehDGtTeC3z4quI6ZgBwHgIpVgPt3vk5y4KPkRjaoLEZLO3h3IqHIM6HQVMFhDSVNQTy8puaCVCZC+SYKQJ0zyuBVG7+fMi735wB/VBbiTs+edQAQJXfAyhWA3mgkcWAf5kqoONUAQmoG1VAUSprCOQk0helb2pmigC9mRAZWNs6ndMY1og4bRcbhukVQIcJgQCI801hihWLWYT61c0aVcczsz+3NClXAQmjCihSZQ6BZFrCfDaQApV1j0BsVOYCOcVTLMSDKiAA6M3esWdNTRbVQCqbwdK+99q987OmhiogZKXMIVC98ZKo3VRqCaMaCOie2qp4WsLQC//aUTsIIAQCEAsPJdKeUZOGNMN9f49QmQf0eortYB6UKY7FoAoIWSlzCORoCVuE4dBA93wegNKN347bhg3o1o7btb5uxidfYyA0gKh4W5iaNJe/qDwn+H3XzOw7lha1KlhHFRCyVPYQqGYClFrCFE+CgRjUpjTmAjkPgagGQjf8ul/dfK0p+cvnpw0AYqJaDZRWq/g2kS2kabaCqc3CS1AFhCwRArU2hQU3MTFhKmgJA7o3/pJO24oHQGoP9NCmNkvKH6LSPOUFgLzsHXvO1PghbxpVPCr3FmkGbVQBda1uVAFFr+whkBszAbSEAXFTawkjzEWnFDeiMAsIQKy8jVWxLazfsL86rHO4NDObzjwg/ztRrAL68pe/bMKoAioAQiCRLWGe+PpLAS1hQG+UWsLSOvVD8akFQKyFBxC7Ay9MNQ+HlPS7OEJlNXxah26qK+F9RIjKmJAl1I0qoEIgBBJqCRsbkyhKaqKKAOiet4Qp3fSxLh6dULvef1PwBB0AuuH3Ah4EqelnccSNIgdLac0DogqoJ1QBFQQhUIvEljCl1JcKAqB7zdOpN9IbVtgvqoGwGsWBmGkO/ASAUBSrgXpdHKHUJTAx/ab1S7UKyMeDqHSGLKFuVAEVBiFQi0RLmIdAtIQBcTvw/KumZDtVfViB2kBM1sIDKAoPgPY/o1XZ6AHQyM3d3xco3Uu8frz/eUCqldLiG8H2GVVAhUEI1FIzkZawQ4ckipKaaAkDuudVDEonfyNbP02giyX5kE+1r4394z8yACiKA89PyQXbvQx43iayFcz/LvvdHOkH3VQBda3eeD1mKAxCoBYPgCQadw8elChKaqKNBOiN2hyAu0c+Y8Bi/cyGyAJVQACKaO/Ys6ak21ZxrwLqZ6B0ml5JYSD07p2fNUXiVUDSfzh0jxBogcxcoNOnJYqSaAkDelRLoV89TVQDYTH/evBrvJLDkz8xACgarxBOY5tVmrpph9o2rLEVzPW7hVVxDp7zAIhZQMgTIdCCURPBljAgbjPHTwne8FENhAVq8xC8AkjtewYA0rJfbOthp9VAHphURVrBXL/LN9Tm4DkPf7wVTBhVQAVECLTAy29qJoCWMCB+ai1hXg00tGGtAYpbUVgLD6DIYq0GUnoO8CqgfmYuqq6E37dvH1VAyB0h0IVoCVuEljCgN2oDot0DX7zFALVw36uADk8eNQAoshirgZQqZ/pZDe/PMmpz8JyHP489Jj1vmSqggiIEutCoiaAlDIibB0Bq1UDdDoNEMamVw1MFBKAMYqsGUjsI9r+/Xvn/T5Xh1u3Eh0HXjSqgwiIEuhAtYUvgoRHojVoI5NRmwSBfakMxW7OA+pvxAACxiOlwaLvQIbCHZ71uj1RsgXbMAkJIhEAXmzABai1hQxuuNgDd8Wqg2nR/myzS5t/PSjd2yJfajfArfdzYA0Bs+p1rk4WlDofUgpPxPlqGWQnfk7pRBVRohEAXGzURSi1h1WGdzQBATA48/6qp+YpoWTSypbgWfv/4jwwAyiSGaqAdt282Jb1WjPqhl9r7nvPDfqqAEBIh0MXqRkvYRZgLBPRGcQaA6oBEZEutFXB88jWqgACUTgyt4ts2X2cq+mkFU1wJ77785S+bsJpRBVR4hEBLoyVskdYJMrOBgF6obQRxqqtSkQ3/t962WauikyogAGWk2iqe3OerzY7rtRVM9T7HK4CEV8I7qoBKgBBoaTUTodQSplhOCcTAq4EUKx5U++SRPr+5V2oBPMIsIAAlptgqnlQDqVXP9NIKpjoM2onPAho1oedgZIcQaGk1a7WFBafUEkb7CNA7xTXYHuzyfV0Oajf1/Qz5BIDYKbaK+z3Bk/d/QawKqLe2YdUqoH379lEFBAmEQMuTKMFRagnzU2RawoDeHG489KptBHF3MyS68PzGXm0t/GFCIAAlp9gqrlb179vUuqW8Ev6xxx4zYaMmUgSB7BECLa9mIrS2hOkMigNiozgM0gOg3X9EW1iRbRe7GVasigOAvKm2iqvwv5teZic99Md3mCJvA6MK6P9v7/5j7KrvO/+/SVPwUIYYbK8YxxZjUIeSKvI49LvB/ap4nMBuIkw8TkQUp1JmrP0GzB9b/wBpUwVpZqTNdiPxw+5+pQD9w3cqFdSiwrg4aroJ8TWV1klV4hkpDcSr4DMLAVZAYHAUDN0oe17nzvFcj2fse2fOuef9Oef5kD6dsXGDsWfuPed13j/gBSHQ4upGS9h5tt3MljBgqRQCeawGUrg70O9raDCyoZDP00BoqoAAYM4Tz/p7OOTFj5bQLqeHHn3r1pg3Cn+cr4SvGVVAlUIIdGG0hM1DSxiwdAqAPFYDychXbqMtrIQG4gDI09/rj5zNwACAIh35gc9WcQ+WskHS60p458OghSqgiiEEurC6OeGpJcxbawEQEoVAHsu/aQsrJ29zEVgLDwBzPD8cKtJSNkh6HQY9OTnpvQpIAVBkqBRCoAurGy1h59my8XoqBoAl0gWf15koagtjW1h56GLY05DPpW55AYAy89oqXqR2N0jq/e4up1VAO3bsMMcia7SCoWIIgS7usDmgljAvw8SSlrDfpSUMWCrNRPF6M+z1SRrat/PTvgK9Z46/aACAc1ENdK6lzI7zGgCpAiiAYdCRoXIIgS7OTQmOp5YwbzcXQGjGxr9rHink9bpZA+3xNhD6eeYBAcCCqAaac6zNtfCqYva4El6czwKKjCqgyiIEurh6fFxMZVY1kBdqMaAlDFg6rYb1elOszRr33nmLIVx6jfZU0cVaeABYHNVAc9r9c9h/5x+ZR6yEh2eEQK05aA4oBPIUBLEuHliexxzfGKvajyHw4fL0d8daeAC4OKqB2p8dpzmGHlvYFf4cOHDAHIuMKqBKIwRqTd2cOHbsmHkx0O+n1QAIkaqB6pM/M6/233kL84ECpCpNT61grIUHgIujGsjs8WenWv61uj7xOp5CVUDvvOOikWQx+wyVRgjUmro5GZrlacUgLWHA8j305D+6ffKn7+9H9n+e7/PADMQBkKe/M9bCA0BrqlwNpBb5k6+80fKv97rIQlVAzlfCT5ijmbcoBiFQ61xMZdYLi6eWMNZJA8ujsmfPT/50gTXylVsN4fA0IFMX9ayFB4DWKAB66MnnrIraWQuvaxOvw6B37dplzlEFBEKgNtTNicOHXWytT3h9AQZCohDI842yNm94Xb+Kc+nCWFWaXhxhFhAAtEUz1KoWnrc7O05Vyh6pAsjTw/oF1IyV8DBCoHbUjZaw8zRuOD5qAJYuhCd/CoEYFO2fp2BeX9cMhAaA9o2Nf9eqpJ0NkroW8Tqv0PlKeGEjGBKEQO1x0RKmQWOeUmZVCQBYnvrkS25XxqdGhm6zvnWrDX55CoGOTfkdeg4AnmlxhPdrgqy0UwWk8OerTiuTA1kJHxlghEDtqpsTrlrCWBUPZGJs/HvuB0I+uv8LbAxzSm1gnv5unjn+ogEAluaxNqpjQtZOFRDDoJcsMlbCowkhUHvq8XExwVUvNF5WD2oLDS1hwPJ5HxIt6cYwgiB/PLXr6Wu5Kk+xASAPqgYq+1y1dquAvM4ipQoIoSEEap+LEhwFQJOTfm4WGRoLZENP/tpZkVoEXYixOt6fLRuvMy+eeNZ3mAkAIXjwyedKvTK+nSogr8OgqQJCiAiB2lczJzwNH+tbt4YbQiAjD/6N//WwCoIeJQhyQ1VAnv4ujk29ZACA5VEA5L1CeKnaqQLyPAx669at5hzDoHEeQqD2ReZkNpAqgTy1hDEbCMiGSsBDuOhT+PvA7tsNxfNUIq82sKqtNwaAvKhCuIyvqa1WAXkeBq0KIOdtYLqYrBkwDyHQ0hwzBxQAjY+7WFiWGOj304oAhC6Uiz4NIx4ZutVQHF0g6+/Bi7LPsACATivbyvh2qoC8DoPWfVgAK+F3GLAAQqClOWBOTExMmBfeNtMAIVMJeCgXfXds/hhBUIE8DebX122dVjAAyJQqhOuTP7OyaLUKSBXHXodBHzx40HsVUM0YBo1FEAItjXqw6uZAvV530xImXl+ogRCF0hYmBEHF2fnpfvPi2NTPSj3EFACKMvaX3yvF66tahlutAnrgHp8t5wp/RkdHzTlmAWFRhEBL52JLmCiJ9mLnp/zcjABloCHR3reFpQiCOq9v/erkSakXzxx/0QAA2VMA9Ni3W9+m5dXY+Pda+nVe28AkgDYwVsLjggiBlq5mTnhqCdOAaE+tCUAZ3Petbwfz9E9B0OP372RrWId8+VObzAvNeNATXgBAPp54djLo19kjx3/S0rxDhT9eHyxrGDQr4RE6QqClc9MSpi1hagvzgmogIFu6YArp6Z8qU7Q+nhlh+fuEo9CdtfAAkL9WK2k8euzIP7X061QF5PVhElVAKANCoOVxs5rr8GE33WnJgGiqAIBs6elfSFuXFAQ9QhCUK2/D+PU1CgDIV/Jg6Eh4bWGtbj29Y/ONbmeMKgByPgw6MqqA0AJCoOVRH5aLqcyeyhIVAG27mQHRQNYefPK5INbGpxRQEATl5w5HF8lqTwjpaxMAQqZAJZR5gdJqcKV7iK9u+6R5pPDnwAE3C6IXs8+AFhACLY8CIBePPrUhzFNL2ED/dQYgW5oLdN+3jgS1HUQB0F99fSevCTnYstHPn2lIVWoAUAajte9aKFpdCe99GLSnjcwLqFmjQAG4qN8yLNd0fIbNgenpaRseHjYP9AKuJ8OvvXXaAGTnrXd/ZR/8n1/bH/7+tRaKy377w/bv/qAv+Vxr77F8qgL6d/9Pn3mh1cUf/OuvDQDQGboeELUGe6YHV3/2xNGLvkfo3uG//H+fMY/0oH3fPvdFNjvMSYcK/KMSaPlUCeTiG04Doj0l1N7flIBQafbKE98Pb/6KnvDde+cthuXb0n+9eaFtLyFVpwFAWYTQFqYWrwd2337RX6f2ca927dplztWMYdBoAyHQ8il1cTEgWgHQ+LibWdVsCQNyFNo8gNTOT/cnK+SZE7R0+rMbcNQK9szxFw0AUIz7vvVt90G8Hgxf6CGQ7hm8XhccPHgwhGHQ7leWwRdCoGy46b+cmPDTCqrk/yZH64uBMmnMB/p2kMN4081hfetWG9rn6XVVX39q/QUAFCMZuvxt/9vC9BBooYUGCn/0zzwKZBg0K+HRNkKgbNTNSUuYelY9pdV3OZ3wD5SBLvzGxsMZDNlMF32P3/9lXiOWwNPq3B8RAAFA4dQmHkIgv//OW857AOR9GDQr4VFGhEDZOWhOeGoJU/mnKoIA5EODlrU6PlS6+NOsANrDWqM/J0/z1h5/dsoAAMUbG/+e+7awZD7QPdvO3huoMsjTg41merBeq9XMOVbCY0nYDpatYXNAA6K/9rWvmRfaBsBGICA/Pz71evIx1GHsvddcbVv6r7Nfvve+nXzlTcPiBuI/pwEnQ6FPvvxmEC0IAFAFp+P30On//fbZbZxeKQD6+IZr7EfxvcHI0G1uHxZv3bo1hJXw3zTM1xuflfFRj+FA08fPzH7U2R6fL8VnU9PPpb/292b//3tn//dKuXHtEkOWjlrjC6hwR48etYGBAfNATyW27n/UAORrNL6Y8vpErVUqaVewwLaphT26//Nuwj61Ij5z/AUDAPhx7xdvCWI5i5ZbaEagR2oDGx0dNec2WDVnAfXaXMizsenz5uAma+k2cH2cnv1Yt4B92JClw+YkBFJLmJcQKB0QTTUQkC+1hfWtX+32oqoVGg6pqqDdDz0V5NDrPHlrBeM1HQD80fbQLRuvc99m7fVahWHQbqThThr26GPv7M93WpqqDsz7+TQMOmaOZgS3gplA2aqZE9oS5qmEkXXxQP5C3hjWTBeuf/eN4WSdLDPF5njaCqYBpIR0AOCPrgX0IIWK2qVRFZDzNrAoPu5TqjYp2BmIz974HIrPqfi8bY0um4etMXIlrfbxRL8n/Z6ftsbv90R8Rm0uNHKLEChbesWomwN68WJANFA9ujEvSxWNqoL+6us7F1wpW0WeWv2O0AYGAG6FsjbeGw2CDmAYtKqAQp5T00rg02thUvgzYo0wSP9d+u/pNYcYDJ09zVkaNAfOnDljw8PD5sFlv/1hBkQDHaLhkKrU0HBIfe+FTOGxBiGvXdWdDI3Wf1sVqTpKcx68GPvL7yWv6QAAn7Q0Ih3CjNbs2LEjhCqgXRaOXmsEPhrCvCc+/3X2DFtjULPH6p6s6L/rZmuEXQPWyAgmzQkqgbI3YU7SWa021PFiYKOPjTZAFSgwufuhvy1NOfi2zR9LqoK0Ur6KPLWCHTn+E9oMACAAmg9E625r1AameUDObTWf5lf3qBJG1T2qhlGrlKpjVCTRa9U0YHNVT/qz6LWCUQmUvTPx6bFG8le4DRs2uBkQveojlyfVCa+9ddoA5O+td39lv4iPl5Xiy6WqJrWWqi2qauvkVQXkZcinbiqi//22AQB8U8XmsamXkvfN0CuD86TwR1VAztXiU/Ssj16bW7d+tzXm3/zX2Y/DNlfdo/KzFYb50rBs2Bqr6KesoOIRVsTnY8AafY2FW7lypb39tp+L9frkz+y+R75tADpHM3VGhm6zstHTzbHx7yXhcpmpnP/oQ3ebB6oA2rr/UQMAhKOs1wFZ2bp1q6vuiQVE1qgCiix/vTbXprVx3o/L2rpVlMga4d6YdRiRcD7q1kj1Cv9GUV+rXtS8VAOlA6JpJQA655nZIb5luwBUZcyj+z+ftCc9duSfSlvyPrDxOvPi2NTPDAAQFl0H9K1fw7beBWgQtPMASA5aNgFQGuSkoU5vfK6d/ZgedE6vzVVRKQiqWYdQCZSfUWv0/BVOAdDRoy4KkxJqJdAB0FllfxJY1jDogXu2uQmC7n7oqdJXXgFAWenBiR7IokFtYKoCcj4LKIrPhgv8896mj2nIo88/0vR58z+DXzVrhEGR5YwQKD+91hj+5IJawtQa5sHJl9+0L3/jcQPQeVUoCVcY9MzxF0sTVqgVTBWURVO49rmv1wwAECZV0D4SB0FeZswVbdeuXSGshNdGqXRuTG/Tz/caykh/1wqCDliOGAydH/0FDpiTb9Curi4GRANIhim/Ft/Ml2VY9EJU8q6wSxu19KQj5AHSemL7hVs+bh6oFaw+9ZIBAMJ0+r33k2twL+8rRZqcnLR77rnHAqAhy712bjUPFT3lpYHaGrDdazkOjiYEytdV1vhLLJxe6L72ta+ZF3oCcWR2TgmAzqpCECR6ndF/Y7pN7JfvfZBcAIfk7m2fTEItDx588h+TrxsAQLi0OVTvhX/4+9dalW3evDmZnQo4pblNg/E5Fp/XLWOEQPl6MT67zcGKvDNnziSVQL29veaBbs6e+P5ksroSQOcpCNLTwIGN15d+baxaqRQG7fx0f/za0x1f/H4QTJix/4u3uGkFe+jJ5wwAEL4fn3o9eW/5+IZrrIrGxsZsYmLCAOdU8aUsYSY+P7AMEQLl60x8brRGkle4mZkZ+9KXvmReKAB6/uTPDUAx1JJ5/F+mbXP8NNBD0NAJaauYqoPkF7NPRD1SWH7Xtk+aB7SCAUC5KAhSNdCqK3/HqkRDoHfs2GFAQNLOomOWEUKg/KnOcNgceP3112337t22YkXhhUmJvnVrbPwfnjcAxVFZ+LH45n5L/3WVCYJE/626+FV1UDo7yFu72ED8d+KlZY9WMAAoFz2MPf4v/6ty7/8aBv3iiy8aEJgBa8wJOmwZIATKXxSfveakJczTgGi1oDAgGiiego8qBkGpdHZQGgh1d13mokLorjtutt5rrrKinf7V+/Znjx81AEC56H3u5Ctv2B2bP2ZVoE1g3/zmNw0IlLqLBqwRBJ2xZSAE6owua/yFFU4D0FQN5AUDogEfdCF45AcvJPMBqrw6Vv/taYWQWsZuWL/a7JJLkoqpTs8w+9Mvb3Uxr+m7/3ySVjAAKCk9jK3CoGi1gakKiGHQCFyvNdrD/tqWEQQRAnXGZHxcrOZSS5i3AdH1yZeSGywAxVLIoe9JrSVHo2VMM4T+3R/02fC//4OkSuiG+McKZvIOhTythn/syA8t+t9vGwCgnKowKHrfvn1Wr9cNKAF9o94cn3FbIkKgzlBKN2CN5K5w7gZE/59fJ8NpARRLQ4i9DCL2SAGZLpDTUEgzezZ/rDFUU8GQ1tBnFQwNbLzOzVPZP3viKJscAaDkyjwoWpvA/vRP/9SAEum1ZcwIusTQKcPxOWQOrFy50k6dOpV89EDzJj53fy35CKAYOz/Vb/d+8RbD8uh1TPMVGh/fTI4+11DlV9sYrPzo/s+7qMjS3La7H3rKAADlp4cdj8TvP2VqC1f716ZNm5J2MKCERuMzZm0qfthAdUzE5+H4FJ686MXw4MGDNjIyYh6o/HTbzTfaE9+fNACdp5XpBEDZ0OtZGt4stNkrCYR+8e7Z0DvduPXqvAH5XlrymNkGANWhhxVj49+NH0R8wcpC9zwEQCix0fjMxOdAO/9PVAJ1lv5y9pgD/f39duLECfPi5Mtv2pe/8bgB6Ky+davt8fu/bMBCPvf1WlsVTACA8Gk5wr13hv9wSOHPhg0bDKiATdaYQ9ySDxk6acKcmJycdDUcrW/96mToKoDOUQBUpqd9yNarbbawAQDK4Yln4/uEyZ9Z6LZu3WpARTxtbXQcEQJ1Vn32uDA21nb7YK4YSAt0jvr9H7hnW9K+BCzkRydfMQBANY395feCfhCg+xzawFAhvdbG/GFCoM5b0gTvPKgSSPOBvNAMjDINogO8KuPgR2SvPvmSAQCqSbPr7vvWEQuRwp/R0VEDKmYwPntb+YWsiO+8F+OzOz4rzIGuri4bGBgwL06/9749f/LnBiAfBEBoFavhAaDa3nr3V8m1uVbHh0RtYK+//roBFXRzfP46Phes9KASqPP0F1I3Jw4caGuQeO60ppr2FCAf+t4iAEIrtBo+3WAGAKgubYkMqS1M28A0+xSoKM0Fevhiv4gV8cU4aI1yrcKpHUxtYV6qgVgXD+RD31uPEgChRSdfeTP5mK6877m629auvvLsxyu6zg/rfxk/LVZwpPPaL07bq2++m/zvnHzlDQIlAAiIXve1sKVx1lkoaAMDEsoZBuwChSesiC+O9rP3mwMKgI4ePWpe6GmD1hIDyM7o0G22bfONBrRClUA9cWCYVWio1/WTL7+RtPvqKBgCAPiRBj+6Vgj1gdGuXbusVqsZAIvis2Gxf0gIVJzR+IyYE6dOnbLe3l7z4u6H/pbZQEBG7v3iLUmrJeCFQiFtH3vm+ItJ4AQA6DxVe+r6ILSKn4Uo/FEIBOCsffFZcPYLIVBx1K/3tjmh0smRETeZVHJTcPdDTxmA5blr2yeTA3hFIAQAnaXA565t/zb44KeZhkFrxAWqZ+XKlcnp7+9Pihquvfba5Mf6PP1nslDBg1oI048akzI1NZXMlEpHpgROs4g32AJDogmBiqUerAFzQN8cqgZKv0k8oBoIWB4CIIRGgdBfHPlh8tof0iBSAAjBHZtvTNq9yhT+pHQTPzY2RjtYiaXBjsKejRs3nv08z24WBUGHDx9OPgY6cHzBaiBCoGINWCMIckGbwvbs2WNeHDn+Exsd/54BaJ/Ku9UGBoRK7wGPPzvF/CAAWCaFP1+NHwpVYTmEQiCFQWmFB8KlgEezaxX46HOdIqVBowKhgL6+IltgNhAhUPHUEuai/MbbgGhtk/nc/TW2ygBt0sXeyNBtBpSBWsS0oviZ+AAAWqeKn5GhWyu5GZQwKBxphU9z4JO2cnkV2NfXVpu3KYwQqHij5mhAtEIgL+vi5bEjP0wOgNb0rVttj9//ZQPKJm0VIwwCgAsr48yfpdLN+vj4OPOCnFCwo3tNhTwKfNLPQ6S5QeqkURjkXN0aQdBZhEDFU8R5yqgGWhDVQEDr9KTvr76+M9n2AZRVffJn9tCT/8jMIACYR+//mgXIRtDzBdrKE6yF5vfoPtNzdc9S6etJg8mdf11tis/ZoUaEQD48HZ9Bc+Ltt9929Q1KNRBwcQqAHtn/+eBKvnfs2GGDg4M2NDRkQDt4bwCAOVVu/WqXgqC0OohAaHmKGNbskaqCFDKqMsgplSuNpj8gBPJhwBwNiPa2Ll5Pez/39ZoBWFioAdCuXbvObvHQxYJeewiD0A69P4yNf5dNkgAqTYsgqP5ZGm180kk3QOlmHudqDnr0eShze4qga1mn7WH6wr4q/QEhkB+si78A1sUDC1Ppt1rAQg6AmhEGYSmoCgJQRXrvf+Ce261v3RpDNhQIqTro2LFjZwOisgdDuufTaQ550h8T9LTPcRB0dkA0IZAfe+PzsDnhbV28tsPc/dBTBuBcj9+/M7iLP70x6g3yQgiD0C6tkr/vW99mVhCASlD71wO7b2cOYAekQZA+Tk9Pn/Nj79IQp/njtddee/ZzQp587Nu3z2Nr2EFrZA6EQI4wIPoiqAYCzjU6dJtt23yjhaSVAKhZGgZt376dixRclAKg+751JA6E3jQAKCu1fqkFDMVTGKTKoeaPMzMzZ2cNNc8cWmz+UPrzi83RSSt15n+e/nqFOuk/S0Od5l+HYmzatMlbUBjFZ4M+IQTyRXGhm/Ibb+viqQYC5mj7h05I2g2AmqVbJTSvrGrDBtG+B//mOXvi+/6f0AJAu0J8/weqSOGegiBn7YSaC/TObxk8OROfYXNC5Y7Dw8PmhfqeFQS99tZpA6osxAvAgwcP2te+9jVbqrTsWv87em1Kn3YBC/nD3288FaV6FECZEAAB4dC16ooVK+wf/uEfzJGfxmeSEMiXyBrDoXvNAaWXCoE8lRKqdK0+9ZIBVRXiBaDWsO7evduyojBI/5s6V111FSXPWJDmZQhBEIAyIAACwnPzzTcn16uOqoGm4/MdQiB/lHMMmhOXXHKJfeYznzEv+tavsSPHX7DT771vQNXcsfnG4GYAKLD57Gc/a3nQG+rExERSHTQ1NZU8bfm93/s9A1IKgnpWddsxHh4ACBgBEBAuPag8fPiwObEiPo8yE8gfVwOiPa6LZxUwqqhv3Wp7dP8XgtoCogBo69atHX36kc4O0lYxTzPNUKxnjv/Exsa/ZwAQGgIgIHyqXHdUDXQVlUD+aC5QlzXawgp35swZ6+rqcnUzpXXYT/3jj+2Df/21AVWgeViH/tMXgwqA1E6qCqDXX3/dOimdHZS2i6lCiPlBuGH9GuvuusyO/2TaACAU2gL2H3f8vwYgbO+//77V63Vz4q+pBPJJZTdvmxO6gXr7bTe/nQTVQKgKBUCP7P988jEUCoBUAbTYKtQipBVCWjU/OOim4xYdxnsHgFCoAvjx+79sAMKnAEjXxk5sJQTy66g5qQaSWq2WtFd4cfpX79vn7q8lH4GyIgDKjwIhhUFbtmyx/v5+Q3WwPh6AdyG+/wO4MEctYVtpB/NLNevD5oS+YD2ti7/stz+ctIOx9QVlpdav//Yn2633mqstFHqd2Lx5s/sASPR7/M53vmOPPvro2baxmZmZ5J9dc801hvLS+vjnT75ir7112gDAowfuuT1pYwVQHj/96U+TkQUOjH/I4FV99rigEjZHfYwJ9UmHNCMFaMfIV25N5l+FJIQKoIXo96xqRwXdmzZtSp7U7NixI9k6ptc9R4P8kJEHdm/jCTsAlzQEWpsNAZSLp8pzQiDf3OySk7GxMfNEAZCCIKBstAZ+oP96C8muXbu8PN1YtnT1/N69e5NgS6GQwiEFQ3od1D8ry39rVen9Q60WPEgA4InCaTaBAeX0kY98xLxgJpBvrtbFy9GjR11tCmM2EMomxFWw+/btswMHDlgV6amOhk7ro4bob9y48ew2Mn2Eb088O2kPPvmcAYAHf/eNYaoUgZJyNByawdABGI3PiDmhdolDhw6ZJ2x7QVmEGACpMmZ0dNRwvuYwKD3pqvprr7327K9Jf5419sVgUDQAD1TdrkpgAOWk8QMbNmwwBwiBAuBqXbxoXbynJ9xUA6EMBvqvS+aUhIQAKDv6cxwZcZP3V4reO/74G0/Yq2+9awBQBFX//NXXd9KiCpSYpxCImUD+aSJp3RzRsFRPmA2E0PWtW20jX7nNQqLXAQKg7KSVQeg8vYeMDN1qAFAUVQFXIQBS6M5DW6B4hEBhcDWRWbM/vG3LYVMYQqWnfw/csy2or1+tVNfQZGRDc9bUaoviaBMPDxMAFEHXAds232hlpdBHLbd3P/SUbd3/KJWXqCxPG3R/yxCCKD4D8ek1B86cOWNdXV2uBkRf9tsftg/+9df2/MmfGxAKXfhpQ1FIQyC1FWvnzp3J6wCWT3OANHB/xYoVhmJ9fMM19t1//p92+j2eUgPoHM0B6lu/xsrk+ZOvJIP3//+n/4c99ORzdvxfpu212eBHr7FHfvBCcu2u112gKhQC6UGqA+PMBArHcHzcTGTWTKBTp04xGwhYIlX+qP8/pABIb15ale6tEjBUaQDEQGg/6pM/s/se+bYBQCfoGkAbwUKna28FO3oYqwCo1WvxOzbfaF/d9kk2oqESNErBSSX9ViqBwqHVJfqqcfG4mGogYHn+23/cbjcE9ORPAZDWWr7++uuGbDz99NPJann40XvN1ckNzGtvnTYAyFvIVUB6rTxy/AV77Mg/2Z89fjSp9olefzu5Fm/VyVfetGNTLyUPxspWDQXM99d//df2gx/8wBygEigwo+ZoXbyqgLQpzBOqgRACXfSFNH8kDYA89TKHTpvAQh2srdfXY1M/s5++/Kb98r0Pkp+7ouvSJNTsW7/a+taFfSGvGxvNrgCAPIVYBZTO90krfrJEVRDKTtfS9XrdHGBFfGDUe3Vq9qMLtVrNhoaGzJPHjvwwOYBH2gCiEwq1fqkFjAAoO3v27EkG7IdGgzz/In5trcdPbS8UtOsC/qa+j9rOT/cHGwiNjX/XnomfcANAXkaHbgtmIHQy4+f7U0nLbN50jaQ/F8IglImup6+66ipzghAoQLpz2GNOaJaFZgN5QjUQvAotABIFQBoGjWyo/evEiRMWEr2WKljX09926SJeX/OfiEOhkC7oFXhpgw3vIwDyEEoVkMIftXtlXfVzMel7R5m3pqFaDh8+bIODg+YEM4EC9KI1ZgO5oFRTc4E8DTZlNhA8Upmz2sBCsmvXLvvOd75jyIZeJ//+7//e1UD9izn5yhu2+6Gn7PhPpm0ptAVGlUMKkLQZRjMfNPvBO/0eeR8BkJeB/uvic715pQBcm7006+e1Ata5p+8dmjnEvCCUwTe/+U1PD1WZCRSoo9ZYGe+CQiBtuPGEaiB40rdutT26/wtB3PymxsbGgp1Z45UqgEIaBK3g5sG/ec6ypjYxzcTyXhnE+wiAvDx+/0637bKq+hkb/15SEemF3i9UFUSbGObT12l312Xur7E3bNjgabQClUCB0iPZYXNCX9BUAwEL08XKn//Jdlv9kd+xUBAAZe/hhx/2VAZ8UWr/0lPgPPz41OvJNhgNkfZ8Ma/3kbdmfpX8fgEgK3rtu2vbzeaRXvsVAKkSxxP9fnRNn1aV6oafMKh6FPgopPzv//w/kxlVqlTTe/Uf/v615plm6I6Pj5sjVAIFjGqgi+ApLoqmC5RH9n8+qAuVgwcP2t69bjpOSyG0QdCdHIrsfU6WLjg/9/WaAUBWvG4IDW2xSqgz59Aavf+efPmNJPx77Renk/Cn+Z5OQeC9d94SxNwoR1vBUpsIgcI1YI0gyA2FQAqDPHni2Ul78Mns2xmAi9Gb06NxABTSdqSJiQnbsWOHITseh+dfSBFbsbwHQXc/9LdUlQLIjAZCewstQt+se1PfumT2IoFQeBTsvPaLRuDz05fftJOvvJnMI7zQQ/yQrrHVMaNWMGcuIQQKm+4ses0Jj9VAoqe4nvqaUQ0P7L7d9dDH+TSsTk8qNOwd2VAApNdET62yF6L5P0vZAJYFXbyPDN1mHunp490PPWUAsFxqBXv86182T0IPgOYjEPJL92M/it9TFfaoukfBT7v3aKFV2WvJitrBHKnHZ+uHDSE7GJ+HzQmVuel4qwYaGbqVC3h0lKoaQgqA9JRCFUAEQNk6dOhQMAHQUlfAZ0XVR1fMlnZ7oxsKPXWktRjAct30u+vME92AlykAEgX36Up7VYrcEAdvWzZed/a1HPmaX9mz1LBnIfo71EPWUP4edX3tLACSKf0fQqCw1eIzEh83+4Y1UNZbCKQXjJvipwGU86MTvLe2zKc3KFUAOdpYUAojIyPuXgsX4+UpsNp3teHD4/eP5neU7UYJQOdpNbwnu0v+kFRtRTppm7NCId0T6KxdfWVQLfueNAc9p9/7IP74Zhz4vGG/fO/93Lov9D6seVohURWQQ3X9H9rBwjdqjSDIDY+zgSjnRyeE9galyp9NmzYRAGVseHg4qQIKwZH4wnh0/LvmyejQbe4GPeqCd+v+Rw0AlkrVC0cfutu8KFsb2FLo70RBUN+61QRDTfSep41sJ2eDHVX0/DIOexT0KPzpZGVsSAOgm6kCyGkIpAFFESFQ+FQFdMocVQN5nQ3EcE/kSRcQj9/vq8//YhQAaRYQsqP2rxMnTtjKlW5ekhelp6Nf/s9PmDe64Purr+901+/PewiA5VAV0AO7t5kHqtb44288QZvrIhQENQKi1bPB0OqzgVHo9HefVOy8OfvxrdP2WnxOz/5cp0OeC9F1wAP33B7cn7vjh6y66N+kT2gHC5+GeGg2kJtqIL+zgW5j1S9yoTepR/d/wUKipxMEQNlS8KMAPIQASBeB933r2+aRLj61pczb95TmfBECAVgqjSfw4i+O/JAA6AL0kETS2ULNFAb1XH1l8lHXfz2rupPPu7sujT+/8uyvuaLrsqTFOY/5Nc0tV6/Nfp5+VKjT+PHps79W/0whT0h/5xruvf/OW4Kc46TxKE6r7I+ln1AJVA5UA7WoyO03KKfQthSI3pxGR0cN2Xr66adtcHDQvNMFoeZAeN+a6G2+Fi1hAJbj8ft3uqhoCOU9oIyWc61Ylb8vhT5679eIhRCpEEKzNp3Sb6yuT6gEKgdVAx2Oz5A54bUaSC8qR37wAk8/kAm9UREAQTQIOoQASO771pEgLiYV2GsGgJfvL32/s2QAwFJ5aWnRim4CoGLw535hobZ/pVT943QOkEQ2GwDJhwxlMWrO6GbTG13Eh5osw5+Rr9waVAB08OBBAqAc7NmzJ5g/V1VDnnzlTQtB2hbmiad2DgDh8PTa8fizUwZ4o/szzQMMee6S4zYwqTf/gBCoPCKb95dbtLQayBu9yIR04w6ftAVMM0JCMTExYXv37jVkS4OgQwmAtAUmtHZYVd0sNJOhKKoEAoB2abCwB6pESefdAB405mp+PrmuDnH+T0oBkDaCOTbe/ANCoHJxV3rjtRpo/51/ZMBShdarrAHQjstTg6UAKJRB0Ap/Ql0F7On3raf5IV+kAijGDet9VDccm3rJAC+0MU/VP6FX2eo62/kDwcioBCq1ujmsBhofHzdvVMHBE10shcIfT8NqL0ZlqTt27EjWVSI76SYwBUHe6clvqAGQeKsG8vJEH0A4tEHKg/okIRCKp4cpD+y+PT7bgn+wkl5nO3deVQYhUPm4K73xmoyGdCMPH3Tzp3LVUOiNSRsKHPcnB+vQoUPBBEDaAhP6MHxPIVZIbaAAfPAw50TvA54CdVSTHqb+3X8eLsV7qR6wBnKdXZ//E4RA5VM3Z9VA+sbQQFpvVHrIkGi0qrGxYJuFQm9MejJBAJQ9BUBsAussVQN5CbKoBALQDl0/eKh2YLMhilSW2T/NArnOrlmjHewchEDl5LIayGM7iqqBmO+Ai9EbV2ir4DUDSD3KyJZWwQ8PD1sIQtoE1govQ61D3lwCoPN6nFw7UAWEoqSbv8q0YXPfvn0uFyAtYMFcgBConOrmrBpIAZDHaiAFQHfdTlsYFpf0Ld9ze1ABkN6YtA0M2VIAxCaw4nj579FrAhsmAbTKy+tFmR4KIAwKfR6/f2epqn9Ei48OHDhgAajbAlVAQghUXu6qgfTN4rEaaOen+xkSjUXde+ctQT35D+iNKShqAQslANL635AHQS/G0zwLWsIAtMrLUGhWw6NTFPgo+FH7V9mqZ3WdHcr1oF0gDyAEKq+6UQ3UMoZEYyH6uti2+UYLhb6/AnpjCkK6BSyUFjDN/7nvW9+2svIy08JLewcA/zxUAilED31BAMKQDn4u49zVwAKgul0gCyAEKjeX1UAeB2gxJBrzKQAKKRxU+9fevXsN2dH2rxMnTtjAwICFQpvAyjAIejFeKoFuWE8lEIDWeKgEogoIedO91N99Y7h0rV+pwAIguWAOQAhUbnVzWA2kbyKPGBKN1ED/dUEFQApWNQga2dmzZ08SAIWwBj6lQdBlDoDEy5awLRtZEw+gNR6uLV8r+XsDipNu/Xo0sAUq7QgwAKrZRTIAQqDyc5e41Go1l9PUGRIN0RvYyFdus1AoANq6davLeVshUujz9NNPJ1WLagULhYYml20Q9GI8PNHW+wUPDQC04oqu4l8rXn3rtAFZSuf+qPqnTFu/5gswAJKL3v8TApVf3ZxVA4nXaiCGRFdbugo+lJu7NADy2GIZorT6Z3Bw0EKiUERVQFXhZcNNz9XMBQJwcR6qI6gEQlaSh+bbPlnauT/NAg2AarbIRrBmhEDV4C5xUSWQx2ogGRkKpwoE2dGb2iOBlbLu2LGDACgDmvlz6tSp4Kp/pOyDoBdy8mUfIRCVQAAuxsvrBJVAWK7m8KcKIzQ0ZiHAACiyFu/7CYGqoW4Oq4H27dtnHikEYFtY9Yx85dagAiC9OU1OVqP9Jy8Kf7T5Syek2T/N7vvWkdLPAZrv9HtnDABC0O2gFQxYrnTjVxXCH41XUJW9xpcESAFQ1MovJASqDnfVQLqB9boyXi92ZR1uhvPpTW2gP5xBrypPDfTNqXCq9BkZGUkqfxT+hLT5a77HjvzQTWtUJ1Ut9AIQrisuv9Q8oB0MS3HH5htLvfFrPlXXb9q0yW23ykXUrdEK1pIPG6qiPnsGzBGV2Q0NDblrwdAL3cjQrXb3Q08Zyi20VfCB9icXTmHP9u3bbXh4OLiWr4VoCLRCoCr65a8+MAAIQXfXCvPg9HvFb1VEGHQPpIfhOlVqe1ZxQsBjFrQdpq01wYRA1aJqoAFzRCV3qgbSk3lvNOleL4BV2bhTRaGtgh8fHycAaoPCHg171qDn/v7yDC9UJUxVAyBPeLIOIBSnf0UIhAuravgjur7eu3dvyJt2W24DSxECVUvdHFYDaRirqoE8zuRQQHBs6iXaD0ootFXwekKhNyhcmIIfVfuo6ifkVq/F6LVo90NPcUEPAACWrcrhj5Sgwr4enwPWJkKg6nFZDaQht5rP4Q1tYeUU4ip4lagG/IQiVwp7tmzZknwsY/DTbGz8e5UPpXuY1wYALeOhARaijgfN/Nmy8bpKhj+6ptaSosBnbEbWZhtYihCoeurxmYjPoDmSroz3eANHW1i5hLYKXgGQthSwCn6Oqn3U3lWmGT+tUAvY8ydfsarrdjJoFQAuxsO1BvOAkNI18Labb0zGIej+pqpKdG3ddhtYihComrSb3VUIJEpjT5w4YR7RFlYeIa2C11OKgIfUZapK1T4LqfIg6Pl6rvbx/cuNFQAgBAp8FPwoAKpi1U+ziYmJpAOlBNX1CoBqtkSEQNUUxUe72feYI+nKeA1y9Ya2sHIIbRW8glF9X1SRKn2ag5+qVPss5OQrb9iDf/OcoeGmG3w8vaTFAgDglYKfm/o+WtlZPwvRdbVm0ZaAbg5GbRkIgaprND5D8XF1Z+V1ZbzQFha2EFfBB96n3BZCn4Wp+vC+b33bMKdv3WoDAADnSoOfxqluu9d8qqhX9Y9Gj5RAFJ8dtkyEQNWlGjhVA7nazZ4O6Tp06JB5RFtYmPRGGFoAVOZV8OlMnzTw0eeEPudLN4HxejOnb/3qYNo5AQDIW9rqpQHPvD+eT8FPyZarKACKbJkIgapN9XDqvXJ196XqB1UDeZz7oXLKB+65PWkLoxUgDHpDfGD37RYK9SqXLQDq7e1Nvp83btx4NvTBhen15b5vHSEAmufLn9pkABAKD6/hBAPlonuRgY3Xx+HP2jj4uZ5Wr0Uo9NFD1ZK0f6U01zeTlhRCoGpzWQ0knodE961bY3fd/kl78ElmdHgX4ip4lauGTBU9aeCTtnhR5dO+sb/8rp185U3DuT7R91HzgIcAAIBO0DWs7j1U7aN2aNq8Lk7zNHU9XbK5mhoEnVmiRQgEfTFpNlCvOeJ5SLTs/HS/1ad+Zs+f/LnBL1VthbYKPqRy1bStSyet8lHVD5ZnbPy7Vp98yXCuOzbf6Ob7mc1gAIA8pKFPOttHn1Pt0zrdP6qivkTtXzJhyxwEPR8hEPQdomTR3RAefQNv377d7U3lyNBtzOtw7N4v3pK8cYZAb1QKgLyvgk/bujTLJw1/kC2tgX/m+AuGcyn8+WpAc70AwBPNRdT7C/xRwJMOdFalD6HP0pRs+HMzlTNl3iZACASpWaMaaMAcSYdEP/300+aRbkpYG++TLna0yS0UXgMgNnZ1li7QuUhfmL6nmWsBIDSvOXlQqNfQbZtvtL/gQUOh0iofhT03rF9tn4jDH97blq+k1T8SWWMQdOb/YYRASKkaaMCc0ZBcJboeh0RLunWKGzc/FP6EtAlMQaeXnmVV+gwODhL6FIAAaHH6ntbNCwBg6RoPL29LqiqfeHaSbbc5I/DJX4mrfySKz1bLYBPYQgiBkKrPngFzRt/cGhLt9YZUgcPzJ19hPpADenMNbRV8kVsL0pk+artU+MM8n2JoBhBPZhem72m1dgJAiHoc3vSnr6s6un7VDDpdw5585Q1D+xT29Fx9ZRz0xIFPHPb0XN0df1xD4JOzElf/SGQ5BkBCCIRm6jc8Zc4o5dXN8sMPP2xeMR+oeKFtAkvfvDpNwY8Cn6GhoSQAotqnONow9dCTzxEALULfy/qe9shLiwcA37ovv9Q8a8yiaWyb0jXsj2Yfav705TcJhebRdabCHYU8a1dfSdhTkJJX/4hSrVwDILnEgHOpLMHlSq6jR4+6bQsTPU1hPlAxdLP4V1/fGcwbsdq/Nm3aZJ1C8OOPLrbv+9YR1sBfgJ5Se53txes9gFbcsfljyfzIEOlBhYIgvU8pGHr1zXfttV+8m/x82eg6srvrsqRyS9eSPavioCc+PcnnVxL0OKCKn6IeoHZQGgDlPieCEAjz6e7w1OxHV3TzqrYwz9Rj/WD8ZB+d9cDu222g/3oLQboKvhODoBWaqtVreHiY4McRBUBUDl6Y2jo9t3YSAgFohffXsqXQe9drs+fVt07HH08nP6dwyFNIlAY7V8RHlTuNzy+d/fzS5OdVyaOfZxuXb6r6UfWP9y26y9SxAEhoB8N8+gI8GJ8Rc0bVE2oLGxlx91s7a+en+5OnJrR3dI4urgiA5ijs2bNnT1L5wwp3f47Erw0Kisv4JDUrGqJZtpsmANVUxnBhbQuVMXqPO/3e+2dbZ/XjX76nn/vgvPc/hUgXo8qcZo2Ap9Fqd8VsiKOjz9PfI8Kn62UtUNGioJLraAAkhEBYyKg1Vsb3mjMqAVRlg+eb2/133mI/ffkN2jw6ILRNYDt27MgtAKLqx78H/+Y5e+L7PjbBeaUL9wfu2WYAUAYeB0N3QhrKEMZgqdLlKSUd/NwsssYa+I5eIH7IgIXtMqeUCHumNz3dxPDGly9VC4S0NSivVfAKfzQvS2fv3r0EQA6pTP7L//lxAqAWaBA0r50AyiKtVgHQGrV+bdiwocybv5pF1uEKoBQhEBZTnz3u6MVBg8E8azzNvp0e45yEVi2Qxyr45vDH88D0qlPw88ffeILKwBYo1A0lAGI7GIBWVLUSCGhXOjKhU3MzHYisA1vAFkMIhAtxWw2kdNj7C0TfujW2/84/MmQrXRsdys1i1psMent77dChQ4Q/zqn6R4OD1QLG/J+LU1un101gALBUVDYCF6ZqH1XLq/qnxGvf54uswABImAmEC4niM2YOh0TrBUPzVbxvC9NqUA28e+zIDw3ZGPnKrUGtgleLVlY0FJ2WL98U+Kj6R4fwpzWhzfYCgFZQDQ4sLl35XpG5P83U+qUAqND/6N8y4ML0hbo7PivMmddff90uueQS99UQN/WtS24Gf3zqdcPy6EbxC7d83EKgSrXPfvazmbyxaRD63//939uXvvQlW7HC3bciZmlt+J/8t7+z+tRL9sG//tpwcZrt9WCAg6C1BVJ/zwCwmN5rrgrmmgXopFqtZjt37ky2fp05c8YqZDw+n41P4f/RtIPhYnQH63YSs9psQigd1KyLOzbfaFi6kKoFslwFr3Xvqnhj3btfCn/U+qXzKrNiWqaKvkf3f8EAoIy6u3hoAzTTPZuuj3ft2lWVuT/N1F0zbE7QDoZW1KyxMn7AHNILiW6SvbfIsDp+6ULbBJbFKvh09g9zf/xS+PPYkX9KPqI9CoA024t2CQBlxTwgoEHhj5akVGjmz3wqqMh2Q8wyUQmEVrmtBtLNtl5YvNPNjp56c1HQntCqBbJYBa+qHwY/+9Vc+UMA1L40AAr5tfDVt04bAFxIz6puA6osrfzRqWgApI4azf9xFQAJIRBapbtat3vZNVQshBeX0DZbFS20aoEsVsGnq99VCQRfCH+WrwwBEAC0gkpHVBXhTyKKz6b41M0hQiC0Y9QKXGV3MVm04HQCN0GtCe3PKYtV8ENDQ0kAxPYvPzTUXdv9Pvf1GuHPMvHaB6BKenitQ8UQ/pw1YY0AKDKnCIHQDtdDorWFSfOBQsDN0IWFVjGl9q/lBkCDg4PJtgT4oLDnwb95zj53fy0JgRj4vDy85gGomu6uSw2oAsKfc2hGyQ4reAX8xTAYGu1Sslk3p0Oi9cKjigxtVPIuvSnazUahczRmJ4Vzs6jqM1WhLWcVfDoEGsVS1c8T35+0+uRLyQpwZIMACEAVUQmEstPDy/HxcYKfBt0IqBphwgJACISl0Bf4ifi47FnZu3evbdy4MYihugRB50oDoL51aywECn6WuwpeARAtYMVR8HPkBy8kwQ+tXtkjAAJQVbzuoYx07asH7pqBuZwHoCUTWWMAdGSBIATCUkTWKHV72JwKZW28EAQ1hBYAib7OljuHShVADIHuLIKfziAAAlBVDIVG2aja5/Dhw0n1D+HPObQ4adSct3/NRwiEpdIKpKH49JtDaYuOKixCoJukv/r6Trv7ob+1k6+8aVUTYgCkTWATE8ur+BwZGWENfIeovasR+vyc4KcDyh4AKUgEgMWwHh5loLBH7V663qXl6zwKfVQU4W79eysuMWDpBuLjOmVRqWII84GaaRit5pJURYg3iyqDVdvhcqj659SpU4Z86CY9DX6OTb1Eu2UH9a1bHYe6Xyj1k/Cx8e/aM8dfMABYyE1965KHW0CIqPq5qMgCa/+aj0ogLEfdGiVwblOWkOYDpe794i3JzZM2EpVdiAGQNoEtNwASVQEhW6rwUSVdOtiZao3Ou2PzjTYydJsBQJXRBovQqItCVT/M+rmoINu/5iMEwnKNxmd7fHrNKc1tUVtYSHNX7tr2SevuioOgb/+wtDeyekr2wO7bg6oWSNsMl0uh5PDwsGF5VN2jKp+TL8fBz9TPCH0KptctHQCoOtrBEII0+FHlD+1eFxXU9q+LIQTCcqXfEG7bwtIbdw2KDsnOT/fblv7rSjkweuen+pOKp5Do62i5m8BSobUoekHo45OC3HvvvMW2bb7RAABUAsEvgp8lqVvjfjeykiAEQhbq5rwtTC08+/bts4cfdrvQbEFpu9RDTz6XtLiUgcIfhUChyWITmKgibXBw0HBh6UwftXelw5wJffzRa9QD99we1FB3AMgblUDwJJ3xowHPWVzLVkjQw58vhBAIWRk1521h6nHVDXhoVRjJTdbubcmMoJDnBIV8s6hNYFk9LWEW0MIU8CjoUeCj4IeZPv6F2NIJAJ3A6yKKpJk+CnyOHTuWfGTGz5JoS49mQERWQoRAyIr7tjAJcVB0SrM21G4RYnuYhsXuv/OWIC+KFACNjo5aVlgJf26Vj1q7FP6wvSsszP8BgMX1XE07GDpHIY+6HlTto4+0eS2bqn9GrcRYEY+sqVzOdanNypUrk/lAIQ2Kni+UqiCFPiNfudUG+q+3EOnpSRaDoFP9/f3BzabKggKeH8VBz09ffnO20ucNQ5hU0TcydGtSBVRl933riNWnytGiCyBbuvY5+tDdBuQlDX1U6aPAR59T7ZMJVf/smv1YalQCIWuj5rwtTC+SGvCrm3EFQiFKq4LGxr+XVFF4pLk/yZazQEui1TOtOUBZqkIVkAKfky+/QVtXCSn4UQDEwFOz0+99YACwEOYBIWuEPh1R+uqfZoRAyFoQbWHpxjCtjg+VbsQe3f95O3L8J/bYkX9y006jG8W7tv3boCsF0k1gWb/BbtmyxcpGIU8S+NDWVVoKchXohjjQHQA6rbtrhQHLoetQhT1TU1NnQx/kpm4l2/zVCkIg5KFuzreFiV5UQ9wYNt+2zR9LTtFhkEKptEIpdAoI89ieEHILYipd087Grmqg+gcA2sPrJdrRHPgo7KHKp2NKu/mrFYRAyMuoOW8LE20MU0tYGTY2FRUG6SZRg5/LEP6IgsG8nriEGAKlQ5zrky8l4Q+VPtVA9Q8ALI2HdjCFCHqgNTg4mFQhayYhiqW/EwU+usYk8Clc3SpY/dOMEAh50SuaJuq6n4KrzU8KgkJbHb+YNAxSlcaR4y8kw0uzrtbQDeK2m2+0gf7rSjUgVpvAFAzmJZQZVGnwc+T4i/HXz8+o9qkYqn8AYOk8zEJMq0vSLVF6CKW5hNu3b08CoTJUJns1P+xJP8+jwhxti6wR/tSt4tgOhrztjU8Q/Va1Ws2GhoasjNJASNuZlrqZSTeEWzZelwQ/fevWBDvweTHj4+M2PDxsedEF16lTp8wzfZ2o4ufID14g+KkgfY/vv/OPgt3m10l3P/SU26H8AIqleY1FPyBT+KPZhovRNYnCIAVDGzduTD4PdVlKUdJwZ3p6OvmcsMe9tPWL0iujEgj50zeb2sIGzLm9e/eefSMsG12MpBckaZWHNje9+ua79tovTp93w6+Ap7vrMutbv9p6ru5O/n/LFvo005u2/v6rSH/3T3x/Mgl/WN1eTfreVtuXTpm/zwGgE7xUAl3sn+tMTEyc/bm0QkgfdT2cfl5FquZJN3LpY3PQkx4Eo24Vb/1aCCEQOkHfeGoLc/2IoXl1fJnLZHVx0hwKVV26KS7vnmyvPd93P/S3SSCIalJl3/47b6H1CwAy0nN18a+nCi3alc6oaQ6GRNfEzefaa69NPqpyKP0YijS8SYOcmZmZs+1bzaEPc3pKITJavxZFCIROiKzxTfi0OZcGQVodT790+aWr4DvxRMfrBcXj93+58M1y6DyFwHdt+7eEwQCQMQ+VQFlec7RS+ZKGQc0nvY7W5x/5yEfO/rqF/n9b+T00mx/UpKFX88+nwU7zQSXoL1pbqmn9ugBCIHSKHiu4XxsvaTBAEFRunQyAmv+dHr+mNEj8E3EY8BdHfmjPHH/BUF6EPwCQH7XRe5DXltPF0B4FJ2rx2WeEPxf1IQM6ZzQ+nX1XWqIiAgJ0Tlrx1em/X89fT2oHGhm6zf7uG8N2x+YbDeWi0EfDSj0MLC0DBqcDWEh31wrzgKoXVEw9PpqErs4TvvhbQAiETkrXxgfxzUkQVE5FBUCiVaHeEQaVC+FPPn75HiEQgPN5ma/GtSsqQsUFW2dP3dAy2sHQaZE1VvQFsTae1rBySQOgTpdJp4r69y5FGgZ9ddsnkzax50/+nJlBgdA8im0332h3/OGN1rdujQEAOqNnVbd5QCUQSk5f4Gr7qhmW5BIDiqFhXe7nA6UUABEEha3oAEg0HPHtt9+2EKn95djUz+zxZ6dYJe+UAh8FPwqAWPWer899vUYoCuA8937xFtv5qWLXqus6Z9OmTQaUEEOfM0IlEIoyGp8t8Sn2nbJFVASFzUMAlP4+6vW6DQwMWGiS6pLNH0uOQqAnnp2kOsiBtOpHq95p9wKAYvWtK34wNFVAKCHCn4wRAqEo6XygE/FZaQFQEKQnKwqC+vuDyK5gjb+3HTt2uGnFOnz4cJAhUDNVnKhVTJ4/+YodOf4CgVCHKfC5Y/Pv2ZaN11P1AwBOeHg9Zh4QSoTwJyeEQChSZI0p7k9bIPR0RUFQrVazoaEhg28eh3vra2dkZCRpDSsDhRFpBYoqhBQG1SdfSsIhZEc3FgrfVPFT5XYvvQaX5XsHQPn0XF38YOjp6WkDAkf4kzNCIBRtwhqDokcsIMPDw0mwoJt5+OR1u5tuYsfHx23PnmBGYrVMIYVOOg9BQdDJV95MQiEFRKzVbo+CnoGN18ch21oqfqwx52LXrl124sQJAwBv9BpNJRCwLIQ/HUIIBA9GrTEfaMACMjo6mnwkCPJHN4sKgLz2xR84cKCUIdB8aZVQGgopCDr5cqNa6Kcvv8mA6Xmaq31u6vsom72aKDjdu3cvVUAA3PKyGYwQCAEi/OkwQiB4kc4H6rWAKAhS4HDo0CFuTpxIbxY9D0bUBZp+n1VrKUwrhTRcWlQZlARDr7yZhEOvvnW6Um1ka1ddmYRkfetXJ8NEGey8sLGxsbOhO6+zALzq7lphHjAYGgEh/CkIK+LhSa8FNCi6GSvkfWi+WfRON7OnTp3ipnYBCoZeffPdRjgUnzQsCrmdrDnw6bm6O/mcgc4Xt2/fvqRyLqXXWH3fFI0V8QDmuyN+wDEydKsV7aqrriIIgnfa1jIen5oR/hSCSiB4ElmjIuioBSadP/Pwww/b4OCgobN0saObRQ1dDoV+zwqt9DWDc6UVQwP915/z881hkMKh1946ndyI68ev/eLdQkOiZBZE12VxyLMmCXnWrr4y+agfKwBCe/T9oa1+9XrdACAEHtrB9NpJAATH6taYBVs3FIoQCN7ULcBB0ZKuIlclCnOCOsfbCvh2qMJh+/btwa+M7xQFLWnL1PyAKKVQ6LXZCg19PP3eB2fDIYVGcvq991sKjNJgJ5Ve4K+NP17R1RgA2hMHPN1dPoaBloW+l/U9zVwLACHxEPjzugmHlEqq6kfLgOoGFwiB4NGoNVrCgpycqxBIT681J4j2sHzpz1k3iyE/9Uq3HdEWlg1dhFN5E64QZnoBwEK8VAIBTtTjc9ho+XLpQwb4tNcCTosVTqg9bGJiwpAPtX953gDWqrSSCag6fU8PDw9zEwMgSKyHB84Oet46exj47BQhEDzTnXFkgUpv7nVjg+zoz3XTpk3nDIsNnUJDzQcCqqiM39MAqkez7Io2PT1tQAHq8dENzwYL/EF+VRACwTMlx0qRIwuYbmw2bNjA05kMHDx4MLlZDHH+z8WojZAgCFWjasmyfk8DqA4vc+G41kQH6Y1bF65XGVU/wSEEgneRNSqCgn5R0ZuygiDd5NPq0L50+1rZZ4UoCNJMFKDs0o1+oc700nBxAEh5qAISQiDkLLJG8KPQZ5M15rhyYxMgQiCEQElzKYam6CZfT7250W9dWv1TlVXRmonC1wfKTFU/obd/tbJdDkB1dF9+qXnAg0bkILK54EftXqNGu1fwCIEQinp8dlkJ6CmNbvS1FYonNotLh2tXcVOQvj5oDUMZpaEur30AyqTnah9bKWmtRUbq1gh+VO1D8FNChEAISc0aL0ilUKvVzraIcUM0J20TUQBUleqfhTAjCGXS3NK5HL29vQYA3qxdXXwIRBUQlkFfPHVrDHdOZ/yMWqMbAyVECITQjFqJgiDRzb5ujqreAqSLF4UeCsbYEtSgrw1VjHFhh5BVraUTQPX0rCo+BKIKCG2KbG6d+wZjuHOlEAIhRKNWsiAobRFTAFK1MKg5/FHoQeBxLlWM0T6DECn00dduFVs6AVRLd1fxM4FmZmYMuAC9EdesMV5D1T7N69x5k64YQiCEajQ+pUtL5odBZb7xJ/xpnb4OGCiOUDS3dPJkGkAVeKgE4mER5klDH7V4KfBR8LNr9ue46K64DxsQruHZj0NWMmkYJPo4MjJSmlkYuilUmKEKF4Kf1unPSl8Lqq4o09cDykXf1wqA+N4GUCVrCYFQvMgaVT1T8ZmY/TGwICqBELphK2FFULN0gHQ6NyjEmyv9nvXfof+GdDU0N4lLk/45UhUET9JtfsywAlA1HgIgIQSqlHSQs2b67LC59i5V+miuT2TABVAJhDIYnv1YuoqgZrrJSgerqiJk+/btNjg4aF7pRjCt+pmYmODGMENppRhVQSha2vqlcBIAqshDK5hwnVVqk7NHVT51Y2sXlokQCGUxPPux1EFQSjdc6U2XgiCdLVu2FB4G6AJEgc+xY8cIfjpAXwMKgjRTaWioEl/6cELf29r6RVUfgKqjEggZ0htqFJ9jNtfeFRkzfJCxSwwol5pVJAhaiEKg/v5+GxgYsI0bNyYf86RKHx2FPgojuAApjv7uH374YdfVYQhf0eGPXtOOHj1qRfuD3X9uACB3bftkcop2ySXc1gUmskbIM23nBj5A7qgEQtkMW+MFdMQqSCGMjqpwUgqFFBCkR+GQ6POVK1cmZyG6wUuP/jf1cWpq6mybF1t/fNHf0Y4dO0o3SBw+UPkDAAtjKDQuIK3s0UUzYQ/cIARCGY3OfqxkEDQfgU21pK2ChEHIAuEPAFxYz6puKxohUKEia4Q9zUHPpNHGBccIgVBWo7MfCYJQSYRBWA7CHwBoTffll1nRCIFy847NBTz6mIY8zT/HmySCQwiEMhu1xgvzwwZUVBoGaZaKwqC850QhbLqR0EY/wh8AaE3P1cW3g01PT1sB0hBk5ezptTBETR/Tz6cX+HkCHpQWIRDK7oA1XsgPWeMNCqgkDe7WUUWQtolt37590XlQqB59bYyNjSUfAQCtURVQhSuBDlpjIUuzNAxaOe/z9J99ZN6vbfdCZKFgpjkBixb4PFrgnwGVRgiEKtCU5Cg+T1s4TymAXOhCUS1iCoNUFbRnz55keDiqJ2350iB55oYBQPs8zAOSgkKgaIGfS9ukADj2IQOqQW9IW42nAEBCF4xqE9u0aVNy1ALETIFqULWPNslt2LAhqQojAAKApfGwGUwKat+lVQoIFJVAqJIoPpus0Ro2aAASCgFUHSSqDtLntIuVi4KfY8eOMesHADLkYR6QFPQQhycIQKAIgVA1uvvZYY2h0WwOA+ZJZwdJGght2bKF7WIBSoc8N/+dAgCys3Z18SGQgv0Cwn2eJgABIwRCVY0am8PQmnp89lkFZ0o1hweaG6RQSBVCbBjzK634IfgBgPz1OGgHK6illyogIGCEQKgybQ7T0OijxsBoLGzMGoGhaKbUCavoljldZOqonUgUBOmoSkgBEa1jxdDTX/29HD58OJnxRKsXAHROd9elVrSZmRkrQCH/UgDZIARC1UXWuLlXRRBzgpDSnbSqf2pNPxfZXBBUefMrTRQIKQxKQyHax/JDtQ8A+NC3bo0VzdFmMACBIAQCGm9kzAlCKrLFN8mp/HmXNYaLo0kaSKSVQgqBFAY1B0NUC7UvrfSZmpo6u8q9ytU+VDoB8KT78susaIRAANpFCATMGbVGe1jlZr/grIM2Ny9qMbXZjwRBF6CLUh0FFykFQzqqGtq4cePZoAgNCjj0Z5aGPgrVWN9+LkIgAF70rV9tHhACAWgXIRBwLt1xqQpkND5DhqrQnaXm/xxo8dfXZj8SBLUhDYbmtzCl7WP6qHBIFUNlrxxKw57p6emz85YIfAAgHN1dK8yDgsJxEnkgYIRAwPmi+AxbYyuU2sN6DWWmO2+1A0bWntrsR4KgZUoDkOaqIVEIlFYPpefaa6895+e9UsiTVvYo6EkDMP13FvTUFhlau+pKe/Wtdw1Ada11sBlMCnqAEBmAYBECAYurWSMI0k3+gKGMmrd/LUVt9qMGizPwJmPpPJwLXeCmgZA+picNh9LAqLmiaKHgaP7PLRTS6PfSfEThTvPPNQc/AIBy61nVbR4UVAkUGYBgEQIBFxZZoz1srzWqgrjRL4fIGtU/WTw+q83+7zBLqgBpUAQAQCd5qASiCgjAUnzIALRCs2I2xWfcEDpV/2ywbAKgVDpLKjIAAFB6HiqBqAICsBSEQEDrImvMCtplvAGGqG6NIG/U8hFZIwiiLAUAgJLrcVAJxGYwAEtBCAS0r2aNMGHMEAI9JttnnQloImt8bRw0AABQWh7awTSbDgDaRQgELI2ChVFrtBXRIuaXwhj9HbW6+j0rmiG1zwAAQOl42QzGIgIAS0EIBCxPZI0WsaWsGEd+6taoyFEYU0jDvDWCJwVQkQEAgNLw0AomhEAAloIQCMjGhDVu+JkXVKy6Ndq+vMzmiYyB4gAAlEr35ZeaBwWFQPSgAYEjBAKyVTPCoCJENhf+1M0XVSING18TAACUQt+6NeYBlUAAloIQCMhHzQiDOqFujT/jDeYv/JmvZo2QiqogAAAC1n35ZVY0AiAAS0UIBOSrZoRBeajbXOVPzcIRGVVBAAAErW/daisaIRCApSIEAjqjZo0wiEqQ5amb37avdtSMrwUAAILkoRJoZmbGChIZgKARAgGdVbdGJUi6Wj4yXIxm6ozF5yoLP/xpFlnja2GT8XUAAEAwPMwEmpz0sP8CQIgIgYBiRDYXBmm9/IShmYKfujVCH4U/o1bcqve86SqOlkEAAALgoQpIaAcDsFSEQEDxFAApCEqDgLpVVz0++2yuda5u1VGzxn/zQQMAAC6xGay0D+WAyiAEAvyIbC4ISAOhslcIpRU/Cn7Sdq8DVt0LjCg+e22uXRBAE558Ayha9+WXmgfvvFPYpRIhEBA4QiDAp8gagZAqhC6xuQqRMjSA679B/y1p2FX14GchkZ07OwqAIz2rrjQA1dRztY/vf2YCAViqDxuAENRtrjVqZXwGZs/G+PTP/pxHCnZ0lTJlc/8NhD2ti6wRBo3OniEDAACFWbu6+BCowCogACVACASER+/8E3Zuq5iCoF6bC4ZWzv5cJ0XWCHymZz/WjUHHWYmMMAgAgML1rVttRSu4CogECggcIRBQDpOzZ/4MobRKqHf26PNrba5yqHfer9eP37Hz3+Cjpo8zs/88mneQv8jODYO22Pl/hwAAICcetoPNzMxYgQiBgMARAgHlRsN4OUXWCIN6rVH9NWKEQShOPT7HrPF1CACl5mEmEEPyASwHg6EBIFyRNQaIpwO2y75NDn7oSfCYzW31qxsAlJyqgDxUAhUcAlEJBASOEAgAyqFujW1yCoR0cx4ZkL26NUIfhT+jNnczwE0BgNLrW7fGPGAmEIDlIAQCgHKJrHFznlYHacU8F2xYjsguXvXD1xiA0uu+/FLzgO1gAJaDmUAAUF51m7thH47P9vgMGnBxusNQgKgWw7oBAFzMA5IC28FIn4ASoBIIAKqhZo12MVVz7LLGzT0Xc2imr4eDNtfutdccBkAeBqJ2d/moBgDQWWtXFx8CqQqowEogrhuAEqASCACqRRdwtdkjA9aoEmLdfDVR8bMEHgbDAui8nlXFh0AFzwMCUAKEQABQbXWbu/nvnz1qGxuIz0pDGekOQivdswx+IgOAklu7qtuKNjMzYwWKDEDwCIEAAKnJ2VOb/bECoQFrVAnpI6FQmFTtU7e54CcyAEDbPMwE8tASCyBshEAAgMWkodCB2R+nlUID8dk4+zn8Ueijv7fDsx/rBgBYFrWBemgFJQQCsFyEQACAVs2vFFJlUBoMpTOFCIY6r7nSh9AHAHLQ46AVTAqeCRQZgOARAgEAlioNH3TSaiGCoXylVT5TNhf4ROZDZAwXB1BSax0MhZYCN4MBKAlCIABAlhYKhkRBUO/sx41GONSKyBpBz7T5C3wAoFI8zAOSgtvBCp1KDSAbhEAAgE5IW8km5v28gqC0eqg3PtfOfuy1agyiVmgWWePPZsbm/pyi2X+GeXQD1Nvba0W6oosV8UDVrF1dfAikKqCCK4F4XwJKgBAIAFCkdLhBfYF/phCot+mjThoSWdPPefWOzYU8OjNNn6eHC+oAeRgOC6Czehy0gzEUGkAWCIEAAF6l828uZqXNBUUL/Viubfq815b2e2kObKYX+PnI5tq1IgMAlMZaB4Ohp6enrWCRAQgeIRAAIHTNFTcoTmQMhgZQUh5mAlEJBCALHzIAAAAAwILUAuqhDdRBCBQZgOARAgEAAADAIvrWrTEPJidb6ZAGgAsjBAIAAMEoeDMOgArqvvxS88DB6x8vwEAJEAIBAIAsdGRi6czMjBXNw4BYAJ3jYR6QOGgHIwQCSoAQCAAAAAAWsXZ18SGQqoCoBAKQBUIgAAAAAFhE37rVVjQn84AIgYASIAQCAAAAgEV42AzmoRUWQDkQAgEAgCzwhBhAKXmYCcR6eABZIQQCAABZ6EgIxHYwAJ2kKiAPlUAMhQaQFUIgAAAQDA8hUM8qH5uCAOSvb90a88DBTCBCIKAkCIEAAAAAYAHdl19qHlAFCSArhEAAAAAAsAAvlUDMBAKQFUIgAACQhcgAoGQ8zANSFZCDSiDWkwElQQgEAADQhu6uFQagGvrWrbaiOZgHJPSjASVBCAQAAILhoCXCrnAyIwRA/jxUAs3MuCjCIQQCSoIQCAAAAAAW4GEmEJVAALJECAQAALLADQKAUlm76krzwMlmsMgAlAIhEAAAyAIhEIBS6XESAjmpBAJQEoRAAAAAbejuKn5GCID8UQl0jsgAlAIhEAAACIaHwdAeBsUCyF/Pqm7zgJlAALJECAQAALIQGQCUiIdKIA/B9yxCIKAkCIEAAAAAYB4PlUBOQiACIKBECIEAAAAAYB4Pg6GdhECRASgNQiAAABAML60RXgbGAsiPh+/z6elpc4BKIKBECIEAAEAWIgOAkuhbv9o8cBJ8zxiA0iAEAgAAAIAm3V0rzAMnIdDbBqA0CIEAAAAAoEnfOiqBmrjoSQOQDUIgAACQlchy9s47PkZTeBgYCyA/a1f7+B5nOxiArBECAQCAYHgJgQCUm4egd3Jy0pzghRcoEUIgAAAAAGjS3XWpFc1R6B0ZgNIgBAIAAFmpzNNiDzeIAPLTt26NFW1qasqcoBIIKBFCIAAAkJWO3Ch4mJHRffllBqCc9P3t4XvcyTwgIQQCSoQQCAAAAABm9azqNg8chUCRASgNQiAAAJAVnhYDCN5aJ9v/nMwE4nUdKBlCIAAAkJUZq4grumgHA8qq52ofIZCT7WCRASgVQiAAABAUZgIByNPa1cWHQKoCohIIQB4IgQAAQFa4WQAQvL51q61oTqqAJDIApUIIBAAAskIIBCB4Hir9ZmbcdNdWps0XqApCIAAAEJTp6Wkr2lon24MAZK9v3RorGpvBAOSFEAgAAGSFSiAAQfOyGcxRCMTrOlAyhEAAACAr3CwACFqPkxCImUAA8kIIBAAAguJhY84VXSsMQPl4qQRyshlMCPeBkiEEAgAAWenIzYKHm6Puyy81AOXT42TeF5VAAPJCCAQAALLCE2MAQetbz1DoJu8Yr+tA6RACAQCAoHioBPIyNwRAtrq7iq/yYzMYgDwRAgEAgKxE1gGOZmUAKBnWw5+DF1ughAiBAAAAAFRe9+WXJado09PT5kRkAEqHEAgAAKBN3V3F3ygCyJaHKiBxNBTaTRoFIDuEQAAAICuRdYCHVgkP1QIAsuVl6x/r4QHkiRAIAAAAQOVRCXSeyACUDiEQAADIUmQ58/KUfC0bwoBS8VDhp9c3KoEA5IkQCAAABIXtYADy0LdutRXNURWQuPrNAMgGIRAAAACAyutxUN03MzNjjpC4AyVECAQAALIUWc68VAJ5uGEEkB0PLZ6OKoGoAgJKihAIAAAEhXYwAFnrW198K5gwDwhA3giBAABAlqatIrq7fKyTBrB83V0rzAM2gwHIGyEQAAAIThRFVjQPm4QAZMPDUGjx8No2qzKBPlA1hEAAACBLtBAACM7a1T5mfDkKgSIDUEqEQAAAIEuVCYEYDA2UB+vhzxMZgFIiBAIAAFnqSAjk6Gk5gBLw0N7pbOh9ZABKiRAIAABkqTKVQMwEAsqjb90aK9rU1JQ5EhmAUiIEAgAAwZmeLn5mKdvBgHJY66S101GFo6u+NADZIgQCAABZigwAAuJlvpejmUAM+AdKjBAIAAAEx8PsDAZDA+XgpRLI0UygyACUFiEQAADIUmQd4GyAKoCA9azqNg8cVQIV328LIDeEQAAAAEtAJRBQDn3rix8K7WzjITOBgBIjBAIAAFmKrANYEQ8gK2sdVAI5e02j1BIoMUIgAACAJejuYkU8UAY9Vxdf1UclEIBOIQQCAABZiyxnHmYCdV9OCASETt/HHr6Xp6fdjOF5x6gEAkqNEAgAAATHy2BogiAgbH3rip8HJI6GQlMFBJQcIRAAAMha7gmNl9YJWsKAsHlZD++oHWzGAJQaIRAAAMgarQQAguBlPbyjEIhKIKDkCIEAAEDWch9u4aUdjDXxQNg8rIfX65mX1zQjBAJKjxAIAAAEx81MoK5LDUC4PKyHdzQPSKjkBEqOEAgAAGQtsg5gQxiA5WI9/HmoBAJKjhAIAABkrSPpjKP2CQABYj38eVgPD1QAIRAAAMhaZW4imAkEhIv18OehCgioAEIgAACQtY6EQB5aKGgHA8LFevjzTBmA0iMEAgAAWatMOxiDoYFwsR7+PJEBKD1CIAAAkLXIOmBmZsYAYKlYD38e2sGACiAEAgAAQfJw48RMICBcrIc/D0OhgQogBAIAAFmLrAN8tIOtMABh8jAY2lErmF5QqQQCKoAQCAAA5CH3hMZDCHTF5cwEAkLkZSi0o/XwBEBARRACAQCAPFQiBOruYjsYECIvrZyO2sEYsgZUBCEQAADIQ2Q5cxECsSIeCFLfutXmgaN2sLoBqARCIAAAkIdKVAKJl7YSAK1bu9rH962jEIh2MKAiCIEAAEAecm8tcHTzBCAwHiqB9BrmaD18ZAAqgRAIAADkIbKKYE08EB4PrZzONoNFBqASCIEAAEAecn+87eUGau2qbgMQFg/r4aempswJWsGACiEEAgAAeehIj4OjVgoAgehbz1DoedykUQDyRwgEAADyEFkHeAiBaAcDwuJlmLuj9fCRAagMQiAAAJCHylQCsSYeCIuHVjBxVMlIOxhQIYRAAAAgDx25u/HQTtHddakBCEffeh8hkKNKIEIgoEIIgQAAQB4i64CZmdw30V/UFV0rDEA4PAS3zgIghqsBFUIIBAAA8hJZzjy0U3iZLwKgNR7awaanp80JN78RAJ1BCAQAAPKSe0LjIQS64nLawYBQaIaXhzlejjaD0QoGVAwhEAAAyEtkOfMxE4jB0EAovAyFdhQC1Q1ApRACAQCAvOQ+sMfLdjA2hAFh6Fu32jxgKDSAohACAQCAvESWMy8rlqkGAsKwdrWPGV5OQqDIGAoNVA4hEAAAyEvuNxdeWiquIAQCguChEkjhtZMAe8oAVA4hEAAAyEslBkPL2lXdBsA/D62btIIBKBIhEAAAyEvuNxhu2sGYCQS4p+9TD4OhGQoNoEiEQAAAIC8dSWg83FD1rPIxZwTA4rxsBpuactOFRSUQUEGEQAAAIC+RdYCHaiDawQD/ui+/1DxgKDSAIhECAQCAPEWWM0etFQAcu6lvnXnAUGgARSIEAgAAecr9bmdmZsaK1rfu3xgA3zxsBhMnlUB1A1BJhEAAACBPkeXMQyXQFU7aTAAsjs1g52AeEFBRhEAAACBP05YzHzOBGAwNeOZlM9j0dO4via0iBAIqihAIAADkKbKcsSYewMV42QzmpBJIvwmGQgMVRQgEAADylPuNhpfB0N1dhECAV142+DkJgY4ZgMoiBAIAAHnK/Y7HSwjkZegsgPP1rfdRCeTk9apuACqLEAgAAOQp90og2sEAXAybwc7BPCCgwgiBAABAniLLOQhSCOQhCOphODTgloeZQE4CoMg6MKsNgF+EQAAAIG+VqAbyMnMEwLm0vc9DpZ6TzWBTBqDSCIEAAEDecn/87eEJ+xVdKwyAP33raQVrUjcAlUYIBAAA8jZjOZuZyf1fcVFebjQBnIv18OeoG4BKIwQCAAB5q8SGMFbEAz6xGews9c0yFBqoOEIgAACQt9wH9rgIgS6/jA1hgEMeNoNpbpmDSiACIACEQAAAIHe533i4WRNPNRDgioZCr3Wwuc9JK9hhA1B5hEAAACBvkeXMyQ2Wi4oDAHO8zOqamnKxlItKIACEQAAAIHfvWM4tYV4qgXocVBwAmHNT3zrzwEFQrRfJugGoPEIgAADQCZHlSCGQhyBo7WpCIMATL9V5zAMC4AUhEAAA6ITceyE8DIfuuZoQCPCE9fBnMQ8IQIIQCAAAdEIl1sR7GEALoEHzgDxs7KvX6+ZA3QDACIEAAEBn5N6rNT09bUXrWdVtAHy46Xd9zANyMBRar7+0gwFIEAIBAIBOqFvOPFQCqerAQ+UBgDgEuoGh0LOOGQDMIgQCAACdkHslkJsNYcwFAlxgKPRZEwYAswiBAABAJyihiSxHDm60Ejes93HjCVSZ5gF5mNGlcNrBa1PdAGAWIRAAAOiUXO+EPLSDSQ/DoYHC3cBWsFRkOQfwAMJCCAQAADol18nNeuLuoSVsLcOhgcJt6b/ePHAwFLpuANCEEAgAAHRKJdbE9637NwagWF7mATlYD3/YAKAJIRAAAOiU3EMgB0/dWRMPFMzLPCBxEALVDQCaEAIBAIBOiSxnXtbEe7kBBaropt/1sxq+4BbVunVgMyOAsBACAQCATsl9Q5iX4dBeWlGAKhrov848cDAUetwAYB5CIAAA0EnHLEde1sSzIQwozk19PiqBjh3L9eWuFXUDgHkIgQAAQCdVYk38DeupBAKK4CUAkoLnAUXGangACyAEAgAAnRRZjjR/gw1hQHXdsflG80CvQwW/FrEVDMCCCIEAAEAnVWJNPBvCgGJ8ou+j5oGDrWATBgALIAQCAACdFFnO22o8rIlnQxjQeZ5Wwxc8Dygy5gEBWAQhEAAA6LS65cjLXKCbnFQkAFXhZTW8FFwJVDcAWAQhEAAA6LRpy5GXDWF969cYgM654w99zAPSaxDzgAB4RQgEAAA6rW45chMCrWNDGNApagPrW+cjeC24FUzttswDArAoQiAAANBpuaY0fjaEUQkEdMqWjdeZFxMThWYwhSZQAPwjBAIAAJ0WWc7DoT1UA2k4NEEQ0BleWsGk4HlAVAEBuCBCIAAAUIS65Wh6OtexQy1jODSQP0+tYKyGB+AdIRAAAChCri0LXuYC3bCeuUBA3nZ+ut+8GB8ftwJpIHSuVZYAwkcIBAAAipBrSuPgaXziE31+VlYDZeVpHhCtYAC8IwQCAABFyDUE0mBoDYgumtpUdADk46Y4aPXyPeZgNTwhEICLIgQCAABFUEJTtxx5aQnzVKUAlM0dm/0MhC54NTytYABaQggEAACKMmU5mprK9X++ZQP9hEBAHrSBb5ujEKjg1fA1A4AWEAIBAICi1C1HXuYCaWuRblYBZGvAUZWd2sAKfM1RBRCtYABaQggEAACKUrcceQmBFAD1rWNLGJC1r277pHnBQGgAoSAEAgAARdHT69wG92gwdMFDWs+6y9HNKlAGngZCS8Gr4Qv9lwMICyEQAAAoUq6TVAse1HqWblhpCQOy42kgdMGtYJHlXFUJoFwIgQAAQJFybWPw0hImOz/VbwCWTxVAngZCF/w6c9gAoA2EQAAAoEi57nEnBALKx1t7ZcGtYAcMANpACAQAAIqkuUB1y4naNLzMBVI72E19HzUAS6cqoE84+j4quBWsbo12MABoGSEQAAAoWq6Dew4f9tMtwYBoYHnUBsZA6Ll/vQFAmwiBAABA0eqWo4kJP9uTGRANLI+nWUBSq9WsIKqiZDU8gLYRAgEAgKLVrXFDk4vJyclkXbwXzAYCluYOZ1VAagMrsN1UAZCfFzYAwSAEAgAAHuTWs6UASEGQFwqBqAYC2qPw56sMhD7nX28AsASEQAAAwINc2xoKvlk7hwKgbTf7amkBvPM2C0jhcoGtYJHl3EYLoLwIgQAAgAd1y7G1QXOBPLWEDfRfZwBao/DH2yyggmeNjRkALBEhEAAA8EAJTW49W95awjQgmnXxQGu0Vc9TFZCMjRWWw+i1sm4AsESEQAAAwItcd7kXeNO2INbFAxfnsQrIwUDoyABgiQiBAACAFzXLkW7cPLWEUQ0EXJzHsLTgGWO0ggFYFkIgAADgRe5tDgcPHjRP7nBW4QB4ou8Pb1VAqgAqcCB03agCArBMhEAAAMCTXFvCDhw4YJ5s2/wx1sUDC9D3hbeV8FJwkMxaeADLRggEAAA8qVmO1A6mtjBPdn6q3wCcS98X3oZBS4FbwSLL+fURQDUQAgEAAE9ybwnzNiBaN7tUAwFzFP54nAWkNrACB0IzCwhAJgiBAACAN7n2W3gbEK0AiGogYM4j+z9vHrEWHkAZEAIBAABv6ta46cmNtwHRVAMBDaoA8tgGVnAVEGvhAWTmtwwAAMCXM/HRSqDcymMmJydt9+7dtmLFCvPgst/+sH3wr7+250/+3ICquqlvnY0O3WYe7dixo8gKwh2WczAOoDqoBAIAAB7VLUe6mTt8ONdFZG2jGghVpuqfkaFbzaOCq4BqRhUQgAxRCQQAADyK4rM7PrmV6igIGh4eNi9UDXTZhz9sx38ybUDVKAD6+HU95hFVQADKhEogAADgkW56Ji1HGhDtbl38p32uxQbypDlAA/3Xm0dUAQEoGyqBAACAV1fF5zOWo5mZGfvSl75knvSs6rb//s//04AqGOi/zv70y58yrwquAtpnhEAAMkYlEAAA8KpmOZuYmHC1Ll5UEXFT30cNKLtkDtBXfA6CloKrgOrGWngAOaASCAAAeKUtYQPx6bUcdXV12cDAgHmim+Mjx18woKz0Nf7I/s/b6o/8jnlVcBXQLqMKCEAOqAQCAACe5b7C68CBA+6qgbQq+47NNxpQRtqC98A9t7uef0UVEICyohIIAAB49np89lqOzpw547IaSEHQU//4Y/vgX39tQJn8l//wmeTr2yuFP7t27aIKCEApUQkEAAA8i6wDT8Q9VgOpWuKu2z9pQJmMDt3mdhNYamxsjCogAKVFJRAAAPBugzVmA+VG1UA9PT128803mycfv+4ae/7kK/baW6cNCJ1Wwe/8dL95llYBFYgqIAC5ohIIAAB4V7MOUDWQR/d+8RYDQqcASMe7ffv2WYFqRhUQgJxRCQQAALxTn9aA5bwlTO1gGzZssP5+X5UKq65sbE96/uTPDQiRWsC8VwCJhkF/85vftALtsMbrHQDkhkogAAAQgmPWAaOjo+bRzk/1u96kBCxGAdC2ADbdqQ1Ms4AKVDPawAB0AJVAAAAgBJPx+ZrlzGs10GW//WG76YaP2t8+92MDQqDB5rX/9EXb/PvXWgjUBlav161AVAEB6IhLDAAAIAxHLecB0dLb22unTp0yj554dtIefPI5AzxT1doj+z8fTPWawp+tW7dagQ7GZ68BQAdQCQQAAEJxVXw+YznzWg0kbAuDd33rVtuf/8n2YAIgfb9/9rOfTT4WJIrPPUYVEIAOYSYQAAAIRc06RLOBCrwpvKCRoduSVhvAG82uenT/F4KaX6U5QJoHVORvwZgFBKCDqAQCAAChOGMd2BImCoC6urpsYGDAvFEA9PEN19iR4y8Y4MW9X7wlWQGv+VWhmJiYKHolfBSfXQYAHcRMIAAAEJIBa8wGyt3KlSuT2UD66NFjR36YHKBIqvp54J7brW/dGguJqn80B6jgKiAFQDUDgA6iEggAAIREPVq747PCcnbmzBm31UByU986O/nKGxa9/rYBRbhj8432wO5tQbV/pRxsA6tZoxUMADqKSiAAABCaA/HZYx2gKqATJ04kG8M8Ov2r9+2Pv/GEvfrWuwZ0iloS773zFtsWh0Ah0hwgzf0q2AZjFhCAAlAJBAAAQqPZQMPWAaoGmpmZscHBQfNI81e29F9nx6ZestPvvW9A3lSB9uf/cXvyMURq/9qxY4cVTBVAEwYABaASCAAAhEhzgQasQ44ePeq2LUzUFnb3Q08llUFAHkKv/hEnc4Aia1QBAUAhqAQCAAAhuio+n7EOmZ6etuHhYfNq1ZW/w8Yw5Ear3zX75+PXXWMh27Vrl/3gBz+wgmkY9IsGAAUhBAIAACHSTVRHBkSLKgeuuuoqu/nmm80rDeftWdWdtIYBWVDL1+jQrfaFWz4e1Or3hWgO0COPPGIFq8XnmwYABaIdDAAAhKpjA6LF+8r41BPPTtqDTz5nwFKp9euubZ9MKoDK4ODBg7Z3714rWBSfrcYwaAAFoxIIAACEqmMDopN/2Zkz9v7779tnPtOxLrQlSVt2nj/5cwPaofBn+N//gf2X//CZYAc/zzc5OZm0gen7t2D74lM3ACgYlUAAACBkHR0QnfwLnQ+JTj1z/Cc2Nv49Ay5G4Y+qfnT0eVk4GQQtNWvMAgKAwhECAQCAkGl3+9PWQb29vXbixAn3bWFCEIQLKWv4I44CoMhoAwPgCO1gAAAgZBoQrWEfHRkQLe+8804QbWFyw/o1NtB/nR3/l/9lp99jfTwamtu+/vD3rw1+6PN8+h797Gc/ay++6GIJF21gAFyhEggAAIRuND4j1mGhtIXJq2+9a7sfeir5iOoqc+VPsx07dtjExIQ5UDPawAA4QwgEAABCp76sU7MfOyaktjBRADQ2/l0GRleQhjyrImzbzTeWOvwRDYGu1WrmQGS0gQFwiHYwAAAQOq396YnPzdZBIbWFiW7+79j8seRzgqBqUPgzOnRrsu794xuuKV3b13xjY2N24MABc4I2MAAuUQkEAADKoD8+J6wAIbWFpY4c/4k9duSfaA8roaq0fM2nAGh0dNScOGiNWWUA4A4hEAAAKIuOr4uX0NrCUrSHlYfCnoGN19u2zb+XVP9UjbMAKIrPpvi8YwDgECEQAAAoiwFrBEEdNzg4aE8/3dFN9Zl57MgPk4PwVGnWz2IczQBKbTDmAAFwjBAIAACUSSHVQKJZJHv27LEQURUUDoKfOQ4DIM0BcjOUCAAWQggEAADKZMAKqgYStYX19/dbqJgV5FMa/GzZeJ2tXXWlVZ2GsmsNfL1eN0dqxjp4AAEgBAIAAGVTWDVQqPOBmp3+1fv2xPcnaRErkCp8+tatoeJnAVEUJQHQ5OSkORIZc4AABIIQCAAAlM2AFVgNpE1h2hgWOlUD/UUcBD1z/AVD/tLhzls2bkgqfwh+zqcAaOvWrclHRxT8KACKDAACQAgEAADKqLBqINm7d689/PDDVgaEQflJ27z61q2u5Favdqj1SxVAagVzRi1gNQOAQBACAQCAMhqwAquBJORB0QtRGPTEs5N2bOolZgYtkVq8bur76Gzws4ZqnxYdPHgwCVYdGovPqAFAQAiBAABAWRVaDSShD4pejAZIP3P8RXv+5CuGxaWhT+PQ4rUU+/btSwJVhybis8MAIDCEQAAAoKwGrOBqIA2K1nwgfSwjVQQdOf5CcqpeHZQOc260dhH6LJfTAdCpyBgEDSBQhEAAAKDMCq8GKnsQlDr5yhv2zP94wZ4/+fPk87LTqnYFPX3rG6GPAiBkw/H8H4nis9UYBA0gUIRAAACgzAas4GogUUuYgqCQV8e3Q1VBPzr5ShII6YReJdQc+PRc3U2VT44ct3+lVAHksjwJAFpBCAQAAMqu8GogKcvq+KVQCHTy5Tdmq4TeTCqFTv/qffNGYU/f+jVJ0HNDHPg0Pr+SwKcD1P61a9eupArIsX3xcZ1QAcDFEAIBAICy643PKXNgeHjYDh06ZLAkBFIYpFDo1Tfftdd+cTr5udfiwCiPyiEFOd1dl1lPHPQo7OlZ1R1/7LYr4p9T2KOfQzG0/Wt0dNRr+1eKTWAASoEQCAAAVMFofEbMAYKg1iSB0C/ePVsx9FobwVDPbKCTfiTg8Umhj6p/JiYmzDkCIAClQQgEAACqQMN4Ts1+LJyqHkZGXGRSQCEU/CgAcl79I+PxGTYAKInfMgAAgPI7Ex+VlHzGHNDck0suuSSZEwRUSbr6/Zvf/KadOXPGnKvHZ4cBQIkQAgEAgKr4gTUGRPeaAwqCpqenbXBw0IAq0OyfnTt32osvvmgB0Aawz1ojQAaA0iAEAgAAVTJtjlo7JicnCYJQego81fr1yCOPhFD9IwqAtsbHfa8aALSLmUAAAKBqtOJ5jznS39+frI9fudLFyCIgE5r3s2/fPqvVahaQyBoBUGQAUEKEQAAAoGpcDYlO9fb2JkGQPgIhU/ij1q8DBw6EMPi5WWQEQABKjhAIAABU0XB83O1pJwhC6FT1MzY2lgyADkxkBEAAKuBDBgAAUD01a2z+cUU3zps2bUrWZwMh0dyfrVu3JrN/CIAAAAAAAN70xuft+PzG4xkdHf0N4N3Ro0d/MzAw4PJ7qMVzwpy1hgIAAAAA8rHXHN+gDg8P/+btt9/+DeBNCcIfAiAAAAAAqKCj5vhGtbe39zenTp36DeBBScIfnZoRAAEAAABA5fSa47YwnZUrV/7mwIEDvwGKcujQobKEPzoHDAAAAABQWYMWwM2r2sOoCkKnqBVRs6kUQobw/dHiGTUAAAAAQOWpOsD9Tazaw55++unfAHk5ceLEb/bu3Vu28EdnrwEAAAAAYI35IKcskBta3aRTFYQslWjez/yjds8BAwAAAACgSa85nw/UfFQVVKvVfgMsVUlbvprPqdnvawAAAAAAzuN6bfxCh1lBaIeCn5INel7sHDU2gAEAAAAALiKI+UDNR5UcqugAFqN2r5LO+lnosAEMAAAAANCyExbWTW9yaBFDMwU/JW/3mn/UzskAaABYxCUGAACAhfRao52k1wIUh0F26NAhGxgYMFRLvV63Y8eOWRwGWhRFViFRfHbEZ9IAAAAAAGhTvwU0KHqho7kvqgZBuaUVP6oEC+nrM8PztDH/BwAAAACwTMMW1s0wYVBFVGzGz4UO7V8AAAAAgMwEtzHMLhAGMTMoTOlWr8HBQYKfxjlljWo9AAAAAAAyNWph3SBf8KQDpFkt71ta7VOBde7tHm3/ov0LAAAAAJCb4FbHt3KGh4dpFXPixIkTvzlw4EAS+lDts+DRjK5BAwAsCdvBAAAA2lOLz5CVkDaK7d2717Zv3558jvxpe9fhw4dtcnLSJiYm7J133jEsqm6N7V/8IQHAEhECAQAAtK9mJQ2CUlotPzw8bFu2bCEQypDCHq1v1xp3HUKflugPacwalXgAgGUgBAIAAGifZpEctYoMpVUgNDg4mARC/f3M4W2VAh4FPQp9FP7oEPq0bSI+u4zqHwDIBCEQAADA0lQqCEqpKkihkA5VQnMU7ijkmZqaSj4q/FGrF5Ysskb4UzcAQGYIgQAAAJZOQdAhq/CgWlUG6SgU2rhxYyUqhdIKn+npaQKffBy0xjY+qn8AIGOEQAAAAMtXs5LPCGrVypUrzwZDqhRKf6yPoVGwo5BHYU/6OS1duarHZ198Jg0AkAtCIAAAgGxoaO0ew4LSIEgf1UJ27bXXJj/W50W0lCnISVu49DENetKfo7KnoyJrDH6uGQAgV4RAAAAA2RmNz4ihbQqCFAo1n+ZwSKFRqxToSBr0SBrw6BDwuKG/HLV+HTBavwAAAAAAARqNz284HM4Fz6H49BoAAAAAAIHToOi3Laybcg6nE+dofAYMAFAI2sEAAADy0WuNG95eA1C3xtyfugEAAAAAUEK98TlhYVVqcDhZnqNG5Q8AAAAAoEI0+DaUm3YOJ4tz1Ah/AAAAAAAVtdeYE8Qp/zlqhD8AAAAAACTtYacsrJt6DqeVc9QIfwAAAAAAOMdKoz2MU46jyrZRY/g5AAAAAAAXNGxUBXHCPGn4o0ATAAAAAAC0oDc+NQsrAOBU9xw1Wr4AAAAAAFiWYaMqiOPzUPUDAAAAAEDGeo2qII6fc9So+gEAAAAAIFeDRlUQp5hzwqj6AQAAAACg40at0YoTUojACe/oa0zb6gYMAAAAAAAUptdoEeNkfwh+AAAAAABwqjc+T1tYQQPH1yH4AQAAAAAgIAPWmNsSUvjAKe4Q/AAAznGJAQAAIDTD8Rkybu5xvnp8js1+rBsAAAAAACiFAWus8g6hKoWTX7WPWgX3Glu9AAAAAAAovV5jgHSVzlGjzQsAsAS0gwEAAJRHrzUqQrbPfo5yiOJzOD6T8ZmIzzsGAMASEAIBAACU07AxNyhUkZ072ycyAAAyQAgEAABQbr3xGYzPHqM6yKvI5ip96kboAwDICSEQAABAdQxYo0JoixEIFUWtXAp7pmxugxftXQCAjiAEAgAAqKYBa1QIMT8oX5E1gh6FPpOzh9AHAFAIQiAAAAD02lwgNGBYquYqH1q7AADuEAIBAABgvoHZs8UIhRajwCeyc1u7Jg0AAMcIgQAAAHAxA/Hpt0YopI+9Vi2RNQKeaZtr6SLwAQAEhxAIAAAA7VppjTAoDYbSH6+0cL1jc+1czWFPZMzwAQCUBCEQAAAAspKGQb2zZ+Psz6U/LlJkcy1c000/nmz6eQAASo0QCAAAAJ2y0uZCIZv9mP6cXLvIr0+l1TrNZpp+Lpr366JF/n8AAKik/wu5Is1aG8yNKAAAAABJRU5ErkJggg=="/>
</defs>
</svg>
$logo_mini$
),
(
 'script_js', $js$
class Utilities {
    static sort(data, key, direction) {
        return structuredClone(data.sort((a, b) => {
            if (a[key] < b[key]) {
                return -1 * direction;
            } else if (a[key] > b[key]) {
                return direction;
            } else {
                return 0;
            }
        }))
    }
    static sum(data, key) {
        return data.reduce((partialSum, a) => partialSum + a[key], 0);
    }
    static filter(data, key) {
        if (key.type === "exists") {
            if (data.every(obj => key["field"] in obj)) {
                return structuredClone(data.filter(obj => obj[key["field"]]));
            }
        } else if (key.type === "equal") {
            if (data.every(obj => key["field"] in obj)) {
                return structuredClone(data.filter(obj => obj[key["field"]] === key["value"]));
            }
        }
        return data;
    }
    static find(data, key, value) {
        return structuredClone(data.filter(obj => obj[key] === value));
    }
    static limit(data, num) {
        if (num > 0) {
            return structuredClone(data.slice(0, num));
        }
        return data;
    }
    static getInputField() {
        return document.getElementById('inputField');
    }
    static cancelSearchResults(rowsForSearch) {
        rowsForSearch.forEach(row => {
            row.style.display = '';
        })
    }
    static searchQueryWithStatistics(rowsForSearch, keyword) {
        let foundQueries = Utilities.searchQueryText(keyword);
        rowsForSearch.forEach(row => {
            if (row.dataset["hexqueryid"]
                && foundQueries[row.dataset["hexqueryid"]]) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
                if (row.nextSibling && row.nextSibling.classList.contains('queryRow')) {
                    row.nextSibling.style.display = 'none';
                }
            }
        })
    }
    static preprocessQueryString(queryString, limit) {
        let etc = '';
        queryString = queryString.split(',').join(', ');
        queryString = queryString.split('+').join(' + ');
        queryString = queryString.split('/').join(' / ');
        if (limit) {
            if (queryString.length > limit) {
                queryString = queryString.substring(0, limit);
                etc = ' ...'
            }
        }
        return `${queryString}${etc}`
    }
    static searchQueryText(keyword) {
        let foundQueries = {};
        data.datasets.queries.forEach(query => {
            Object.keys(query).forEach(key => {
                query.query_texts.forEach(query_text => {
                    if (query_text && query_text.toLowerCase().includes(keyword) && !foundQueries[query["hexqueryid"]]) {
                        foundQueries[query["hexqueryid"]] = true;
                    }
                })
            })
            if (query.plans) {
                query.plans.forEach(plan => {
                    if (plan.plan_text.toLowerCase().includes(keyword) && !foundQueries[query["hexqueryid"]]) {
                        foundQueries[query["hexqueryid"]] = true;
                    }
                })
            }
        })
        return foundQueries;
    }
    static searchWithParam(rowsForSearch, keyword, searchParam) {
        let foundQueries = {};
        if (searchParam === 'all') {
            foundQueries = Utilities.searchQueryText(keyword)
        }
        rowsForSearch.forEach(row => {
            if (row.dataset[searchParam] && row.dataset[searchParam].toLowerCase().includes(keyword)) {
                row.style.display = '';
                if (row.dataset["hexqueryid"]) {
                    foundQueries[row.dataset["hexqueryid"]] = true;
                }
            } else {
                row.style.display = 'none';
                if (row.nextSibling && row.nextSibling.classList.contains('queryRow')) {
                    row.nextSibling.style.display = 'none';
                }
            }
        })
        rowsForSearch.forEach(row => {
            if (row.parentNode.id === 'sqllist_t' || searchParam === 'all') {
                if (foundQueries[row.dataset["hexqueryid"]]) {
                    row.style.display = '';
                }
            } else {
                if (foundQueries[row.dataset["hexqueryid"]] && row.dataset[searchParam].toLowerCase().includes(keyword)) {
                    row.style.display = '';
                }
            }
        })
    }
    static search(rowsForSearch, searchParam, keyword) {
        keyword = keyword.toLowerCase();
        if (!keyword) {
            Utilities.cancelSearchResults(rowsForSearch);
        } else if (searchParam === 'querytext') {
            Utilities.searchQueryWithStatistics(rowsForSearch, keyword);
        } else {
            Utilities.searchWithParam(rowsForSearch, keyword, searchParam);
        }
    }
    static getValue(el) {
        console.log(el.value)
    }
}
class BaseChart {
    static drawIntoTable(cls, newRow, column, data) {
        let key = column.ordering[0] === '-' ? column.ordering.substring(1) : column.ordering;
        let value = column.id;
        let direction = column.ordering[0] === '-' ? -1 : 1;
        let newCell = newRow.insertCell(-1);
        newCell.setAttribute('class', column.class);
        if (Utilities.sum(data, value) > 0) {
            let orderedData = Utilities.sort(data, key, direction);
            let svg = cls.drawSVG(orderedData, value, key);
            newCell.insertAdjacentHTML('beforeend', svg);
        }
    }
}
class PipeChart extends BaseChart {
    static drawSVG(orderedData, value, key) {
        let x = 0; // Start position of nested svg
        let nestedSvg = '';
        let totalWidth = 0;
        orderedData.forEach(elem => {
            let width = Math.floor(elem[value]);
            if (width > 0) {
                totalWidth += width;
            }
        });
        orderedData.forEach(elem => {
            let width = Math.floor(elem[value]);
            if (width > 0) {
                let textContent = `${elem.objname}: ${elem[key]}`;
                let lineColor;
                if (elem[value] > 50) {         // >50%
                    lineColor = "FA1900";
                } else if (elem[value] > 25) {  // >25% <=50%
                    lineColor = "FF9500";
                } else if (elem[value] > 10) {  // >10% <=25%
                    lineColor = "FFC83B";
                } else {                        // <=10%
                    lineColor = "00B896";
                }
                if (width !== 100) {
                    width = width - 0.3;
                }
                nestedSvg += `
                    <svg class="lineSvg" height="2em" width="${width}%" x="${x}%">
                        <title>${elem.objname}: ${elem[value]}%</title>
                        <line opacity="0.4" x1="0" y1="80%" x2="100%" y2="80%" stroke="#${lineColor}" stroke-width="4px"></line>
                        <text x="0.1em" y="45%" dominant-baseline="middle" fill="#${lineColor}" class="textSvg">
                            ${textContent}
                        </text>
                    </svg>
                `;
                x += width + 0.3;
            }
        });
        if (totalWidth < 100) {
            let remainingWidth = 100 - totalWidth;
            nestedSvg += `
                <svg class="lineSvg" height="2em" width="${remainingWidth}%" x="${x}%">
                    <title>Others (${remainingWidth}%)</title>
                    <line opacity="0.4" x1="0" y1="80%" x2="100%" y2="80%" stroke="#8898AE" stroke-width="4px"></line>
                </svg>
            `;
        }
        return `<svg height="2em" width="100%" class="pipe-chart-container">${nestedSvg}</svg>`;
    }
    static drawIntoTable(newRow, column, data) {
        BaseChart.drawIntoTable(PipeChart, newRow, column, data);
        setTimeout(() => {
            let containerSvg = newRow.querySelectorAll('.pipe-chart-container');
            containerSvg.forEach(containerSvg => {
                if (containerSvg) {
                    PipeChart.checkTextOverflow(containerSvg); 
                    let resizeObserver = new ResizeObserver((entries) => {
                        entries.forEach(entry => {
                            PipeChart.checkTextOverflow(entry.target);
                        });
                    });
                    resizeObserver.observe(containerSvg);
                    containerSvg._resizeObserver = resizeObserver;
                }
            });
        }, 100); 
        return true;
    }
    static checkTextOverflow(containerSvg) {
        let lineSvgs = containerSvg.querySelectorAll('.lineSvg');
        if (lineSvgs) {
            lineSvgs.forEach(svg => {
                let textElement = svg.querySelector('.textSvg');
                let lineElement = svg.querySelector('line');
                if (textElement && lineElement && textElement.getBBox && lineElement.getBBox) {
                    let textBBox = textElement.getBBox();
                    let lineBBox = lineElement.getBBox();
                    textElement.style.visibility = textBBox?.width > lineBBox?.width ? 'hidden' : 'visible';
                }
            });
        }
    }
}
class SessionChart extends BaseChart {
    colours = [
        "#FFD700", "#FFA500", "#AAAFEE", "#00FF00", "#00FFFF",
        "#FFFF00", "#FFA0ED", "#FF00FF", "#FF1493", "#F7DDD2",
        "#8A2BE2", "#ADFF2F", "#20B2AA", "#9932CC", "#FF6347",
        "#40E0D0", "#9370DB", "#FFFFFF"
    ]
    drawRect(dataObj, reportStartUT, proportion, num, strokeColour, fillColour, title, klass, target) {
        let startPoint = Math.ceil(proportion * (dataObj.start_ut - reportStartUT));
        return `
            <rect
                class="${klass}"
                data-target="${target}"
                x="${startPoint}px"
                y="${num * 20}px"
                height="10px"
                width="${Math.ceil(proportion * (dataObj.duration))}"
                stroke="${strokeColour}"
                fill="${fillColour}">
                <title>${title}</title>
            </rect>
        `;
    }
    drawPID(dataObj, reportStartUT, proportion, num) {
        let startPoint = Math.ceil(proportion * (dataObj.start_ut - reportStartUT));
        let charCount = dataObj.pid.toString().length ? dataObj.pid.toString().length : 4;
        let pid = `
            <text
                x="${startPoint - charCount * 8}px"
                y="${(num * 20) + 10}px"
                fill="black"
                font-style="italic"
                font-size="12px"
            >
            ${dataObj.pid}
            </text>
        `
        return pid
    }
    drawLegend(clr, com) {
        let div = document.createElement('div');
        let legendSVG = `
            <svg height="12px">
                <rect x="0px" y="0px" height="10px" width="10px" fill="${clr}"></rect>
                <text x="20px" y="10px" fill="black" font-style="italic" font-size="12px">- ${com}</text>
            </svg>
        `
        div.insertAdjacentHTML('beforeend', legendSVG);
        div.style.display = 'inline-block';
        div.style.height = '14px';
        return div;
    }
    static initTreshold(newBlock) {
        let div = document.createElement('div');
        div.setAttribute('id', 'tresholdDimmer');
        let inputFields = document.createElement('div');
        let inputFieldsHeader = document.createElement('p');
        let inputFieldsRanges = document.createElement('div');
        inputFieldsHeader.innerHTML = 'Duration threshold (sec.):';
        inputFieldsRanges.style.display = 'flex';
        inputFieldsRanges.style.width = `${document.documentElement.offsetWidth ? 0.85 * document.documentElement.offsetWidth : 1520}px`;
        inputFieldsRanges.style.justifyContent = 'space-around';
        inputFieldsRanges.style.flexDirection = 'row';
        inputFieldsRanges.style.fontStyle = 'italic';
        inputFieldsRanges.style.fontSize = '15px';
        let maxBackendDuration = 0;
        let maxXactDuration = 0;
        let maxStateDuration = 0;
        newBlock.data.forEach(elem => {
            let backend_duration = elem.backend_duration_ut;
            let xact_duration = elem.xact_duration_ut;
            let state_duration = elem.xact_duration_ut;
            if (backend_duration > maxBackendDuration) {
                maxBackendDuration = backend_duration;
            }
            if (xact_duration > maxXactDuration) {
                maxXactDuration = xact_duration;
            }
            if (state_duration > maxStateDuration) {
                maxStateDuration = state_duration
            }
        })
        let thresholdBackendField = document.createElement('div');
        thresholdBackendField.id = 'thresholdBackendField';
        let thresholdBackendInput = document.createElement('input');
        thresholdBackendInput.type = 'range';
        thresholdBackendInput.min = 0;
        thresholdBackendInput.max = Math.floor(maxBackendDuration);
        thresholdBackendInput.defaultValue = 0;
        thresholdBackendInput.style.width = '200px';
        let thresholdBackendName = document.createElement('span');
        thresholdBackendName.innerHTML = `Backend: ${thresholdBackendInput.value}`;
        thresholdBackendField.appendChild(thresholdBackendInput);
        thresholdBackendField.appendChild(thresholdBackendName);
        let thresholdXactField = document.createElement('div');
        thresholdXactField.id = 'thresholdXactField';
        let thresholdXactInput = document.createElement('input');
        thresholdXactInput.type = 'range';
        thresholdXactInput.min = 0;
        thresholdXactInput.max = Math.floor(maxXactDuration);
        thresholdXactInput.defaultValue = 0;
        thresholdXactInput.style.width = '200px';
        let thresholdXactName = document.createElement('span');
        thresholdXactName.innerHTML = `Xact: ${thresholdXactInput.value}`;
        thresholdXactField.appendChild(thresholdXactInput);
        thresholdXactField.appendChild(thresholdXactName);
        let thresholdStateField = document.createElement('div');
        thresholdStateField.id = 'thresholdStateField';
        let thresholdStateInput = document.createElement('input');
        thresholdStateInput.type = 'range';
        thresholdStateInput.min = 0;
        thresholdStateInput.max = Math.floor(maxStateDuration);
        thresholdStateInput.defaultValue = 0;
        thresholdStateInput.style.width = '200px';
        let thresholdStateName = document.createElement('span');
        thresholdStateName.innerHTML = `State: ${thresholdStateInput.value}`;
        thresholdStateField.appendChild(thresholdStateInput);
        thresholdStateField.appendChild(thresholdStateName);
        thresholdBackendField.style.display = 'flex';
        thresholdXactField.style.display = 'flex';
        thresholdStateField.style.display = 'flex';
        [thresholdBackendInput, thresholdXactInput, thresholdStateInput].forEach(elem => {
            elem.addEventListener('change', function() {
                let mainNode = document.getElementById('stateChangeSVG');
                let thresholdBackendValue = document.getElementById('thresholdBackendField').firstChild.value;
                let thresholdXactValue = document.getElementById('thresholdXactField').firstChild.value;
                let thresholdStateValue = document.getElementById('thresholdStateField').firstChild.value;
                document.getElementById('thresholdBackendField').childNodes[1].innerHTML = `Backend: ${thresholdBackendValue}`;
                document.getElementById('thresholdXactField').childNodes[1].innerHTML = `Xact: ${thresholdXactValue}`;
                document.getElementById('thresholdStateField').childNodes[1].innerHTML = `State: ${thresholdStateValue}`;
                mainNode.remove();
                div.insertAdjacentElement('afterend', new SessionChart().init(newBlock, thresholdBackendValue, thresholdXactValue, thresholdStateValue))
            });
        })
        inputFieldsRanges.appendChild(thresholdBackendField);
        inputFieldsRanges.appendChild(thresholdXactField);
        inputFieldsRanges.appendChild(thresholdStateField);
        inputFields.appendChild(inputFieldsHeader);
        inputFields.appendChild(inputFieldsRanges);
        div.appendChild(inputFields);
        return div;
    }
    init(newBlock, threshold_backend=null, threshold_xact=null, threshold_state=null) {
        let div = document.createElement('div');
        div.setAttribute('id', 'stateChangeSVG');
        let stateChanging = {};
        let reportStartUT = data.properties.report_start1_ut;
        let reportEndUT = data.properties.report_end2_ut ? data.properties.report_end2_ut : data.properties.report_end1_ut;
        let reportDuration = reportEndUT - reportStartUT;
        let totalSVGWidth = 1520;
        if (document.documentElement.offsetWidth) {
            totalSVGWidth = Math.ceil(0.85 * document.documentElement.offsetWidth / 12) * 12;
        }
        let timeLineWidth = 4;
        let proportion = totalSVGWidth / reportDuration;
        let linesCount = Math.ceil(totalSVGWidth / timeLineWidth);
        newBlock.data.forEach(elem => {
            let backend_duration = elem.backend_duration_ut;
            let xact_duration = elem.xact_duration_ut;
            let state_duration = elem.xact_duration_ut;
            if (backend_duration < threshold_backend) {
                return;
            }
            if (xact_duration < threshold_xact) {
                return;
            }
            if (state_duration < threshold_state) {
                return;
            }
            let state_change = {};
            state_change[elem.state_change_ut] = {
                'pid': elem.pid,
                'state': elem.state,
                'start_ut': elem.state_change_ut,
                'start': elem.state_change,
                'duration': elem.state_duration_ut,
                'state_code': elem.state_code,
                'queryid': elem.queryid
            };
            if (stateChanging[`${elem.pid}_${elem.backend_start_ut}`] === undefined) {
                let xact = {}
                xact[elem.xact_start_ut] = {
                    'pid': elem.pid,
                    'start_ut': elem.xact_start_ut,
                    'start': elem.xact_start,
                    'duration': elem.xact_duration_ut,
                    'state_changes': state_change
                }
                stateChanging[`${elem.pid}_${elem.backend_start_ut}`] = {
                    'pid': elem.pid,
                    'start': elem.backend_start,
                    'start_ut': elem.backend_start_ut,
                    'duration': elem.backend_duration_ut,
                    'count': 1,
                    'xacts': xact
                }
            } else {
                if (stateChanging[`${elem.pid}_${elem.backend_start_ut}`].xacts[elem.xact_start_ut] === undefined) {
                    stateChanging[`${elem.pid}_${elem.backend_start_ut}`].xacts[elem.xact_start_ut] = {
                        'pid': elem.pid,
                        'start_ut': elem.xact_start_ut,
                        'start': elem.xact_start,
                        'duration': elem.xact_duration_ut,
                        'state_changes': state_change
                    };
                } else {
                    stateChanging[`${elem.pid}_${elem.backend_start_ut}`]
                        .xacts[elem.xact_start_ut]
                        .state_changes[elem.state_change_ut] = state_change[elem.state_change_ut];
                }
                stateChanging[`${elem.pid}_${elem.backend_start_ut}`].count += 1;
            }
        })
        let backends = Object.keys(stateChanging).map((key) => stateChanging[key]);
        let statesByStart = structuredClone(backends.sort((a,b) => a.start_ut - b.start_ut));
        let statesByEnd = structuredClone(backends.sort((a,b) => (a.start_ut + a.duration) - (b.start_ut + b.duration)));
        let statesByEndPointer = 0;
        let s = 0;
        for (let statesByStartPointer = 0; statesByStartPointer < statesByStart.length; statesByStartPointer++) {
            let firstBackend = statesByStart[statesByStartPointer];
            let firstBackendID = `${firstBackend.pid}_${firstBackend.start_ut}`
            let secondBackend = statesByEnd[statesByEndPointer];
            let secondBackendID = `${secondBackend.pid}_${secondBackend.start_ut}`
            let charCount = firstBackend.pid.toString().length ? firstBackend.pid.toString().length : 4;
            let charToTime = charCount * 8 * 1.2 / proportion;
            let isLater = (firstBackend.start_ut - charToTime) > secondBackend.start_ut + secondBackend.duration;
            if (isLater) {
                stateChanging[firstBackendID]['chart_line'] = stateChanging[secondBackendID]['chart_line'];
                statesByEndPointer += 1;
            } else {
                s += 1;
                stateChanging[firstBackendID]['chart_line'] = s;
            }
        }
        let StateChangeSVGNested = '';
        Object.keys(stateChanging).forEach(backend => {
            let colour;
            let backendObj = stateChanging[backend];
            let title = '';
            title += `PID: ${backendObj.pid}\n`;
            title += `Backend start: ${new Date(backendObj.start_ut * 1000)}\n`;
            title += `Backend duration: ${Math.round(backendObj.duration * 100) / 100} sec`;
            let backendSVG = this.drawRect(backendObj, reportStartUT, proportion, backendObj['chart_line'], this.colours[2], this.colours[17], title, 'backend');
            let pidSVG = this.drawPID(backendObj, reportStartUT, proportion, backendObj['chart_line']);
            StateChangeSVGNested += backendSVG;
            StateChangeSVGNested += pidSVG;
            Object.keys(backendObj.xacts).forEach(xact => {
                let xactObj = backendObj.xacts[xact];
                let title = '';
                title += `PID: ${xactObj.pid}\n`;
                title += `Xact start: ${new Date(xactObj.start_ut * 1000)} \n`;
                title += `Xact duration: ${Math.round(xactObj.duration * 100) / 100} sec \n`;
                title += `Backend start: ${new Date(backendObj.start_ut * 1000)} \n`;
                title += `Backend duration: ${Math.round(backendObj.duration * 100) / 100} sec`;
                let xactSVG = this.drawRect(xactObj, reportStartUT, proportion, backendObj['chart_line'], this.colours[2], this.colours[17], title, 'xact');
                StateChangeSVGNested += xactSVG;
                Object.keys(xactObj.state_changes).forEach(state_change => {
                    let stateChangeObj = xactObj.state_changes[state_change];
                    if (stateChangeObj.state_code === 1) {
                        colour = this.colours[6]
                    } else if (stateChangeObj.state_code === 3) {
                        colour = this.colours[9]
                    }
                    let title = '';
                    title += `PID: ${stateChangeObj.pid} \n`;
                    title += `State: ${stateChangeObj.state} \n`;
                    title += `Query ID: ${stateChangeObj.queryid}\n`;
                    title += `State start: ${new Date(stateChangeObj.start_ut * 1000)} \n`;
                    title += `State duration: ${Math.round(stateChangeObj.duration * 100) / 100} sec \n`;
                    title += `Xact start: ${new Date(xactObj.start_ut * 1000)} \n`;
                    title += `Xact duration: ${Math.round(xactObj.duration * 100) / 100} sec \n`;
                    title += `Backend start: ${new Date(backendObj.start_ut * 1000)} \n`;
                    title += `Backend duration: ${Math.round(backendObj.duration * 100) / 100} sec`;
                    let stateChangeSVG = this.drawRect(
                        stateChangeObj,
                        reportStartUT,
                        proportion,
                        backendObj['chart_line'],
                        colour,
                        colour,
                        title,
                        'stateChange',
                        `${backendObj.pid}_${xactObj.start_ut}_${stateChangeObj.start_ut}`
                    );
                    StateChangeSVGNested += stateChangeSVG;
                })
            })
        })
        let timeGridNestedSVG = '';
        for (let i = 0; i <= linesCount; i++) {
            let pointTime = new Date((i * timeLineWidth / proportion + reportStartUT) * 1000);
            let timeLineSVG = `
                <path
                    id="line${i}"
                    d="M ${i * timeLineWidth} 0 L ${i * timeLineWidth} ${(s + 1) * 20 }"
                    stroke="lightgrey"
                    stroke-dasharray="1">
                </path>
            `;
            let hiddenLineSVG = `
                <path
                    d="M ${i * timeLineWidth} 0 L ${i * timeLineWidth} ${(s + 1) * 20}"
                    stroke="white"
                    stroke-width="${timeLineWidth}"
                    >
                    <title>${pointTime}</title>
                </path>
            `;
            timeGridNestedSVG += hiddenLineSVG;
            timeGridNestedSVG += timeLineSVG;
        }
        let StateChangeSVG = `<svg>${StateChangeSVGNested}</svg>`
        let timeGridSVG = `<svg>${timeGridNestedSVG}</svg>`;
        let svg = `
            <svg
                width="${totalSVGWidth}px"
                height="${(s * 20) + 20}px"
            >
                ${timeGridSVG}
                ${StateChangeSVG}
            </svg>
        `;
        div.insertAdjacentHTML('beforeend', svg);
        div.style.display = 'flex';
        div.style.flexDirection = 'column';
        div.querySelectorAll('rect.stateChange').forEach(elem => {
            elem.addEventListener('click', e => {
                let target = e.target.dataset.target;
                window.location.replace(`#${target}`);
                let targetNode = document.getElementById(target);
                targetNode.click();
            })
        })
        return div;
    }
    drawSessionChartLegend() {
        let legend = document.createElement('div');
        legend.style.display = 'flex';
        legend.style.flexDirection = 'column';
        legend.appendChild(this.drawLegend(this.colours[6], 'idle in transaction'));
        legend.appendChild(this.drawLegend(this.colours[9], 'active'));
        legend.appendChild(this.drawLegend(this.colours[2], 'backend with pid'));
        return legend;
    }
}
class BaseSection {
    constructor(section, deep) {
        this.section = section;
        this.deep = deep;
        this.sectionHasContent = ('content' in section);
        this.sectionHasTable = ('header' in section);
        this.sectionHasTitle = ('tbl_cap' in section);
    }
    static buildTitle(section, deep) {
        let title = document.createElement('h3');
        if (deep !== 1) {
            title = document.createElement('p');
        }
        title.innerHTML = section.tbl_cap;
        title.id = section.sect_id;
        return title;
    }
    init() {
        let div = document.createElement('div');
        if (this.section.sect_id) {
            div.setAttribute('id', this.section.sect_id);
        }
        if (this.sectionHasTitle) {
            div.appendChild(BaseSection.buildTitle(this.section, this.deep));
        }
        if (this.sectionHasContent) {
            let contentClass = this.section.content.class;
            let contentText = this.section.content.text;
            let contentDiv = document.createElement('div');
            contentDiv.classList.add(contentClass);
            contentDiv.innerHTML = contentText;
            div.appendChild(contentDiv);
        }
        if (this.sectionHasTable) {
            let table = document.createElement('table');
            table.setAttribute('id', `${this.section.sect_id}_t`);
            for (let i = 0; i < this.section.header.length; i++) {
                let newBlock = structuredClone(this.section);
                newBlock.header = this.section.header[i];
                if (newBlock.header.source) {
                    newBlock.data = data.datasets[newBlock.header.source];
                } else {
                    newBlock.data = this.section.data[i];
                }
                if (!newBlock.data) {
                    console.log(newBlock);
                    continue;
                }
                if (newBlock.header.filter) {
                    newBlock.data = Utilities.filter(newBlock.data, newBlock.header.filter);
                }
                if (newBlock.header.ordering) {
                    let direction = 1;
                    let key = newBlock.header.ordering;
                    if (newBlock.header.ordering.startsWith('-')) {
                        direction = -1;
                        key = newBlock.header.ordering.slice(1);
                    }
                    newBlock.data = Utilities.sort(newBlock.data, key, direction);
                }
                if (newBlock.header.limit) {
                    newBlock.data = Utilities.limit(newBlock.data, Number.parseInt(data.properties[newBlock.header.limit]));
                }
                if (newBlock.header.class) {
                    table.setAttribute('class', newBlock.header.class);
                }
                if (newBlock.header["highlight"]) {
                    table.classList.add('highlight');
                }
                if (newBlock.header["preview"]) {
                    table.classList.add('preview');
                }
                if (newBlock.header.type === 'row_table') {
                    div.appendChild(new HorizontalTable(newBlock, table).init());
                } else if (newBlock.header.type === 'column_table') {
                    div.appendChild(new VerticalTable(newBlock, table).init());
                } else if (newBlock.header.type === 'chart') {
                    div.appendChild(SessionChart.initTreshold(newBlock));
                    let sessionChart = new SessionChart();
                    div.appendChild(sessionChart.init(newBlock));
                    div.appendChild(sessionChart.drawSessionChartLegend());
                }
            }
        }
        return div;
    }
}
class BaseTable extends BaseSection {
    static uniqueHeaders = {
        'waitEventsBlock': BaseTable.buildWaitEventsBlockHeader
    }
    static uniqueCells = {
        'queryId': BaseTable.buildQueryIdCell,
        'jitCellId': BaseTable.buildJitCellId,
        'jitTimeCell': BaseTable.buildJitTimeCell,
        'interval': BaseTable.buildIntervalCell,
        'queryTextId': BaseTable.buildQueryTextIdCell,
        'planId': BaseTable.buildPlanIdCell,
        'queryText': BaseTable.buildQueryTextCell,
        'waitEvent': BaseTable.buildWaitEventDetailsCell,
        'pipeChart': PipeChart.drawIntoTable,
    }
    static properties = {
        'topn': data.properties.topn,
        'end1_id': data.properties.end1_id,
        'end2_id': data.properties.end2_id,
        'start1_id': data.properties.start1_id,
        'start2_id': data.properties.start2_id,
        'description': data.properties.description,
        'report_end1': data.properties.report_end1,
        'report_end2': data.properties.report_end2,
        'server_name': data.properties.server_name,
        'report_start1': data.properties.report_start1,
        'report_start2': data.properties.report_start2,
        'max_query_length': data.properties.max_query_length,
        'pgprofile_version': data.properties.pgprofile_version,
        'server_description': data.properties.server_description,
        'checksum_fail_detected': data.properties.checksum_fail_detected,
        'interval1_duration_sec': data.properties.interval1_duration_sec,
        'interval2_duration_sec': data.properties.interval2_duration_sec
    }
    constructor(section, table) {
        super(section);
        this.table = table;
    }
    static buildWaitEventsBlockHeader(table, header) {
        let tr0 = document.createElement('tr');
        let tr1 = document.createElement('tr');
        let tr2 = document.createElement('tr');
        tr0.classList.add('header');
        tr1.classList.add('header');
        tr2.classList.add('header');
        let th0 = document.createElement('th');
        let mainColumn = header.columns[0];
        th0.innerHTML = mainColumn.caption;
        th0.setAttribute('colspan', '100%');
        tr0.appendChild(th0);
        mainColumn.columns.forEach(column => {
            let th1 = document.createElement('th');
            th1.innerHTML = column.caption;
            if (column.columns) {
                th1.setAttribute('colspan', column.columns.length);
                column.columns.forEach(column => {
                    let th2 = document.createElement('th');
                    th2.innerHTML = column.caption;
                    if (column.title) {
                        th2.setAttribute('title', column.title);
                    }
                    tr2.appendChild(th2);
                })
            } else {
                th1.setAttribute('rowspan', '2');
            }
            tr1.appendChild(th1);
        })
        table.appendChild(tr0);
        table.appendChild(tr1);
        table.appendChild(tr2);
    }
    static buildJitTimeCell(newRow, column, row) {
        let newCell = newRow.insertCell(-1);
        if (row[column.id]) {
            newCell.setAttribute('class', 'table_obj_value');
            let p = document.createElement('p');
            let a = document.createElement('a');
            a.href = `#jit_${row.hexqueryid}_${row.datid}_${row.userid}_${row.toplevel}`;
            a.innerHTML = row[column.id];
            p.appendChild(a);
            newCell.appendChild(p);
        }
        return !!row[column.id];
    }
    static buildQueryIdCell(newRow, column, row) {
        let newCell = newRow.insertCell(-1);
        newCell.setAttribute('class', column.class);
        if (column.rowspan) {
            newCell.setAttribute('rowspan', '2');
        }
        let p1 = document.createElement('p');
        let a1 = document.createElement('a');
        a1.href = `#${row.hexqueryid}`;
        a1.innerHTML = row.hexqueryid;
        let p2 = document.createElement('p');
        p2.classList.add('small_p');
        let small = document.createElement('small');
        p2.appendChild(small);
        small.innerHTML = `[${row.hashed_ids}]`;
        if (!row.toplevel) {
            small = document.createElement('small');
            p2.appendChild(small);
            small.innerHTML = '(N)';
            small.title = 'Nested level';
        }
        newCell.appendChild(p1);
        newCell.appendChild(p2);
        let button = Previewer.drawCopyButton();
        button.addEventListener("click", event => {
            navigator.clipboard.writeText(newRow.dataset.queryid).then(r => console.log(newRow.dataset.queryid))
        });
        button.classList.add('copyQueryId');
        p1.appendChild(button);
        p1.appendChild(a1);
        return !!row.hexqueryid;
    }
    static buildJitCellId(newRow, column, row) {
        BaseTable.buildQueryIdCell(newRow, column, row);
        newRow.firstChild.setAttribute('id', `jit_${row.hexqueryid}_${row.datid}_${row.userid}_${row.toplevel}`);
    }
    static buildPlanIdCell(newRow, column, row) {
        let newCell = newRow.insertCell(-1);
        newCell.setAttribute('class', column.class);
        if (column.rowspan) {
            newCell.setAttribute('rowspan', '2');
        }
        let p1 = document.createElement('p');
        let a1 = document.createElement('a');
        a1.href = `#${row.hexqueryid}_${row.hexplanid}`;
        a1.innerHTML = row.hexplanid;
        p1.appendChild(a1);
        newCell.appendChild(p1);
        return !!row.hexplanid;
    }
    static buildQueryTextIdCell(newRow, column, row) {
        let cell = newRow.insertCell(-1);
        let columnId = row[column.id];
        newRow.classList.add('statement');
        cell.setAttribute('id', columnId);
        let newText = document.createTextNode(columnId);
        cell.setAttribute('class', column.class);
        const queryTextsLength = row.query_texts.length;
        cell.setAttribute('rowspan', `${queryTextsLength}`);
        cell.appendChild(newText);
        return !!columnId;
    }
    static buildQueryTextCell(newRow, column, row) {
        for (let i = 0; i < row[column.id].length; i++) {
            if (i > 0) {
                newRow = newRow.parentNode.insertRow(-1);
                newRow.setAttribute('data-hexqueryid', row.hexqueryid);
                newRow.setAttribute('data-all', row.hexqueryid);
            }
            let newCell = newRow.insertCell(-1);
            let preprocessedQueryText = Utilities.preprocessQueryString(row[column.id][i]);
            newCell.setAttribute('class', column.class);
            let newText = `<pre>${preprocessedQueryText}</pre>`;
            newCell.insertAdjacentHTML('afterbegin', newText);
        }
        if (row.plans && row.plans.length) {
            for (let i = 0; i < row.plans.length; i++) {
                newRow = newRow.parentNode.insertRow(-1);
                newRow.setAttribute('data-hexqueryid', row.hexqueryid);
                newRow.setAttribute('data-hexplanid', row.plans[i].hexplanid);
                newRow.setAttribute('data-all', `${row.hexqueryid} ${row.plans[i].hexplanid}`);
                newRow.classList.add('plantext');
                let newCell = newRow.insertCell(-1);
                let text = row.plans[i].hexplanid;
                let newText = document.createTextNode(text);
                newCell.appendChild(newText);
                newCell.setAttribute('class', column.class);
                newCell.setAttribute('id', `${row.hexqueryid}_${row.plans[i].hexplanid}`);
                let newPlanCell = newRow.insertCell(-1);
                let preprocessedPlanText = Utilities.preprocessQueryString(row.plans[i].plan_text);
                let planText = `<pre>${preprocessedPlanText}</pre>`;
                newPlanCell.setAttribute('class', column.class);
                newPlanCell.insertAdjacentHTML('afterbegin', planText);
            }
        }
        return !!row[column.id];
    }
    static buildIntervalCell(newRow, column, row) {
        let cell = newRow.insertCell(-1);
        let newText = document.createTextNode(column.id);
        if (column.class) {
            cell.setAttribute('class', 'table_obj_value');
        }
        if (column.rowspan) {
            cell.setAttribute('rowspan', '2');
        }
        if (column.title) {
            cell.setAttribute('title', BaseTable.getTagTitle(column.title));
        }
        cell.appendChild(newText);
        return true;
    }
    static buildWaitEventDetailsCell(newRow, column, row) {
        let newCell = newRow.insertCell(-1);
        newRow.setAttribute('id', `${row.event_type}_${row.hexqueryid}_${row.hexplanid}`);
        if (column.rowspan) {
            newCell.setAttribute('rowspan', row.rowspan);
        }
        if (column.class) {
            newCell.setAttribute('class', column.class);
            newCell.classList.add('table_obj_value');
        }
        let dataExists = Boolean(row[column.id]);
        if (dataExists) {
            for (let i = 0; i < row[column.id].length; i++) {
                let details = row[column.id][i];
                if (details.event) {
                    let p = document.createElement('p');
                    let a = document.createElement('a');
                    if (row.event_type === 'Total') {
                        a.href = `#${details.event}_${row.hexqueryid}_${row.hexplanid}`;
                    }
                    a.innerHTML = details.event;
                    p.appendChild(a);
                    let colons = document.createTextNode(': ');
                    p.appendChild(colons);
                    let strong = document.createElement('strong');
                    strong.innerHTML = details.wait;
                    p.appendChild(strong);
                    newCell.appendChild(p);
                }
            }
        }
        return true;
    }
    static bifurcateObject(column) {
        let objects = [];
        let keys = Object.keys(column);
        for (let i = 0; i < column.id.length; i++) {
            let newObj = structuredClone(column);
            for (let j = 0; j < keys.length; j++) {
                if (typeof newObj[keys[j]] === 'object') {
                    newObj[keys[j]] = column[keys[j]][i];
                }
            }
            objects.push(newObj);
        }
        return objects;
    }
    static getTagTitle(title) {
        const TITLES = {
            'properties.timePeriod1': `(${BaseTable.properties.report_start1} - ${BaseTable.properties.report_end1})`,
            'properties.timePeriod2': `(${BaseTable.properties.report_start2} - ${BaseTable.properties.report_end2})`,
            'properties.timePeriod1,properties.timePeriod2': 'Sample\'s time period'
        }
        if (TITLES[title] !== undefined) {
            return TITLES[title];
        }
        return title;
    }
    static hasSpecialClass(column) {
        if (column.class) {
            let classList = column.class.split(' ');
            for (let i = 0; i < classList.length; i++) {
                let klass = classList[i].trim();
                if (BaseTable.uniqueCells[klass]) {
                    return klass;
                }
            }
        }
        return false;
    }
    static collectHeader(header, deep, resultMatrix) {
        if (resultMatrix === null) {
            resultMatrix = [];
        }
        if (header.caption) {
            if (!resultMatrix[deep]) {
                resultMatrix.push([]);
            }
            let sumCols = 0;
            if (header.columns) {
                deep++;
                header.columns.forEach(column => {
                    BaseTable.collectHeader(column, deep, resultMatrix);
                    if (column.columns) {
                        sumCols += column.columns.length - 1;
                    }
                })
                deep--;
            }
            let th = {
                'caption': header.caption,
                'colspan': header.columns ? header.columns.length + sumCols : 1,
                'rowspan': deep === 0 && !('columns' in header) ? 2 : 1
            };
            if (header.id) {
                th['id'] = header.id
            }
            if (header.title) {
                th['title'] = BaseTable.getTagTitle(header.title)
            }
            resultMatrix[deep].push(th);
        } else {
            if (header.columns) {
                header.columns.forEach(column => {
                    BaseTable.collectHeader(column, deep, resultMatrix);
                })
            }
        }
        return resultMatrix;
    }
    buildHeader() {
        // Three-level headers building
        if (this.section.header.class) {
            let classList = this.section.header.class.split(' ');
            for (let i = 0; i < classList.length; i++) {
                let klass = classList[i].trim();
                if (BaseTable.uniqueHeaders[klass]) {
                    return BaseTable.uniqueHeaders[klass](this.table, this.section.header);
                }
            }
        };
        let headerMatrix = BaseTable.collectHeader(this.section.header, 0, null);
        headerMatrix.forEach(row => {
            let tr = document.createElement('tr');
            tr.classList.add('header');
            row.forEach(column => {
                let th = document.createElement('th');
                th.innerHTML = column.caption;
                th.setAttribute('rowspan', headerMatrix.length === 1 ? 1 : column.rowspan);
                th.setAttribute('colspan', column.colspan);
                if (column.title) {
                    th.setAttribute('title', column.title);
                }
                if (column.id) {
                    th.setAttribute('id', column.id);
                }
                tr.appendChild(th);
            });
            this.table.appendChild(tr);
        });
        if (headerMatrix.length === 1) {
            let emptyRow = document.createElement('tr');
            emptyRow.classList.add("header");
            this.table.appendChild(emptyRow);
        }
    }
    init() {
        this.buildHeader();
        this.insertRows();
        return this.table;
    }
}
class HorizontalTable extends BaseTable {
    static buildCell(newRow, column, row) {
        let specialClass = BaseTable.hasSpecialClass(column);
        if (specialClass) {
            let notEmpty = BaseTable.uniqueCells[specialClass](newRow, column, row);
            return !notEmpty;
        }
        let newCell = newRow.insertCell(-1);
        if (column.rowspan) {
            newCell.setAttribute('rowspan', '2');
        }
        if (column.class) {
            newCell.setAttribute('class', column.class);
        }
        if (row[column.id]) {
            let newText = document.createTextNode(row[column.id]);
            newCell.appendChild(newText);
            return false;
        }
        return true;
    }
    static collectColumns(header, array, matrix) {
        if (array === null) {
            array = [];
        }
        if (matrix === null) {
            matrix = [];
        }
        if ('columns' in header) {
            for (let i = 0; i < header.columns.length; i++) {
                let column = header.columns[i];
                HorizontalTable.collectColumns(column, array, matrix);
            }
        } else {
            if (typeof header.id === 'string') {
                array.push(header);
            } else if (typeof header.id === 'object') {
                matrix.push(BaseTable.bifurcateObject(header));
            }
        }
        if (matrix.length) {
            matrix = matrix[0].map((_, colIndex) => matrix.map(row => row[colIndex]));
        }
        return [array, matrix];
    }
    static getColumns(columns) {
        let matrixCollection = HorizontalTable.collectColumns(columns, null, null);
        let singeRowColumns = matrixCollection[0];
        let matrixWithVectors = matrixCollection[1];
        let newMatrix = Array.from(matrixCollection[1]);
        if (matrixWithVectors[0]) {
            newMatrix[0] = singeRowColumns.concat(matrixWithVectors[0]);
        } else {
            newMatrix[0] = singeRowColumns;
        }
        return newMatrix;
    }
    static setDataAttrs(newRow, row) {
        let searchArray = [];
        Object.keys(row).forEach(attr => {
            newRow.setAttribute(`data-${attr}`, row[attr]);
            searchArray.push(row[attr]);
        });
        let searchString = Object.values(searchArray).join(' ').replace(/\s\s+/g, ' ');
        newRow.setAttribute('data-all', searchString);
    }
    static setId(newRow, row, dataAttrs) {
        let data = new Array();
        dataAttrs.forEach(item => {
            data.push(row[item]);
        });
        let customId = data.join("_");
        newRow.setAttribute('id', customId)
    }
    insertRows() {
        let columns = HorizontalTable.getColumns(this.section.header);  // Getting columns matrix
        let highlightRowAttrs = this.section.header.highlight;
        let previewQueryAttrs = this.section.header.preview;
        let scrollQueryAttrs = this.section.header.scroll;
        let rows = this.section.data;  // Getting json array with data
        if (highlightRowAttrs) {
            let result = JSON.stringify(highlightRowAttrs);
            this.table.setAttribute('data-highlight', result);
        }
        if (previewQueryAttrs) {
            let result = JSON.stringify(previewQueryAttrs);
            this.table.setAttribute('data-preview', result);
        }
        if (scrollQueryAttrs) {
            let scrollAttrs = JSON.stringify(scrollQueryAttrs);
            this.table.setAttribute('data-scroll', scrollAttrs);
        }
        for (let i = 0; i < rows.length; i++) {
            let row = rows[i];
            for (let j = 0; j < columns.length; j++) {
                let newRow = this.table.insertRow(-1);
                if (columns.length > 1) {
                    newRow.classList.add(`int${j + 1}`);
                }
                if (row.klass) {
                    newRow.classList.add(row.klass);
                }
                if (i % 2 !== 0) {
                    newRow.classList.add('grey');
                }
                HorizontalTable.setDataAttrs(newRow, row);
                if (scrollQueryAttrs) {
                    HorizontalTable.setId(newRow, row, scrollQueryAttrs);
                }
                let isEmpty = [];
                for (let k = 0; k < columns[j].length; k++) {
                    let column = columns[j][k];
                    isEmpty.push(HorizontalTable.buildCell(newRow, column, row));
                }
                if (isEmpty.every(Boolean)) {
                    newRow.style.visibility = 'collapse';
                    let prevSib = newRow.previousSibling;
                    prevSib.style.verticalAlign = 'baseline';
                }
            }
        }
    }
}
class VerticalTable extends BaseTable {
    static getColumns(section) {
        let columns = [];
        let rows = section.header.rows;
        for (let i = 0; i < rows.length; i++) {
            if (typeof rows[i].id === 'object') {
                columns.push(BaseTable.bifurcateObject(rows[i]));
            } else {
                columns.push(rows[i]);
            }
        }
        return columns;
    }
    static buildCell(newRow, column, row, klass) {
        let specialClass = BaseTable.hasSpecialClass(column);
        if (specialClass) {
            BaseTable.uniqueCells[specialClass](newRow, column, row);
            return;
        }
        let newCell = newRow.insertCell(-1);
        if ('caption' in column) {
            let newText = document.createTextNode(column['caption']);
            newCell.appendChild(newText);
        }
        if ('title' in column) {
            newCell.setAttribute('title', column.title);
        }
        if ('id' in column) {
            newCell.innerHTML = row[0][column.id];
        }
        if (klass) {
            newCell.setAttribute('class', klass);
        }
    }
    insertRows() {
        let columns = VerticalTable.getColumns(this.section);
        let classes = this.section.header.columns;
        let rows = this.section.data;
        for (let i = 0; i < columns.length; i++) {
            let newRow = this.table.insertRow(-1);
            if (i % 2 !== 0) {
                newRow.classList.add('grey');
            }
            VerticalTable.buildCell(newRow, columns[i], rows, classes[0].class);
            for (let j = 0; j < columns[i].cells.length; j++) {
                let cell = columns[i].cells[j];
                let klass = classes[j].class;
                VerticalTable.buildCell(newRow, cell, rows, klass);
            }
        }
    }
}
class Highlighter {
    static transition = 'background-color 70ms';
    static toggleClass(tr, allRows) {
        Highlighter.cleanAllActiveClasses(allRows);
        if (Object.keys(tr.dataset).length && !tr.classList.contains('active')) {
            allRows.forEach((row) => {
                let isEqual = Highlighter.isDatasetEqual(tr, row);
                if (isEqual) {
                    Highlighter.setBackgroundColorToRow(row, '', this.transition);
                    row.classList.add('active');
                    let navId = this.getClosestTag(row, 0, 'div').firstChild.id;
                    if (navId) {
                        let navLi = document.getElementById(`menu_${navId}`);
                        if (navLi && !navLi.classList.contains('active')) {
                            navLi.classList.add('active');
                        }
                    }
                }
            });
        }
    }
    static getAllRows() {
        return document.querySelectorAll('tr');
    }
    static getHighlightableRows() {
        return document.querySelectorAll('table.highlight tr:not(.queryRow)');
    }
    static getClosestTag(target, curDeep, targetTag) {
        let tooDeep = curDeep >= 5;
        let headOfTable = target.tagName.toLowerCase() === 'th';
        let stillNotRow = target.tagName.toLowerCase() !== targetTag;
        if (tooDeep) {
            return false;
        } else if (headOfTable) {
            return false;
        } else if (stillNotRow) {
            curDeep++;
            return Highlighter.getClosestTag(target.parentNode, curDeep, targetTag);
        } else {
            return target;
        }
    }
    static cleanAllActiveClasses(rows) {
        rows.forEach(elem => {
            if (elem.classList.contains('active')) {
                elem.classList.remove('active');
            }
        })
        let menu = document.getElementById('sections');
        if (menu) {
            let allItems = document.querySelectorAll('li');
            allItems.forEach(item => {
                if (item.classList.contains('active')) {
                    item.classList.remove('active');
                }
            })
        }
    }
    static getTargetDS(tr) {
        let fieldsList = JSON.parse(tr.closest('table').dataset.highlight);
        let targetDS = {};
        fieldsList.forEach(field => {
            targetDS[field.id] = tr.dataset[field.id]
        })
        return targetDS;
    }
    static isDatasetEqual(tr, row) {
        let targetDataset = Highlighter.getTargetDS(tr);
        let rowDataset = row.dataset;
        let trIsSqlList = Highlighter.getClosestTag(tr, 0, 'table').id === 'sqllist_t';
        let rowIsSqlList = Highlighter.getClosestTag(row, 0, 'table').id === 'sqllist_t';
        let isSameQuery = targetDataset.hexqueryid !== undefined
            && targetDataset.hexqueryid === rowDataset.hexqueryid
            && targetDataset.planid === rowDataset.planid;
        if ((trIsSqlList || rowIsSqlList) && isSameQuery) {
            return true;
        }
        for (let data in targetDataset) {
            if (targetDataset[data] === '*' && rowDataset[data] !== undefined) {
                continue;
            }
            if (data === 'all') {
                continue;
            }
            if (targetDataset[data] !== rowDataset[data]) {
                return false;
            }
        }
        return true;
    }
    static setBackgroundColorToRow(tr, hoverColor, transition) {
        tr.querySelectorAll('td').forEach(td => {
            td.style.backgroundColor = hoverColor;
            td.style.transition = transition;
        })
        let siblings = null;
        if (tr.classList.contains('int1')) {
            siblings = tr.nextSibling.querySelectorAll('td');
        } else if (tr.classList.contains('int2')) {
            siblings = tr.previousSibling.querySelectorAll('td');
        }
        if (siblings) {
            siblings.forEach(elem => {
                elem.style.backgroundColor = hoverColor;
                elem.style.transition = transition;
            })
        }
    }
    static highlight(event, allRows) {
        if (event.target.tagName.toLowerCase() !== 'a') {
            let tr = Highlighter.getClosestTag(event.target, 0, 'tr');
            if (tr && Object.keys(tr.dataset).length) {
                Highlighter.toggleClass(tr, allRows);
            }
        }
    }
    static smartHover(eventType, event, transition) {
        let hoverColor = '#14B0FF1A';
        let tr = Highlighter.getClosestTag(event.target, 0, 'tr');
        if (tr && !tr.classList.contains('active') && eventType === 'mouseover') {
            Highlighter.setBackgroundColorToRow(tr, hoverColor, transition);
        } else if (tr && eventType === 'mouseout') {
            Highlighter.setBackgroundColorToRow(tr, '', transition);
        }
    }
    static init() {
        const ALL_ROWS = Highlighter.getAllRows();
        const HIGHLIGHTABLE_ROWS = Highlighter.getHighlightableRows();
        HIGHLIGHTABLE_ROWS.forEach((elem) => {
            elem.addEventListener('click', (event) => {
                Highlighter.highlight(event, HIGHLIGHTABLE_ROWS);
            });
        })
        ALL_ROWS.forEach((elem) => {
            ['mouseover', 'mouseout'].forEach(eventType => {
                elem.addEventListener(eventType, (event) => {
                    Highlighter.smartHover(eventType, event, this.transition);
                });
            })
        })
    }
}
class Menu {
    static buildNavigator(section, deep) {
        let hasNestedSections = ('sections' in section);
        let hasTocCap = ('toc_cap' in section);
        let navigator = document.getElementById('sections');
        let div = document.createElement('div');
        div.classList.add(`level${deep}`);
        if (hasTocCap) {
            let title = document.createElement('div');
            let a = document.createElement('a');
            a.innerHTML = section.toc_cap;
            a.href = `#${section.sect_id}`;
            a.classList.add('anchor');
            a.setAttribute('id', `menu_${section.sect_id}`);
            title.appendChild(a);
            div.appendChild(title);
            if (!hasNestedSections) {
                navigator.appendChild(div);
            } else {
                let nestedDiv = document.createElement('div');
                nestedDiv.classList.add('nested-sections', 'hidden');
                let hasNestedContent = false;
                section.sections.forEach(nestedSection => {
                    let nestedSectionDiv = Menu.buildNavigator(nestedSection, deep + 1);
                    if (nestedSectionDiv) {
                        nestedDiv.appendChild(nestedSectionDiv);
                        hasNestedContent = true;
                    }
                });
                const arrowHTML = `
                    <svg viewBox="0 0 16 16" width="16" height="16" class="arrow">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M4.9417 5.5L8 8.54753L11.0583 5.5L12.5 6.93662L8.72085 10.7025C8.32273 11.0992 7.67726 11.0992 7.27915 10.7025L3.5 6.93662L4.9417 5.5Z" fill="#A6B5C7"/>
                    </svg>
                `;
                if (hasNestedContent) {
                    title.insertAdjacentHTML('beforeend', arrowHTML);
                    let arrowSvg = title.querySelector('.arrow');
                    div.appendChild(nestedDiv);
                    navigator.appendChild(div);
                    arrowSvg.addEventListener('click', () => {
                        nestedDiv.classList.toggle('hidden');
                        arrowSvg.classList.toggle('up');
                    });
                } else {
                    navigator.appendChild(div);
                }
            }
            return div;
        }
    }
    static buildPageContent(data, parentNode, deep = 1) {
        let initialDeep = 1;
        data.sections.forEach(section => {
            Menu.buildNavigator(section, initialDeep);
        })
        let allLinks = parentNode.querySelectorAll('div[class^="level"] a');
        allLinks.forEach(link => {
            let parentDiv = link.closest('div');
            if (parentDiv) {
                parentDiv.classList.add('chapter');
            }
        });
        return parentNode;
    }
    static drawLogo() {
        let reportContent = document.getElementById('pageContent');
        let logo = logoFile;
        let logoMini = logoMiniFile;
        reportContent.insertAdjacentHTML('afterbegin', logo);
        reportContent.insertAdjacentHTML('afterbegin', logoMini);
    }
    static buildMenu() {
        let body = document.querySelector('body');
        let pageContent = `
            <div id="pageContent">
                <div id="sections" class="active"></div>
            </div>
        `
        body.insertAdjacentHTML('afterbegin', pageContent);
        let sections = document.getElementById("sections");
        Menu.buildPageContent(data, sections, 1);
        this.drawLogo();
        this.createSearchAndDropdown();
    }
    static createSearchAndDropdown() {
        let body = document.querySelector('body');
        let container = document.createElement('div');
        container.id = 'searchDropdownContainer';
        let searchWrapper = document.createElement('div');
        searchWrapper.id = 'searchWrap';
        searchWrapper.style.display = 'flex';
        let input = document.createElement('input');
        input.type = 'text';
        input.id = 'searchField';
        input.placeholder = 'Search';
        let searchButton = document.createElement('button');
        searchButton.type = 'button';
        searchButton.id = 'searchButton';
        searchButton.innerHTML = `
            <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_371_5886)">
                    <path 
                        fill-rule="evenodd" 
                        clip-rule="evenodd" 
                        d="M7 14C10.866 14 14 10.866 14 7C14 3.13401 10.866 0 7 0C3.13401 0 0 3.13401 0 7C0 10.866 
                            3.13401 14 7 14ZM7 12C9.76142 12 12 9.76142 12 7C12 4.23858 9.76142 2 7 2C4.23858 2 2 
                            4.23858 2 7C2 9.76142 4.23858 12 7 12ZM14 12.5858L15.7071 14.2929L14.2929 15.7071L12.5858 
                            14L14 12.5858ZM6.24974 6.33882C6.43444 6.12956 6.70147 6 7 6V4C6.10384 4 5.2985 4.3942 
                            4.75026 5.01535L6.24974 6.33882Z" 
                        fill="#14B0FF"
                    />
                </g>
                <defs>
                    <clipPath id="clip0_371_5886">
                        <rect width="16" height="16" fill="white"/>
                    </clipPath>
                </defs>
            </svg>
        `;
        searchWrapper.appendChild(input);
        searchWrapper.appendChild(searchButton);
        let select = document.createElement('select');
        select.id = 'dropdownSelect';
        let defaultOption = document.createElement('option');
        defaultOption.value = 'all';
        defaultOption.textContent = 'Everywhere';
        select.appendChild(defaultOption);
        const options = [
            { value: 'dbname', text: 'Database' },
            { value: 'username', text: 'User' },
            { value: 'relname', text: 'Table' },
            { value: 'indexrelname', text: 'Index' },
            { value: 'querytext', text: 'Query' }
        ];
        options.forEach(option => {
            let optElement = document.createElement('option');
            optElement.value = option.value;
            optElement.textContent = option.text;
            select.appendChild(optElement);
        });
        const arrowBlue = `
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path 
                    fill-rule="evenodd" 
                    clip-rule="evenodd" 
                    d="M4.9417 5.5L8 8.54753L11.0583 5.5L12.5 6.93662L8.72085 10.7025C8.32273 11.0992 7.67726 11.0992 
                        7.27915 10.7025L3.5 6.93662L4.9417 5.5Z" 
                    fill="#14B0FF"
                />
            </svg>
        `;
        let DropDownArrow = encodeURIComponent(arrowBlue);
        select.style.backgroundImage = `url("data:image/svg+xml;utf8,${DropDownArrow}")`;
        container.appendChild(searchWrapper);
        container.appendChild(select);
        let logoContainer = document.getElementById('logo');
        if (logoContainer && logoContainer.parentNode) {
            logoContainer.parentNode.insertBefore(container, logoContainer.nextSibling);
        } else {
            document.body.insertBefore(container, document.body.firstChild);
        }
        let rowsForSearch = document.querySelectorAll('tr:not(.header, .previewRow)');
        input.addEventListener("keyup", event => {
            if (event.key === "Escape") {
                event.target.value = "";
                Utilities.search(rowsForSearch, defaultOption.value, event.target.value);
            } else {
                Utilities.search(rowsForSearch, select.value, event.target.value);
            }
        })
    }
    static navigateBorder() {
        function updateHighlight() {
            let width = document.getElementById('pageContent').offsetWidth + 30;
            let height = 0;
            let element = document.elementFromPoint(width, height);
            if (element) {
                let sectId;
                let targetHeader = element.closest('h3, p, table');
                if (targetHeader) {
                    if (targetHeader.tagName === 'H3') {
                        sectId = targetHeader.getAttribute('id');
                    } else if (targetHeader.tagName === 'P') {
                        sectId = targetHeader.getAttribute('id');
                    } else if (targetHeader.tagName === 'TABLE') {
                        sectId = targetHeader.parentNode.firstChild.getAttribute('id');
                    }
                }
                if (sectId) {
                    let targetLink = document.querySelector(`.chapter a[href="#${sectId}"]`);
                    let currentChapter = targetLink?.closest('.chapter');
                    if (targetLink && currentChapter) {
                        document.querySelectorAll('.chapter.activeSection').forEach(ch => ch.classList.remove('activeSection'));
                        function highlightParentSections(chapter) {
                            let parentContainer = chapter.closest('[class^="level"]');
                            while (parentContainer) {
                                let parentChapter = parentContainer.querySelector('.chapter:first-child');
                                let nestedSections = parentContainer.querySelector('.nested-sections');
                                if (parentChapter && nestedSections && nestedSections.classList.contains('hidden')) {
                                    parentChapter.classList.add('activeSection');
                                }
                                parentContainer = parentContainer.parentElement.closest('[class^="level"]');
                            }
                        }
                        highlightParentSections(currentChapter);
                        currentChapter.classList.add('activeSection');
                    }
                }
            }
        }
        document.addEventListener('scroll', updateHighlight);
        let observer = new MutationObserver((mutations) => {
            mutations.forEach(mutation => {
                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                    updateHighlight();
                }
            });
        });
        document.querySelectorAll('.nested-sections').forEach(section => {
            observer.observe(section, { attributes: true });
        });
        updateHighlight();
    }
    static toggleMenu() {
        let menu = document.getElementById('pageContent');
        let logo = document.getElementById('logo');
        let logoMini = document.getElementById('logoMini');
        let mainContainer = document.getElementById('container');
        let searchDropdownContainer = document.getElementById('searchDropdownContainer');
        let table = document.querySelectorAll('.pgprototals');
        let paddingHorizontal = 40;
        let minMenuWidthPx = 100;
        let collapsedWidthPx = 35;
        function getExpandedWidthPx() {
            let maxWidthVw = 19;
            let widthFromVw = window.innerWidth * maxWidthVw / 100;
            return Math.max(widthFromVw, minMenuWidthPx + paddingHorizontal);
        }
        function toggleMenuState(shouldExpand) {
            let tableMarginRight = window.innerWidth * 0.03;
            if (shouldExpand) {
                const totalWidth = getExpandedWidthPx();
                menu.style.width = (totalWidth - paddingHorizontal) + 'px';
                mainContainer.style.left = totalWidth + 'px';
                menu.classList.remove('hidden');
                logo.classList.remove('hidden');
                logoMini.classList.add('hidden');
                searchDropdownContainer.classList.remove('hidden');
                table.forEach(table => {
                    table.style.width = `${window.innerWidth - totalWidth - tableMarginRight}px`; 
                });
            } else {
                menu.style.width = collapsedWidthPx + 'px';
                mainContainer.style.left = (collapsedWidthPx + paddingHorizontal) + 'px';
                menu.classList.add('hidden');
                logo.classList.add('hidden');
                logoMini.classList.remove('hidden');
                searchDropdownContainer.classList.add('hidden');
                table.forEach(table => {
                    table.style.width = `${window.innerWidth - (collapsedWidthPx + paddingHorizontal) - tableMarginRight}px`; 
                });
            }
        }
        toggleMenuState(!menu.classList.contains('hidden'));
        [logo, logoMini].forEach(elem =>
            elem.addEventListener('click', function() {
                toggleMenuState(menu.classList.contains('hidden'));
            })
        );
        window.addEventListener('resize', function() {
            if (!menu.classList.contains('hidden')) {
                toggleMenuState(true);
            }
        });
    }
    static init() {
        this.buildMenu();
        this.navigateBorder();
        this.toggleMenu();
    }
}
class Previewer {
    static getParentRows() {
        return document.querySelectorAll("table.preview tr:not(.header)");
    }
    static queryTextPreviewer(queryCell, queryRow, newRow, queryString) {
        queryCell.style.width = `${Math.floor(newRow.offsetWidth * 0.95)}px`;
        queryCell.style.fontFamily = 'Monospace';
        queryRow.style.display = '';
        if (!queryCell.hasChildNodes()) {
            let preprocessedText = Utilities.preprocessQueryString(queryString);
            queryCell.insertAdjacentHTML('afterbegin', `<p><i>${preprocessedText}</i></p>`);
        }
    }
    static storageParamsPreviewer(previewCell, previewRow, newRow, previewData) {
        previewCell.style.width = `${Math.floor(newRow.offsetWidth * 0.95)}px`;
        previewCell.style.fontFamily = 'Monospace';
        previewRow.style.display = '';
        if (!previewCell.hasChildNodes()) {
            let topn = data.properties.topn || 20;
            previewData.slice(-topn).reverse().forEach(item => {
                let preprocessedText = Utilities.preprocessQueryString(`${item['first_seen']}: ${item['reloptions']}`);
                previewCell.insertAdjacentHTML('afterbegin', `<p><i>${preprocessedText}</i></p>`);
            })
        }
    }
    static findQuery(queryRaw) {
        // datasetName, dataID, parentRow.dataset[dataID]
        let datasetName = queryRaw.dataset["dataset_name"];
        let dataID = queryRaw.dataset["dataset_col_id"];
        let querySet = data.datasets[datasetName];
        let queryId = queryRaw.dataset["dataset_id"]
        for (let i = 0; i < querySet.length; i++) {
            if (querySet[i][dataID] === queryId) {
                return i
            }
        }
        return -1
    }
    static drawCopyButton() {
        let button = document.createElement('a');
        button.setAttribute('class', 'copyButton');
        button.setAttribute('title', 'Copy to clipboard');
        let svg = `
            <svg width="14" height="14" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M8 0C5.79086 0 4 1.79086 4 4V10C4 12.2091 5.79086 14 8 14H14C16.2091 14 18 12.2091 18 10V4C18 1.79086 16.2091 0 14 0H8ZM6 4C6 2.89543 6.89543 2 8 2H14C15.1046 2 16 2.89543 16 4V10C16 11.1046 15.1046 12 14 12H8C6.89543 12 6 11.1046 6 10V4ZM0 7C0 5.69378 0.834808 4.58254 2 4.17071V14C2 15.1046 2.89543 16 4 16H13.8293C13.4175 17.1652 12.3062 18 11 18H3C1.34315 18 0 16.6569 0 15V7Z" fill="#14B0FF"/>
            </svg>
        `
        button.insertAdjacentHTML('afterbegin', svg);
        return button;
    }
    static init() {
        const PARENT_ROWS = Previewer.getParentRows();
        PARENT_ROWS.forEach(parentRow => {
            let previewCell = document.createElement("td");
            previewCell.setAttribute("colspan", "100");
            let previewRow = document.createElement("tr");
            previewRow.classList.add("previewRow");
            let preview = JSON.parse(parentRow.closest('table').dataset["preview"])[0]
            let sourceDatasetName = preview.dataset;
            let sourceDatasetKey = preview.id;
            previewRow.setAttribute("data-dataset_name", sourceDatasetName);
            previewRow.setAttribute("data-dataset_col_id", sourceDatasetKey);
            previewRow.setAttribute("data-dataset_id", parentRow.dataset[sourceDatasetKey]);
            previewRow.style.display = "none";
            previewRow.appendChild(previewCell);
            if (!parentRow.classList.contains("int1")) {
                parentRow.insertAdjacentElement("afterend", previewRow);
            }
            parentRow.addEventListener("click", event => {
                if (parentRow.classList.contains('int1')) {
                    previewRow = parentRow.nextSibling.nextSibling;
                    previewCell = previewRow.firstChild;
                }
                if (
                    event.target.tagName.toLowerCase() !== 'a' &&
                    event.target.tagName.toLowerCase() !== 'rect' &&
                    event.target.tagName.toLowerCase() !== 'svg' &&
                    event.target.tagName.toLowerCase() !== 'path'
                ) {
                    if (previewRow.style.display === 'none') {
                        if (sourceDatasetName === "queries" || sourceDatasetName === "act_queries") {
                            let queryIndex = Previewer.findQuery(previewRow);
                            if (queryIndex >= 0) {
                                let queryText = data.datasets[sourceDatasetName][queryIndex].query_texts[0];
                                Previewer.queryTextPreviewer(previewCell, previewRow, parentRow, queryText);
                                if (!previewCell.querySelector('.copyQueryTextButton')) {
                                    let copyQueryTextButton = Previewer.drawCopyButton();
                                    copyQueryTextButton.setAttribute("class", "copyQueryTextButton");
                                    previewCell.appendChild(copyQueryTextButton);
                                    copyQueryTextButton.addEventListener("click", event => {
                                        navigator.clipboard.writeText(queryText).then(r => console.log(queryText));
                                    });
                                }
                            }
                        }
                        if (sourceDatasetName === "table_storage_parameters" || sourceDatasetName === "index_storage_parameters") {
                            let sourceDataset = data.datasets[sourceDatasetName]; 
                            let targetDatasetValue = parentRow.dataset[sourceDatasetKey];
                            let previewData = Utilities.find(sourceDataset, sourceDatasetKey, targetDatasetValue);
                            if (previewData.length) {
                                let previewDataJSON = JSON.stringify(previewData);
                                Previewer.storageParamsPreviewer(previewCell, previewRow, parentRow, previewData);
                            }
                        }
                    } else {
                        previewRow.style.display = 'none';
                    }
                }
            })
        })
    }
}
function buildReport(data, parentNode, deep) {
    data.sections.forEach(section => {
        let sectionHasNestedSections = ('sections' in section);
        let newSection = new BaseSection(section, deep).init();
        if (sectionHasNestedSections) {
            deep++;
            buildReport(section, newSection, deep);
            deep--;
        }
        parentNode.appendChild(newSection);
    })
    return parentNode;
}
function addDescription(data, parentNode) {
    if (data.properties.description) {
        let description = `
            <h3>Description:</h3>
            <p>${data.properties.description}</p>
        `;
        parentNode.insertAdjacentHTML('beforeend', description);
    }
    if (data.properties.server_description) {
        let server_description = `
            <h3>Server description:</h3>
            <p>${data.properties.server_description}</p>
        `;
        parentNode.insertAdjacentHTML('beforeend', server_description);
    }
}
function main() {
    const CONTAINER = document.getElementById('container');
    addDescription(data, CONTAINER);
    buildReport(data, CONTAINER, 1);
    Highlighter.init();
    Previewer.init();
    Menu.init();
}
main();$js$
),
('report',
  '<!DOCTYPE html>'
  '<html lang="en"><head>'
  '<style>{static:css}</style>'
  '<script>const logoFile=`{static:logo}`</script>'
  '<script>const logoMiniFile=`{static:logo_mini}`</script>'
  '<script>const data={dynamic:data1}</script>'
  '<title>Postgres profile report ({properties:start1_id} -'
  ' {properties:end1_id})</title></head><body>'
  '<div id="container">'
  '</div>'
  '<script>{static:script_js}</script>'
  '</body></html>'),
('diffreport',
  '<!DOCTYPE html>'
  '<html lang="en"><head>'
  '<style>{static:css}</style>'
  '<script>const logoFile=`{static:logo}`</script>'
  '<script>const logoMiniFile=`{static:logo_mini}`</script>'
  '<script>const data={dynamic:data1}</script>'
  '<title>Postgres profile differential report (1): ({properties:start1_id} -'
  ' {properties:end1_id}) with (2): ({properties:start2_id} -'
  ' {properties:end2_id})</title></head><body>'
  '<div id="container">'
  '</div>'
  '<script>{static:script_js}</script>'
  '</body></html>')
;
/* === report table data === */
INSERT INTO report(report_id, report_name, report_description, template)
VALUES
(1, 'report', 'Regular single interval report', 'report'),
(2, 'diffreport', 'Differential report on two intervals', 'diffreport')
;
/* === report_struct table data === */
-- Regular report
INSERT INTO report_struct (
  report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
  content, sect_struct)
VALUES
(1, 'rep_details', NULL, 10, 'Report details', 'Report details', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "properties",'
    '"columns": ['
        '{"id": "pgprofile_version", "class": "table_obj_value", "caption": "Version"},'
        '{"id": "server_name", "class": "table_obj_value", "caption": "Server name"},'
        '{"caption": "Interval (sample)", "class": "table_obj_value", "columns": ['
          '{"id": "start1_id", "class": "table_obj_value", "caption": "start"},'
          '{"id": "end1_id", "class": "table_obj_value", "caption": "end"}'
        ']},'
        '{"caption": "Interval (time)", "class": "table_obj_value", "columns": ['
          '{"id": "report_start1", "class": "table_obj_value", "caption": "start"},'
          '{"id": "report_end1", "class": "table_obj_value", "caption": "end"}'
        ']}'
    ']}'
  ']'::jsonb),
(1, 'rep_settings', NULL, 11, NULL, NULL, NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "settings",'
    '"filter": {"type": "exists", "field": "h_ord"},'
    '"ordering": "h_ord",'
    '"columns": ['
      '{"caption": "Setting", "id": "name", "class": "table_obj_name"},'
      '{"caption": "Value", "id": "reset_val", "class": "table_obj_value"}'
    ']'
  '}]'::jsonb),
(1, 'stmt_cmt1', NULL, 100, NULL, NULL, 'stmt_cnt_range', NULL,
  '{"class": "warning", "text": "This interval contains sample(s) with captured statements count more than 90% of pg_stat_statements.max parameter. '
  'Consider increasing pg_stat_statements.max parameter"}',
  '[{'
  '"type": "row_table", '
  '"source": "stmt_cnt_range",'
  '"ordering": "sample_id",'
  '"columns": ['
      '{"id": "sample_id", "class": "table_obj_value", "caption": "Sample ID"}, '
      '{"id": "sample_time", "class": "table_obj_value", "caption": "Sample Time"}, '
      '{"id": "stmt_cnt", "class": "table_obj_value", "caption": "Stmts Captured"}, '
      '{"id": "max_cnt", "class": "table_obj_value", "caption": "pg_stat_statements.max"}'
  ']}]'::jsonb),
(1, 'srvstat', NULL, 200, 'Server statistics', 'Server statistics', NULL, NULL, NULL, NULL),
(1, 'actsesshdr', NULL, 250, 'Session states', 'Session states observed by subsamples', 'act_backend', NULL,
  '{"class": "notice", "text": "Statistics about session states exceeding capturing thresholds."}', NULL),
(1, 'sqlsthdr', NULL, 300, 'SQL query statistics', 'SQL query statistics', 'statstatements', NULL, NULL, NULL),
(1, 'objects', NULL, 400, 'Schema object statistics', 'Schema object statistics', NULL, NULL, NULL, NULL),
(1, 'funchdr', NULL, 500, 'User function statistics', 'User function statistics', 'function_stats', NULL, NULL, NULL),
(1, 'vachdr', NULL, 600, 'Vacuum-related statistics', 'Vacuum-related statistics', NULL, NULL, NULL, NULL),
(1, 'settings', NULL, 700, 'Cluster settings', 'Cluster settings during the report interval', NULL, NULL, NULL, NULL),
(1, 'extensions', NULL, 750, 'Extension versions', 'Extension versions during the report interval', NULL, NULL, NULL, NULL),
(1, 'stmt_warn', NULL, 800, NULL, 'Warning!', 'stmt_cnt_all', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "stmt_cnt_all",'
    '"ordering": "sample_id",'
    '"columns": ['
        '{"id": "sample_id", "class": "table_obj_value", "caption": "Sample ID"}, '
        '{"id": "sample_time", "class": "table_obj_value", "caption": "Sample Time"}, '
        '{"id": "stmt_cnt", "class": "table_obj_value", "caption": "Stmts Captured"}, '
        '{"id": "max_cnt", "class": "table_obj_value", "caption": "pg_stat_statements.max"}'
    ']}]'::jsonb)
;

-- Server section of regular report
INSERT INTO report_struct (
  report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
  content, sect_struct)
VALUES
(1, 'dbstat', 'srvstat', 100, 'Database statistics', 'Database statistics', NULL, NULL, NULL, NULL),
(1, 'dbstatreset', 'dbstat', 200, NULL, NULL, 'dbstats_reset', NULL,
  '{"class": "warning", "text": "Database statistics reset detected during report interval! Statistics for listed databases and contained objects might be affected"}',
  '[{'
    '"type": "row_table",'
    '"source": "dbstats_reset",'
    '"ordering": "sample_id",'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name"},'
      '{"caption": "Sample", "id": "sample_id", "class": "table_obj_value"},'
      '{"caption": "Reset time", "id": "stats_reset", "class": "table_obj_value"}'
    ']'
  '}]'::jsonb),
(1, 'dbstatmain', 'dbstat', 300, NULL, NULL, NULL, NULL, NULL,
'[{'
    '"type": "row_table",'
    '"source": "dbstat",'
    '"ordering": "ord_db",'
    '"highlight": ['
      '{"id": "dbname", "index": 0}'
    '],'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name"},'
      '{"caption": "Transactions", "columns": ['
        '{"caption": "Commits", "id": "xact_commit", "class": "table_obj_value", '
          '"title": "Number of transactions in this database that have been committed"},'
        '{"caption": "Rollbacks", "id": "xact_rollback", "class": "table_obj_value", '
          '"title": "Number of transactions in this database that have been rolled back"},'
        '{"caption": "Deadlocks", "id": "deadlocks", "class": "table_obj_value", '
          '"title": "Number of deadlocks detected in this database"}'
     ']},'
      '{"caption": "Checksums", "condition": "checksum_fail_detected", "columns": ['
        '{"caption": "Failures", "id": "checksum_failures", "class": "table_obj_value", '
          '"title": "Number of block checksum failures detected"},'
        '{"caption": "Last", "id": "checksum_last_failure", "class": "table_obj_value", '
          '"title": "Last checksum failure detected"}'
     ']},'
      '{"caption": "Block statistics", "columns": ['
        '{"caption": "Hit(%)", "id": "blks_hit_pct", "class": "table_obj_value", '
          '"title": "Buffer cache hit ratio"},'
        '{"caption": "Read", "id": "blks_read", "class": "table_obj_value", '
          '"title": "Number of disk blocks read in this database"},'
        '{"caption": "Hit", "id": "blks_hit", "class": "table_obj_value", '
          '"title": "Number of times disk blocks were found already in the buffer cache"}'
     ']},'
      '{"caption": "Block I/O times", "condition": "io_times", "columns": ['
        '{"caption": "Read", "id": "blk_read_time", "class": "table_obj_value", '
          '"title": "Time spent reading data file blocks by backends, in seconds"},'
        '{"caption": "Write", "id": "blk_write_time", "class": "table_obj_value", '
          '"title": "Time spent writing data file blocks by backends, in seconds"}'
     ']},'
      '{"caption": "Tuples", "columns": ['
        '{"caption": "Ret", "id": "tup_returned", "class": "table_obj_value", '
          '"title": "Number of rows returned by queries in this database"},'
        '{"caption": "Fet", "id": "tup_fetched", "class": "table_obj_value", '
          '"title": "Number of rows fetched by queries in this database"},'
        '{"caption": "Ins", "id": "tup_inserted", "class": "table_obj_value", '
          '"title": "Number of rows inserted by queries in this database"},'
        '{"caption": "Upd", "id": "tup_updated", "class": "table_obj_value", '
          '"title": "Number of rows updated by queries in this database"},'
        '{"caption": "Del", "id": "tup_deleted", "class": "table_obj_value", '
          '"title": "Number of rows deleted"}'
     ']},'
     '{"caption": "Parallel workers", "condition": "db_parallel_workers", "columns": ['
        '{"caption": "Planned", "id": "parallel_workers_to_launch", "class": "table_obj_value", '
          '"title": "Number of parallel workers planned to be launched by queries on this database"},'
        '{"caption": "Launched", "id": "parallel_workers_launched", "class": "table_obj_value", '
          '"title": "Number of parallel workers launched by queries on this database"}'
     ']},'
      '{"caption": "Temp files", "columns": ['
        '{"caption": "Size", "id": "temp_bytes", "class": "table_obj_value", '
          '"title": "Total amount of data written to temporary files by queries in this database"},'
        '{"caption": "Files", "id": "temp_files", "class": "table_obj_value", '
          '"title": "Number of temporary files created by queries in this database"}'
     ']},'
     '{"caption": "Size", "id": "datsize", "class": "table_obj_value", '
       '"title": "Database size as is was at the moment of last sample in report interval"},'
     '{"caption": "Growth", "id": "datsize_delta", "class": "table_obj_value", '
       '"title": "Database size increment during report interval"}'
    ']'
  '}]'::jsonb),
(1, 'iostat', 'srvstat', 328, 'Cluster I/O statistics', 'Cluster I/O statistics', 'stat_io', NULL, NULL, NULL),
(1, 'iostatrst', 'srvstat', 329, NULL, NULL, 'stat_io_reset', NULL,
  '{"class": "warning", "text": "IO stats reset was detected during report interval. Statistic values may be affected"}',
  '[{'
    '"type": "row_table",'
    '"source": "stat_io_reset",'
    '"columns": ['
      '{"caption": "Sample ID", "id": "sample_id", "class": "table_obj_name", '
        '"title": "Sample identifier with detected reset"},'
      '{"caption": "Object", "id": "object", "class": "table_obj_name", '
        '"title": "Target object of an I/O operation"},'
      '{"caption": "Backend", "id": "backend_type", "class": "table_obj_name", '
        '"title": "Type of backend (see stat_activity)"},'
      '{"caption": "Context", "id": "context", "class": "table_obj_name", '
        '"title": "The context of an I/O operation"},'
      '{"caption": "Reset time", "id": "stats_reset", "class": "table_obj_value", '
        '"title": "Date and time of the last reset performed in sample"}'
    ']'
    '}]'::jsonb),
(1, 'iostatmain', 'srvstat', 330, NULL, NULL, 'stat_io', NULL, NULL,
'[{'
    '"type": "row_table",'
    '"source": "stat_io",'
    '"columns": ['
      '{"caption": "Object", "id": "object", "class": "table_obj_name", '
        '"title": "Target object of an I/O operation"},'
      '{"caption": "Backend", "id": "backend_type", "class": "table_obj_name", '
        '"title": "Type of backend (see stat_activity)"},'
      '{"caption": "Context", "id": "context", "class": "table_obj_name", '
        '"title": "The context of an I/O operation"},'
      '{"caption": "Reads", "columns": ['
        '{"caption": "Count", "id": "reads", "class": "table_obj_value", '
          '"title": "Number of read operations"},'
        '{"caption": "Bytes", "id": "read_sz", "class": "table_obj_value", '
          '"title": "Read data amount"},'
        '{"caption": "Time", "id": "read_time", "class": "table_obj_value", '
          '"condition": "io_times", '
          '"title": "Time spent in reading operation (seconds)"}'
     ']},'
      '{"caption": "Writes", "columns": ['
        '{"caption": "Count", "id": "writes", "class": "table_obj_value", '
          '"title": "Number of write operations"},'
        '{"caption": "Bytes", "id": "write_sz", "class": "table_obj_value", '
          '"title": "Written data amount"},'
        '{"caption": "Time", "id": "write_time", "class": "table_obj_value", '
          '"condition": "io_times", '
          '"title": "Time spent in writing operations (seconds)"}'
     ']},'
      '{"caption": "Writebacks", "columns": ['
        '{"caption": "Count", "id": "writebacks", "class": "table_obj_value", '
          '"title": "Number of blocks which the process requested the kernel write out to permanent storage"},'
        '{"caption": "Bytes", "id": "writeback_sz", "class": "table_obj_value", '
          '"title": "The amount of data requested for write out to permanent storage"},'
        '{"caption": "Time", "id": "writeback_time", "class": "table_obj_value", '
          '"condition": "io_times", '
          '"title": "Time spent in writeback operations (seconds)"}'
     ']},'
      '{"caption": "Extends", "columns": ['
        '{"caption": "Count", "id": "extends", "class": "table_obj_value", '
          '"title": "Number of relation extend operations"},'
        '{"caption": "Bytes", "id": "extend_sz", "class": "table_obj_value", '
          '"title": "The amount of space used by extend operations"},'
        '{"caption": "Time", "id": "extend_time", "class": "table_obj_value", '
          '"condition": "io_times", '
          '"title": "Time spent in extend operations (seconds)"}'
     ']},'
     '{"caption": "Hits", "id": "hits", "class": "table_obj_value", '
       '"title": "The number of times a desired block was found in a shared buffer"},'
     '{"caption": "Evictions", "id": "evictions", "class": "table_obj_value", '
       '"title": "Number of times a block has been written out from a shared or local buffer in order to make it available for another use"},'
     '{"caption": "Reuses", "id": "reuses", "class": "table_obj_value", '
       '"title": "The number of times an existing buffer in a size-limited ring buffer outside of shared buffers was reused as part of an I/O operation in the bulkread, bulkwrite, or vacuum contexts"},'
      '{"caption": "Fsyncs", "columns": ['
        '{"caption": "Count", "id": "fsyncs", "class": "table_obj_value", '
          '"title": "Number of fsync calls. These are only tracked in context normal"},'
        '{"caption": "Time", "id": "fsync_time", "class": "table_obj_value", '
          '"condition": "io_times", '
          '"title": "Time spent in fsync operations (seconds)"}'
     ']}'
    ']'
    '}]'::jsonb),
(1, 'slrustat', 'srvstat', 358, 'Cluster SLRU statistics', 'Cluster SLRU statistics', 'stat_slru', NULL, NULL, NULL),
(1, 'slrustatrst', 'slrustat', 359, NULL, NULL, 'stat_slru_reset', NULL,
    '{"class": "warning", "text": "SLRU stats reset was detected during report interval. Statistic values may be affected"}',
    '[{'
    '"type": "row_table",'
    '"source": "stat_slru_reset",'
    '"columns": ['
      '{"caption": "Sample ID", "id": "sample_id", "class": "table_obj_name", '
        '"title": "Sample identifier with detected reset"},'
      '{"caption": "Name", "id": "name", "class": "table_obj_name", '
        '"title": "Name of the SLRU"},'
      '{"caption": "Reset time", "id": "stats_reset", "class": "table_obj_value", '
        '"title": "Date and time of the last reset performed in sample"}'
    ']'
    '}]'::jsonb),
(1, 'slrustatmain', 'slrustat', 360, NULL, NULL, 'stat_slru', NULL, NULL,
'[{'
    '"type": "row_table",'
    '"source": "stat_slru",'
    '"columns": ['
      '{"caption": "Name", "id": "name", "class": "table_obj_name", '
        '"title": "Name of the SLRU"},'
      '{"caption": "Zeroed", "id": "blks_zeroed", "class": "table_obj_value", '
        '"title": "Number of blocks zeroed during initializations"},'
      '{"caption": "Hits", "id": "blks_hit", "class": "table_obj_value", '
        '"title": "Number of times disk blocks were found already in the SLRU, so that a '
        'read was not necessary (this only includes hits in the SLRU, not the operating '
        'system''s file system cache)"},'
      '{"caption": "Reads", "id": "blks_read", "class": "table_obj_value", '
        '"title": "Number of disk blocks read for this SLRU"},'
      '{"caption": "%Hit", "id": "hit_pct", "class": "table_obj_value", '
        '"title": "Number of disk blocks hits for this SLRU as a percentage of reads + hits"},'
      '{"caption": "Writes", "id": "blks_written", "class": "table_obj_value", '
        '"title": "Number of disk blocks written for this SLRU"},'
      '{"caption": "Checked", "id": "blks_exists", "class": "table_obj_value", '
        '"title": "Number of blocks checked for existence for this SLRU (blks_exists field)"},'
      '{"caption": "Flushes", "id": "flushes", "class": "table_obj_value", '
        '"title": "Number of flushes of dirty data for this SLRU"},'
      '{"caption": "Truncates", "id": "truncates", "class": "table_obj_value", '
        '"title": "Number of truncates for this SLRU"}'
    ']'
    '}]'::jsonb),
(1, 'sesstat', 'srvstat', 400, 'Session statistics by database', 'Session statistics by database', 'sess_stats', NULL, NULL,
'[{'
    '"type": "row_table",'
    '"source": "dbstat",'
    '"ordering": "ord_db",'
    '"highlight": ['
      '{"id": "dbname", "index": 0}'
    '],'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name"},'
      '{"caption": "Timings", "columns": ['
        '{"caption": "Total", "id": "session_time", "class": "table_obj_value", '
          '"title": "Time spent by database sessions in this database (note that statistic are only updated when the state of a session changes, so if sessions have been idle for a long time, this idle time will not be included)"},'
        '{"caption": "Active", "id": "active_time", "class": "table_obj_value", '
          '"title": "Time spent executing SQL statements in this database (this corresponds to the states active and fastpath function call in pg_stat_activity)"},'
        '{"caption": "Idle", "id": "idle_in_transaction_time", "class": "table_obj_value", '
          '"title": "Time spent idling while in a transaction in this database (this corresponds to the states idle in transaction and idle in transaction (aborted) in pg_stat_activity)"}'
     ']},'
     '{"caption": "Sessions", "columns": ['
        '{"caption": "Established", "id": "sessions", "class": "table_obj_value", '
          '"title": "Total number of sessions established to this database"},'
        '{"caption": "Abondoned", "id": "sessions_abandoned", "class": "table_obj_value", '
          '"title": "Number of database sessions to this database that were terminated because connection to the client was lost"},'
        '{"caption": "Fatal", "id": "sessions_fatal", "class": "table_obj_value", '
          '"title": "Number of database sessions to this database that were terminated by fatal errors"},'
        '{"caption": "Killed", "id": "sessions_killed", "class": "table_obj_value", '
          '"title": "Number of database sessions to this database that were terminated by operator intervention"}'
     ']}'
    ']'
    '}]'::jsonb),
(1, 'stmtstat', 'srvstat', 500, 'Statement statistics by database', 'Statement statistics by database', 'statstatements', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "statements_dbstats",'
    '"ordering": "ord_db",'
    '"highlight": ['
      '{"id": "dbname", "index": 0}'
    '],'
    '"columns": ['
        '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
        '{"id": "calls", "class": "table_obj_value", "title": "Number of query executions", "caption": "Calls"}, '
        '{"caption": "Time (s)", "columns": ['
            '{"id": "total_plan_time", "class": "table_obj_value", "title": "Time spent planning queries", "caption": "Plan", "condition": "planning_times"}, '
            '{"id": "total_exec_time", "class": "table_obj_value", "title": "Time spent executing queries", "caption": "Exec"}, '
            '{"id": "shared_blk_read_time", "class": "table_obj_value", "title": "Time spent reading blocks", "caption": "Read"}, '
            '{"id": "shared_blk_write_time", "class": "table_obj_value", "title": "Time spent writing blocks", "caption": "Write"}, '
            '{"id": "trg_fn_total_time", "class": "table_obj_value", "title": "Time spent in trigger functions", "caption": "Trg"}'
            ']}, '
        '{"caption": "Temp I/O Time", "condition": "statements_temp_io_times", "columns": ['
            '{"id": "temp_blk_read_time", "class": "table_obj_value", "title": "Time spent reading temporary file blocks, in seconds", "caption": "Read"}, '
            '{"id": "temp_blk_write_time", "class": "table_obj_value", "title": "Time spent writing temporary file blocks, in seconds", "caption": "Write"} '
            ']}, '
        '{"title": "Number of blocks fetched (hit + read)", "caption": "Fetched (blk)", "columns": ['
            '{"id": "shared_gets", "class": "table_obj_value", "caption": "Shared"}, '
            '{"id": "local_gets", "class": "table_obj_value", "caption": "Local"}'
            ']}, '
        '{"title": "Number of blocks read", "caption": "Read (blk)", "columns": ['
            '{"id": "shared_reads", "class": "table_obj_value", "caption": "Shared"}, '
            '{"id": "local_reads", "class": "table_obj_value", "caption": "Local"}'
            ']}, '
        '{"title": "Number of blocks dirtied", "caption": "Dirtied (blk)", "columns": ['
            '{"id": "shared_blks_dirtied", "class": "table_obj_value", "caption": "Shared"}, '
            '{"id": "local_blks_dirtied", "class": "table_obj_value", "caption": "Local"}'
            ']}, '
        '{"title": "Number of blocks, used in operations (like sorts and joins)", "caption": "Temp (blk)", "columns": ['
            '{"id": "temp_blks_read", "class": "table_obj_value", "caption": "Read"}, '
            '{"id": "temp_blks_written", "class": "table_obj_value", "caption": "Write"}'
            ']}, '
        '{"title": "Number of blocks, used for temporary tables", "caption": "Local (blk)", "columns": ['
            '{"id": "local_blks_read", "class": "table_obj_value", "caption": "Read"}, '
            '{"id": "local_blks_written", "class": "table_obj_value", "caption": "Write"}'
            ']}, '
        '{"id": "statements", "class": "table_obj_value", "caption": "Statements"}, '
        '{"id": "wal_bytes_fmt", "class": "table_obj_value", "caption": "WAL size", "condition": "statement_wal_bytes"}, '
        '{"id": "wal_buffers_full", "class": "table_obj_value", "title": "Number of times the WAL buffers became full", "caption": "WAL buffers full", "condition": "wal_buffers_full"}'
    ']}]'::jsonb),
(1, 'stmtminmax', 'srvstat', 520, 'Statement average min/max timings', 'Statement average min/max timings', 'mean_mm_times', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "statements_dbstats",'
    '"ordering": "ord_db",'
    '"highlight": ['
      '{"id": "dbname", "index": 0}'
    '],'
    '"columns": ['
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"caption": "Average planning times (ms)", "condition": "planning_times", "columns": ['
          '{"id": "mean_min_plan_time", "class": "table_obj_value", "title": "The average value of min_plan_time for all statements", "caption": "Min (ms.)"}, '
          '{"id": "mean_max_plan_time", "class": "table_obj_value", "title": "The average value of max_plan_time for all statements", "caption": "Max (ms.)"}, '
          '{"id": "min_max_plan_delta", "class": "table_obj_value", "title": "Mean max planning time to mean min planning time delta as a percentage of mean min planning time", "caption": "Delta%"} '
      ']}, '
      '{"caption": "Average execution times (ms)", "columns": ['
          '{"id": "mean_min_exec_time", "class": "table_obj_value", "title": "The average value of min_exec_time for all statements", "caption": "Min (ms.)"}, '
          '{"id": "mean_max_exec_time", "class": "table_obj_value", "title": "The average value of max_exec_time for all statements", "caption": "Max (ms.)"}, '
          '{"id": "min_max_exec_delta", "class": "table_obj_value", "title": "Mean max exec time to mean min exec time delta as a percentage of mean min exec time", "caption": "Delta%"} '
      ']}, '
      '{"id": "statements", "class": "table_obj_value", "caption": "Statements"} '
    ']}]'::jsonb),
(1, 'dbjitstat', 'srvstat', 550, 'JIT statistics by database', 'JIT statistics by database', 'statements_jit_stats', NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "statements_dbstats",'
    '"ordering": "ord_db",'
    '"highlight": ['
      '{"id": "dbname", "index": 0}'
    '],'
    '"columns": ['
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "calls", "class": "table_obj_value", "title": "Number of query executions", "caption": "Calls"}, '
      '{"caption": "Time", "columns": ['
          '{"id": "total_plan_time", "class": "table_obj_value", "title": "Time spent planning queries", "caption": "Plan"}, '
          '{"id": "total_exec_time", "class": "table_obj_value", "title": "Time spent executing queries", "caption": "Exec"}'
          ']}, '
      '{"caption": "Generation", "columns": ['
          '{"id": "jit_functions", "class": "table_obj_value", "title": "Total number of functions JIT-compiled by the statements", "caption": "Count"}, '
          '{"id": "jit_generation_time", "class": "table_obj_value", "title": "Time spent by the statements on generating JIT code", "caption": "Time"}'
          ']}, '
      '{"caption": "Inlining", "columns": ['
          '{"id": "jit_inlining_count", "class": "table_obj_value", "title": "Number of times functions have been inlined", "caption": "Count"}, '
          '{"id": "jit_inlining_time", "class": "table_obj_value", "title": "Time spent by statements on inlining functions", "caption": "Time"}'
          ']}, '
      '{"caption": "Optimization", "columns": ['
          '{"id": "jit_optimization_count", "class": "table_obj_value", "title": "Number of times statements hasbeen optimized", "caption": "Count"}, '
          '{"id": "jit_optimization_time", "class": "table_obj_value", "title": "Time spent by statements on optimizing", "caption": "Time"}'
          ']}, '
      '{"caption": "Emission", "columns": ['
          '{"id": "jit_emission_count", "class": "table_obj_value", "title": "Number of times code has been emitted", "caption": "Count"}, '
          '{"id": "jit_emission_time", "class": "table_obj_value", "title": "Time spent by the statement on emitting code", "caption": "Time"}'
          ']}, '
      '{"caption": "Deform", "condition": "statements_jit_deform", "columns": ['
          '{"id": "jit_deform_count", "class": "table_obj_value", "caption": "Count", "title": "Number of tuple deform functions JIT-compiled by the statement of the database."}, '
          '{"id": "jit_deform_time", "class": "table_obj_value", "caption": "Time", "title": "Total time spent by the statements of the databse on JIT-compiling tuple deform functions, in seconds."}'
          ']}'
      ']'
    '}]'::jsonb),
(1, 'clusthdr', 'srvstat', 700, 'Cluster statistics', 'Cluster statistics', NULL, NULL, NULL, NULL),
(1, 'clustrst', 'srvstat', 800, NULL, NULL, 'cluster_stats_reset', NULL,
  '{"class": "warning", "text": "Cluster statistics reset detected during report interval! Cluster statistics might be affected"}',
  '[{'
    '"type": "row_table",'
    '"source": "cluster_stats_reset",'
    '"columns": ['
        '{"id": "sample_id", "class": "table_obj_value", "caption": "Sample"}, '
        '{"id": "bgwriter_stats_reset", "class": "table_obj_value", "caption": "BGWriter reset time"}, '
        '{"id": "checkpoint_stats_reset", "class": "table_obj_value", "caption": "Checkpointer reset time"}, '
        '{"id": "archiver_stats_reset", "class": "table_obj_value", "caption": "Archiver reset time"}'
        ']'
    '}]'::jsonb),
(1, 'clust', 'srvstat', 900, NULL, NULL, NULL, NULL, NULL,
  '[{'
    '"type": "column_table", '
    '"source": "cluster_stats",'
    '"columns": ['
        '{"caption": "Metric", "class": "table_obj_name"}, '
        '{"caption": "Value", "class": "table_obj_value"}'
    '],'
    '"rows": ['
        '{"caption": "Scheduled checkpoints", "cells": ['
            '{"id": "checkpoints_timed"}'
        ']}, '
        '{"caption": "Requested checkpoints", "cells": ['
            '{"id": "checkpoints_req"}'
        ']}, '
        '{"caption": "Checkpoints done", "condition": "checkpoints_done_and_slru", "cells": ['
            '{"id": "checkpoints_done"}'
        ']}, '
        '{"caption": "Scheduled restartpoints", "condition": "restartpoints", "cells": ['
            '{"id": "restartpoints_timed"}'
        ']}, '
        '{"caption": "Requested restartpoints", "condition": "restartpoints", "cells": ['
            '{"id": "restartpoints_req"}'
        ']}, '
        '{"caption": "Restartpoints done", "condition": "restartpoints", "cells": ['
            '{"id": "restartpoints_done"}'
        ']}, '
        '{"caption": "Checkpoint write time (s)", "cells": ['
            '{"id": "checkpoint_write_time"}'
        ']}, '
        '{"caption": "Checkpoint sync time (s)", "cells": ['
            '{"id": "checkpoint_sync_time"}'
        ']}, '
        '{"caption": "Checkpoint buffers written", "cells": ['
            '{"id": "buffers_checkpoint"}'
        ']}, '
        '{"caption": "SLRU buffers written by checkpoint", "condition": "checkpoints_done_and_slru", "cells": ['
            '{"id": "slru_checkpoint"}'
        ']}, '
        '{"caption": "Background buffers written", "cells": ['
            '{"id": "buffers_clean"}'
        ']}, '
        '{"caption": "Backend buffers written", "condition": "buffers_backend", "cells": ['
            '{"id": "buffers_backend"}'
        ']}, '
        '{"caption": "Backend fsync count", "condition": "buffers_backend", "cells": ['
            '{"id": "buffers_backend_fsync"}'
        ']}, '
        '{"caption": "Bgwriter interrupts (too many buffers)", "cells": ['
            '{"id": "maxwritten_clean"}'
        ']}, '
        '{"caption": "Number of buffers allocated", "cells": ['
            '{"id": "buffers_alloc"}'
        ']}, '
        '{"caption": "WAL generated", "cells": ['
            '{"id": "wal_size_pretty"}'
        ']}, '
        '{"caption": "Start LSN", "cells": ['
            '{"id": "start_lsn"}'
        ']}, '
        '{"caption": "End LSN", "cells": ['
            '{"id": "end_lsn"}'
        ']}, '
        '{"caption": "WAL segments archived", "cells": ['
            '{"id": "archived_count"}'
        ']}, '
        '{"caption": "WAL segments archive failed", "cells": ['
            '{"id": "failed_count"}'
        ']}'
    ']'
  '}]'::jsonb),
(1, 'walsthdr', 'srvstat', 1000, 'WAL statistics', 'WAL statistics', 'wal_stats', NULL, NULL, NULL),
(1, 'walstrst', 'srvstat', 1100, NULL, NULL, 'wal_stats_reset', NULL,
  '{"class": "warning", "text": "WAL statistics reset detected during report interval! WAL statistics might be affected"}',
  '[{'
    '"type": "row_table",'
    '"source": "wal_stats_reset",'
    '"columns": ['
        '{"id": "sample_id", "class": "table_obj_value", "caption": "Sample"},'
        '{"id": "wal_stats_reset", "class": "table_obj_value", "caption": "WAL stats reset time"}'
    ']}]'::jsonb),
(1, 'walst', 'srvstat', 1200, NULL, NULL, 'wal_stats', NULL, NULL,
  '[{'
    '"type": "column_table",'
    '"source": "wal_stats",'
    '"columns": ['
        '{"caption": "Metric", "class": "table_obj_name"},'
        '{"caption": "Value", "class": "table_obj_value"}'
    '],'
    '"rows": ['
        '{"caption": "WAL generated", "title": "Total amount of WAL generated", "cells": ['
            '{"id": "wal_bytes_text"}'
        ']},'
        '{"caption": "WAL per second", "title": "Average amount of WAL generated per second", "cells": ['
            '{"id": "wal_bytes_per_sec"}'
        ']},'
        '{"caption": "WAL records", "title": "Total number of WAL records generated", "cells": ['
            '{"id": "wal_records"}'
        ']},'
        '{"caption": "WAL FPI", "title": "Total number of WAL full page images generated", "cells": ['
            '{"id": "wal_fpi"}'
        ']},'
        '{"caption": "WAL buffers full", "title": "Number of times WAL data was written to disk because WAL buffers became full", "cells": ['
            '{"id": "wal_buffers_full"}'
        ']},'
        '{"caption": "WAL writes", "title": "Number of times WAL buffers were written out to disk via XLogWrite request", "cells": ['
            '{"id": "wal_write"}'
        ']},'
        '{"caption": "WAL writes per second", "title": "Average number of times WAL buffers were written out to disk via XLogWrite request per second", "cells": ['
            '{"id": "wal_write_per_sec"}'
        ']},'
        '{"caption": "WAL sync", "title": "Number of times WAL files were synced to disk via issue_xlog_fsync request (if fsync is on and wal_sync_method is either fdatasync, fsync or fsync_writethrough, otherwise zero)", "cells": ['
            '{"id": "wal_sync"}'
        ']},'
        '{"caption": "WAL syncs per second", "title": "Average number of times WAL files were synced to disk via issue_xlog_fsync request per second", "cells": ['
            '{"id": "wal_sync_per_sec"}'
        ']},'
        '{"caption": "WAL write time (s)", "title": "Total amount of time spent writing WAL buffers to disk via XLogWrite request, in seconds (if track_wal_io_timing is enabled, otherwise zero). This includes the sync time when wal_sync_method is either open_datasync or open_sync", "cells": ['
            '{"id": "wal_write_time"}'
        ']},'
        '{"caption": "WAL write duty", "title": "WAL write time as a percentage of the report duration time", "cells": ['
            '{"id": "wal_write_time_per_sec"}'
        ']},'
        '{"caption": "WAL sync time (s)", "title": "Total amount of time spent syncing WAL files to disk via issue_xlog_fsync request, in seconds (if track_wal_io_timing is enabled, fsync is on, and wal_sync_method is either fdatasync, fsync or fsync_writethrough, otherwise zero)", "cells": ['
            '{"id": "wal_sync_time"}'
        ']},'
        '{"caption": "WAL sync duty", "title": "WAL sync time as a percentage of the report duration time", "cells": ['
            '{"id": "wal_sync_time_per_sec"}'
        ']}'
    ']'
  '}]'::jsonb),
(1, 'tbspst', 'srvstat', 1400, 'Tablespace statistics', 'Tablespace statistics', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "tablespace_stats",'
    '"ordering": "tablespacename",'
    '"columns": ['
      '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name"},'
      '{"caption": "Path", "id": "tablespacepath", "class": "table_obj_value"},'
      '{"caption": "Size", "id": "size", "class": "table_obj_value", '
      '"title": "Tablespace size as it was at the moment of last sample in report interval"},'
      '{"caption": "Growth", "id": "size_delta", "class": "table_obj_value", '
      '"title": "Tablespace size increment during report interval"}'
    ']'
  '}]'::jsonb),
(1, 'wait_sampling_srvstats', 'srvstat', 1500, 'Wait sampling', 'Wait sampling', 'wait_sampling_tot', NULL, NULL, NULL),
(1, 'wait_sampling_total', 'wait_sampling_srvstats', 100, 'Wait events types', 'Wait events types', 'wait_sampling_tot', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "wait_sampling_total_stats",'
    '"ordering": "event_type_order",'
    '"columns": ['
      '{"id": "event_type", "class": "table_obj_name", "caption": "Wait event type"}, '
      '{"id": "stmt_waited", "class": "table_obj_value", "title": "Time, waited in events of wait event type executing statements in seconds", "caption": "Statements Waited (s)"}, '
      '{"id": "stmt_waited_pct", "class": "table_obj_value", "title": "Time, waited in events of wait event type as a percentage of total time waited in a cluster executing statements", "caption": "%Total"}, '
      '{"id": "tot_waited", "class": "table_obj_value", "title": "Time, waited in events of wait event type by all backends (including background activity) in seconds", "caption": "All Waited (s)"}, '
      '{"id": "tot_waited_pct", "class": "table_obj_value", "title": "Time, waited in events of wait event type as a percentage of total time waited in a cluster by all backends (including background activity)", "caption": "%Total"}'
    ']}]'::jsonb),
(1, 'wait_sampling_statements', 'wait_sampling_srvstats', 200, 'Top wait events (statements)', 'Top wait events (statements)', 'wait_sampling_tot', NULL,
 '{"class": "notice", "text": "Top wait events detected in statements execution"}',
  '[{'
    '"type": "row_table", '
    '"source": "wait_sampling_events",'
    '"filter": {"type": "exists", "field": "stmt_filter"},'
    '"ordering": "-stmt_waited",'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "event_type", "class": "table_obj_name", "caption": "Wait event type"}, '
      '{"id": "event", "class": "table_obj_name", "caption": "Wait event"}, '
      '{"id": "stmt_waited", "class": "table_obj_value", "title": "Time, waited in event executing statements in seconds", "caption": "Waited (s)"}, '
      '{"id": "stmt_waited_pct", "class": "table_obj_value", "title": "Time, waited in event as a percentage of total time waited in a cluster executing statements", "caption": "%Total"}'
  ']}]'::jsonb),
(1, 'wait_sampling_all', 'wait_sampling_srvstats', 300, 'Top wait events (All)', 'Top wait events (All)', 'wait_sampling_tot', NULL,
 '{"class": "notice", "text": "Top wait events detected in all backends"}',
  '[{'
    '"type": "row_table", '
    '"source": "wait_sampling_events",'
    '"filter": {"type": "exists", "field": "total_filter"},'
    '"ordering": "-tot_waited",'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "event_type", "class": "table_obj_name", "caption": "Wait event type"}, '
      '{"id": "event", "class": "table_obj_name", "caption": "Wait event"}, '
      '{"id": "tot_waited", "class": "table_obj_value", "title": "Time, waited in event by all backends (including background activity) in seconds", "caption": "Waited (s)"}, '
      '{"id": "tot_waited_pct", "class": "table_obj_value", "title": "Time, waited in event by all backends as a percentage of total time waited in a cluster by all backends (including background activity)", "caption": "%Total"}'
  ']}]'::jsonb)
;

-- Subsamples-based section of regular reports
INSERT INTO report_struct (
  report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
  content, sect_struct)
VALUES
(1, 'act_chart', 'actsesshdr', 50, 'Chart with session state', 'Chart with session state', 'act_backend', NULL,
  NULL,
'[{'
    '"type": "chart",'
    '"source": "act_top_states",'
    '"class": "act_chart"'
    '}]'::jsonb),
(1, 'db_activity_agg', 'actsesshdr', 100, 'Session state statistics by database', 'Session state statistics by database', 'act_backend', NULL,
  NULL,
'[{'
    '"type": "row_table",'
    '"source": "db_activity_agg",'
    '"ordering": "ord_db",'
    '"highlight": ['
      '{"id": "dbname", "index": 0}'
    '],'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name"},'
      '{"caption": "Summary", "columns": ['
        '{"caption": "Active", "id": "active_dur", "class": "table_obj_value", '
          '"title": "Summary time in ''active'' state"},'
        '{"caption": "Idle in xact", "id": "idle_xact_dur", "class": "table_obj_value", '
          '"title": "Summary time in ''idle in transaction'' state"},'
        '{"caption": "Idle in xact (A)", "id": "idle_xact_a_dur", "class": "table_obj_value", '
          '"title": "Summary time in ''idle in transaction (aborted)'' state"}'
     ']},'
      '{"caption": "Maximal", "columns": ['
        '{"caption": "Active", "id": "max_active_dur", "class": "table_obj_value", '
          '"title": "Longest detected ''active'' state"},'
        '{"caption": "Idle in xact", "id": "max_idle_xact_d", "class": "table_obj_value", '
          '"title": "Longest detected ''idle in xact'' state"},'
        '{"caption": "Idle in xact (A)", "id": "max_idle_xact_a_d", "class": "table_obj_value", '
          '"title": "Longest detected ''idle in transaction (aborted)'' state"},'
        '{"caption": "xact age", "id": "max_xact_age", "class": "table_obj_value", '
          '"title": "Maximal detected backend_xid age"}'
     ']}'
    ']'
    '}]'::jsonb),
(1, 'act_ix', 'actsesshdr', 200, 'Top ''idle in transaction'' states', 'Top ''idle in transaction'' session states by duration', 'act_ix', NULL,
  NULL,
'[{'
    '"type": "row_table",'
    '"source": "act_top_states",'
    '"ordering": "ord_dur",'
    '"limit": "topn",'
    '"highlight": ['
      '{"id": "pid", "index": 0},'
      '{"id": "state_change", "index": 0}'
    '],'
    '"preview": ['
      '{"id": "act_query_md5", "dataset": "act_queries"}'
    '],'
    '"scroll": ['
      '"pid", "xact_start_ut", "state_change_ut"'
    '],'
    '"filter": {"type": "equal", "field": "flt_state_code", "value": 1},'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name"},'
      '{"caption": "User", "id": "username", "class": "table_obj_name"},'
      '{"caption": "App", "id": "application_name", "class": "table_obj_name", '
        '"title": "application_name"},'
      '{"caption": "Addr", "id": "client_addr", "class": "table_obj_name", '
        '"title": "client_addr"},'
      '{"caption": "Pid", "id": "pid", "class": "table_obj_name"},'
      '{"caption": "Xact start", "id": "xact_start_format", "class": "table_obj_value"},'
      '{"caption": "State change", "id": "state_change_format", "class": "table_obj_value"},'
      '{"caption": "State duration", "id": "state_duration_format", "class": "table_obj_value"}'
    ']}]'::jsonb),
(1, 'act_ixa', 'actsesshdr', 300, 'Top ''idle in transaction (aborted)'' states', 'Top ''idle in transaction (aborted)'' session states by duration', 'act_ixa', NULL,
  NULL,
'[{'
    '"type": "row_table",'
    '"source": "act_top_states",'
    '"ordering": "ord_dur",'
    '"limit": "topn",'
    '"highlight": ['
      '{"id": "pid", "index": 0},'
      '{"id": "state_change", "index": 0}'
    '],'
    '"preview": ['
      '{"id": "act_query_md5", "dataset": "act_queries"}'
    '],'
    '"scroll": ['
      '"pid", "xact_start_ut", "state_change_ut"'
    '],'
    '"filter": {"type": "equal", "field": "flt_state_code", "value": 2},'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name"},'
      '{"caption": "User", "id": "username", "class": "table_obj_name"},'
      '{"caption": "App", "id": "application_name", "class": "table_obj_name", '
        '"title": "application_name"},'
      '{"caption": "Addr", "id": "client_addr", "class": "table_obj_name", '
        '"title": "client_addr"},'
      '{"caption": "Pid", "id": "pid", "class": "table_obj_name"},'
      '{"caption": "State change", "id": "state_change_format", "class": "table_obj_value"},'
      '{"caption": "State duration", "id": "state_duration_format", "class": "table_obj_value"}'
    ']}]'::jsonb),
(1, 'act_active', 'actsesshdr', 400, 'Top ''active'' states', 'Top ''active'' session states by duration', 'act_active', NULL,
  NULL,
'[{'
    '"type": "row_table",'
    '"source": "act_top_states",'
    '"ordering": "ord_dur",'
    '"limit": "topn",'
    '"highlight": ['
      '{"id": "pid", "index": 0},'
      '{"id": "state_change", "index": 0}'
    '],'
    '"preview": ['
      '{"id": "act_query_md5", "dataset": "act_queries"}'
    '],'
    '"scroll": ['
      '"pid", "xact_start_ut", "state_change_ut"'
    '],'
    '"filter": {"type": "equal", "field": "flt_state_code", "value": 3},'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name"},'
      '{"caption": "User", "id": "username", "class": "table_obj_name"},'
      '{"caption": "App", "id": "application_name", "class": "table_obj_name", '
        '"title": "application_name"},'
      '{"caption": "Addr", "id": "client_addr", "class": "table_obj_name", '
        '"title": "client_addr"},'
      '{"caption": "Pid", "id": "pid", "class": "table_obj_name"},'
      '{"caption": "Xact start", "id": "xact_start_format", "class": "table_obj_value"},'
      '{"caption": "State change", "id": "state_change_format", "class": "table_obj_value"},'
      '{"caption": "State duration", "id": "state_duration_format", "class": "table_obj_value"}'
    ']}]'::jsonb),
(1, 'act_age', 'actsesshdr', 500, 'Top states by transaction age', 'Top states by transaction age', 'act_backend', NULL,
  NULL,
'[{'
    '"type": "row_table",'
    '"source": "act_top_states",'
    '"ordering": "ord_age",'
    '"limit": "topn",'
    '"highlight": ['
      '{"id": "pid", "index": 0},'
      '{"id": "state_change", "index": 0}'
    '],'
    '"preview": ['
      '{"id": "act_query_md5", "dataset": "act_queries"}'
    '],'
    '"scroll": ['
      '"pid", "xact_start_ut", "state_change_ut"'
    '],'
    '"filter": {"type": "equal", "field": "flt_age", "value": true},'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name"},'
      '{"caption": "User", "id": "username", "class": "table_obj_name"},'
      '{"caption": "App", "id": "application_name", "class": "table_obj_name", '
        '"title": "application_name"},'
      '{"caption": "Addr", "id": "client_addr", "class": "table_obj_name", '
        '"title": "client_addr"},'
      '{"caption": "Pid", "id": "pid", "class": "table_obj_name"},'
      '{"caption": "Xact start", "id": "xact_start_format", "class": "table_obj_value"},'
      '{"caption": "Xact duration", "id": "xact_duration_format", "class": "table_obj_value"},'
      '{"caption": "Age", "id": "xmin_age", "class": "table_obj_value", '
        '"title": "Last detected age of backend_xmin"},'
      '{"caption": "State", "id": "state", "class": "table_obj_value"},'
      '{"caption": "State change", "id": "state_change_format", "class": "table_obj_value"},'
      '{"caption": "State duration", "id": "state_duration_format", "class": "table_obj_value"}'
    ']}]'::jsonb),
(1, 'act_xact_dur', 'actsesshdr', 600, 'Top states by transaction duration', 'Top states by transaction duration', 'act_backend', NULL,
  NULL,
'[{'
    '"type": "row_table",'
    '"source": "act_top_states",'
    '"ordering": "ord_xact",'
    '"limit": "topn",'
    '"highlight": ['
      '{"id": "pid", "index": 0},'
      '{"id": "state_change", "index": 0}'
    '],'
    '"preview": ['
      '{"id": "act_query_md5", "dataset": "act_queries"}'
    '],'
    '"scroll": ['
      '"pid", "xact_start_ut", "state_change_ut"'
    '],'
    '"filter": {"type": "equal", "field": "flt_age", "value": true},'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name"},'
      '{"caption": "User", "id": "username", "class": "table_obj_name"},'
      '{"caption": "App", "id": "application_name", "class": "table_obj_name", '
        '"title": "application_name"},'
      '{"caption": "Addr", "id": "client_addr", "class": "table_obj_name", '
        '"title": "client_addr"},'
      '{"caption": "Pid", "id": "pid", "class": "table_obj_name"},'
      '{"caption": "Xact start", "id": "xact_start_format", "class": "table_obj_value"},'
      '{"caption": "Xact duration", "id": "xact_duration_format", "class": "table_obj_value"},'
      '{"caption": "Age", "id": "xmin_age", "class": "table_obj_value", '
        '"title": "Last detected age of backend_xmin"},'
      '{"caption": "State", "id": "state", "class": "table_obj_value"},'
      '{"caption": "State change", "id": "state_change_format", "class": "table_obj_value"},'
      '{"caption": "State duration", "id": "state_duration_format", "class": "table_obj_value"}'
    ']}]'::jsonb)
;

-- Query section of regular report
INSERT INTO report_struct (
  report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
  content, sect_struct)
VALUES
(1, 'sqlela', 'sqlsthdr', 100, 'Top SQL by elapsed time', 'Top SQL by elapsed time', 'planning_times', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"ordering": "ord_total_time",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "total_time"},'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "table_obj_name queryId", "caption": "Query ID"}, '
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
      '{"id": "total_time_pct", "class": "table_obj_value", "title": "Elapsed time as a percentage of total cluster elapsed time", "caption": "%Total"}, '
      '{"caption": "Time (s)", "columns": ['
        '{"id": "total_time", "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed"}, '
        '{"id": "total_plan_time", "class": "table_obj_value", "title": "Time spent planning statement", "caption": "Plan"}, '
        '{"id": "total_exec_time", "class": "table_obj_value", "title": "Time spent executing statement", "caption": "Exec"}'
        ']}, '
      '{"id": "jit_total_time", "class": "jitTimeCell", "caption": "JIT, time (s)", "condition": "statements_jit_stats"}, '
      '{"class": "table_obj_name", "caption": "I/O time (s)", "condition": "io_times", "columns": ['
        '{"id": "shared_blk_read_time", "class": "table_obj_value", "title": "Time spent reading blocks by statement", "caption": "Read"}, '
        '{"id": "shared_blk_write_time", "class": "table_obj_value", "title": "Time spent writing blocks by statement", "caption": "Write"}'
        ']}, '
      '{"class": "table_obj_name", "caption": "CPU time (s)", "condition": "kcachestatements", "columns": ['
        '{"id": "user_time", "class": "table_obj_value", "caption": "Usr"}, '
        '{"id": "system_time", "class": "table_obj_value", "caption": "Sys"}'
        ']}, '
      '{"id": "plans", "class": "table_obj_value", "caption": "Plans", "title": "Number of times the statement was planned"}, '
      '{"id": "calls", "class": "table_obj_value", "caption": "Executions", "title": "Number of times the statement was executed"}, '
      '{"id": "stmt_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(1, 'sqlplan', 'sqlsthdr', 200, 'Top SQL by planning time', 'Top SQL by planning time', 'planning_times', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"ordering": "ord_plan_time",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "total_plan_time"},'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "table_obj_name queryId", "caption": "Query ID"}, '
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
      '{"id": "total_plan_time", "class": "table_obj_value", "title": "Time spent planning statement", "caption": "Plan elapsed (s)"}, '
      '{"id": "plan_time_pct", "class": "table_obj_value", "title": "Plan elapsed as a percentage of statement elapsed time", "caption": "%Elapsed"}, '
      '{"title": "Planning time statistics", "caption": "Plan times (ms)", "columns": ['
        '{"id": "mean_plan_time", "class": "table_obj_value", "caption": "Mean"}, '
        '{"id": "min_plan_time", "class": "table_obj_value", "caption": "Min"}, '
        '{"id": "max_plan_time", "class": "table_obj_value", "caption": "Max"}, '
        '{"id": "stddev_plan_time", "class": "table_obj_value", "caption": "StdErr"}'
      ']}, '
      '{"id": "plans", "class": "table_obj_value", "title": "Number of times the statement was planned", "caption": "Plans"}, '
      '{"id": "calls", "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": "stmt_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
      ']'
    '}]'::jsonb),
(1, 'sqlexec', 'sqlsthdr', 300, 'Top SQL by execution time', 'Top SQL by execution time', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"ordering": "ord_exec_time",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "total_exec_time"},'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "caption": "Query ID", "class": "table_obj_name queryId"}, '
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
      '{"id": "total_exec_time", "class": "table_obj_value", "title": "Time spent executing statement", "caption": "Exec (s)"}, '
      '{"id": "exec_time_pct", "class": "table_obj_value", "title": "Exec time as a percentage of statement elapsed time", "caption": "%Elapsed", "condition": "planning_times"}, '
      '{"id": "total_exec_time_pct", "class": "table_obj_value", "title": "Exec time as a percentage of total cluster elapsed time", "caption": "%Total"}, '
      '{"id": "jit_total_time", "class": "jitTimeCell", "title": "Exec time as a percentage of statement elapsed time", "caption": "JIT time (s)", "condition": "statements_jit_stats"}, '
      '{"caption": "I/O time (s)", "condition": "io_times", "columns": ['
        '{"id": "shared_blk_read_time", "class": "table_obj_value", "caption": "Read"}, '
        '{"id": "shared_blk_write_time", "class": "table_obj_value", "caption": "Write"}'
      ']}, '
      '{"caption": "CPU time (s)", "condition": "kcachestatements", "columns": ['
        '{"id": "user_time", "class": "table_obj_value", "caption": "Usr"}, '
        '{"id": "system_time", "class": "table_obj_value", "caption": "Sys"}'
      ']}, '
      '{"id": "rows", "class": "table_obj_value", "caption": "Rows"}, '
      '{"title": "Execution time statistics", "caption": "Execution times (ms)", "columns": ['
        '{"id": "mean_exec_time", "class": "table_obj_value", "caption": "Mean"}, '
        '{"id": "min_exec_time", "class": "table_obj_value", "caption": "Min"}, '
        '{"id": "max_exec_time", "class": "table_obj_value", "caption": "Max"}, '
        '{"id": "stddev_exec_time", "class": "table_obj_value", "caption": "StdErr"}'
      ']}, '
      '{"id": "calls", "title": "Number of times the statement was executed", "caption": "Executions", "class": "table_obj_value"}, '
      '{"id": "stmt_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(1, 'sqlmeanexec', 'sqlsthdr', 350, 'Top SQL by mean time', 'Top SQL by mean execution time', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"ordering": "ord_mean_exec_time",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "mean_exec_time"},'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "caption": "Query ID", "class": "table_obj_name queryId"}, '
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
      '{"title": "Execution time statistics", "caption": "Execution times (ms)", "columns": ['
        '{"id": "mean_exec_time", "class": "table_obj_value", "caption": "Mean"}, '
        '{"id": "min_exec_time", "class": "table_obj_value", "caption": "Min"}, '
        '{"id": "max_exec_time", "class": "table_obj_value", "caption": "Max"}, '
        '{"id": "stddev_exec_time", "class": "table_obj_value", "caption": "StdErr"}'
      ']}, '
      '{"id": "total_exec_time", "class": "table_obj_value", "title": "Time spent executing statement", "caption": "Exec (s)"}, '
      '{"id": "exec_time_pct", "class": "table_obj_value", "title": "Exec time as a percentage of statement elapsed time", "caption": "%Elapsed", "condition": "planning_times"}, '
      '{"id": "total_exec_time_pct", "class": "table_obj_value", "title": "Exec time as a percentage of total cluster elapsed time", "caption": "%Total"}, '
      '{"id": "jit_total_time", "class": "jitTimeCell", "title": "Exec time as a percentage of statement elapsed time", "caption": "JIT time (s)", "condition": "statements_jit_stats"}, '
      '{"caption": "I/O time (s)", "condition": "io_times", "columns": ['
        '{"id": "shared_blk_read_time", "class": "table_obj_value", "caption": "Read"}, '
        '{"id": "shared_blk_write_time", "class": "table_obj_value", "caption": "Write"}'
      ']}, '
      '{"caption": "CPU time (s)", "condition": "kcachestatements", "columns": ['
        '{"id": "user_time", "class": "table_obj_value", "caption": "Usr"}, '
        '{"id": "system_time", "class": "table_obj_value", "caption": "Sys"}'
      ']}, '
      '{"id": "rows", "class": "table_obj_value", "caption": "Rows"}, '
      '{"id": "calls", "title": "Number of times the statement was executed", "caption": "Executions", "class": "table_obj_value"}, '
      '{"id": "stmt_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(1, 'sqlcalls', 'sqlsthdr', 400, 'Top SQL by executions', 'Top SQL by executions', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"ordering": "ord_calls",'
    '"filter": {"type": "exists", "field": "ord_calls"},'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "table_obj_name queryId", "caption": "Query ID"}, '
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
      '{"id": "calls", "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": "calls_pct", "class": "table_obj_value", "title": "Executions of this statement as a percentage of total executions of all statements in a cluster", "caption": "%Total"}, '
      '{"id": "rows", "class": "table_obj_value", "title": "Total number of rows retrieved or affected by the statement", "caption": "Rows"}, '
      '{"id": "mean_exec_time", "class": "table_obj_value", "caption": "Mean(ms)"}, '
      '{"id": "min_exec_time", "class": "table_obj_value", "caption": "Min(ms)"}, '
      '{"id": "max_exec_time", "class": "table_obj_value", "caption": "Max(ms)"}, '
      '{"id": "stddev_exec_time", "class": "table_obj_value", "caption": "StdErr(ms)"}, '
      '{"id": "total_exec_time", "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"},'
      '{"id": "stmt_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(1, 'sqlio', 'sqlsthdr', 500, 'Top SQL by I/O wait time', 'Top SQL by I/O wait time', 'io_times', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"ordering": "ord_io_time",'
    '"filter": {"type": "exists", "field": "io_time"},'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "table_obj_name queryId", "caption": "Query ID"}, '
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
      '{"id": "io_time", "class": "table_obj_value", "title": "Time spent by the statement reading and writing blocks", "caption": "IO(s)"}, '
      '{"id": "shared_blk_read_time", "class": "table_obj_value", "title": "Time spent by the statement reading blocks", "caption": "R(s)"}, '
      '{"id": "shared_blk_write_time", "class": "table_obj_value", "title": "Time spent by the statement writing blocks", "caption": "W(s)"}, '
      '{"id": "io_time_pct", "class": "table_obj_value", "title": "I/O time of this statement as a percentage of total I/O time for all statements in a cluster", "caption": "%Total"}, '
      '{"title": "Number of blocks read by the statement", "caption": "Reads", "columns": ['
        '{"id": "shared_blks_read", "title": "Number of shared blocks read by the statement", "caption": "Shr", "class": "table_obj_value"}, '
        '{"id": "local_blks_read", "title": "Number of local blocks read by the statement (usually used for temporary tables)", "caption": "Loc", "class": "table_obj_value"}, '
        '{"id": "temp_blks_read", "title": "Number of temp blocks read by the statement (usually used for operations like sorts and joins)", "caption": "Tmp", "class": "table_obj_value"}'
      ']}, '
      '{"title": "Number of blocks written by the statement", "caption": "Writes", "columns": ['
        '{"id": "shared_blks_written", "title": "Number of shared blocks written by the statement", "caption": "Shr", "class": "table_obj_value"}, '
        '{"id": "local_blks_written", "title": "Number of local blocks written by the statement (usually used for temporary tables)", "caption": "Loc", "class": "table_obj_value"}, '
        '{"id": "temp_blks_written", "title": "Number of temp blocks written by the statement (usually used for operations like sorts and joins)", "caption": "Tmp", "class": "table_obj_value"}'
      ']}, '
      '{"id": "total_time", "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": "calls", "class": "table_obj_value", "title": "Number of blocks written by the statement", "caption": "Executions"}, '
      '{"id": "stmt_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']}]'::jsonb),
(1, 'sqlfetch', 'sqlsthdr', 600, 'Top SQL by shared blocks fetched', 'Top SQL by shared blocks fetched', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"ordering": "ord_shared_blocks_fetched",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "shared_blks_fetched"},'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "table_obj_name queryId", "caption": "Query ID"}, '
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
      '{"id": "shared_blks_fetched", "class": "table_obj_value", "title": "Shared blocks fetched (read and hit) by the statement", "caption": "blks fetched"}, '
      '{"id": "shared_blks_fetched_pct", "class": "table_obj_value", "title": "Shared blocks fetched by this statement as a percentage of all shared blocks fetched in a cluster", "caption": "%Total"}, '
      '{"id": "shared_hit_pct", "class": "table_obj_value", "title": "Shared blocks hits as a percentage of shared blocks fetched (read + hit)", "caption": "Hits(%)"}, '
      '{"id": "total_time", "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": "rows", "class": "table_obj_value", "title": "Total number of rows retrieved or affected by the statement", "caption": "Rows"}, '
      '{"id": "calls", "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": "stmt_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']}]'::jsonb),
(1, 'sqlshrd', 'sqlsthdr', 700, 'Top SQL by shared blocks read', 'Top SQL by shared blocks read', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "shared_blks_read"},'
    '"ordering": "ord_shared_blocks_read",'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "table_obj_name queryId", "caption": "Query ID"}, '
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
      '{"id": "shared_blks_read", "class": "table_obj_value", "title": "Total number of shared blocks read by the statement", "caption": "Reads"}, '
      '{"id": "read_pct", "class": "table_obj_value", "title": "Shared blocks read by this statement as a percentage of all shared blocks read in a cluster", "caption": "%Total"}, '
      '{"id": "shared_hit_pct", "class": "table_obj_value", "title": "Shared blocks hits as a percentage of shared blocks fetched (read + hit)", "caption": "Hits(%)"}, '
      '{"id": "total_time", "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": "rows", "class": "table_obj_value", "title": "Total number of rows retrieved or affected by the statement", "caption": "Rows"}, '
      '{"id": "calls", "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": "stmt_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']}]'::jsonb),
(1, 'sqlshdir', 'sqlsthdr', 800, 'Top SQL by shared blocks dirtied', 'Top SQL by shared blocks dirtied', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"filter": {"type": "exists", "field": "shared_blks_dirtied"},'
    '"ordering": "ord_shared_blocks_dirt",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "table_obj_name queryId", "caption": "Query ID"}, '
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
      '{"id": "shared_blks_dirtied", "class": "table_obj_value", "title": "Total number of shared blocks dirtied by the statement", "caption": "Dirtied"}, '
      '{"id": "dirtied_pct", "class": "table_obj_value", "title": "Shared blocks dirtied by this statement as a percentage of all shared blocks dirtied in a cluster", "caption": "%Total"}, '
      '{"id": "shared_blks_hit", "class": "table_obj_value", "title": "Total number of shared blocks dirtied by the statement", "caption": "Hits"}, '
      '{"id": "shared_hit_pct", "class": "table_obj_value", "title": "Shared blocks hits as a percentage of shared blocks fetched (read + hit)", "caption": "%Total"}, '
      '{"id": "wal_bytes_fmt", "class": "table_obj_value", "title": "Total amount of WAL bytes generated by the statement", "caption": "WAL", "condition": "statement_wal_bytes"}, '
      '{"id": "wal_bytes_pct", "class": "table_obj_value", "title": "WAL bytes of this statement as a percentage of total WAL bytes generated by a cluster", "caption": "%Total", "condition": "statement_wal_bytes"}, '
      '{"id": "total_time", "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": "rows", "class": "table_obj_value", "title": "Total number of rows retrieved or affected by the statement", "caption": "Rows"}, '
      '{"id": "calls", "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": "stmt_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(1, 'sqlshwr', 'sqlsthdr', 900, 'Top SQL by shared blocks written', 'Top SQL by shared blocks written', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "shared_blks_written"},'
    '"ordering": "ord_shared_blocks_written",'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "table_obj_name queryId", "caption": "Query ID"}, '
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
      '{"id": "shared_blks_written", "class": "table_obj_value", "title": "Total number of shared blocks written by the statement", "caption": "Written"}, '
      '{"id": "tot_written_pct", "class": "table_obj_value", "title": "Shared blocks written by this statement as a percentage of all shared blocks written in a cluster (sum of pg_stat_bgwriter fields buffers_checkpoint, buffers_clean and buffers_backend)", "caption": "%Total"}, '
      '{"id": "backend_written_pct", "class": "table_obj_value", "title": "Shared blocks written by this statement as a percentage total buffers written directly by a backends (buffers_backend of pg_stat_bgwriter view)", "caption": "%BackendW"}, '
      '{"id": "shared_hit_pct", "class": "table_obj_value", "title": "Shared blocks hits as a percentage of shared blocks fetched (read + hit)", "caption": "Hits(%)"}, '
      '{"id": "total_time", "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": "rows", "class": "table_obj_value", "title": "Total number of rows retrieved or affected by the statement", "caption": "Rows"}, '
      '{"id": "calls", "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": "stmt_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(1, 'sqlwalsz', 'sqlsthdr', 1000, 'Top SQL by WAL size', 'Top SQL by WAL size', 'statement_wal_bytes', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "wal_bytes"},'
    '"ordering": "ord_wal",'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "table_obj_name queryId", "caption": "Query ID"}, '
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
      '{"id": "wal_bytes_fmt", "class": "table_obj_value", "title": "Total amount of WAL bytes generated by the statement", "caption": "WAL"}, '
      '{"id": "wal_bytes_pct", "class": "table_obj_value", "title": "WAL bytes of this statement as a percentage of total WAL bytes generated by a cluster", "caption": "%Total"}, '
      '{"id": "wal_buffers_full", "class": "table_obj_value", "title": "Number of times the WAL buffers became full", "caption": "WAL buffers full", "condition": "wal_buffers_full"}, '
      '{"id": "shared_blks_dirtied", "class": "table_obj_value", "title": "Total number of shared blocks dirtied by the statement", "caption": "Dirtied"}, '
      '{"id": "wal_fpi", "class": "table_obj_value", "title": "Total number of WAL full page images generated by the statement", "caption": "WAL FPI"}, '
      '{"id": "wal_records", "class": "table_obj_value", "title": "Total number of WAL records generated by the statement", "caption": "WAL records"}, '
      '{"id": "stmt_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(1, 'sqltmp', 'sqlsthdr', 1100, 'Top SQL by temp usage', 'Top SQL by temp usage', 'statements_top_temp', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"filter": {"type": "exists", "field": "sum_tmp_blks"},'
    '"ordering": "ord_temp",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "table_obj_name queryId", "caption": "Query ID"}, '
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
      '{"id": "local_blks_fetched", "class": "table_obj_value", "title": "Number of local blocks fetched (hit + read)", "caption": "Local fetched"}, '
      '{"id": "local_hit_pct", "class": "table_obj_value", "title": "Local blocks hit percentage", "caption": "Hits(%)"}, '
      '{"title": "Number of blocks, used for temporary tables", "caption": "Local (blk)", "columns": ['
        '{"id": "local_blks_written", "class": "table_obj_value", "title": "Number of written local blocks", "caption": "Write"}, '
        '{"id": "local_write_total_pct", "class": "table_obj_value", "title": "Percentage of all local blocks written", "caption": "%Total"}, '
        '{"id": "local_blks_read", "class": "table_obj_value", "title": "Number of read local blocks", "caption": "Read"}, '
        '{"id": "local_read_total_pct", "class": "table_obj_value", "title": "Percentage of all local blocks read", "caption": "%Total"}'
      ']}, '
      '{"title": "Number of blocks, used in operations (like sorts and joins)", "caption": "Temp (blk)", "columns": ['
        '{"id": "temp_blks_written", "class": "table_obj_value", "title": "Number of written temp blocks", "caption": "Write"}, '
        '{"id": "temp_write_total_pct", "class": "table_obj_value", "title": "Percentage of all temp blocks written", "caption": "%Total"}, '
        '{"id": "temp_blks_read", "class": "table_obj_value", "title": "Number of read temp blocks", "caption": "Read"}, '
        '{"id": "temp_read_total_pct", "class": "table_obj_value", "title": "Percentage of all temp blocks read", "caption": "%Total"}'
      ']}, '
      '{"id": "total_time", "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": "rows", "class": "table_obj_value", "title": "Total number of rows retrieved or affected by the statement", "caption": "Rows"}, '
      '{"id": "calls", "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": "stmt_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(1, 'sqltmpiotime', 'sqlsthdr', 1125, 'Top SQL by temp I/O time', 'Top SQL by temp I/O time', 'statements_temp_io_times', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"filter": {"type": "exists", "field": "ord_temp_io_time"},'
    '"ordering": "ord_temp_io_time",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "table_obj_name queryId", "caption": "Query ID"}, '
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
      '{"title": "Time the statement spent on temporary file blocks I/O", "caption": "Temp I/O time (s)", "columns": ['
        '{"id": "temp_blk_read_time", "class": "table_obj_value", "title": "Time the statement spent reading temporary file blocks, in seconds", "caption": "Read"}, '
        '{"id": "temp_blk_write_time", "class": "table_obj_value", "title": "Time the statement spent reading temporary file blocks, in seconds", "caption": "Write"}, '
        '{"id": "temp_io_time_pct", "class": "table_obj_value", "title": "Time spent on temporary file blocks I/O of this statement as a percentage of total time spent on temporary file blocks I/O by all statements", "caption": "%Total"} '
      ']}, '
      '{"title": "Number of blocks, used in operations (like sorts and joins)", "caption": "Temp (blk)", "columns": ['
        '{"id": "temp_blks_written", "class": "table_obj_value", "title": "Number of written temp blocks", "caption": "Write"}, '
        '{"id": "temp_write_total_pct", "class": "table_obj_value", "title": "Percentage of all temp blocks written", "caption": "%Total"}, '
        '{"id": "temp_blks_read", "class": "table_obj_value", "title": "Number of read temp blocks", "caption": "Read"}, '
        '{"id": "temp_read_total_pct", "class": "table_obj_value", "title": "Percentage of all temp blocks read", "caption": "%Total"}'
      ']}, '
      '{"id": "total_time", "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": "rows", "class": "table_obj_value", "title": "Total number of rows retrieved or affected by the statement", "caption": "Rows"}, '
      '{"id": "calls", "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": "stmt_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(1, 'sqljit', 'sqlsthdr', 1150, 'Top SQL by JIT elapsed time', 'Top SQL by JIT elapsed time', 'statements_jit_stats', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "sum_jit_time"},'
    '"ordering": "ord_jit",'
    '"limit": "topn",'
    '"columns": ['
        '{"id": "hexqueryid", "class": "table_obj_name jitCellId", "caption": "Query ID"}, '
        '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
        '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
        '{"id": "jit_total_time", "class": "table_obj_value", "title": "Time spent on JIT in seconds", "caption": "JIT total (s)"}, '
        '{"caption": "Generation", "columns": ['
          '{"id": "jit_functions", "class": "table_obj_value", "title": "Total number of functions JIT-compiled by the statement.", "caption": "Count"}, '
          '{"id": "jit_generation_time", "class": "table_obj_value", "title": "Time spent by the statement on generating JIT code, in seconds.", "caption": "Time (s)"}'
          ']}, '
        '{"class": "table_obj_name", "caption": "Inlining", "columns": ['
          '{"id": "jit_inlining_count", "class": "table_obj_value", "title": "Number of times functions have been inlined.", "caption": "Count"}, '
          '{"id": "jit_inlining_time", "class": "table_obj_value", "title": "Time spent by the statement on inlining functions, in seconds.", "caption": "Time (s)"}'
          ']}, '
        '{"class": "table_obj_name", "caption": "Optimization", "columns": ['
          '{"id": "jit_optimization_count", "class": "table_obj_value", "title": "Number of times the statement has been optimized.", "caption": "Count"}, '
          '{"id": "jit_optimization_time", "class": "table_obj_value", "title": "Time spent by the statement on optimizing, in seconds.", "caption": "Time (s)"}'
        ']}, '
        '{"class": "table_obj_name", "caption": "Emission", "columns": ['
          '{"id": "jit_emission_count", "class": "table_obj_value", "title": "Number of times code has been emitted.", "caption": "Count"}, '
          '{"id": "jit_emission_time", "class": "table_obj_value", "title": "Total time spent by the statement on emitting code, in seconds.", "caption": "Time (s)"}'
        ']}, '
        '{"class": "table_obj_name", "caption": "Deform", "condition": "statements_jit_deform", "columns": ['
          '{"id": "jit_deform_count", "class": "table_obj_value", "title": "Number of tuple deform functions JIT-compiled by the statement.", "caption": "Count"}, '
          '{"id": "jit_deform_time", "class": "table_obj_value", "title": "Total time spent by the statement on JIT-compiling tuple deform functions, in seconds.", "caption": "Time (s)"}'
        ']}, '
        '{"class": "table_obj_name", "caption": "Time (s)", "columns": ['
          '{"id": "total_plan_time", "class": "table_obj_value", "title": "Time spent planning statement", "condition": "planning_times", "caption": "Plan"}, '
          '{"id": "total_exec_time", "class": "table_obj_value", "title": "Time spent executing statement", "caption": "Exec"}'
        ']}, '
        '{"class": "table_obj_name", "caption": "I/O time (s)", "condition": "io_times", "columns": ['
          '{"id": "shared_blk_read_time", "class": "table_obj_value", "title": "Time spent reading blocks by statement", "caption": "Read"}, '
          '{"id": "shared_blk_write_time", "class": "table_obj_value", "title": "Time spent writing blocks by statement", "caption": "Write"}, '
      '{"id": "stmt_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
        ']}'
    ']}]'::jsonb),
(1, 'sqlworkers', 'sqlsthdr', 1175, 'Top SQL by parallel workers usage', 'Top SQL by parallel workers usage', 'statements_workers_stats', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "ord_wrkrs_cnt"},'
    '"ordering": "ord_wrkrs_cnt",'
    '"limit": "topn",'
    '"columns": ['
        '{"id": "hexqueryid", "class": "table_obj_name queryId", "caption": "Query ID"}, '
        '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
        '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
        '{"class": "table_obj_name", "caption": "Parallel workers", "columns": ['
          '{"id": "parallel_workers_to_launch", "class": "table_obj_value", "caption": "Planned", "title": "Number of parallel workers planned to be launched by queries on this database"},'
          '{"id": "parallel_workers_launched", "class": "table_obj_value", "caption": "Launched", "title": "Number of parallel workers launched by queries on this database"}'
        ']},'
        '{"id": "total_exec_time", "class": "table_obj_value", "title": "Time spent executing statement", "caption": "Exec (s)"}, '
        '{"id": "shared_blks_fetched", "class": "table_obj_value", "title": "Shared blocks fetched (read and hit) by the statement", "caption": "blks fetched"}, '
        '{"title": "Number of blocks read by the statement", "caption": "Reads", "columns": ['
          '{"id": "shared_blks_read", "title": "Number of shared blocks read by the statement", "caption": "Shr", "class": "table_obj_value"}, '
          '{"id": "local_blks_read", "title": "Number of local blocks read by the statement (usually used for temporary tables)", "caption": "Loc", "class": "table_obj_value"}, '
          '{"id": "temp_blks_read", "title": "Number of temp blocks read by the statement (usually used for operations like sorts and joins)", "caption": "Tmp", "class": "table_obj_value"}'
        ']}, '
        '{"caption": "I/O time (s)", "condition": "io_times", "columns": ['
          '{"id": "shared_blk_read_time", "class": "table_obj_value", "caption": "Read"}, '
          '{"id": "shared_blk_write_time", "class": "table_obj_value", "caption": "Write"}'
        ']}'
    ']}]'::jsonb),
(1, 'sqlkcachehdr', 'sqlsthdr', 1200, 'Rusage statistics', 'Rusage statistics', 'kcachestatements', NULL, NULL, NULL),
(1, 'sqlrusgcpu', 'sqlkcachehdr', 100, 'Top SQL by system and user time', 'Top SQL by system and user time', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_rusage_statements",'
    '"filter": {"type": "exists", "field": "sum_cpu_time"},'
    '"ordering": "ord_cpu_time",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "table_obj_name queryId", "caption": "Query ID"}, '
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
      '{"id": "username", "class": "table_obj_name", "caption": "User"}, '
      '{"title": "Userspace CPU", "caption": "User Time", "columns": ['
        '{"id": "plan_user_time", "class": "table_obj_value", "title": "User CPU time elapsed during planning", "caption": "Plan (s)", "condition": "rusage_planstats"}, '
        '{"id": "exec_user_time", "class": "table_obj_value", "title": "User CPU time elapsed during execution", "caption": "Exec (s)"}, '
        '{"id": "user_time_pct", "class": "table_obj_value", "title": "User CPU time elapsed by this statement as a percentage of total user CPU time", "caption": "%Total"}'
        ']}, '
      '{"title": "Kernelspace CPU", "caption": "System Time", "columns": ['
        '{"id": "plan_system_time", "class": "table_obj_value", "title": "System CPU time elapsed during planning", "caption": "Plan (s)", "condition": "rusage_planstats"}, '
        '{"id": "exec_system_time", "class": "table_obj_value", "title": "System CPU time elapsed during execution", "caption":"Exec (s)"}, '
        '{"id": "system_time_pct", "class": "table_obj_value", "title": "System CPU time elapsed by this statement as a percentage of total system CPU time", "caption": "%Total"}'
        ']}, '
      '{"id": "rusage_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
      ']'
    '}]'::jsonb),
(1, 'sqlrusgio', 'sqlkcachehdr', 200, 'Top SQL by reads/writes done by filesystem layer', 'Top SQL by reads/writes done by filesystem layer', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_rusage_statements",'
    '"filter": {"type": "exists", "field": "sum_io_bytes"},'
    '"ordering": "ord_io_bytes",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "table_obj_name queryId", "caption": "Query ID"},'
      '{"id": "dbname", "class": "table_obj_name", "caption": "Database"},'
      '{"id": "username", "class": "table_obj_name", "caption": "User"},'
      '{"title": "Filesystem reads", "caption": "Read Bytes", "columns": ['
          '{"id": "plan_reads", "class": "table_obj_value", "title": "Filesystem read amount during planning", "caption": "Plan", "condition": "rusage_planstats"},'
          '{"id": "exec_reads", "class": "table_obj_value", "title": "Filesystem read amount during execution", "caption": "Bytes"},'
          '{"id": "reads_total_pct", "class": "table_obj_value", "title": "Filesystem read amount of this statement as a percentage of all statements FS read amount", "caption": "%Total"}'
      ']},'
      '{"title": "Filesystem writes", "caption": "Write Bytes", "columns": ['
          '{"id": "plan_writes", "class": "table_obj_value", "title": "Filesystem write amount during planning", "caption": "Plan", "condition": "rusage_planstats"},'
          '{"id": "exec_writes", "class": "table_obj_value", "title": "Filesystem write amount during execution", "caption": "Bytes"},'
          '{"id": "writes_total_pct", "class": "table_obj_value", "title": "Filesystem write amount of this statement as a percentage of all statements FS read amount", "caption": "%Total"}'
      ']}, '
      '{"id": "rusage_cover", "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(1, 'sqllist', 'sqlsthdr', 1300, 'Complete list of SQL texts', 'Complete list of SQL texts', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "queries",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0}'
    '],'
    '"columns": ['
      '{"id": "hexqueryid", "class": "table_obj_name queryTextId", "caption": "Query ID", "rowspan": true}, '
      '{"id": "query_texts", "class": "table_obj_name queryText", "caption": "Query Text"}'
    ']'
  '}]'::jsonb)
;

-- Schema objects section of a regular report
INSERT INTO report_struct (
  report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
  content, sect_struct)
VALUES
(1, 'tblscan', 'objects', 100, 'Top tables by estimated sequentially scanned volume', 'Top tables by estimated sequentially scanned volume', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_seq_scan"},'
    '"ordering": "ord_seq_scan",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": ["relname", "toastrelname"], "class": "table_obj_name"},'
     '{"caption": "~SeqBytes", "id": ["seqscan_bytes_pretty", "t_seqscan_bytes_pretty"], '
       '"class": "table_obj_value", '
       '"title": "Estimated number of bytes, fetched by sequential scans"}, '
     '{"caption": "SeqScan", "id": ["seq_scan", "toastseq_scan"], '
       '"class": "table_obj_value", '
       '"title": "Number of sequential scans initiated on this table"},'
     '{"caption": "IxScan", "id": ["idx_scan", "toastidx_scan"], '
       '"class": "table_obj_value", '
       '"title": "Number of index scans initiated on this table"},'
     '{"caption": "IxFet", "id": ["idx_tup_fetch", "toastidx_tup_fetch"], '
       '"class": "table_obj_value", '
       '"title": "Number of live rows fetched by index scans"},'
     '{"caption": "Ins", "id": ["n_tup_ins", "toastn_tup_ins"], '
       '"class": "table_obj_value", '
       '"title": "Number of rows inserted"},'
     '{"caption": "Upd", "id": ["n_tup_upd", "toastn_tup_upd"], '
       '"class": "table_obj_value", '
       '"title": "Number of rows updated (includes HOT updated rows)"},'
     '{"caption": "Del", "id": ["n_tup_del", "toastn_tup_del"], '
       '"class": "table_obj_value", '
       '"title": "Number of rows deleted"},'
     '{"caption": "Upd(HOT)", "id": ["n_tup_hot_upd", "toastn_tup_hot_upd"], '
       '"class": "table_obj_value", '
       '"title": "Number of rows HOT updated (i.e., with no separate index update required)"}'
    ']'
  '}]'::jsonb),
(1, 'tblfetch', 'objects', 200, 'Top tables by blocks fetched', 'Top tables by blocks fetched', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_io_tables",'
    '"filter": {"type": "exists", "field": "ord_fetch"},'
    '"ordering": "ord_fetch",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
    '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
    '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name"},'
    '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
    '{"caption": "Table", "id": "relname", "class": "table_obj_name"},'
    '{"caption": "Heap", "columns": ['
         '{"caption": "Blks", "id": "heap_blks_fetch", "title": "Number of blocks fetched (read+hit) from this table", "class": "table_obj_value"},'
         '{"caption": "%Total", "id": "heap_blks_proc_pct", "title": "Heap blocks fetched for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
    ']},'
    '{"caption": "Ix", "columns": ['
         '{"caption": "Blks", "id": "idx_blks_fetch", "title": "Number of blocks fetched (read+hit) from all indexes on this table", "class": "table_obj_value"},'
         '{"caption": "%Total", "id": "idx_blks_fetch_pct", "title": "Indexes of blocks fetched for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
    ']},'
    '{"caption": "TOAST", "columns": ['
         '{"caption": "Blks", "id": "toast_blks_fetch", "title": "Number of blocks fetched (read+hit) from this table''s TOAST table (if any)", "class": "table_obj_value"},'
         '{"caption": "%Total", "id": "toast_blks_fetch_pct", "title": "TOAST blocks fetched for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
    ']},'
    '{"caption": "TOAST-Ix", "columns": ['
         '{"caption": "Blks", "id": "tidx_blks_fetch", "title": "Number of blocks fetched (read+hit) from this table''s TOAST table indexes (if any)", "class": "table_obj_value"},'
         '{"caption": "%Total", "id": "tidx_blks_fetch_pct", "title": "TOAST table index blocks fetched for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
    ']}'
   ']'
  '}]'::jsonb),
(1, 'tblrd', 'objects', 300, 'Top tables by blocks read', 'Top tables by blocks read', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_io_tables",'
    '"filter": {"type": "exists", "field": "ord_read"},'
    '"ordering": "ord_read",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name"},'
     '{"caption": "Heap", "columns": ['
          '{"caption": "Blks", "id": "heap_blks_read", "title": "Number of blocks read from this table", "class": "table_obj_value"},'
          '{"caption": "%Total", "id": "heap_blks_read_pct", "title": "Heap blocks read for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Ix", "columns": ['
          '{"caption": "Blks", "id": "idx_blks_read", "title": "Number of blocks read from all indexes on this table", "class": "table_obj_value"},'
          '{"caption": "%Total", "id": "idx_blks_read_pct", "title": "Indexes of blocks read for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
     ']},'
     '{"caption": "TOAST", "columns": ['
          '{"caption": "Blks", "id": "toast_blks_read", "title": "Number of blocks read from this table''s TOAST table (if any)", "class": "table_obj_value"},'
          '{"caption": "%Total", "id": "toast_blks_read_pct", "title": "TOAST blocks read for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
     ']},'
     '{"caption": "TOAST-Ix", "columns": ['
          '{"caption": "Blks", "id": "tidx_blks_read", "title": "Number of blocks read from this table''s TOAST table indexes (if any)", "class": "table_obj_value"},'
          '{"caption": "%Total", "id": "tidx_blks_read_pct", "title": "TOAST table index blocks read for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Hit(%)", "id": "hit_pct", "class": "table_obj_value", "title": "Number of heap, indexes, toast and toast index blocks fetched from shared buffers as a percentage of all their blocks fetched from shared buffers and file system"}'
    ']'
  '}]'::jsonb),
(1, 'tbldml', 'objects', 400, 'Top DML tables', 'Top DML tables', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_dml"},'
    '"ordering": "ord_dml",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1},'
      '{"id": "toastrelname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": ["relname", "toastrelname"], "class": "table_obj_name"},'
     '{"caption": "Ins", "id": ["n_tup_ins", "toastn_tup_ins"], "title": "Number of rows inserted", "class": "table_obj_value"},'
     '{"caption": "Upd", "id": ["n_tup_upd", "toastn_tup_upd"], "title": "Number of rows updated (includes HOT updated rows)", "class": "table_obj_value"},'
     '{"caption": "Del", "id": ["n_tup_del", "toastn_tup_del"], "title": "Number of rows deleted", "class": "table_obj_value"},'
     '{"caption": "Upd(HOT)", "id": ["n_tup_hot_upd", "toastn_tup_hot_upd"], "title": "Number of rows HOT updated (i.e., with no separate index update required)", "class": "table_obj_value"},'
     '{"caption": "SeqScan", "id": ["seq_scan", "toastseq_scan"], "title": "Number of live rows fetched by sequential scans", "class": "table_obj_value"},'
     '{"caption": "SeqFet", "id": ["seq_tup_read", "toastseq_tup_read"], "title": "Number of live rows fetched by sequential scans", "class": "table_obj_value"},'
     '{"caption": "IxScan", "id": ["idx_scan", "toastidx_scan"], "title": "Number of index scans initiated on this table", "class": "table_obj_value"},'
     '{"caption": "IxFet", "id": ["idx_tup_fetch", "toastidx_tup_fetch"], "title": "Number of live rows fetched by index scans", "class": "table_obj_value"}'
    ']'
  '}]'::jsonb),
(1, 'tblud', 'objects', 500, 'Top tables by updated/deleted tuples', 'Top tables by updated/deleted tuples', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_upd"},'
    '"ordering": "ord_upd",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1},'
      '{"id": "toastrelname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": ["relname", "toastrelname"], "class": "table_obj_name"},'
     '{"caption": "Upd", "id": ["n_tup_upd", "toastn_tup_upd"], "title": "Number of rows updated (includes HOT updated rows)", "class": "table_obj_value"},'
     '{"caption": "Upd(HOT)", "id": ["n_tup_hot_upd", "toastn_tup_hot_upd"], "title": "Number of rows HOT updated (i.e., with no separate index update required)", "class": "table_obj_value"},'
     '{"caption": "Del", "id": ["n_tup_del", "toastn_tup_del"], "title": "Number of rows deleted", "class": "table_obj_value"},'
     '{"caption": "Vacuum count", "title": "Number of times vacuum operation was performed on the underlying table", "columns": ['
          '{"caption": "Vacuum", "id": ["vacuum_count", "toastvacuum_count"], "title": "Number of times this table has been manually vacuumed (not counting VACUUM FULL)", "class": "table_obj_value"},'
          '{"caption": "AutoVacuum", "id": ["autovacuum_count", "toastautovacuum_count"], "title": "Number of times this table has been vacuumed by the autovacuum daemon", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Analyze count", "title": "Number of times vacuum operation was performed on the underlying table", "columns": ['
          '{"caption": "Analyze", "id": ["analyze_count", "toastanalyze_count"], "title": "Number of times this table has been manually analyzed", "class": "table_obj_value"},'
          '{"caption": "AutoAnalyze", "id": ["autoanalyze_count", "toastautoanalyze_count"], "title": "Number of times this table has been analyzed by the autovacuum daemon", "class": "table_obj_value"}'
     ']}'
    ']'
  '}]'::jsonb),
(1, 'tblupd_np', 'objects', 550, 'Top tables by new-page updated tuples', 'Top tables by new-page updated tuples', 'table_new_page_updates', NULL,
  '{"class": "notice", "text": "Top tables by number of rows updated where the successor version goes onto a new heap page, '
  'leaving behind an original version with a t_ctid field that points to a different heap page. '
  'These are always non-HOT updates"}',
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_upd_np"},'
    '"ordering": "ord_upd_np",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1},'
      '{"id": "toastrelname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": ["relname", "toastrelname"], "class": "table_obj_name"},'
     '{"caption": "NP Upd", "id": ["n_tup_newpage_upd", "toastn_tup_newpage_upd"], "title": "Number of rows updated to a new heap page", "class": "table_obj_value"},'
     '{"caption": "%Upd", "id": ["np_upd_pct", "toastnp_upd_pct"], "title": "Number of new-page updated rows as a percentage of all rows updated", "class": "table_obj_value"},'
     '{"caption": "Upd", "id": ["n_tup_upd", "toastn_tup_upd"], "title": "Number of rows updated (includes HOT updated rows)", "class": "table_obj_value"},'
     '{"caption": "Upd(HOT)", "id": ["n_tup_hot_upd", "toastn_tup_hot_upd"], "title": "Number of rows HOT updated (i.e., with no separate index update required)", "class": "table_obj_value"}'
    ']'
  '}]'::jsonb),
(1, 'tblgrw', 'objects', 600, 'Top growing tables', 'Top growing tables', NULL, NULL,
  '{"class": "notice", "text": "Sizes in square brackets are based on pg_class.relpages data instead of pg_relation_size() function"}',
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_growth"},'
    '"ordering": "ord_growth",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1},'
      '{"id": "toastrelname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": ["relname", "toastrelname"], "class": "table_obj_name"},'
     '{"caption": "Size", "id": ["relsize_pretty", "t_relsize_pretty"], "title": "Table size, as it was at the moment of last sample in report interval", "class": "table_obj_value"},'
     '{"caption": "Growth", "id": ["growth_pretty", "toastgrowth_pretty"], "title": "Table size increment during report interval", "class": "table_obj_value"},'
     '{"caption": "Ins", "id": ["n_tup_ins", "toastn_tup_ins"], "title": "Number of rows inserted", "class": "table_obj_value"},'
     '{"caption": "Upd", "id": ["n_tup_upd", "toastn_tup_upd"], "title": "Number of rows updated (includes HOT updated rows)", "class": "table_obj_value"},'
     '{"caption": "Del", "id": ["n_tup_del", "toastn_tup_del"], "title": "Number of rows deleted", "class": "table_obj_value"},'
     '{"caption": "Upd(HOT)", "id": ["n_tup_hot_upd", "toastn_tup_hot_upd"], "title": "Number of rows HOT updated (i.e., with no separate index update required)", "class": "table_obj_value"}'
    ']'
  '}]'::jsonb),
(1, 'ixfetch', 'objects', 700, 'Top indexes by blocks fetched', 'Top indexes by blocks fetched', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_io_indexes",'
    '"filter": {"type": "exists", "field": "ord_fetch"},'
    '"ordering": "ord_fetch",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1},'
      '{"id": "indexrelname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "indexrelid", "dataset": "index_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name"},'
     '{"caption": "Index", "id": "indexrelname", "class": "table_obj_name"},'
     '{"caption": "Scans", "id": "idx_scan", "title": "Number of scans performed on index", "class": "table_obj_value"},'
     '{"caption": "Blks", "id": "idx_blks_fetch", "title": "Number of blocks fetched (read+hit) from this index", "class": "table_obj_value"},'
     '{"caption": "%Total", "id": "idx_blks_fetch_pct", "title": "Blocks fetched from this index as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
    ']'
  '}]'::jsonb),
(1, 'ixrd', 'objects', 800, 'Top indexes by blocks read', 'Top indexes by blocks read', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_io_indexes",'
    '"filter": {"type": "exists", "field": "ord_read"},'
    '"ordering": "ord_read",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1},'
      '{"id": "indexrelname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "indexrelid", "dataset": "index_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name"},'
     '{"caption": "Index", "id": "indexrelname", "class": "table_obj_name"},'
     '{"caption": "Scans", "id": "idx_scan", "title": "Number of scans performed on index", "class": "table_obj_value"},'
     '{"caption": "Blks Reads", "id": "idx_blks_read", "title": "Number of disk blocks read from this index", "class": "table_obj_value"},'
     '{"caption": "%Total", "id": "idx_blks_read_pct", "title": "Blocks fetched from this index as a percentage of all blocks read in a cluster", "class": "table_obj_value"}, '
     '{"caption": "Hits(%)", "id": "idx_blks_hit_pct", "title": "Index blocks buffer cache hit percentage", "class": "table_obj_value"}'
    ']'
  '}]'::jsonb),
(1, 'ixgrw', 'objects', 900, 'Top growing indexes', 'Top growing indexes', NULL, NULL,
  '{"class": "notice", "text": "Sizes in square brackets are based on pg_class.relpages data instead of pg_relation_size() function"}',
  '[{'
    '"type": "row_table",'
    '"source": "top_indexes",'
    '"filter": {"type": "exists", "field": "ord_growth"},'
    '"ordering": "ord_growth",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1},'
      '{"id": "indexrelname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "indexrelid", "dataset": "index_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name"},'
     '{"caption": "Index", "id": "indexrelname", "class": "table_obj_name"},'
     '{"caption": "Index", "columns": ['
          '{"id": "indexrelsize_pretty", "caption": "Size", "title": "Index size, as it was at the moment of last sample in report interval", "class": "table_obj_value"},'
          '{"id": "growth_pretty", "caption": "Growth", "title": "Index size increment during report interval", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Table", "columns": ['
          '{"id": "tbl_n_tup_ins", "caption": "Ins", "title": "Number of rows inserted", "class": "table_obj_value"},'
          '{"id": "tbl_n_tup_upd", "caption": "Upd", "title": "Number of rows updated (without HOT updated rows)", "class": "table_obj_value"},'
          '{"id": "tbl_n_tup_del", "caption": "Del", "title": "Number of rows deleted", "class": "table_obj_value"}'
     ']}'
    ']'
  '}]'::jsonb),
(1, 'ixunused', 'objects', 1000, 'Unused indexes', 'Unused indexes', NULL, NULL,
  '{"class": "notice", "text": "This table contains non-scanned indexes (during report interval), ordered by number of DML '
  'operations on underlying tables. Constraint indexes are excluded"}',
  '[{'
    '"type": "row_table",'
    '"source": "top_indexes",'
    '"filter": {"type": "exists", "field": "ord_unused"},'
    '"ordering": "ord_unused",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1},'
      '{"id": "indexrelname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "indexrelid", "dataset": "index_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name"},'
     '{"caption": "Index", "id": "indexrelname", "class": "table_obj_name"},'
     '{"caption": "Index", "columns": ['
          '{"id": "indexrelsize_pretty", "caption": "Size", "title": "Index size, as it was at the moment of last sample in report interval", "class": "table_obj_value"},'
          '{"id": "growth_pretty", "caption": "Growth", "title": "Index size increment during report interval", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Table", "columns": ['
          '{"id": "tbl_n_tup_ins", "caption": "Ins", "title": "Number of rows inserted", "class": "table_obj_value"},'
          '{"id": "tbl_n_tup_upd", "caption": "Upd", "title": "Number of rows updated (without HOT updated rows)", "class": "table_obj_value"},'
          '{"id": "tbl_n_tup_del", "caption": "Del", "title": "Number of rows deleted", "class": "table_obj_value"}'
     ']}'
    ']'
  '}]'::jsonb)
;

-- Functions section of a regular report
INSERT INTO report_struct (
  report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
  content, sect_struct)
VALUES
(1, 'func_time', 'funchdr', 100, 'Top functions by total time', 'Top functions by total time', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_functions",'
    '"filter": {"type": "exists", "field": "ord_time"},'
    '"ordering": "ord_time",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "funcname", "index": 1}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
     '{"caption": "Function", "id": "funcname", "class": "table_obj_name"},'
     '{"caption": "Executions", "id": "calls", "title": "Number of times this function has been called", "class": "table_obj_value"},'
     '{"caption": "Time (s)", "title": "Function execution timing statistics", "columns": ['
          '{"caption": "Total", "id": "total_time", "class": "table_obj_value", "title": "Time spent in this function and all other functions called by it"},'
          '{"caption": "Self", "id": "self_time", "class": "table_obj_value", "title": "Time spent in this function itself, not including other functions called by it"},'
          '{"caption": "Mean", "id": "m_time", "class": "table_obj_value", "title": "Mean total time per execution"},'
          '{"caption": "Mean self", "id": "m_stime", "class": "table_obj_value", "title": "Mean self time per execution"}'
     ']}'
    ']'
  '}]'::jsonb),
(1, 'func_calls', 'funchdr', 200, 'Top functions by executions', 'Top functions by executions', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_functions",'
    '"filter": {"type": "exists", "field": "ord_calls"},'
    '"ordering": "ord_calls",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "funcname", "index": 1}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
     '{"caption": "Function", "id": "funcname", "class": "table_obj_name"},'
     '{"caption": "Executions", "id": "calls", "title": "Number of times this function has been called", "class": "table_obj_value"},'
     '{"caption": "Time (s)", "title": "Function execution timing statistics", "columns": ['
          '{"caption": "Total", "id": "total_time", "class": "table_obj_value", "title": "Time spent in this function and all other functions called by it"},'
          '{"caption": "Self", "id": "self_time", "class": "table_obj_value", "title": "Time spent in this function itself, not including other functions called by it"},'
          '{"caption": "Mean", "id": "m_time", "class": "table_obj_value", "title": "Mean total time per execution"},'
          '{"caption": "Mean self", "id": "m_stime", "class": "table_obj_value", "title": "Mean self time per execution"}'
     ']}'
    ']'
  '}]'::jsonb),
(1, 'func_trg', 'funchdr', 300, 'Top trigger functions by total time', 'Top trigger functions by total time', 'trigger_function_stats', NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_functions",'
    '"filter": {"type": "exists", "field": "ord_trgtime"},'
    '"ordering": "ord_trgtime",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "funcname", "index": 1}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr"},'
     '{"caption": "Function", "id": "funcname", "class": "table_obj_name hdr"},'
     '{"caption": "Executions", "id": "calls", "title": "Number of times this function has been called", "class": "table_obj_value"},'
     '{"caption": "Time (s)", "title": "Function execution timing statistics", "columns": ['
          '{"caption": "Total", "id": "total_time", "class": "table_obj_value", "title": "Time spent in this function and all other functions called by it"},'
          '{"caption": "Self", "id": "self_time", "class": "table_obj_value", "title": "Time spent in this function itself, not including other functions called by it"},'
          '{"caption": "Mean", "id": "m_time", "class": "table_obj_value", "title": "Mean total time per execution"},'
          '{"caption": "Mean self", "id": "m_stime", "class": "table_obj_value", "title": "Mean self time per execution"}'
     ']}'
    ']'
  '}]'::jsonb)
;

-- Vacuum section of a regular report
INSERT INTO report_struct (
  report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
  content, sect_struct)
VALUES
(1, 'vacops', 'vachdr', 100, 'Top tables by vacuum operations', 'Top tables by vacuum operations', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_vac_cnt"},'
    '"ordering": "ord_vac_cnt",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name"},'
     '{"caption": "Vacuum count", "title": "Number of times vacuum operation was performed on the underlying table", "columns": ['
          '{"caption": "Vacuum", "id": "vacuum_count", "title": "Number of times this table has been manually vacuumed (not counting VACUUM FULL)", "class": "table_obj_value"},'
          '{"caption": "AutoVacuum", "id": "autovacuum_count", "title": "Number of times this table has been vacuumed by the autovacuum daemon", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Vacuum time (s)", "title": "Time spent by vacuum operations on a table", "condition": "vacuum_time", "columns": ['
          '{"caption": "Vacuum", "id": "total_vacuum_time", "title": "Total time this table has been manually vacuumed, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"},'
          '{"caption": "AutoVacuum", "id": "total_autovacuum_time", "title": "Total time this table has been vacuumed by the autovacuum daemon, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Ins", "id": "n_tup_ins", "class": "table_obj_value", "title": "Number of rows inserted"},'
     '{"caption": "Upd", "id": "n_tup_upd", "class": "table_obj_value", "title": "Number of rows updated (includes HOT updated rows)"},'
     '{"caption": "Del", "id": "n_tup_del", "class": "table_obj_value", "title": "Number of rows deleted"},'
     '{"caption": "Upd(HOT)", "id": "n_tup_hot_upd", "class": "table_obj_value", "title": "Number of rows HOT updated (i.e., with no separate index update required)"}'
    ']'
  '}]'::jsonb),
(1, 'anops', 'vachdr', 150, 'Top tables by analyze operations', 'Top tables by analyze operations', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_anl_cnt"},'
    '"ordering": "ord_anl_cnt",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name"},'
     '{"caption": "Analyze count", "title": "Number of times vacuum operation was performed on the underlying table", "columns": ['
          '{"caption": "Analyze", "id": "analyze_count", "title": "Number of times this table has been manually analyzed", "class": "table_obj_value"},'
          '{"caption": "AutoAnalyze", "id": "autoanalyze_count", "title": "Number of times this table has been analyzed by the autovacuum daemon", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Analyze time (s)", "title": "Time spent by analyze operations on a table", "condition": "analyze_time", "columns": ['
          '{"caption": "Analyze", "id": "total_analyze_time", "title": "Total time this table has been manually analyzed, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"},'
          '{"caption": "AutoAnalyze", "id": "total_autoanalyze_time", "title": "Total time this table has been analyzed by the autovacuum daemon, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Ins", "id": "n_tup_ins", "class": "table_obj_value", "title": "Number of rows inserted"},'
     '{"caption": "Upd", "id": "n_tup_upd", "class": "table_obj_value", "title": "Number of rows updated (includes HOT updated rows)"},'
     '{"caption": "Del", "id": "n_tup_del", "class": "table_obj_value", "title": "Number of rows deleted"},'
     '{"caption": "Upd(HOT)", "id": "n_tup_hot_upd", "class": "table_obj_value", "title": "Number of rows HOT updated (i.e., with no separate index update required)"}'
    ']}]'::jsonb),
(1, 'vactime', 'vachdr', 200, 'Top tables by vacuum time spent', 'Top tables by vacuum time spent', 'vacuum_time', NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_vac_time"},'
    '"ordering": "ord_vac_time",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name"},'
     '{"caption": "Vacuum time (s)", "title": "Time spent by vacuum operations on a table", "columns": ['
          '{"caption": "Vacuum", "id": "total_vacuum_time", "title": "Total time this table has been manually vacuumed, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"},'
          '{"caption": "AutoVacuum", "id": "total_autovacuum_time", "title": "Total time this table has been vacuumed by the autovacuum daemon, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Vacuum count", "title": "Number of times vacuum operation was performed on the underlying table", "columns": ['
          '{"caption": "Vacuum", "id": "vacuum_count", "title": "Number of times this table has been manually vacuumed (not counting VACUUM FULL)", "class": "table_obj_value"},'
          '{"caption": "AutoVacuum", "id": "autovacuum_count", "title": "Number of times this table has been vacuumed by the autovacuum daemon", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Ins", "id": "n_tup_ins", "class": "table_obj_value", "title": "Number of rows inserted"},'
     '{"caption": "Upd", "id": "n_tup_upd", "class": "table_obj_value", "title": "Number of rows updated (includes HOT updated rows)"},'
     '{"caption": "Del", "id": "n_tup_del", "class": "table_obj_value", "title": "Number of rows deleted"},'
     '{"caption": "Upd(HOT)", "id": "n_tup_hot_upd", "class": "table_obj_value", "title": "Number of rows HOT updated (i.e., with no separate index update required)"}'
    ']'
  '}]'::jsonb),
(1, 'antime', 'vachdr', 250, 'Top tables by analyze time spent', 'Top tables by analyze time spent', 'analyze_time', NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_anl_time"},'
    '"ordering": "ord_anl_time",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name"},'
     '{"caption": "Analyze time (s)", "title": "Time spent by analyze operations on a table", "columns": ['
          '{"caption": "Analyze", "id": "total_analyze_time", "title": "Total time this table has been manually analyzed, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"},'
          '{"caption": "AutoAnalyze", "id": "total_autoanalyze_time", "title": "Total time this table has been analyzed by the autovacuum daemon, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Analyze count", "title": "Number of times vacuum operation was performed on the underlying table", "columns": ['
          '{"caption": "Analyze", "id": "analyze_count", "title": "Number of times this table has been manually analyzed", "class": "table_obj_value"},'
          '{"caption": "AutoAnalyze", "id": "autoanalyze_count", "title": "Number of times this table has been analyzed by the autovacuum daemon", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Ins", "id": "n_tup_ins", "class": "table_obj_value", "title": "Number of rows inserted"},'
     '{"caption": "Upd", "id": "n_tup_upd", "class": "table_obj_value", "title": "Number of rows updated (includes HOT updated rows)"},'
     '{"caption": "Del", "id": "n_tup_del", "class": "table_obj_value", "title": "Number of rows deleted"},'
     '{"caption": "Upd(HOT)", "id": "n_tup_hot_upd", "class": "table_obj_value", "title": "Number of rows HOT updated (i.e., with no separate index update required)"}'
    ']}]'::jsonb),
(1, 'ixvacest', 'vachdr', 300, 'Top indexes by estimated vacuum load', 'Top indexes by estimated vacuum load', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_indexes",'
    '"filter": {"type": "exists", "field": "ord_vac"},'
    '"ordering": "ord_vac",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1},'
      '{"id": "indexrelname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "indexrelid", "dataset": "index_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name"},'
     '{"caption": "Index", "id": "indexrelname", "class": "table_obj_name"},'
     '{"id": "vacuum_bytes_pretty", "caption": "Vacuum bytes", "class": "table_obj_value", "title": "Estimated implicit vacuum load caused by table indexes"},'
     '{"caption": "Vacuum count", "title": "Number of times vacuum operation was performed on the underlying table", "columns": ['
          '{"caption": "Vacuum", "id": "vacuum_count", "title": "Number of times this table has been manually vacuumed (not counting VACUUM FULL)", "class": "table_obj_value"},'
          '{"caption": "AutoVacuum", "id": "autovacuum_count", "title": "Number of times this table has been vacuumed by the autovacuum daemon", "class": "table_obj_value"}'
     ']},'
     '{"id": "avg_indexrelsize_pretty", "caption": "IX size", "class": "table_obj_value", "title": "Average index size during report interval"},'
     '{"id": "avg_relsize_pretty", "caption": "Relsize", "class": "table_obj_value", "title": "Average relation size during report interval"}'
    ']'
  '}]'::jsonb),
(1, 'tblbydead', 'vachdr', 400, 'Top tables by dead tuples ratio', 'Top tables by dead tuples ratio', 'top_tables_dead', NULL,
  '{"class": "notice", "text": "Data in this section is not differential. This data is valid for last report sample only"}',
  '[{'
    '"type": "row_table",'
    '"source": "top_tbl_last_sample",'
    '"filter": {"type": "exists", "field": "ord_dead"},'
    '"ordering": "ord_dead",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name"},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name"},'
     '{"caption": "Live", "id": "n_live_tup", "class": "table_obj_value", "title": "Estimated number of live rows"},'
     '{"caption": "Dead", "id": "n_dead_tup", "class": "table_obj_value", "title": "Estimated number of dead rows"},'
     '{"caption": "%Dead", "id": "dead_pct", "class": "table_obj_value", "title": "Dead rows count as a percentage of total rows count"},'
     '{"caption": "Last AV", "id": "last_autovacuum", "class": "table_obj_value", "title": "Last autovacuum ran time"},'
     '{"caption": "Size", "id": "relsize_pretty", "class": "table_obj_value", "title": "Table size without indexes and TOAST"}'
    ']'
  '}]'::jsonb),
(1, 'tblbymod', 'vachdr', 500, 'Top tables by modified tuples ratio', 'Top tables by modified tuples ratio', 'top_tables_mods', NULL,
  '{"class": "notice", "text": "Data in this section is not differential. This data is valid for last report sample only"}',
  '[{'
    '"type": "row_table",'
    '"source": "top_tbl_last_sample",'
    '"filter": {"type": "exists", "field": "ord_mod"},'
    '"ordering": "ord_mod",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name"},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name"},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name"},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name"},'
     '{"caption": "Live", "id": "n_live_tup", "class": "table_obj_value", "title": "Estimated number of live rows"},'
     '{"caption": "Dead", "id": "n_dead_tup", "class": "table_obj_value", "title": "Estimated number of dead rows"},'
     '{"caption": "Mod", "id": "n_mod_since_analyze", "class": "table_obj_value", "title": "Estimated number of rows modified since this table was last analyzed"},'
     '{"caption": "%Mod", "id": "mods_pct", "class": "table_obj_value", "title": "Modified rows of the table as a percentage of all rows in the table"},'
     '{"caption": "Last AA", "id": "last_autoanalyze", "class": "table_obj_value", "title": "Last autoanalyze ran time"},'
     '{"caption": "Size", "id": "relsize_pretty", "class": "table_obj_value", "title": "Table size without indexes and TOAST"}'
    ']'
  '}]'::jsonb)
;

-- Settings sections
INSERT INTO report_struct(
    report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
    content, sect_struct)
VALUES
(1, 'definedset', 'settings', 800, NULL, NULL, NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "settings",'
    '"filter": {"type": "exists", "field": "defined_val"},'
    '"columns": ['
     '{"caption": "Defined settings", "columns": ['
          '{"caption": "Setting", "id": "name", "class": "table_obj_value"},'
          '{"caption": "reset_val", "id": "reset_val", "class": "table_obj_value switch_bold"},'
          '{"caption": "Unit", "id": "unit", "class": "table_obj_value"},'
          '{"caption": "Source", "id": "source", "class": "table_obj_value"},'
          '{"caption": "Notes", "id": "notes", "class": "table_obj_value switch_bold"}'
     ']}'
    ']'
  '},'
  '{'
    '"type": "row_table",'
    '"source": "settings",'
    '"filter": {"type": "exists", "field": "default_val"},'
    '"columns": ['
     '{"caption": "Default settings", "columns": ['
          '{"caption": "Setting", "id": "name", "class": "table_obj_value"},'
          '{"caption": "reset_val", "id": "reset_val", "class": "table_obj_value switch_bold"},'
          '{"caption": "Unit", "id": "unit", "class": "table_obj_value"},'
          '{"caption": "Source", "id": "source", "class": "table_obj_value"},'
          '{"caption": "Notes", "id": "notes", "class": "table_obj_value switch_bold"}'
     ']}'
    ']'
  '}]'::jsonb)
;

-- Extension sections
INSERT INTO report_struct(
    report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
    content, sect_struct)
VALUES
(1, 'extension_versions', 'extensions', 900, NULL, NULL, NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "extension_versions",'
    '"ordering": "ord_ext",'
    '"columns": ['
     '{"caption": "Name", "id": "extname", "class": "table_obj_name", "title": "Name of the extension"},'
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name", "title": "Name of the database"},'
     '{"caption": "First seen", "condition": "extension_versions_show_date_columns", "id": "first_seen", "class": "table_obj_value", "title": " The first appearance this extension version"},'
     '{"caption": "Last seen", "condition": "extension_versions_show_date_columns", "id": "last_seen", "class": "table_obj_value", "title": "The last appearance of the extension version"},'
     '{"caption": "Version", "id": "extversion", "class": "table_obj_value", "title": "Version name for the extension"}'
    ']'
  '}]'::jsonb)
;

-- Schema objects section of a differential report
INSERT INTO report_struct (
  report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
  content, sect_struct)
VALUES
(2, 'rep_details', NULL, 10, 'Report details', 'Report details', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "properties",'
    '"columns": ['
        '{"id": "pgprofile_version", "class": "hdr table_obj_value", "caption": "Version", "rowspan": true},'
        '{"id": "server_name", "class": "hdr table_obj_value", "caption": "Server name", "rowspan": true},'
        '{"id": ["1", "2"], "class": "interval", "title":["properties.timePeriod1", "properties.timePeriod2"], "caption": "I"},'
        '{"caption": "Interval (sample)", "columns": ['
          '{"id": ["start1_id", "start2_id"], "class": "table_obj_value", "caption": "start"},'
          '{"id": ["end1_id", "end2_id"], "class": "table_obj_value", "caption": "end"}'
        ']},'
        '{"caption": "Interval (time)", "columns": ['
          '{"id": ["report_start1", "report_start2"], "class": "table_obj_value", "caption": "start"},'
          '{"id": ["report_end1", "report_end2"], "class": "table_obj_value", "caption": "end"}'
        ']}'
    ']}]'::jsonb),
(2, 'rep_settings', NULL, 11, NULL, NULL, NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "settings",'
    '"filter": {"type": "exists", "field": "h_ord"},'
    '"ordering": "h_ord",'
    '"columns": ['
      '{"caption": "Setting", "id": "name", "class": "table_obj_name"},'
      '{"caption": "Value", "id": "reset_val", "class": "table_obj_value"}'
    ']'
  '}]'::jsonb),
(2, 'stmt_cmt1', NULL, 100, NULL, NULL, 'stmt_cnt_range', NULL,
  '{"class": "warning", "text": "Report interval contains sample(s) with captured statements count more than 90% of pg_stat_statements.max. '
  'Consider increasing pg_stat_statements.max parameter."}',
  '[{'
    '"type": "row_table", '
    '"source": "stmt_cnt_range",'
    '"ordering": "ord",'
    '"columns": ['
        '{"id": "sample_id", "class": "table_obj_value", "caption": "Sample ID"}, '
        '{"id": "sample_time", "class": "table_obj_value", "caption": "Sample Time"}, '
        '{"id": "stmt_cnt", "class": "table_obj_value", "caption": "Stmts Captured"}, '
        '{"id": "max_cnt", "class": "table_obj_value", "caption": "pg_stat_statements.max"}'
    ']}]'::jsonb),
(2, 'srvstat', NULL, 300, 'Server statistics', 'Server statistics', NULL, NULL, NULL, NULL),
(2, 'actsesshdr', NULL, 350, 'Session states', 'Session states observed by subsamples', 'act_backend', NULL,
  '{"class": "notice", "text": "Statistics about session states exceeding capturing thresholds."}', NULL),
(2, 'sqlsthdr', NULL, 400, 'SQL query statistics', 'SQL query statistics', 'statstatements', NULL, NULL, NULL),
(2, 'objects', NULL, 500, 'Schema object statistics', 'Schema object statistics', NULL, NULL, NULL, NULL),
(2, 'funchdr', NULL, 600, 'User function statistics', 'User function statistics', 'function_stats', NULL, NULL, NULL),
(2, 'vachdr', NULL, 700, 'Vacuum-related statistics', 'Vacuum-related statistics', NULL, NULL, NULL, NULL),
(2, 'settings', NULL, 800, 'Cluster settings', 'Cluster settings during the report interval', NULL, NULL, NULL, NULL),
(2, 'extensions', NULL, 850, 'Extension versions', 'Extension versions during the report interval', NULL, NULL, NULL, NULL),
(2, 'stmt_warn', NULL, 900, NULL, 'Warning!', 'stmt_cnt_all', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "stmt_cnt_all",'
    '"ordering": "sample_id",'
    '"columns": ['
        '{"id": "sample_id", "class": "table_obj_value", "caption": "Sample ID"}, '
        '{"id": "sample_time", "class": "table_obj_value", "caption": "Sample Time"}, '
        '{"id": "stmt_cnt", "class": "table_obj_value", "caption": "Stmts Captured"}, '
        '{"id": "max_cnt", "class": "table_obj_value", "caption": "pg_stat_statements.max"}'
    ']}]'::jsonb)
;


-- Server section of differential report
INSERT INTO report_struct (
  report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name, content,
  sect_struct)
VALUES
(2, 'dbstat', 'srvstat', 100, 'Database statistics', 'Database statistics', NULL, NULL, NULL, NULL),
(2, 'dbstatreset', 'dbstat', 200, NULL, NULL, 'dbstats_reset', NULL,
  '{"class": "warning", "text": "Database statistics reset detected during report interval! '
  'Statistics for listed databases and contained objects might be affected."}',
  '[{'
    '"type": "row_table", '
    '"source": "dbstats_reset", '
    '"ordering": "sample_id",'
    '"columns": ['
        '{"id": "interval_num", "class": "table_obj_value", "caption": "I"}, '
        '{"id": "dbname", "class": "table_obj_name", "caption": "Database"}, '
        '{"id": "sample_id", "class": "table_obj_value", "caption": "Sample"}, '
        '{"id": "stats_reset", "class": "table_obj_value", "caption": "Reset time"}'
    ']'
  '}]'::jsonb),
(2, 'dbstatmain', 'dbstat', 300, NULL, NULL, NULL, NULL, NULL,
'[{'
    '"type": "row_table", '
    '"source": "dbstat", '
    '"ordering": "ord_db",'
    '"highlight": ['
      '{"id": "dbname", "index": 0}'
    '],'
    '"columns": ['
        '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
        '{"id": ["1", "2"], "class": "interval", "title":["properties.timePeriod1", "properties.timePeriod2"], "caption": "I"}, '
        '{"caption": "Transactions", "columns": ['
            '{"id": ["xact_commit1", "xact_commit2"], "class": "table_obj_value", "title": "Number of transactions in this database that have been committed", "caption": "Commits"}, '
            '{"id": ["xact_rollback1", "xact_rollback2"], "class": "table_obj_value", "title": "Number of transactions in this database that have been rolled back", "caption": "Rollbacks"}, '
            '{"id": ["deadlocks1", "deadlocks2"], "class": "table_obj_value", "title": "Number of deadlocks detected in this database", "caption": "Deadlocks"}'
        ']}, '
        '{"caption": "Checksums", "condition": "checksum_fail_detected", "columns": ['
            '{"id": ["checksum_failures1", "checksum_failures2"], "class": "table_obj_value", "title": "Number of block checksum failures detected", "caption": "Failures"}, '
            '{"id": ["checksum_last_failure1", "checksum_last_failure2"], "class": "table_obj_value", "title": "Last checksum failure detected", "caption": "Last"}
            ]}, '
        '{"caption": "Block statistics", "columns": ['
            '{"id": ["blks_hit_pct1", "blks_hit_pct2"], "class": "table_obj_value", "title": "Buffer cache hit ratio", "caption": "Hit(%)"}, '
            '{"id": ["blks_read1", "blks_read2"], "class": "table_obj_value", "title": "Number of disk blocks read in this database", "caption": "Read"}, '
            '{"id": ["blks_hit1", "blks_hit2"], "class": "table_obj_value", "title": "Number of times disk blocks were found already in the buffer cache", "caption": "Hit"}'
        ']}, '
        '{"caption": "Block I/O times", "condition": "io_times", "columns": ['
            '{"id": ["blk_read_time1", "blk_read_time2"], "class": "table_obj_value", "title": "Time spent reading data file blocks by backends", "caption": "Read"}, '
            '{"id": ["blk_write_time1", "blk_write_time2"], "class": "table_obj_value", "title": "Time spent writing data file blocks by backends", "caption": "Write"} '
        ']}, '
        '{"caption": "Tuples", "columns": ['
            '{"id": ["tup_returned1", "tup_returned2"], "class": "table_obj_value", "title": "Number of rows returned by queries in this database", "caption": "Ret"}, '
            '{"id": ["tup_fetched1", "tup_fetched2"], "class": "table_obj_value", "title": "Number of rows fetched by queries in this database", "caption": "Fet"}, '
            '{"id": ["tup_inserted1", "tup_inserted2"], "class": "table_obj_value", "title": "Number of rows inserted by queries in this database", "caption": "Ins"}, '
            '{"id": ["tup_updated1", "tup_updated2"], "class": "table_obj_value", "title": "Number of rows updated by queries in this database", "caption": "Upd"}, '
            '{"id": ["tup_deleted1", "tup_deleted2"], "class": "table_obj_value", "title": "Number of rows deleted", "caption": "Del"}'
        ']},'
        '{"caption": "Parallel workers", "condition": "db_parallel_workers", "columns": ['
           '{"id": ["parallel_workers_to_launch1", "parallel_workers_to_launch2"], "class": "table_obj_value", "title": "Number of parallel workers planned to be launched by queries on this database", "caption": "Planned"},'
           '{"id": ["parallel_workers_launched1", "parallel_workers_launched2"], "class": "table_obj_value", "title": "Number of parallel workers launched by queries on this database", "caption": "Launched"}'
        ']}, '
        '{"caption": "Temp files", "columns": ['
            '{"id": ["temp_bytes1", "temp_bytes2"], "class": "table_obj_value", "title": "Total amount of data written to temporary files by queries in this database", "caption": "Size"}, '
            '{"id": ["temp_files1", "temp_files2"], "class": "table_obj_value", "title": "Number of temporary files created by queries in this database", "caption": "Files"}'
        ']}, '
        '{"id": ["datsize1", "datsize2"], "class": "table_obj_value", "title": "Database size as is was at the moment of last sample in report interval", "caption": "Size"}, '
        '{"id": ["datsize_delta1", "datsize_delta2"], "class": "table_obj_value", "title": "Database size increment during report interval", "caption": "Growth"} '
']}]'::jsonb),
(2, 'iostat', 'srvstat', 328, 'Cluster I/O statistics', 'Cluster I/O statistics', 'stat_io', NULL, NULL, NULL),
(2, 'iostatrst', 'srvstat', 329, NULL, NULL, 'stat_io_reset', NULL,
'{"class": "warning", "text": "IO stats reset was detected during report interval. Statistic values may be affected"}',
'[{'
    '"type": "row_table",'
    '"source": "stat_io_reset",'
    '"columns": ['
      '{"caption": "Sample ID", "id": "sample_id", "class": "table_obj_name", '
        '"title": "Sample identifier with detected reset"},'
      '{"caption": "Object", "id": "object", "class": "table_obj_name", '
        '"title": "Target object of an I/O operation"},'
      '{"caption": "Backend", "id": "backend_type", "class": "table_obj_name", '
        '"title": "Type of backend (see stat_activity)"},'
      '{"caption": "Context", "id": "context", "class": "table_obj_name", '
        '"title": "The context of an I/O operation"},'
      '{"caption": "Reset time", "id": "stats_reset", "class": "table_obj_value", '
        '"title": "Date and time of the last reset performed in sample"}'
    ']'
    '}]'::jsonb),
(2, 'iostatmain', 'srvstat', 330, NULL, NULL, 'stat_io', NULL, NULL,
'[{'
    '"type": "row_table",'
    '"source": "stat_io",'
    '"columns": ['
      '{"caption": "Object", "id": "object", "class": "table_obj_name hdr", "rowspan": true, '
        '"title": "Target object of an I/O operation"},'
      '{"caption": "Backend", "id": "backend_type", "class": "table_obj_name hdr", "rowspan": true, '
        '"title": "Type of backend (see stat_activity)"},'
      '{"caption": "Context", "id": "context", "class": "table_obj_name hdr", "rowspan": true, '
        '"title": "The context of an I/O operation"},'
      '{"id": ["1", "2"], "class": "interval", "title":["properties.timePeriod1", "properties.timePeriod2"], "caption": "I"},'
      '{"caption": "Reads", "columns": ['
        '{"caption": "Count", "id": ["reads1", "reads2"], "class": "table_obj_value", '
          '"title": "Number of read operations"},'
        '{"caption": "Bytes", "id": ["read_sz1", "read_sz2"], "class": "table_obj_value", '
          '"title": "Read data amount"},'
        '{"caption": "Time", "id": ["read_time1", "read_time2"], "class": "table_obj_value", '
          '"condition": "io_times", '
          '"title": "Time spent in reading operation (seconds)"}'
     ']},'
      '{"caption": "Writes", "columns": ['
        '{"caption": "Count", "id": ["writes1", "writes2"], "class": "table_obj_value", '
          '"title": "Number of write operations"},'
        '{"caption": "Bytes", "id": ["write_sz1", "write_sz2"], "class": "table_obj_value", '
          '"title": "Written data amount"},'
        '{"caption": "Time", "id": ["write_time1", "write_time2"], "class": "table_obj_value", '
          '"condition": "io_times", '
          '"title": "Time spent in writing operations (seconds)"}'
     ']},'
      '{"caption": "Writebacks", "columns": ['
        '{"caption": "Count", "id": ["writebacks1", "writebacks2"], "class": "table_obj_value", '
          '"title": "Number of blocks which the process requested the kernel write out to permanent storage"},'
        '{"caption": "Bytes", "id": ["writeback_sz1", "writeback_sz2"], "class": "table_obj_value", '
          '"title": "The amount of data requested for write out to permanent storage"},'
        '{"caption": "Time", "id": ["writeback_time1", "writeback_time2"], "class": "table_obj_value", '
          '"condition": "io_times", '
          '"title": "Time spent in writeback operations (seconds)"}'
     ']},'
      '{"caption": "Extends", "columns": ['
        '{"caption": "Count", "id": ["extends1", "extends2"], "class": "table_obj_value", '
          '"title": "Number of relation extend operations"},'
        '{"caption": "Bytes", "id": ["extend_sz1", "extend_sz2"], "class": "table_obj_value", '
          '"title": "The amount of space used by extend operations"},'
        '{"caption": "Time", "id": ["extend_time1", "extend_time2"], "class": "table_obj_value", '
          '"condition": "io_times", '
          '"title": "Time spent in extend operations (seconds)"}'
     ']},'
     '{"caption": "Hits", "id": ["hits1", "hits2"], "class": "table_obj_value", '
       '"title": "The number of times a desired block was found in a shared buffer"},'
     '{"caption": "Evictions", "id": ["evictions1", "evictions2"], "class": "table_obj_value", '
       '"title": "Number of times a block has been written out from a shared or local buffer in order to make it available for another use"},'
     '{"caption": "Reuses", "id": ["reuses1", "reuses2"], "class": "table_obj_value", '
       '"title": "The number of times an existing buffer in a size-limited ring buffer outside of shared buffers was reused as part of an I/O operation in the bulkread, bulkwrite, or vacuum contexts"},'
      '{"caption": "Fsyncs", "columns": ['
        '{"caption": "Count", "id": ["fsyncs1", "fsyncs2"], "class": "table_obj_value", '
          '"title": "Number of fsync calls. These are only tracked in context normal"},'
        '{"caption": "Time", "id": ["fsync_time1", "fsync_time2"], "class": "table_obj_value", '
          '"condition": "io_times", '
          '"title": "Time spent in fsync operations (seconds)"}'
     ']}'
    ']'
    '}]'::jsonb),
(2, 'slrustat', 'srvstat', 358, 'Cluster SLRU statistics', 'Cluster SLRU statistics', 'stat_slru', NULL, NULL, NULL),
(2, 'slrustatrst', 'slrustat', 359, NULL, NULL, 'stat_slru_reset', NULL,
'{"class": "warning", "text": "SLRU stats reset was detected during report interval. Statistic values may be affected"}',
'[{'
    '"type": "row_table",'
    '"source": "stat_slru_reset",'
    '"columns": ['
      '{"caption": "Sample ID", "id": "sample_id", "class": "table_obj_name", '
        '"title": "Sample identifier with detected reset"},'
      '{"caption": "Name", "id": "name", "class": "table_obj_name", '
        '"title": "Name of the SLRU"},'
      '{"caption": "Reset time", "id": "stats_reset", "class": "table_obj_value", '
        '"title": "Date and time of the last reset performed in sample"}'
    ']'
    '}]'::jsonb),
(2, 'slrustatmain', 'slrustat', 360, NULL, NULL, 'stat_slru', NULL, NULL,
'[{'
    '"type": "row_table",'
    '"source": "stat_slru",'
    '"columns": ['
      '{"caption": "Name", "id": "name", "class": "table_obj_name hdr", "rowspan": true, '
        '"title": "Name of the SLRU"},'
      '{"id": ["1", "2"], "class": "interval", "title":["properties.timePeriod1", "properties.timePeriod2"], "caption": "I"},'
      '{"caption": "Zeroed", "id": ["blks_zeroed1", "blks_zeroed2"], "class": "table_obj_value", '
        '"title": "Number of blocks zeroed during initializations"},'
      '{"caption": "Hits", "id": ["blks_hit1", "blks_hit2"], "class": "table_obj_value", '
        '"title": "Number of times disk blocks were found already in the SLRU, so that a '
        'read was not necessary (this only includes hits in the SLRU, not the operating '
        'system''s file system cache)"},'
      '{"caption": "Reads", "id": ["blks_read1", "blks_read2"], "class": "table_obj_value", '
        '"title": "Number of disk blocks read for this SLRU"},'
      '{"caption": "%Hit", "id": ["hit_pct1", "hit_pct2"], "class": "table_obj_value", '
        '"title": "Number of disk blocks hits for this SLRU as a percentage of reads + hits"},'
      '{"caption": "Writes", "id": ["blks_written1", "blks_written2"], "class": "table_obj_value", '
        '"title": "Number of disk blocks written for this SLRU"},'
      '{"caption": "Checked", "id": ["blks_exists1", "blks_exists2"], "class": "table_obj_value", '
        '"title": "Number of blocks checked for existence for this SLRU (blks_exists field)"},'
      '{"caption": "Flushes", "id": ["flushes1", "flushes2"], "class": "table_obj_value", '
        '"title": "Number of flushes of dirty data for this SLRU"},'
      '{"caption": "Truncates", "id": ["truncates1", "truncates2"], "class": "table_obj_value", '
        '"title": "Number of truncates for this SLRU"}'
    ']'
    '}]'::jsonb),
(2, 'sesstat', 'srvstat', 400, 'Session statistics by database', 'Session statistics by database', 'sess_stats', NULL, NULL,
'[{'
    '"type": "row_table",'
    '"source": "dbstat", '
    '"ordering": "ord_db",'
    '"highlight": ['
      '{"id": "dbname", "index": 0}'
    '],'
    '"columns": ['
        '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true},'
        '{"id": ["1", "2"], "class": "interval", "title":["properties.timePeriod1", "properties.timePeriod2"], "caption": "I"},'
        '{"caption": "Timings (s)", "columns": ['
          '{"id": ["session_time1", "session_time2"], "class": "table_obj_value", "title": "Time spent by database sessions in this database (note that statistics are only updated when the state of a session changes, so if sessions have been idle for a long time, this idle time wont be included)", "caption": "Total"},'
          '{"id": ["active_time1", "active_time2"], "class": "table_obj_value", "title": "Time spent executing SQL statements in this database (this corresponds to the states active and fastpath function call in pg_stat_activity)", "caption": "Active"},'
          '{"id": ["idle_in_transaction_time1", "idle_in_transaction_time2"], "class": "table_obj_value", "title": "Time spent idling while in a transaction in this database (this corresponds to the states idle in transaction and idle in transaction (aborted) in pg_stat_activity)", "caption": "Idle(T)"}'
        ']},'
        '{"caption": "Sessions", "columns": ['
          '{"id": ["sessions1", "sessions2"], "class": "table_obj_value", "title": "Total number of sessions established to this database", "caption": "Established"},'
          '{"id": ["sessions_abandoned1", "sessions_abandoned2"], "class": "table_obj_value", "title": "Number of database sessions to this database that were terminated because connection to the client was lost", "caption": "Abondoned"},'
          '{"id": ["sessions_fatal1", "sessions_fatal2"], "class": "table_obj_value", "title": "Number of database sessions to this database that were terminated by fatal errors", "caption": "Fatal"},'
          '{"id": ["sessions_killed1", "sessions_killed2"], "class": "table_obj_value", "title": "Number of database sessions to this database that were terminated by operator intervention", "caption": "Killed"}'
        ']}'
    ']}]'::jsonb),
(2, 'stmtstat', 'srvstat', 500, 'Statement statistics by database', 'Statement statistics by database', 'statstatements', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "statements_dbstats",'
    '"ordering": "ord_db",'
    '"highlight": ['
      '{"id": "dbname", "index": 0}'
    '],'
    '"columns": ['
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": "true"}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"}, '
      '{"id": ["calls1", "calls2"], "class": "table_obj_value", "title": "Number of query executions", "caption": "Calls"}, '
      '{"caption": "Time (s)", "columns": ['
        '{"id": ["total_plan_time1", "total_plan_time2"], "class": "table_obj_value", "title": "Time spent planning queries", "caption": "Plan", "condition": "planning_times"}, '
        '{"id": ["total_exec_time1", "total_exec_time2"], "class": "table_obj_value", "title": "Time spent executing queries", "caption": "Exec"}, '
        '{"id": ["shared_blk_read_time1", "shared_blk_read_time2"], "class": "table_obj_value", "title": "Time spent reading blocks", "caption": "Read"}, '
        '{"id": ["shared_blk_write_time1", "shared_blk_write_time2"], "class": "table_obj_value", "title": "Time spent writing blocks", "caption": "Write"}, '
        '{"id": ["trg_fn_total_time1", "trg_fn_total_time2"], "class": "table_obj_value", "title": "Time spent in trigger functions", "caption": "Trg"}'
        ']}, '
      '{"caption": "Temp I/O Time", "condition": "statements_temp_io_times", "columns": ['
        '{"id": ["temp_blk_read_time1", "temp_blk_read_time2"], "class": "table_obj_value", "title": "Time spent reading temporary file blocks, in seconds", "caption": "Read"}, '
        '{"id": ["temp_blk_write_time1", "temp_blk_write_time2"], "class": "table_obj_value", "title": "Time spent writing temporary file blocks, in seconds", "caption": "Write"} '
        ']}, '
      '{"title": "Number of blocks fetched (hit + read)", "caption": "Fetched (blk)", "columns": ['
        '{"id": ["shared_gets1", "shared_gets2"], "class": "table_obj_value", "caption": "Shared"}, '
        '{"id": ["local_gets1", "local_gets2"], "class": "table_obj_value", "caption": "Local"}'
        ']}, '
      '{"title": "Number of blocks read", "caption": "Read (blk)", "columns": ['
        '{"id": ["shared_reads1", "shared_reads2"], "class": "table_obj_value", "caption": "Shared"}, '
        '{"id": ["local_reads1", "local_reads2"], "class": "table_obj_value", "caption": "Local"}'
        ']}, '
      '{"title": "Number of blocks dirtied", "caption": "Dirtied (blk)", "columns": ['
        '{"id": ["shared_blks_dirtied1", "shared_blks_dirtied2"], "class": "table_obj_value", "caption": "Shared"}, '
        '{"id": ["local_blks_dirtied1", "local_blks_dirtied2"], "class": "table_obj_value", "caption": "Local"}'
        ']}, '
      '{"title": "Number of blocks, used in operations (like sorts and joins)", "caption": "Temp (blk)", "columns": ['
        '{"id": ["temp_blks_read1", "temp_blks_read2"], "class": "table_obj_value", "caption": "Read"}, '
        '{"id": ["temp_blks_written1", "temp_blks_written2"], "class": "table_obj_value", "caption": "Write"}'
        ']}, '
      '{"title": "Number of blocks, used for temporary tables", "caption": "Local (blk)", "columns": ['
        '{"id": ["local_blks_read1", "local_blks_read2"], "class": "table_obj_value", "caption": "Read"}, '
        '{"id": ["local_blks_written1", "local_blks_written2"], "class": "table_obj_value", "caption": "Write"}'
        ']}, '
      '{"id": ["statements1", "statements2"], "class": "table_obj_value", "caption": "Statements"}, '
      '{"id": ["wal_bytes1", "wal_bytes2"], "class": "table_obj_value", "caption": "WAL size", "condition": "statement_wal_bytes"},'
      '{"id": ["wal_buffers_full1", "wal_buffers_full2"], "class": "table_obj_value", "title": "Number of times the WAL buffers became full", "caption": "WAL buffers full", "condition": "wal_buffers_full"}'
    ']}]'::jsonb),
(2, 'stmtminmax', 'srvstat', 520, 'Statement average min/max timings', 'Statement average min/max timings', 'mean_mm_times', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "statements_dbstats",'
    '"ordering": "ord_db",'
    '"highlight": ['
      '{"id": "dbname", "index": 0}'
    '],'
    '"columns": ['
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": "true"}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"},'
      '{"caption": "Average planning times (ms)", "condition": "planning_times", "columns": ['
          '{"id": ["mean_min_plan_time1", "mean_min_plan_time2"], "class": "table_obj_value", "title": "The average value of min_plan_time for all statements", "caption": "Min (ms.)"}, '
          '{"id": ["mean_max_plan_time1", "mean_max_plan_time2"], "class": "table_obj_value", "title": "The average value of max_plan_time for all statements", "caption": "Max (ms.)"}, '
          '{"id": ["min_max_plan_delta1", "min_max_plan_delta2"], "class": "table_obj_value", "title": "Mean max planning time to mean min planning time delta as a percentage of mean min planning time", "caption": "Delta%"} '
      ']}, '
      '{"caption": "Average execution times (ms)", "columns": ['
          '{"id": ["mean_min_exec_time1", "mean_min_exec_time2"], "class": "table_obj_value", "title": "The average value of min_exec_time for all statements", "caption": "Min (ms.)"}, '
          '{"id": ["mean_max_exec_time1", "mean_max_exec_time2"], "class": "table_obj_value", "title": "The average value of max_exec_time for all statements", "caption": "Max (ms.)"}, '
          '{"id": ["min_max_exec_delta1", "min_max_exec_delta2"], "class": "table_obj_value", "title": "Mean max exec time to mean min exec time delta as a percentage of mean min exec time", "caption": "Delta%"} '
      ']}, '
      '{"id": ["statements1", "statements2"], "class": "table_obj_value", "caption": "Statements"} '
    ']}]'::jsonb),
(2, 'dbjitstat', 'srvstat', 550, 'JIT statistics by database', 'JIT statistics by database', 'statements_jit_stats', NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "statements_dbstats",'
    '"ordering": "ord_db",'
    '"highlight": ['
      '{"id": "dbname", "index": 0}'
    '],'
    '"columns": ['
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": "true"},'
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"},'
      '{"id": ["calls1", "calls2"], "class": "table_obj_value", "title": "Number of query executions", "caption": "Calls"},'
      '{"caption": "Time (s)", "columns": ['
          '{"id": ["total_plan_time1", "total_plan_time2"], "class": "table_obj_value", "title": "Time spent planning queries", "caption": "Plan", "condition": "planning_times"},'
          '{"id": ["total_exec_time1", "total_exec_time2"], "class": "table_obj_value", "title": "Time spent planning queries", "caption": "Exec"}'
          ']},'
      '{"caption": "Generation", "columns": ['
          '{"id": ["jit_functions1", "jit_functions2"], "class": "table_obj_value", "title": "Total number of functions JIT-compiled by the statements", "caption": "Count"},'
          '{"id": ["jit_generation_time1", "jit_generation_time2"], "class": "table_obj_value", "title": "Time spent by the statements on generating JIT code", "caption": "Time"}'
          ']},'
      '{"caption": "Inlining", "columns": ['
          '{"id": ["jit_inlining_count1", "jit_inlining_count2"], "class": "table_obj_value", "title": "Number of times functions have been inlined", "caption": "Count"},'
          '{"id": ["jit_inlining_time1", "jit_inlining_time2"], "class": "table_obj_value", "title": "Time spent by statements on inlining functions", "caption": "Time"}'
          ']},'
      '{"caption": "Optimization", "columns": ['
          '{"id": ["jit_optimization_count1", "jit_optimization_count2"], "class": "table_obj_value", "title": "Number of times statements hasbeen optimized", "caption": "Count"},'
          '{"id": ["jit_optimization_time1", "jit_optimization_time2"], "class": "table_obj_value", "title": "Time spent by statements on optimizing", "caption": "Time"}'
          ']},'
      '{"caption": "Emission", "columns": ['
          '{"id": ["jit_emission_count1", "jit_emission_count2"], "class": "table_obj_value", "title": "Number of times code has been emitted", "caption": "Count"},'
          '{"id": ["jit_emission_time1", "jit_emission_time2"], "class": "table_obj_value", "title": "Time spent by the statement on emitting code", "caption": "Exec"} '
          ']},'
      '{"caption": "Deform", "condition": "statements_jit_deform", "columns": ['
          '{"id": ["jit_deform_count1", "jit_deform_count2"], "class": "table_obj_value", "caption": "Count", "title": "Number of tuple deform functions JIT-compiled by the statement of the database."}, '
          '{"id": ["jit_deform_time1", "jit_deform_time2"], "class": "table_obj_value", "caption": "Time", "title": "Total time spent by the statements of the databse on JIT-compiling tuple deform functions, in seconds."}'
          ']}'
      ']}]'::jsonb),
(2, 'clusthdr', 'srvstat', 700, 'Cluster statistics', 'Cluster statistics', NULL, NULL, NULL, NULL),
(2, 'clustrst', 'srvstat', 800, NULL, NULL, 'cluster_stats_reset', NULL,
  '{"class": "warning", "text": "Cluster statistics reset detected during report interval! Cluster statistics might be affected"}',
  '[{'
    '"type": "row_table",'
    '"source": "cluster_stats_reset",'
    '"columns": ['
      '{"id": "interval_num", "class": "table_obj_value", "caption": "I"},'
      '{"id": "sample_id", "class": "table_obj_value", "caption": "Sample"},'
      '{"id": "bgwriter_stats_reset", "class": "table_obj_value", "caption": "BGWriter reset time"},'
      '{"id": "checkpoint_stats_reset", "class": "table_obj_value", "caption": "Checkpointer reset time"},'
      '{"id": "archiver_stats_reset", "class": "table_obj_value", "caption": "Archiver reset time"}'
    ']}]'::jsonb),
(2, 'clust', 'srvstat', 900, NULL, NULL, NULL, NULL, NULL,
  '[{'
    '"type": "column_table", '
    '"source": "cluster_stats",'
    '"columns": ['
        '{"caption": "Metric", "class": "table_obj_name"},'
        '{"caption": "Value (1)", "title": "properties.timePeriod1", "class": "table_obj_value int1"},'
        '{"caption": "Value (2)", "title": "properties.timePeriod2", "class": "table_obj_value int2"}'
    '],'
    '"rows": ['
        '{"caption": "Scheduled checkpoints", "cells": ['
            '{"id": "checkpoints_timed1"},'
            '{"id": "checkpoints_timed2"}'
        ']}, '
        '{"caption": "Requested checkpoints", "cells": ['
            '{"id": "checkpoints_req1"},'
            '{"id": "checkpoints_req2"}'
        ']}, '
        '{"caption": "Checkpoints done", "condition": "checkpoints_done_and_slru", "cells": ['
            '{"id": "checkpoints_done1"},'
            '{"id": "checkpoints_done2"}'
        ']}, '
        '{"caption": "Scheduled restartpoints", "condition": "restartpoints", "cells": ['
            '{"id": "restartpoints_timed1"},'
            '{"id": "restartpoints_timed2"}'
        ']}, '
        '{"caption": "Requested restartpoints", "condition": "restartpoints", "cells": ['
            '{"id": "restartpoints_req1"},'
            '{"id": "restartpoints_req"}'
        ']}, '
        '{"caption": "Restartpoints done", "condition": "restartpoints", "cells": ['
            '{"id": "restartpoints_done1"},'
            '{"id": "restartpoints_done2"}'
        ']}, '
        '{"caption": "Checkpoint write time (s)", "cells": ['
            '{"id": "checkpoint_write_time1"},'
            '{"id": "checkpoint_write_time2"}'
        ']}, '
        '{"caption": "Checkpoint sync time (s)", "cells": ['
            '{"id": "checkpoint_sync_time1"},'
            '{"id": "checkpoint_sync_time2"}'
        ']}, '
        '{"caption": "Checkpoint buffers written", "cells": ['
            '{"id": "buffers_checkpoint1"},'
            '{"id": "buffers_checkpoint2"}'
        ']}, '
        '{"caption": "SLRU buffers written by checkpoint", "condition": "checkpoints_done_and_slru", "cells": ['
            '{"id": "slru_checkpoint1"},'
            '{"id": "slru_checkpoint2"}'
        ']}, '
        '{"caption": "Background buffers written", "cells": ['
            '{"id": "buffers_clean1"},'
            '{"id": "buffers_clean2"}'
        ']}, '
        '{"caption": "Backend buffers written", "condition": "buffers_backend", "cells": ['
            '{"id": "buffers_backend1"},'
            '{"id": "buffers_backend2"}'
        ']}, '
        '{"caption": "Backend fsync count", "condition": "buffers_backend", "cells": ['
            '{"id": "buffers_backend_fsync1"},'
            '{"id": "buffers_backend_fsync2"}'
        ']}, '
        '{"caption": "Bgwriter interrupts (too many buffers)", "cells": ['
            '{"id": "maxwritten_clean1"},'
            '{"id": "maxwritten_clean2"}'
        ']}, '
        '{"caption": "Number of buffers allocated", "cells": ['
            '{"id": "buffers_alloc1"},'
            '{"id": "buffers_alloc2"}'
        ']}, '
        '{"caption": "WAL generated", "cells": ['
            '{"id": "wal_size_pretty1"},'
            '{"id": "wal_size_pretty2"}'
        ']}, '
        '{"caption": "Start LSN", "cells": ['
            '{"id": "start_lsn1"},'
            '{"id": "start_lsn2"}'
        ']}, '
        '{"caption": "End LSN", "cells": ['
            '{"id": "end_lsn1"},'
            '{"id": "end_lsn2"}'
        ']}, '
        '{"caption": "WAL segments archived", "cells": ['
            '{"id": "archived_count1"},'
            '{"id": "archived_count2"}'
        ']}, '
        '{"caption": "WAL segments archive failed", "cells": ['
            '{"id": "failed_count1"},'
            '{"id": "failed_count2"}'
        ']}'
    ']'
    '}]'::jsonb),
(2, 'walsthdr', 'srvstat', 1000, 'WAL statistics', 'WAL statistics', 'wal_stats', NULL, NULL, NULL),
(2, 'walstrst', 'srvstat', 1100, NULL, NULL, 'wal_stats_reset', NULL,
  '{"class": "warning", "text": "WAL statistics reset detected during report interval! WAL statistics might be affected"}',
  '[{'
    '"type": "row_table",'
    '"source": "wal_stats_reset",'
    '"columns": ['
      '{"id": "interval_num", "class": "table_obj_value", "caption": "I"},'
      '{"id": "sample_id", "class": "table_obj_value", "caption": "Sample"},'
      '{"id": "wal_stats_reset", "class": "table_obj_value", "caption": "WAL stats reset time"}'
    ']}]'::jsonb),
(2, 'walst', 'srvstat', 1200, NULL, NULL, 'wal_stats', NULL, NULL,
  '[{'
    '"type": "column_table",'
    '"source": "wal_stats",'
    '"columns": ['
        '{"caption": "Metric", "class": "table_obj_name"},'
        '{"caption": "Value (1)", "title": "properties.timePeriod1", "class": "table_obj_value int1"},'
        '{"caption": "Value (2)", "title": "properties.timePeriod2", "class": "table_obj_value int2"}'
    '],'
    '"rows": ['
      '{"caption": "WAL generated", "title": "Total amount of WAL generated", "cells": ['
          '{"id": "wal_bytes1"},'
          '{"id": "wal_bytes2"}'
      ']},'
      '{"caption": "WAL per second", "title": "Average amount of WAL generated per second", "cells": ['
          '{"id": "wal_bytes_per_sec1"}, '
          '{"id": "wal_bytes_per_sec2"}'
      ']},'
      '{"caption": "WAL records", "title": "Total number of WAL records generated", "cells": ['
          '{"id": "wal_records1"},'
          '{"id": "wal_records2"}'
      ']},'
      '{"caption": "WAL FPI", "title": "Total number of WAL full page images generated", "cells": ['
          '{"id": "wal_fpi1"},'
          '{"id": "wal_fpi2"}'
      ']},'
      '{"caption": "WAL buffers full", "title": "Number of times WAL data was written to disk because WAL buffers became full", "cells": ['
          '{"id": "wal_buffers_full1"},'
          '{"id": "wal_buffers_full2"}'
      ']},'
      '{"caption": "WAL writes", "title": "Number of times WAL buffers were written out to disk via XLogWrite request", "cells": ['
          '{"id": "wal_write1"}, '
          '{"id": "wal_write2"}'
      ']},'
      '{"caption": "WAL writes per second", "title": "Average number of times WAL buffers were written out to disk via XLogWrite request per .second", "cells": ['
          '{"id": "wal_write_per_sec1"}, '
          '{"id": "wal_write_per_sec2"}'
      ']},'
      '{"caption": "WAL sync", "title": "Number of times WAL files were synced to disk via issue_xlog_fsync request (if fsync is on and wal_sync_method is either fdatasync, fsync or fsync_writethrough, otherwise zero)", "cells": ['
          '{"id": "wal_sync1"}, '
          '{"id": "wal_sync2"}'
      ']},'
      '{"caption": "WAL syncs per second", "title": "Average number of times WAL files were synced to disk via issue_xlog_fsync request per second", "cells": ['
          '{"id": "wal_sync_per_sec1"},'
          '{"id": "wal_sync_per_sec2"}'
      ']},'
      '{"caption": "WAL write time (s)", "title": "Total amount of time spent writing WAL buffers to disk via XLogWrite request, in seconds (if track_wal_io_timing is enabled, otherwise zero). This includes the sync time when wal_sync_method is either open_datasync or open_sync", "cells": ['
          '{"id": "wal_write_time1"}, '
          '{"id": "wal_write_time2"}'
      ']},'
      '{"title": "WAL write time as a percentage of the report duration time", "caption": "WAL write duty", "cells": ['
          '{"id": "wal_write_time_per_sec1"},'
          '{"id": "wal_write_time_per_sec2"}'
      ']},'
      '{"caption": "WAL sync time (s)", "title": "Total amount of time spent syncing WAL files to disk via issue_xlog_fsync request, in seconds (if track_wal_io_timing is enabled, fsync is on, and wal_sync_method is either fdatasync, fsync or fsync_writethrough, otherwise zero)", "cells": ['
          '{"id": "wal_sync_time1"},'
          '{"id": "wal_sync_time2"}'
      ']},'
      '{"caption": "WAL sync duty", "title": "WAL sync time as a percentage of the report duration time", "cells": ['
          '{"id": "wal_sync_time_per_sec1"},'
          '{"id": "wal_sync_time_per_sec2"}'
      ']}'
    ']'
  '}]'::jsonb),
(2, 'tbspst', 'srvstat', 1400, 'Tablespace statistics', 'Tablespace statistics', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "tablespace_stats",'
    '"ordering": "tablespacename",'
    '"columns": ['
      '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
      '{"caption": "Path", "id": "tablespacepath", "class": "table_obj_name hdr", "rowspan": true},'
      '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"}, '
      '{"caption": "Size", "id": ["size1", "size2"], "class": "table_obj_value", '
      '"title": "Tablespace size as it was at the moment of last sample in report interval"},'
      '{"caption": "Growth", "id": ["size_delta1", "size_delta2"], "class": "table_obj_value", '
      '"title": "Tablespace size increment during report interval"}'
    ']'
  '}]'::jsonb),
(2, 'wait_sampling_srvstats', 'srvstat', 1500, 'Wait sampling', 'Wait sampling', 'wait_sampling_tot', NULL, NULL, NULL),
(2, 'wait_sampling_total', 'wait_sampling_srvstats', 100, 'Wait events types', 'Wait events types', 'wait_sampling_tot', NULL, NULL,
  '[{'
      '"type": "row_table", '
      '"source": "wait_sampling_total_stats",'
      '"ordering": "event_type_order",'
      '"columns": ['
          '{"id": "event_type", "class": "table_obj_name hdr", "caption": "Wait event type", "rowspan": true}, '
          '{"id": ["1", "2"], "class": "interval", "title":["properties.timePeriod1", "properties.timePeriod2"], "caption": "I"}, '
          '{"id": ["stmt_waited1", "stmt_waited2"], "class": "table_obj_value", "title": "Time, waited in events of wait event type executing statements in seconds", "caption": "Statements Waited (s)"}, '
          '{"id": ["stmt_waited_pct1", "stmt_waited_pct2"], "class": "table_obj_value", "title": "Time, waited in events of wait event type as a percentage of total time waited in a cluster executing statements", "caption": "%Total"}, '
          '{"id": ["tot_waited1", "tot_waited2"], "class": "table_obj_value", "title": "Time, waited in events of wait event type by all backends (including background activity) in seconds", "caption": "All Waited (s)"}, '
          '{"id": ["tot_waited_pct1", "tot_waited_pct2"], "class": "table_obj_value", "title": "Time, waited in events of wait event type as a percentage of total time waited in a cluster by all backends (including background activity)", "caption": "%Total"}'
      ']}]'::jsonb),
(2, 'wait_sampling_statements', 'wait_sampling_srvstats', 200, 'Top wait events (statements)', 'Top wait events (statements)', 'wait_sampling_tot', NULL, '{"class": "notice", "text": "Top wait events detected in statements execution"}',
  '[{'
    '"type": "row_table", '
    '"source": "wait_sampling_events",'
    '"filter": {"type": "exists", "field": "stmt_filter"},'
    '"ordering": "stmt_ord",'
    '"limit": "topn",'
    '"columns": ['
        '{"id": "event_type", "class": "table_obj_name hdr", "caption": "Wait event type", "rowspan": true}, '
        '{"id": "event", "class": "table_obj_name hdr", "caption": "Wait event", "rowspan": true}, '
        '{"id": ["1", "2"], "class": "interval", "title":["properties.timePeriod1", "properties.timePeriod2"], "caption": "I"}, '
        '{"id": ["stmt_waited1", "stmt_waited2"], "class": "table_obj_value", "title": "Time, waited in event executing statements in seconds", "caption": "Waited (s)"}, '
        '{"id": ["stmt_waited_pct1", "stmt_waited_pct2"], "class": "table_obj_value", "title": "Time, waited in event as a percentage of total time waited in a cluster executing statements", "caption": "%Total"}'
    ']}]'::jsonb),
(2, 'wait_sampling_all', 'wait_sampling_srvstats', 300, 'Top wait events (All)', 'Top wait events (All)', 'wait_sampling_tot', NULL, '{"class": "notice", "text": "Top wait events detected in all backends"}',
  '[{'
    '"type": "row_table", '
    '"source": "wait_sampling_events",'
    '"filter": {"type": "exists", "field": "total_filter"},'
    '"ordering": "tot_ord",'
    '"limit": "topn",'
    '"columns": ['
        '{"id": "event_type", "class": "table_obj_name hdr", "caption": "Wait event type", "rowspan": true}, '
        '{"id": "event", "class": "table_obj_name hdr", "caption": "Wait event", "rowspan": true}, '
        '{"id": ["1", "2"], "class": "interval", "title":["properties.timePeriod1", "properties.timePeriod2"], "caption": "I"}, '
        '{"id": ["tot_waited1", "tot_waited2"], "class": "table_obj_value", "title": "Time, waited in event by all backends (including background activity) in seconds", "caption": "Waited (s)"}, '
        '{"id": ["tot_waited_pct1", "tot_waited_pct2"], "class": "table_obj_value", "title": "Time, waited in event by all backends as a percentage of total time waited in a cluster by all backends (including background activity)", "caption": "%Total"}'
    ']}]'::jsonb)
;

-- Subsamples-based section of regular reports
INSERT INTO report_struct (
  report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
  content, sect_struct)
VALUES
(2, 'act_chart', 'actsesshdr', 50, 'Chart with session state', 'Chart with session state', 'act_backend', NULL,
  NULL,
'[{'
    '"type": "chart",'
    '"source": "act_top_states",'
    '"class": "act_chart"'
    '}]'::jsonb),
(2, 'db_activity_agg', 'actsesshdr', 100, 'Session state statistics by database', 'Session state statistics by database', 'act_backend', NULL,
  NULL,
'[{'
    '"type": "row_table",'
    '"source": "db_activity_agg",'
    '"ordering": "ord_db",'
    '"highlight": ['
      '{"id": "dbname", "index": 0}'
    '],'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name hdr", "rowspan": "true"},'
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"}, '
      '{"caption": "Summary", "columns": ['
        '{"caption": "Active", "id": ["active_dur1", "active_dur2"], "class": "table_obj_value", '
          '"title": "Summary time in ''active'' state"},'
        '{"caption": "Idle in xact", "id": ["idle_xact_dur1", "idle_xact_dur2"], "class": "table_obj_value", '
          '"title": "Summary time in ''idle in transaction'' state"},'
        '{"caption": "Idle in xact (A)", "id": ["idle_xact_a_dur1", "idle_xact_a_dur2"], "class": "table_obj_value", '
          '"title": "Summary time in ''idle in transaction (aborted)'' state"}'
     ']},'
      '{"caption": "Maximal", "columns": ['
        '{"caption": "Active", "id": ["max_active_dur1", "max_active_dur2"], "class": "table_obj_value", '
          '"title": "Longest detected ''active'' state"},'
        '{"caption": "Idle in xact", "id": ["max_idle_xact_d1", "max_idle_xact_d2"], "class": "table_obj_value", '
          '"title": "Longest detected ''idle in xact'' state"},'
        '{"caption": "Idle in xact (A)", "id": ["max_idle_xact_a_d1", "max_idle_xact_a_d2"], "class": "table_obj_value", '
          '"title": "Longest detected ''idle in transaction (aborted)'' state"},'
        '{"caption": "xact age", "id": ["max_xact_age1", "max_xact_age2"], "class": "table_obj_value", '
          '"title": "Maximal detected backend_xid age"}'
     ']}'
    ']'
    '}]'::jsonb),
(2, 'act_ix', 'actsesshdr', 200, 'Top ''idle in transaction'' states', 'Top ''idle in transaction'' session states by duration', 'act_ix', NULL,
  NULL,
'[{'
    '"type": "row_table",'
    '"source": "act_top_states",'
    '"ordering": "ord_dur",'
    '"limit": "topn",'
    '"highlight": ['
      '{"id": "pid", "index": 0},'
      '{"id": "state_change", "index": 0}'
    '],'
    '"preview": ['
      '{"id": "act_query_md5", "dataset": "act_queries"}'
    '],'
    '"scroll": ['
      '"pid", "xact_start_ut", "state_change_ut"'
    '],'
    '"filter": {"type": "equal", "field": "flt_state_code", "value": 1},'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name"},'
      '{"caption": "User", "id": "username", "class": "table_obj_name"},'
      '{"caption": "App", "id": "application_name", "class": "table_obj_name", '
        '"title": "application_name"},'
      '{"caption": "Addr", "id": "client_addr", "class": "table_obj_name", '
        '"title": "client_addr"},'
      '{"caption": "Pid", "id": "pid", "class": "table_obj_name"},'
      '{"caption": "Xact start", "id": "xact_start_format", "class": "table_obj_value"},'
      '{"caption": "State change", "id": "state_change_format", "class": "table_obj_value"},'
      '{"caption": "State duration", "id": "state_duration_format", "class": "table_obj_value"}'
    ']}]'::jsonb),
(2, 'act_ixa', 'actsesshdr', 300, 'Top ''idle in transaction (aborted)'' states', 'Top ''idle in transaction (aborted)'' session states by duration', 'act_ixa', NULL,
  NULL,
'[{'
    '"type": "row_table",'
    '"source": "act_top_states",'
    '"ordering": "ord_dur",'
    '"limit": "topn",'
    '"highlight": ['
      '{"id": "pid", "index": 0},'
      '{"id": "state_change", "index": 0}'
    '],'
    '"preview": ['
      '{"id": "act_query_md5", "dataset": "act_queries"}'
    '],'
    '"scroll": ['
      '"pid", "xact_start_ut", "state_change_ut"'
    '],'
    '"filter": {"type": "equal", "field": "flt_state_code", "value": 2},'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name"},'
      '{"caption": "User", "id": "username", "class": "table_obj_name"},'
      '{"caption": "App", "id": "application_name", "class": "table_obj_name", '
        '"title": "application_name"},'
      '{"caption": "Addr", "id": "client_addr", "class": "table_obj_name", '
        '"title": "client_addr"},'
      '{"caption": "Pid", "id": "pid", "class": "table_obj_name"},'
      '{"caption": "State change", "id": "state_change_format", "class": "table_obj_value"},'
      '{"caption": "State duration", "id": "state_duration_format", "class": "table_obj_value"}'
    ']}]'::jsonb),
(2, 'act_active', 'actsesshdr', 400, 'Top ''active'' states', 'Top ''active'' session states by duration', 'act_active', NULL,
  NULL,
'[{'
    '"type": "row_table",'
    '"source": "act_top_states",'
    '"ordering": "ord_dur",'
    '"limit": "topn",'
    '"highlight": ['
      '{"id": "pid", "index": 0},'
      '{"id": "state_change", "index": 0}'
    '],'
    '"preview": ['
      '{"id": "act_query_md5", "dataset": "act_queries"}'
    '],'
    '"scroll": ['
      '"pid", "xact_start_ut", "state_change_ut"'
    '],'
    '"filter": {"type": "equal", "field": "flt_state_code", "value": 3},'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name"},'
      '{"caption": "User", "id": "username", "class": "table_obj_name"},'
      '{"caption": "App", "id": "application_name", "class": "table_obj_name", '
        '"title": "application_name"},'
      '{"caption": "Addr", "id": "client_addr", "class": "table_obj_name", '
        '"title": "client_addr"},'
      '{"caption": "Pid", "id": "pid", "class": "table_obj_name"},'
      '{"caption": "Xact start", "id": "xact_start_format", "class": "table_obj_value"},'
      '{"caption": "State change", "id": "state_change_format", "class": "table_obj_value"},'
      '{"caption": "State duration", "id": "state_duration_format", "class": "table_obj_value"}'
    ']}]'::jsonb),
(2, 'act_age', 'actsesshdr', 500, 'Top states by transaction age', 'Top states by transaction age', 'act_backend', NULL,
  NULL,
'[{'
    '"type": "row_table",'
    '"source": "act_top_states",'
    '"ordering": "ord_age",'
    '"limit": "topn",'
    '"highlight": ['
      '{"id": "pid", "index": 0},'
      '{"id": "state_change", "index": 0}'
    '],'
    '"preview": ['
      '{"id": "act_query_md5", "dataset": "act_queries"}'
    '],'
    '"scroll": ['
      '"pid", "xact_start_ut", "state_change_ut"'
    '],'
    '"filter": {"type": "equal", "field": "flt_age", "value": true},'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name"},'
      '{"caption": "User", "id": "username", "class": "table_obj_name"},'
      '{"caption": "App", "id": "application_name", "class": "table_obj_name", '
        '"title": "application_name"},'
      '{"caption": "Addr", "id": "client_addr", "class": "table_obj_name", '
        '"title": "client_addr"},'
      '{"caption": "Pid", "id": "pid", "class": "table_obj_name"},'
      '{"caption": "Xact start", "id": "xact_start_format", "class": "table_obj_value"},'
      '{"caption": "Xact duration", "id": "xact_duration_format", "class": "table_obj_value"},'
      '{"caption": "Age", "id": "xmin_age", "class": "table_obj_value", '
        '"title": "Last detected age of backend_xmin"},'
      '{"caption": "State", "id": "state", "class": "table_obj_value"},'
      '{"caption": "State change", "id": "state_change_format", "class": "table_obj_value"},'
      '{"caption": "State duration", "id": "state_duration_format", "class": "table_obj_value"}'
    ']}]'::jsonb),
(2, 'act_xact_dur', 'actsesshdr', 600, 'Top states by transaction duration', 'Top states by transaction duration', 'act_backend', NULL,
  NULL,
'[{'
    '"type": "row_table",'
    '"source": "act_top_states",'
    '"ordering": "ord_xact",'
    '"limit": "topn",'
    '"highlight": ['
      '{"id": "pid", "index": 0},'
      '{"id": "state_change", "index": 0}'
    '],'
    '"preview": ['
      '{"id": "act_query_md5", "dataset": "act_queries"}'
    '],'
    '"scroll": ['
      '"pid", "xact_start_ut", "state_change_ut"'
    '],'
    '"filter": {"type": "equal", "field": "flt_age", "value": true},'
    '"columns": ['
      '{"caption": "Database", "id": "dbname", "class": "table_obj_name"},'
      '{"caption": "User", "id": "username", "class": "table_obj_name"},'
      '{"caption": "App", "id": "application_name", "class": "table_obj_name", '
        '"title": "application_name"},'
      '{"caption": "Addr", "id": "client_addr", "class": "table_obj_name", '
        '"title": "client_addr"},'
      '{"caption": "Pid", "id": "pid", "class": "table_obj_name"},'
      '{"caption": "Xact start", "id": "xact_start_format", "class": "table_obj_value"},'
      '{"caption": "Xact duration", "id": "xact_duration_format", "class": "table_obj_value"},'
      '{"caption": "Age", "id": "xmin_age", "class": "table_obj_value", '
        '"title": "Last detected age of backend_xmin"},'
      '{"caption": "State", "id": "state", "class": "table_obj_value"},'
      '{"caption": "State change", "id": "state_change_format", "class": "table_obj_value"},'
      '{"caption": "State duration", "id": "state_duration_format", "class": "table_obj_value"}'
    ']}]'::jsonb)
;

-- Query section of differential report
INSERT INTO report_struct (
  report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
  content, sect_struct)
VALUES
(2, 'sqlela', 'sqlsthdr', 100, 'Top SQL by elapsed time', 'Top SQL by elapsed time', 'planning_times', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"ordering": "ord_total_time",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "ord_total_time"},'
    '"limit": "topn",'
    '"columns": ['
        '{"id": "hexqueryid", "class": "hdr table_obj_name queryId", "caption": "Query ID", "rowspan": true}, '
        '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
        '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
        '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"}, '
        '{"id": ["total_time_pct1", "total_time_pct2"], "class": "table_obj_value", "title": "Elapsed time as a percentage of total cluster elapsed time", "caption": "%Total"}, '
        '{"caption": "Time (s)", "columns": ['
            '{"id": ["total_time1", "total_time2"], "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed"}, '
            '{"id": ["total_plan_time1", "total_plan_time2"], "class": "table_obj_value", "title": "Time spent planning statement", "caption": "Plan"}, '
            '{"id": ["total_exec_time1", "total_exec_time2"], "class": "table_obj_value", "title": "Time spent executing statement", "caption": "Exec"}'
            ']}, '
        '{"id": ["jit_total_time1", "jit_total_time2"], "class": "jitTimeCell", "caption": "JIT, time (s)", "condition": "statements_jit_stats"}, '
        '{"class": "table_obj_name", "caption": "I/O time (s)", "condition": "io_times", "columns": ['
            '{"id": ["shared_blk_read_time1", "shared_blk_read_time2"], "class": "table_obj_value", "title": "Time spent reading blocks by statement", "caption": "Read"}, '
            '{"id": ["shared_blk_write_time1", "shared_blk_write_time2"], "class": "table_obj_value", "title": "Time spent writing blocks by statement", "caption": "Write"}'
            ']}, '
        '{"class": "table_obj_name", "caption": "CPU time (s)", "condition": "kcachestatements", "columns": ['
            '{"id": ["user_time1", "user_time2"], "class": "table_obj_value", "caption": "Usr"}, '
            '{"id": ["system_time1", "system_time2"], "class": "table_obj_value", "caption": "Sys"}'
            ']}, '
        '{"id": ["plans1", "plans2"], "class": "table_obj_value", "caption": "Plans", "title": "Number of times the statement was planned"}, '
        '{"id": ["calls1", "calls2"], "class": "table_obj_value", "caption": "Executions", "title": "Number of times the statement was executed"}, '
        '{"id": ["stmt_cover1", "stmt_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(2, 'sqlplan', 'sqlsthdr', 200, 'Top SQL by planning time', 'Top SQL by planning time', 'planning_times', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"ordering": "ord_plan_time",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "ord_plan_time"},'
    '"limit": "topn",'
    '"columns": ['
        '{"id": "hexqueryid", "class": "hdr table_obj_name queryId", "caption": "Query ID", "rowspan": true}, '
        '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
        '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
        '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"}, '
        '{"id": ["total_plan_time1", "total_plan_time2"], "class": "table_obj_value", "title": "Time spent planning statement", "caption": "Plan elapsed (s)"}, '
        '{"id": ["plan_time_pct1", "plan_time_pct2"], "class": "table_obj_value", "title": "Plan elapsed as a percentage of statement elapsed time", "caption": "%Elapsed"}, '
        '{"title": "Planning time statistics", "caption": "Plan times (ms)", "columns": ['
            '{"id": ["mean_plan_time1", "mean_plan_time2"], "class": "table_obj_value", "caption": "Mean"}, '
            '{"id": ["min_plan_time1", "min_plan_time2"], "class": "table_obj_value", "caption": "Min"}, '
            '{"id": ["max_plan_time1", "max_plan_time2"], "class": "table_obj_value", "caption": "Max"}, '
            '{"id": ["stddev_plan_time1", "stddev_plan_time2"], "class": "table_obj_value", "caption": "StdErr"}'
        ']}, '
        '{"id": ["plans1", "plans2"], "class": "table_obj_value", "title": "Number of times the statement was planned", "caption": "Plans"}, '
        '{"id": ["calls1", "calls2"], "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
        '{"id": ["stmt_cover1", "stmt_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(2, 'sqlexec', 'sqlsthdr', 300, 'Top SQL by execution time', 'Top SQL by execution time', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"ordering": "ord_exec_time",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "ord_exec_time"},'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "caption": "Query ID", "class": "hdr table_obj_name queryId", "rowspan": true}, '
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
      '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"}, '
      '{"id": ["total_exec_time1", "total_exec_time2"], "class": "table_obj_value", "title": "Time spent executing statement", "caption": "Exec (s)"}, '
      '{"id": ["exec_time_pct1", "exec_time_pct2"], "class": "table_obj_value", "title": "Exec time as a percentage of statement elapsed time", "caption": "%Elapsed", "condition": "planning_times"}, '
      '{"id": ["total_exec_time_pct1", "total_exec_time_pct2"], "class": "table_obj_value", "title": "Exec time as a percentage of total cluster elapsed time", "caption": "%Total"}, '
      '{"id": ["jit_total_time1", "jit_total_time2"], "class": "jitTimeCell", "title": "Exec time as a percentage of statement elapsed time", "caption": "JIT time (s)", "condition": "statements_jit_stats"}, '
      '{"caption": "I/O time (s)", "condition": "io_times", "columns": ['
          '{"id": ["shared_blk_read_time1", "shared_blk_read_time2"], "class": "table_obj_value", "caption": "Read"}, '
          '{"id": ["shared_blk_write_time1", "shared_blk_write_time2"], "class": "table_obj_value", "caption": "Write"}'
      ']}, '
      '{"caption": "CPU time (s)", "condition": "kcachestatements", "columns": ['
          '{"id": ["user_time1", "user_time2"], "class": "table_obj_value", "caption": "Usr"}, '
          '{"id": ["system_time1", "system_time2"], "class": "table_obj_value", "caption": "Sys"}'
      ']}, '
      '{"id": ["rows1", "rows2"], "class": "table_obj_value", "caption": "Rows"}, '
      '{"title": "Execution time statistics", "caption": "Execution times (ms)", "columns": ['
          '{"id": ["mean_exec_time1", "mean_exec_time2"], "class": "table_obj_value", "caption": "Mean"}, '
          '{"id": ["min_exec_time1", "min_exec_time2"], "class": "table_obj_value", "caption": "Min"}, '
          '{"id": ["max_exec_time1", "max_exec_time2"], "class": "table_obj_value", "caption": "Max"}, '
          '{"id": ["stddev_exec_time1", "stddev_exec_time2"], "class": "table_obj_value", "caption": "StdErr"}'
      ']}, '
      '{"id": ["calls1", "calls2"], "title": "Number of times the statement was executed", "caption": "Executions", "class": "table_obj_value"}, '
      '{"id": ["stmt_cover1", "stmt_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(2, 'sqlmeanexec', 'sqlsthdr', 350, 'Top SQL by mean time', 'Top SQL by mean execution time', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"ordering": "ord_mean_exec_time",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "ord_exec_time"},'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "caption": "Query ID", "class": "hdr table_obj_name queryId", "rowspan": true}, '
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
      '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"}, '
      '{"title": "Execution time statistics", "caption": "Execution times (ms)", "columns": ['
          '{"id": ["mean_exec_time1", "mean_exec_time2"], "class": "table_obj_value", "caption": "Mean"}, '
          '{"id": ["min_exec_time1", "min_exec_time2"], "class": "table_obj_value", "caption": "Min"}, '
          '{"id": ["max_exec_time1", "max_exec_time2"], "class": "table_obj_value", "caption": "Max"}, '
          '{"id": ["stddev_exec_time1", "stddev_exec_time2"], "class": "table_obj_value", "caption": "StdErr"}'
      ']}, '
      '{"id": ["total_exec_time1", "total_exec_time2"], "class": "table_obj_value", "title": "Time spent executing statement", "caption": "Exec (s)"}, '
      '{"id": ["exec_time_pct1", "exec_time_pct2"], "class": "table_obj_value", "title": "Exec time as a percentage of statement elapsed time", "caption": "%Elapsed", "condition": "planning_times"}, '
      '{"id": ["total_exec_time_pct1", "total_exec_time_pct2"], "class": "table_obj_value", "title": "Exec time as a percentage of total cluster elapsed time", "caption": "%Total"}, '
      '{"id": ["jit_total_time1", "jit_total_time2"], "class": "jitTimeCell", "title": "Exec time as a percentage of statement elapsed time", "caption": "JIT time (s)", "condition": "statements_jit_stats"}, '
      '{"caption": "I/O time (s)", "condition": "io_times", "columns": ['
          '{"id": ["shared_blk_read_time1", "shared_blk_read_time2"], "class": "table_obj_value", "caption": "Read"}, '
          '{"id": ["shared_blk_write_time1", "shared_blk_write_time2"], "class": "table_obj_value", "caption": "Write"}'
      ']}, '
      '{"caption": "CPU time (s)", "condition": "kcachestatements", "columns": ['
          '{"id": ["user_time1", "user_time2"], "class": "table_obj_value", "caption": "Usr"}, '
          '{"id": ["system_time1", "system_time2"], "class": "table_obj_value", "caption": "Sys"}'
      ']}, '
      '{"id": ["rows1", "rows2"], "class": "table_obj_value", "caption": "Rows"}, '
      '{"id": ["calls1", "calls2"], "title": "Number of times the statement was executed", "caption": "Executions", "class": "table_obj_value"}, '
      '{"id": ["stmt_cover1", "stmt_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(2, 'sqlcalls', 'sqlsthdr', 400, 'Top SQL by executions', 'Top SQL by executions', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"ordering": "ord_calls",'
    '"filter": {"type": "exists", "field": "ord_calls"},'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "hdr table_obj_name queryId", "caption": "Query ID", "rowspan": true}, '
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
      '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"}, '
      '{"id": ["calls1", "calls2"], "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": ["calls_pct1", "calls_pct2"], "class": "table_obj_value", "title": "Executions of this statement as a percentage of total executions of all statements in a cluster", "caption": "%Total"}, '
      '{"id": ["rows1", "rows2"], "class": "table_obj_value", "title": "Total number of rows retrieved or affected by the statement", "caption": "Rows"}, '
      '{"id": ["mean_exec_time1", "mean_exec_time2"], "class": "table_obj_value", "caption": "Mean(ms)"}, '
      '{"id": ["min_exec_time1", "min_exec_time2"], "class": "table_obj_value", "caption": "Min(ms)"}, '
      '{"id": ["max_exec_time1", "max_exec_time2"], "class": "table_obj_value", "caption": "Max(ms)"}, '
      '{"id": ["stddev_exec_time1", "stddev_exec_time2"], "class": "table_obj_value", "caption": "StdErr(ms)"}, '
      '{"id": ["total_exec_time1", "total_exec_time2"], "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": ["stmt_cover1", "stmt_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(2, 'sqlio', 'sqlsthdr', 500, 'Top SQL by I/O wait time', 'Top SQL by I/O wait time', 'io_times', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"ordering": "ord_io_time",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "ord_io_time"},'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "hdr table_obj_name queryId", "caption": "Query ID", "rowspan": true}, '
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
      '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"}, '
      '{"id": ["io_time1", "io_time2"], "class": "table_obj_value", "title": "Time spent by the statement reading and writing blocks", "caption": "IO(s)"}, '
      '{"id": ["shared_blk_read_time1", "shared_blk_read_time2"], "class": "table_obj_value", "title": "Time spent by the statement reading blocks", "caption": "R(s)"}, '
      '{"id": ["shared_blk_write_time1", "shared_blk_write_time2"], "class": "table_obj_value", "title": "Time spent by the statement writing blocks", "caption": "W(s)"}, '
      '{"id": ["io_time_pct1", "io_time_pct2"], "class": "table_obj_value", "title": "I/O time of this statement as a percentage of total I/O time for all statements in a cluster", "caption": "%Total"}, '
      '{"title": "Number of blocks read by the statement", "caption": "Reads", "columns": ['
          '{"id": ["shared_blks_read1", "shared_blks_read2"], "title": "Number of shared blocks read by the statement", "caption": "Shr", "class": "table_obj_value"}, '
          '{"id": ["local_blks_read1", "local_blks_read2"], "title": "Number of local blocks read by the statement (usually used for temporary tables)", "caption": "Loc", "class": "table_obj_value"}, '
          '{"id": ["temp_blks_read1", "temp_blks_read2"], "title": "Number of temp blocks read by the statement (usually used for operations like sorts and joins)", "caption": "Tmp", "class": "table_obj_value"}'
      ']}, '
      '{"title": "Number of blocks written by the statement", "caption": "Writes", "columns": ['
          '{"id": ["shared_blks_written1", "shared_blks_written2"], "title": "Number of shared blocks written by the statement", "caption": "Shr", "class": "table_obj_value"}, '
          '{"id": ["local_blks_written1", "local_blks_written2"], "title": "Number of local blocks written by the statement (usually used for temporary tables)", "caption": "Loc", "class": "table_obj_value"}, '
          '{"id": ["temp_blks_written1", "temp_blks_written2"], "title": "Number of temp blocks written by the statement (usually used for operations like sorts and joins)", "caption": "Tmp", "class": "table_obj_value"}'
      ']}, '
      '{"id": ["total_time1", "total_time2"], "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": ["calls1", "calls2"], "class": "table_obj_value", "title": "Number of blocks written by the statement", "caption": "Executions"}, '
      '{"id": ["stmt_cover1", "stmt_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(2, 'sqlfetch', 'sqlsthdr', 600, 'Top SQL by shared blocks fetched', 'Top SQL by shared blocks fetched', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"ordering": "ord_shared_blocks_fetched",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "ord_shared_blocks_fetched"},'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "hdr table_obj_name queryId", "caption": "Query ID", "rowspan": true}, '
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
      '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"}, '
      '{"id": ["shared_blks_fetched1", "shared_blks_fetched2"], "class": "table_obj_value", "title": "Shared blocks fetched (read and hit) by the statement", "caption": "blks fetched"}, '
      '{"id": ["shared_blks_fetched_pct1", "shared_blks_fetched_pct2"], "class": "table_obj_value", "title": "Shared blocks fetched by this statement as a percentage of all shared blocks fetched in a cluster", "caption": "%Total"}, '
      '{"id": ["shared_hit_pct1", "shared_hit_pct2"], "class": "table_obj_value", "title": "Shared blocks hits as a percentage of shared blocks fetched (read + hit)", "caption": "Hits(%)"}, '
      '{"id": ["total_time1", "total_time2"], "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": ["rows1", "rows2"], "class": "table_obj_value", "title": "Total number of rows retrieved or affected by the statement", "caption": "Rows"}, '
      '{"id": ["calls1", "calls2"], "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": ["stmt_cover1", "stmt_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']}]'::jsonb),
(2, 'sqlshrd', 'sqlsthdr', 700, 'Top SQL by shared blocks read', 'Top SQL by shared blocks read', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"filter": {"type": "exists", "field": "ord_shared_blocks_read"},'
    '"ordering": "ord_shared_blocks_read",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "hdr table_obj_name queryId", "caption": "Query ID", "rowspan": true}, '
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
      '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"}, '
      '{"id": ["shared_blks_read1", "shared_blks_read2"], "class": "table_obj_value", "title": "Total number of shared blocks read by the statement", "caption": "Reads"}, '
      '{"id": ["read_pct1", "read_pct2"], "class": "table_obj_value", "title": "Shared blocks read by this statement as a percentage of all shared blocks read in a cluster", "caption": "%Total"}, '
      '{"id": ["shared_hit_pct1", "shared_hit_pct2"], "class": "table_obj_value", "title": "Shared blocks hits as a percentage of shared blocks fetched (read + hit)", "caption": "Hits(%)"}, '
      '{"id": ["total_time1", "total_time2"], "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": ["rows1", "rows2"], "class": "table_obj_value", "title": "Total number of rows retrieved or affected by the statement", "caption": "Rows"}, '
      '{"id": ["calls1", "calls2"], "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": ["stmt_cover1", "stmt_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(2, 'sqlshdir', 'sqlsthdr', 800, 'Top SQL by shared blocks dirtied', 'Top SQL by shared blocks dirtied', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"filter": {"type": "exists", "field": "ord_shared_blocks_dirt"},'
    '"ordering": "ord_shared_blocks_dirt",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "hdr table_obj_name queryId", "caption": "Query ID", "rowspan": true}, '
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
      '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"],  "class": "interval", "caption": "I"}, '
      '{"id": ["shared_blks_dirtied1", "shared_blks_dirtied2"], "class": "table_obj_value", "title": "Total number of shared blocks dirtied by the statement", "caption": "Dirtied"}, '
      '{"id": ["dirtied_pct1", "dirtied_pct2"], "class": "table_obj_value", "title": "Shared blocks dirtied by this statement as a percentage of all shared blocks dirtied in a cluster", "caption": "%Total"}, '
      '{"id": ["shared_blks_hit1", "shared_blks_hit2"], "class": "table_obj_value", "title": "Total number of shared blocks dirtied by the statement", "caption": "Hits"}, '
      '{"id": ["shared_hit_pct1", "shared_hit_pct2"], "class": "table_obj_value", "title": "Shared blocks hits as a percentage of shared blocks fetched (read + hit)", "caption": "%Total"}, '
      '{"id": ["wal_bytes1", "wal_bytes2"], "class": "table_obj_value", "title": "Total amount of WAL bytes generated by the statement", "caption": "WAL", "condition": "statement_wal_bytes"}, '
      '{"id": ["wal_bytes_pct1", "wal_bytes_pct2"], "class": "table_obj_value", "title": "WAL bytes of this statement as a percentage of total WAL bytes generated by a cluster", "caption": "%Total", "condition": "statement_wal_bytes"}, '
      '{"id": ["total_time1", "total_time2"], "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": ["rows1", "rows2"], "class": "table_obj_value", "title": "Total number of rows retrieved or affected by the statement", "caption": "Rows"}, '
      '{"id": ["calls1", "calls2"], "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": ["stmt_cover1", "stmt_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(2, 'sqlshwr', 'sqlsthdr', 900, 'Top SQL by shared blocks written', 'Top SQL by shared blocks written', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"filter": {"type": "exists", "field": "ord_shared_blocks_written"},'
    '"ordering": "ord_shared_blocks_written",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "hdr table_obj_name queryId", "caption": "Query ID", "rowspan": true}, '
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
      '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"],  "class": "interval", "caption": "I"}, '
      '{"id": ["shared_blks_written1", "shared_blks_written2"], "class": "table_obj_value", "title": "Total number of shared blocks written by the statement", "caption": "Written"}, '
      '{"id": ["tot_written_pct1", "tot_written_pct2"], "class": "table_obj_value", "title": "Shared blocks written by this statement as a percentage of all shared blocks written in a cluster (sum of pg_stat_bgwriter fields buffers_checkpoint, buffers_clean and buffers_backend)", "caption": "%Total"}, '
      '{"id": ["backend_written_pct1", "backend_written_pct2"], "class": "table_obj_value", "title": "Shared blocks written by this statement as a percentage total buffers written directly by a backends (buffers_backend of pg_stat_bgwriter view)", "caption": "%BackendW"}, '
      '{"id": ["shared_hit_pct1", "shared_hit_pct2"], "class": "table_obj_value", "title": "Shared blocks hits as a percentage of shared blocks fetched (read + hit)", "caption": "Hits(%)"}, '
      '{"id": ["total_time1", "total_time2"], "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": ["rows1", "rows2"], "class": "table_obj_value", "title": "Total number of rows retrieved or affected by the statement", "caption": "Rows"}, '
      '{"id": ["calls1", "calls2"], "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": ["stmt_cover1", "stmt_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(2, 'sqlwalsz', 'sqlsthdr', 1000, 'Top SQL by WAL size', 'Top SQL by WAL size', 'statement_wal_bytes', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"filter": {"type": "exists", "field": "ord_wal"},'
    '"ordering": "ord_wal",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "hdr table_obj_name queryId", "caption": "Query ID", "rowspan": true}, '
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
      '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"],  "class": "interval", "caption": "I"}, '
      '{"id": ["wal_bytes1", "wal_bytes2"], "class": "table_obj_value", "title": "Total amount of WAL bytes generated by the statement", "caption": "WAL"}, '
      '{"id": ["wal_bytes_pct1", "wal_bytes_pct2"], "class": "table_obj_value", "title": "WAL bytes of this statement as a percentage of total WAL bytes generated by a cluster", "caption": "%Total"}, '
      '{"id": ["wal_buffers_full1", "wal_buffers_full2"], "class": "table_obj_value", "title": "Number of times the WAL buffers became full", "caption": "WAL buffers full", "condition": "wal_buffers_full"}, '
      '{"id": ["shared_blks_dirtied1", "shared_blks_dirtied2"], "class": "table_obj_value", "title": "Total number of shared blocks dirtied by the statement", "caption": "Dirtied"}, '
      '{"id": ["wal_fpi1", "wal_fpi2"], "class": "table_obj_value", "title": "Total number of WAL full page images generated by the statement", "caption": "WAL FPI"}, '
      '{"id": ["wal_records1", "wal_records2"], "class": "table_obj_value", "title": "Total number of WAL records generated by the statement", "caption": "WAL records"}, '
      '{"id": ["stmt_cover1", "stmt_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(2, 'sqltmp', 'sqlsthdr', 1100, 'Top SQL by temp usage', 'Top SQL by temp usage', 'statements_top_temp', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"filter": {"type": "exists", "field": "ord_temp"},'
    '"ordering": "ord_temp",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "hdr table_obj_name queryId", "caption": "Query ID", "rowspan": true}, '
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
      '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"],  "class": "interval", "caption": "I"}, '
      '{"id": ["local_blks_fetched1", "local_blks_fetched2"], "class": "table_obj_value", "title": "Number of local blocks fetched (hit + read)", "caption": "Local fetched"}, '
      '{"id": ["local_hit_pct1", "local_hit_pct2"], "class": "table_obj_value", "title": "Local blocks hit percentage", "caption": "Hits(%)"}, '
      '{"title": "Number of blocks, used for temporary tables", "caption": "Local (blk)", "columns": ['
          '{"id": ["local_blks_written1", "local_blks_written2"], "class": "table_obj_value", "title": "Number of written local blocks", "caption": "Write"}, '
          '{"id": ["local_write_total_pct1", "local_write_total_pct2"], "class": "table_obj_value", "title": "Percentage of all local blocks written", "caption": "%Total"}, '
          '{"id": ["local_blks_read1", "local_blks_read2"], "class": "table_obj_value", "title": "Number of read local blocks", "caption": "Read"}, '
          '{"id": ["local_read_total_pct1", "local_read_total_pct2"], "class": "table_obj_value", "title": "Percentage of all local blocks read", "caption": "%Total"}'
      ']}, '
      '{"title": "Number of blocks, used in operations (like sorts and joins)", "caption": "Temp (blk)", "columns": ['
          '{"id": ["temp_blks_written1", "temp_blks_written2"], "class": "table_obj_value", "title": "Number of written temp blocks", "caption": "Write"}, '
          '{"id": ["temp_write_total_pct1", "temp_write_total_pct2"], "class": "table_obj_value", "title": "Percentage of all temp blocks written", "caption": "%Total"}, '
          '{"id": ["temp_blks_read1", "temp_blks_read2"], "class": "table_obj_value", "title": "Number of read temp blocks", "caption": "Read"}, '
          '{"id": ["temp_read_total_pct1", "temp_read_total_pct2"], "class": "table_obj_value", "title": "Percentage of all temp blocks read", "caption": "%Total"}'
      ']}, '
      '{"id": ["total_time1", "total_time2"], "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": ["rows1", "rows2"], "class": "table_obj_value", "title": "Total number of rows retrieved or affected by the statement", "caption": "Rows"}, '
      '{"id": ["calls1", "calls2"], "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": ["stmt_cover1", "stmt_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(2, 'sqltmpiotime', 'sqlsthdr', 1125, 'Top SQL by temp I/O time', 'Top SQL by temp I/O time', 'statements_temp_io_times', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"filter": {"type": "exists", "field": "ord_temp_io_time"},'
    '"ordering": "ord_temp_io_time",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "hdr table_obj_name queryId", "caption": "Query ID", "rowspan": true}, '
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
      '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"],  "class": "interval", "caption": "I"}, '
      '{"title": "Time the statement spent on temporary file blocks I/O", "caption": "Temp I/O time (s)", "columns": ['
          '{"id": ["temp_blk_read_time1", "temp_blk_read_time2"], "class": "table_obj_value", "title": "Time the statement spent reading temporary file blocks, in seconds", "caption": "Read"}, '
          '{"id": ["temp_blk_write_time1", "temp_blk_write_time2"], "class": "table_obj_value", "title": "Time the statement spent reading temporary file blocks, in seconds", "caption": "Write"}, '
          '{"id": ["temp_io_time_pct1", "temp_io_time_pct2"], "class": "table_obj_value", "title": "Time spent on temporary file blocks I/O of this statement as a percentage of total time spent on temporary file blocks I/O by all statements", "caption": "%Total"} '
      ']}, '
      '{"title": "Number of blocks, used in operations (like sorts and joins)", "caption": "Temp (blk)", "columns": ['
          '{"id": ["temp_blks_written1", "temp_blks_written2"], "class": "table_obj_value", "title": "Number of written temp blocks", "caption": "Write"}, '
          '{"id": ["temp_write_total_pct1", "temp_write_total_pct2"], "class": "table_obj_value", "title": "Percentage of all temp blocks written", "caption": "%Total"}, '
          '{"id": ["temp_blks_read1", "temp_blks_read2"], "class": "table_obj_value", "title": "Number of read temp blocks", "caption": "Read"}, '
          '{"id": ["temp_read_total_pct1", "temp_read_total_pct2"], "class": "table_obj_value", "title": "Percentage of all temp blocks read", "caption": "%Total"}'
      ']}, '
      '{"id": ["total_time1", "total_time2"], "class": "table_obj_value", "title": "Time spent by the statement", "caption": "Elapsed(s)"}, '
      '{"id": ["rows1", "rows2"], "class": "table_obj_value", "title": "Total number of rows retrieved or affected by the statement", "caption": "Rows"}, '
      '{"id": ["calls1", "calls2"], "class": "table_obj_value", "title": "Number of times the statement was executed", "caption": "Executions"}, '
      '{"id": ["stmt_cover1", "stmt_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(2, 'sqljit', 'sqlsthdr', 1150, 'Top SQL by JIT elapsed time', 'Top SQL by JIT elapsed time', 'statements_jit_stats', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"filter": {"type": "exists", "field": "ord_jit"},'
    '"ordering": "ord_jit",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "hdr table_obj_name jitCellId", "caption": "Query ID", "rowspan": true}, '
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
      '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"}, '
      '{"id": ["jit_total_time1", "jit_total_time2"], "class": "table_obj_value", "title": "Time spent on JIT in seconds", "caption": "JIT total (s)"}, '
      '{"caption": "Generation", "columns": ['
          '{"id": ["jit_functions1", "jit_functions2"], "class": "table_obj_value", "title": "Total number of functions JIT-compiled by the statement.", "caption": "Count"}, '
          '{"id": ["jit_generation_time1", "jit_generation_time2"], "class": "table_obj_value", "title": "Time spent by the statement on generating JIT code, in seconds.", "caption": "Time (s)"}'
          ']}, '
      '{"class": "table_obj_name", "caption": "Inlining", "columns": ['
          '{"id": ["jit_inlining_count1", "jit_inlining_count2"], "class": "table_obj_value", "title": "Number of times functions have been inlined.", "caption": "Count"}, '
          '{"id": ["jit_inlining_time1", "jit_inlining_time2"], "class": "table_obj_value", "title": "Time spent by the statement on inlining functions, in seconds.", "caption": "Time (s)"}'
          ']}, '
      '{"class": "table_obj_name", "caption": "Optimization", "columns": ['
          '{"id": ["jit_optimization_count1", "jit_optimization_count2"], "class": "table_obj_value", "title": "Number of times the statement has been optimized.", "caption": "Count"}, '
          '{"id": ["jit_optimization_time1", "jit_optimization_time2"], "class": "table_obj_value", "title": "Time spent by the statement on optimizing, in seconds.", "caption": "Time (s)"}'
      ']}, '
      '{"class": "table_obj_name", "caption": "Emission", "columns": ['
          '{"id": ["jit_emission_count1", "jit_emission_count2"], "class": "table_obj_value", "title": "Number of times code has been emitted.", "caption": "Count"}, '
          '{"id": ["jit_emission_time1", "jit_emission_time2"], "class": "table_obj_value", "title": "Time spent by the statement on emitting code, in seconds.", "caption": "Time (s)"}'
      ']}, '
      '{"class": "table_obj_name", "caption": "Deform", "condition": "statements_jit_deform", "columns": ['
        '{"id": ["jit_deform_count1", "jit_deform_count2"], "class": "table_obj_value", "title": "Number of tuple deform functions JIT-compiled by the statement.", "caption": "Count"}, '
        '{"id": ["jit_deform_time1", "jit_deform_time2"], "class": "table_obj_value", "title": "Total time spent by the statement on JIT-compiling tuple deform functions, in seconds.", "caption": "Time (s)"}'
      ']}, '
      '{"class": "table_obj_name", "caption": "Time (s)", "columns": ['
          '{"id": ["total_plan_time1", "total_plan_time2"], "class": "table_obj_value", "title": "Time spent planning statement", "condition": "planning_times", "caption": "Plan"}, '
          '{"id": ["total_exec_time1", "total_exec_time2"], "class": "table_obj_value", "title": "Time spent executing statement", "caption": "Exec"}'
      ']}, '
      '{"class": "table_obj_name", "caption": "I/O time (s)", "condition": "io_times", "columns": ['
          '{"id": ["shared_blk_read_time1", "shared_blk_read_time2"], "class": "table_obj_value", "title": "Time spent reading blocks by statement", "caption": "Read"}, '
          '{"id": ["shared_blk_write_time1", "shared_blk_write_time2"], "class": "table_obj_value", "title": "Time spent writing blocks by statement", "caption": "Write"}'
      ']},'
      '{"id": ["stmt_cover1", "stmt_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']}]'::jsonb),
(2, 'sqlworkers', 'sqlsthdr', 1175, 'Top SQL by parallel workers usage', 'Top SQL by parallel workers usage', 'statements_workers_stats', NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_statements",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"filter": {"type": "exists", "field": "ord_wrkrs_cnt"},'
    '"ordering": "ord_wrkrs_cnt",'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "hdr table_obj_name queryId", "caption": "Query ID", "rowspan": true}, '
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
      '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"],  "class": "interval", "caption": "I"}, '
      '{"caption": "Parallel workers", "columns": ['
        '{"id": ["parallel_workers_to_launch1", "parallel_workers_to_launch2"], "class": "table_obj_value", "caption": "Planned", "title": "Number of parallel workers planned to be launched by queries on this database"},'
        '{"id": ["parallel_workers_launched1", "parallel_workers_launched2"], "class": "table_obj_value", "caption": "Launched", "title": "Number of parallel workers launched by queries on this database"}'
      ']},'
      '{"id": ["total_exec_time1", "total_exec_time2"], "class": "table_obj_value", "title": "Time spent executing statement", "caption": "Exec (s)"}, '
      '{"id": ["shared_blks_fetched1", "shared_blks_fetched2"], "class": "table_obj_value", "title": "Shared blocks fetched (read and hit) by the statement", "caption": "blks fetched"}, '
      '{"title": "Number of blocks read by the statement", "caption": "Reads", "columns": ['
        '{"id": ["shared_blks_read1", "shared_blks_read2"], "title": "Number of shared blocks read by the statement", "caption": "Shr", "class": "table_obj_value"}, '
        '{"id": ["local_blks_read1", "local_blks_read2"], "title": "Number of local blocks read by the statement (usually used for temporary tables)", "caption": "Loc", "class": "table_obj_value"}, '
        '{"id": ["temp_blks_read1", "temp_blks_read2"], "title": "Number of temp blocks read by the statement (usually used for operations like sorts and joins)", "caption": "Tmp", "class": "table_obj_value"}'
      ']}, '
      '{"caption": "I/O time (s)", "condition": "io_times", "columns": ['
        '{"id": ["shared_blk_read_time1", "shared_blk_read_time2"], "class": "table_obj_value", "caption": "Read"}, '
        '{"id": ["shared_blk_write_time1", "shared_blk_write_time2"], "class": "table_obj_value", "caption": "Write"}'
      ']}'
    ']}]'::jsonb),
(2, 'sqlkcachehdr', 'sqlsthdr', 1200, 'Rusage statistics', 'Rusage statistics', 'kcachestatements', NULL, NULL, NULL),
(2, 'sqlrusgcpu', 'sqlkcachehdr', 100, 'Top SQL by system and user time', 'Top SQL by system and user time', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "top_rusage_statements",'
    '"filter": {"type": "exists", "field": "ord_cpu_time"},'
    '"ordering": "ord_cpu_time",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
        '{"id": "hexqueryid", "class": "hdr table_obj_name queryId", "caption": "Query ID", "rowspan": true}, '
        '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true}, '
        '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true}, '
        '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"}, '
        '{"title": "Userspace CPU", "caption": "User Time", "columns": ['
            '{"id": ["plan_user_time1", "plan_user_time2"], "class": "table_obj_value", "title": "User CPU time elapsed during planning", "caption": "Plan (s)", "condition": "rusage_planstats"}, '
            '{"id": ["exec_user_time1", "exec_user_time2"], "class": "table_obj_value", "title": "User CPU time elapsed during execution", "caption": "Exec (s)"}, '
            '{"id": ["user_time_pct1", "user_time_pct2"], "class": "table_obj_value", "title": "User CPU time elapsed by this statement as a percentage of total user CPU time", "caption": "%Total"}'
            ']}, '
        '{"title": "Kernelspace CPU", "caption": "System Time", "columns": ['
            '{"id": ["plan_system_time1", "plan_system_time2"], "class": "table_obj_value", "title": "System CPU time elapsed during planning", "caption": "Plan (s)", "condition": "rusage_planstats"}, '
            '{"id": ["exec_system_time1", "exec_system_time2"], "class": "table_obj_value", "title": "System CPU time elapsed during execution", "caption":"Exec (s)"}, '
            '{"id": ["system_time_pct1", "system_time_pct2"], "class": "table_obj_value", "title": "System CPU time elapsed by this statement as a percentage of total system CPU time", "caption": "%Total"}'
            ']}, '
        '{"id": ["rusage_cover1", "rusage_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
        ']'
    '}]'::jsonb),
(2, 'sqlrusgio', 'sqlkcachehdr', 200, 'Top SQL by reads/writes done by filesystem layer', 'Top SQL by reads/writes done by filesystem layer', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_rusage_statements",'
    '"filter": {"type": "exists", "field": "ord_io_bytes"},'
    '"ordering": "ord_io_bytes",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0},'
      '{"id": "queryid", "index": 1},'
      '{"id": "dbname", "index": 1},'
      '{"id": "username", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "hexqueryid", "dataset": "queries"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
      '{"id": "hexqueryid", "class": "hdr table_obj_name queryId", "caption": "Query ID", "rowspan": true},'
      '{"id": "dbname", "class": "table_obj_name hdr", "caption": "Database", "rowspan": true},'
      '{"id": "username", "class": "table_obj_name hdr", "caption": "User", "rowspan": true},'
      '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval", "caption": "I"},'
      '{"title": "Filesystem reads", "caption": "Read Bytes", "columns": ['
          '{"id": ["plan_reads1", "plan_reads2"], "class": "table_obj_value", "title": "Filesystem read amount during planning", "caption": "Plan", "condition": "rusage_planstats"},'
          '{"id": ["exec_reads1", "exec_reads2"], "class": "table_obj_value", "title": "Filesystem read amount during execution", "caption": "Bytes"},'
          '{"id": ["reads_total_pct1", "reads_total_pct2"], "class": "table_obj_value", "title": "Filesystem read amount of this statement as a percentage of all statements FS read amount", "caption": "%Total"}'
      ']},'
      '{"title": "Filesystem writes", "caption": "Write Bytes", "columns": ['
          '{"id": ["plan_writes1", "plan_writes2"], "class": "table_obj_value", "title": "Filesystem write amount during planning", "caption": "Plan", "condition": "rusage_planstats"},'
         '{"id": ["exec_writes1", "exec_writes2"], "class": "table_obj_value", "title": "Filesystem write amount during execution", "caption": "Bytes"},'
         '{"id": ["writes_total_pct1", "writes_total_pct2"], "class": "table_obj_value", "title": "Filesystem write amount of this statement as a percentage of all statements FS read amount", "caption": "%Total"}'
      ']}, '
      '{"id": ["rusage_cover1", "rusage_cover2"], "class": "table_obj_value", "condition": "statements_coverage", "caption": "%Cvr", "title": "Coverage: statement stats collection duration as a percentage of the report duration"} '
    ']'
  '}]'::jsonb),
(2, 'sqllist', 'sqlsthdr', 1300, 'Complete list of SQL texts', 'Complete list of SQL texts', NULL, NULL, NULL,
  '[{'
    '"type": "row_table", '
    '"source": "queries",'
    '"highlight": ['
      '{"id": "hexqueryid", "index": 0}'
    '],'
    '"columns": ['
        '{"id": "hexqueryid", "class": "table_obj_name queryTextId", "caption": "Query ID", "rowspan": true}, '
        '{"id": "query_texts", "class": "table_obj_name queryText", "caption": "Query Text"}'
    ']'
  '}]'::jsonb)
;

-- Schema objects section of a differential report
INSERT INTO report_struct (
  report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
  content, sect_struct)
VALUES
(2, 'tblscan', 'objects', 100, 'Top tables by estimated sequentially scanned volume', 'Top tables by estimated sequentially scanned volume', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_seq_scan"},'
    '"ordering": "ord_seq_scan",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "rowspan":true, "class": "table_obj_name hdr"},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Table", "columns": ['
       '{"caption": "~SeqBytes", "id": ["seqscan_bytes_pretty1", "seqscan_bytes_pretty2"], '
         '"class": "table_obj_value", '
         '"title": "Estimated number of bytes, fetched by sequential scans on this table"}, '
       '{"caption": "SeqScan", "id": ["seq_scan1", "seq_scan2"], '
         '"class": "table_obj_value", '
         '"title": "Number of sequential scans initiated on this table"}, '
       '{"caption": "IxScan", "id": ["idx_scan1", "idx_scan2"], '
         '"class": "table_obj_value", '
         '"title": "Number of index scans initiated on this table"}, '
       '{"caption": "IxFet", "id": ["idx_tup_fetch1", "idx_tup_fetch2"], '
         '"class": "table_obj_value", '
         '"title": "Number of live rows fetched by index scans from this table"} '
     ']},'
     '{"caption": "TOAST", "columns": ['
       '{"caption": "~SeqBytes", "id": ["t_seqscan_bytes_pretty1", "t_seqscan_bytes_pretty2"], '
         '"class": "table_obj_value", '
         '"title": "Estimated number of bytes, fetched by sequential scans on TOAST table"}, '
       '{"caption": "SeqScan", "id": ["toastseq_scan1", "toastseq_scan2"], '
         '"class": "table_obj_value", '
         '"title": "Number of sequential scans initiated on TOAST table"}, '
       '{"caption": "IxScan", "id": ["toastidx_scan1", "toastidx_scan2"], '
         '"class": "table_obj_value", '
         '"title": "Number of index scans initiated on TOAST table"}, '
       '{"caption": "IxFet", "id": ["toastidx_tup_fetch1", "toastidx_tup_fetch2"], '
         '"class": "table_obj_value", '
         '"title": "Number of live rows fetched by index scans from TOAST table"} '
     ']}'
    ']'
  '}]'::jsonb),
(2, 'tblfetch', 'objects', 200, 'Top tables by blocks fetched', 'Top tables by blocks fetched', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_io_tables",'
    '"filter": {"type": "exists", "field": "ord_fetch"},'
    '"ordering": "ord_fetch",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Heap", "columns": ['
          '{"caption": "Blks", "id": ["heap_blks_fetch1", "heap_blks_fetch2"], "title": "Number of blocks fetched (read+hit) from this table", "class": "table_obj_value"},'
          '{"caption": "%Total", "id": ["heap_blks_proc_pct1", "heap_blks_proc_pct2"], "title": "Heap blocks fetched for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Ix", "columns": ['
          '{"caption": "Blks", "id": ["idx_blks_fetch1", "idx_blks_fetch2"], "title": "Number of blocks fetched (read+hit) from all indexes on this table", "class": "table_obj_value"},'
          '{"caption": "%Total", "id": ["idx_blks_fetch_pct1", "idx_blks_fetch_pct2"], "title": "Indexes of blocks fetched for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
     ']},'
     '{"caption": "TOAST", "columns": ['
          '{"caption": "Blks", "id": ["toast_blks_fetch1", "toast_blks_fetch2"], "title": "Number of blocks fetched (read+hit) from this table''s TOAST table (if any)", "class": "table_obj_value"},'
          '{"caption": "%Total", "id": ["toast_blks_fetch_pct1", "toast_blks_fetch_pct2"], "title": "TOAST blocks fetched for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
     ']},'
     '{"caption": "TOAST-Ix", "columns": ['
          '{"caption": "Blks", "id": ["tidx_blks_fetch1", "tidx_blks_fetch2"], "title": "Number of blocks fetched (read+hit) from this table''s TOAST table indexes (if any)", "class": "table_obj_value"},'
          '{"caption": "%Total", "id": ["tidx_blks_fetch_pct1", "tidx_blks_fetch_pct2"], "title": "TOAST table index blocks fetched for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
     ']}'
    ']'
  '}]'::jsonb),
(2, 'tblrd', 'objects', 300, 'Top tables by blocks read', 'Top tables by blocks read', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_io_tables",'
    '"filter": {"type": "exists", "field": "ord_read"},'
    '"ordering": "ord_read",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Heap", "columns": ['
          '{"caption": "Blks", "id": ["heap_blks_read1", "heap_blks_read2"], "title": "Number of blocks read from this table", "class": "table_obj_value"},'
          '{"caption": "%Total", "id": ["heap_blks_read_pct1", "heap_blks_read_pct2"], "title": "Heap blocks read for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Ix", "columns": ['
          '{"caption": "Blks", "id": ["idx_blks_read1", "idx_blks_read2"], "title": "Number of blocks read from all indexes on this table", "class": "table_obj_value"},'
          '{"caption": "%Total", "id": ["idx_blks_read_pct1", "idx_blks_read_pct2"], "title": "Indexes of blocks read for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
     ']},'
     '{"caption": "TOAST", "columns": ['
          '{"caption": "Blks", "id": ["toast_blks_read1", "toast_blks_read2"], "title": "Number of blocks read from this table''s TOAST table (if any)", "class": "table_obj_value"},'
          '{"caption": "%Total", "id": ["toast_blks_read_pct1", "toast_blks_read_pct2"], "title": "TOAST blocks read for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
     ']},'
     '{"caption": "TOAST-Ix", "columns": ['
          '{"caption": "Blks", "id": ["tidx_blks_read1", "tidx_blks_read2"], "title": "Number of blocks read from this table''s TOAST table indexes (if any)", "class": "table_obj_value"},'
          '{"caption": "%Total", "id": ["tidx_blks_read_pct1", "tidx_blks_read_pct2"], "title": "TOAST table index blocks read for this table as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Hit(%)", "id": ["hit_pct1", "hit_pct2"], "class": "table_obj_value", "title": "Number of heap, indexes, toast and toast index blocks fetched from shared buffers as a percentage of all their blocks fetched from shared buffers and file system"}'
    ']'
  '}]'::jsonb),
(2, 'tbldml', 'objects', 400, 'Top DML tables', 'Top DML tables', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_dml"},'
    '"ordering": "ord_dml",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Table", "columns": ['
          '{"caption": "Ins", "id": ["n_tup_ins1", "n_tup_ins2"], "title": "Number of rows inserted", "class": "table_obj_value"},'
          '{"caption": "Upd", "id": ["n_tup_upd1", "n_tup_upd2"], "title": "Number of rows updated (includes HOT updated rows)", "class": "table_obj_value"},'
          '{"caption": "Del", "id": ["n_tup_del1", "n_tup_del2"], "title": "Number of rows deleted", "class": "table_obj_value"},'
          '{"caption": "Upd(HOT)", "id": ["n_tup_hot_upd1", "n_tup_hot_upd2"], "title": "Number of rows HOT updated (i.e., with no separate index update required)", "class": "table_obj_value"}'
     ']},'
     '{"caption": "TOAST", "columns": ['
          '{"caption": "Ins", "id": ["toastn_tup_ins1", "toastn_tup_ins2"], "title": "Number of rows inserted", "class": "table_obj_value"},'
          '{"caption": "Upd", "id": ["toastn_tup_upd1", "toastn_tup_upd2"], "title": "Number of rows updated (includes HOT updated rows)", "class": "table_obj_value"},'
          '{"caption": "Del", "id": ["toastn_tup_del1", "toastn_tup_del2"], "title": "Number of rows deleted", "class": "table_obj_value"},'
          '{"caption": "Upd(HOT)", "id": ["toastn_tup_hot_upd1", "toastn_tup_hot_upd2"], "title": "Number of rows HOT updated (i.e., with no separate index update required)", "class": "table_obj_value"}'
     ']}'
    ']'
  '}]'::jsonb),
(2, 'tblud', 'objects', 500, 'Top tables by updated/deleted tuples', 'Top tables by updated/deleted tuples', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_upd"},'
    '"ordering": "ord_upd",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Upd", "id": ["n_tup_upd1", "n_tup_upd2"], "title": "Number of rows updated (includes HOT updated rows)", "class": "table_obj_value"},'
     '{"caption": "Upd(HOT)", "id": ["n_tup_hot_upd1", "n_tup_hot_upd2"], "title": "Number of rows HOT updated (i.e., with no separate index update required)", "class": "table_obj_value"},'
     '{"caption": "Del", "id": ["n_tup_del1", "n_tup_del2"], "title": "Number of rows deleted", "class": "table_obj_value"},'
     '{"caption": "Vacuum count", "title": "Number of times vacuum operation was performed on the underlying table", "columns": ['
          '{"caption": "Vacuum", "id": ["vacuum_count1", "vacuum_count2"], "title": "Number of times this table has been manually vacuumed (not counting VACUUM FULL)", "class": "table_obj_value"},'
          '{"caption": "AutoVacuum", "id": ["autovacuum_count1", "autovacuum_count2"], "title": "Number of times this table has been vacuumed by the autovacuum daemon", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Analyze count", "title": "Number of times vacuum operation was performed on the underlying table", "columns": ['
          '{"caption": "Analyze", "id": ["analyze_count1", "analyze_count2"], "title": "Number of times this table has been manually analyzed", "class": "table_obj_value"},'
          '{"caption": "AutoAnalyze", "id": ["autoanalyze_count1", "autoanalyze_count2"], "title": "Number of times this table has been analyzed by the autovacuum daemon", "class": "table_obj_value"}'
     ']}'
    ']'
  '}]'::jsonb),
(2, 'tblupd_np', 'objects', 550, 'Top tables by new-page updated tuples', 'Top tables by new-page updated tuples', 'table_new_page_updates', NULL,
  '{"class": "notice", "text": "Top tables by number of rows updated where the successor version goes onto a new heap page, '
  'leaving behind an original version with a t_ctid field that points to a different heap page. '
  'These are always non-HOT updates."}',
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_upd_np"},'
    '"ordering": "ord_upd_np",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "NP Upd", "id": ["n_tup_newpage_upd1", "n_tup_newpage_upd2"], "title": "Number of rows updated to a new heap page", "class": "table_obj_value"},'
     '{"caption": "%Upd", "id": ["np_upd_pct1", "np_upd_pct2"], "title": "Number of new-page updated rows as a percentage of all rows updated", "class": "table_obj_value"},'
     '{"caption": "Upd", "id": ["n_tup_upd1", "n_tup_upd2"], "title": "Number of rows updated (includes HOT updated rows)", "class": "table_obj_value"},'
     '{"caption": "Upd(HOT)", "id": ["n_tup_hot_upd1", "n_tup_hot_upd2"], "title": "Number of rows HOT updated (i.e., with no separate index update required)", "class": "table_obj_value"}'
    ']'
  '}]'::jsonb),
(2, 'tblgrw', 'objects', 600, 'Top growing tables', 'Top growing tables', NULL, NULL,
  '{"class": "notice", "text": "Sizes in square brackets are based on pg_class.relpages data instead of pg_relation_size() function"}',
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_growth"},'
    '"ordering": "ord_growth",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Table", "columns": ['
          '{"caption": "Size", "id": ["relsize_pretty1", "relsize_pretty2"], "title": "Table size, as it was at the moment of last sample in report interval", "class": "table_obj_value"},'
          '{"caption": "Growth", "id": ["growth_pretty1", "growth_pretty2"], "title": "Table size increment during report interval", "class": "table_obj_value"},'
          '{"caption": "Ins", "id": ["n_tup_ins1", "n_tup_ins2"], "title": "Number of rows inserted", "class": "table_obj_value"},'
          '{"caption": "Upd", "id": ["n_tup_upd1", "n_tup_upd2"], "title": "Number of rows updated (includes HOT updated rows)", "class": "table_obj_value"},'
          '{"caption": "Del", "id": ["n_tup_del1", "n_tup_del2"], "title": "Number of rows deleted", "class": "table_obj_value"},'
          '{"caption": "Upd(HOT)", "id": ["n_tup_hot_upd1", "n_tup_hot_upd2"], "title": "Number of rows HOT updated (i.e., with no separate index update required)", "class": "table_obj_value"}'
     ']},'
     '{"caption": "TOAST", "columns": ['
          '{"caption": "Size", "id": ["t_relsize_pretty1", "t_relsize_pretty2"], "title": "Table size, as it was at the moment of last sample in report interval", "class": "table_obj_value"},'
          '{"caption": "Growth", "id": ["toastgrowth_pretty1", "toastgrowth_pretty2"], "title": "Table size increment during report interval", "class": "table_obj_value"},'
          '{"caption": "Ins", "id": ["toastn_tup_ins1", "toastn_tup_ins2"], "title": "Number of rows inserted", "class": "table_obj_value"},'
          '{"caption": "Upd", "id": ["toastn_tup_upd1", "toastn_tup_upd2"], "title": "Number of rows updated (includes HOT updated rows)", "class": "table_obj_value"},'
          '{"caption": "Del", "id": ["toastn_tup_del1", "toastn_tup_del2"], "title": "Number of rows deleted", "class": "table_obj_value"},'
          '{"caption": "Upd(HOT)", "id": ["toastn_tup_hot_upd1", "toastn_tup_hot_upd2"], "title": "Number of rows HOT updated (i.e., with no separate index update required)", "class": "table_obj_value"}'
     ']}'
    ']'
  '}]'::jsonb),
(2, 'ixfetch', 'objects', 700, 'Top indexes by blocks fetched', 'Top indexes by blocks fetched', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_io_indexes",'
    '"filter": {"type": "exists", "field": "ord_fetch"},'
    '"ordering": "ord_fetch",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1},'
      '{"id": "indexrelname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "indexrelid", "dataset": "index_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Index", "id": "indexrelname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Scans", "id": ["idx_scan1", "idx_scan2"], "title": "Number of scans performed on index", "class": "table_obj_value"},'
     '{"caption": "Blks", "id": ["idx_blks_fetch1", "idx_blks_fetch2"], "title": "Number of blocks fetched (read+hit) from this index", "class": "table_obj_value"},'
     '{"caption": "%Total", "id": ["idx_blks_fetch_pct1", "idx_blks_fetch_pct2"], "title": "Blocks fetched from this index as a percentage of all blocks fetched in a cluster", "class": "table_obj_value"}'
    ']'
  '}]'::jsonb),
(2, 'ixrd', 'objects', 800, 'Top indexes by blocks read', 'Top indexes by blocks read', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_io_indexes",'
    '"filter": {"type": "exists", "field": "ord_read"},'
    '"ordering": "ord_read",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1},'
      '{"id": "indexrelname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "indexrelid", "dataset": "index_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Index", "id": "indexrelname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Scans", "id": ["idx_scan1", "idx_scan2"], "title": "Number of scans performed on index", "class": "table_obj_value"},'
     '{"caption": "Blks Reads", "id": ["idx_blks_read1", "idx_blks_read2"], "title": "Number of disk blocks read from this index", "class": "table_obj_value"},'
     '{"caption": "%Total", "id": ["idx_blks_read_pct1", "idx_blks_read_pct2"], "title": "Blocks fetched from this index as a percentage of all blocks read in a cluster", "class": "table_obj_value"}, '
     '{"caption": "Hits(%)", "id": ["idx_blks_hit_pct1", "idx_blks_hit_pct2"], "title": "Index blocks buffer cache hit percentage", "class": "table_obj_value"}'
    ']'
  '}]'::jsonb),
(2, 'ixgrw', 'objects', 900, 'Top growing indexes', 'Top growing indexes', NULL, NULL,
  '{"class": "notice", "text": "Sizes in square brackets are based on pg_class.relpages data instead of pg_relation_size() function"}',
  '[{'
    '"type": "row_table",'
    '"source": "top_indexes",'
    '"filter": {"type": "exists", "field": "ord_growth"},'
    '"ordering": "ord_growth",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1},'
      '{"id": "indexrelname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "indexrelid", "dataset": "index_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Index", "id": "indexrelname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Index", "columns": ['
          '{"id": ["indexrelsize_pretty1", "indexrelsize_pretty2"], "caption": "Size", "title": "Index size, as it was at the moment of last sample in report interval", "class": "table_obj_value"},'
          '{"id": ["growth_pretty1", "growth_pretty2"], "caption": "Growth", "title": "Index size increment during report interval", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Table", "columns": ['
          '{"id": ["tbl_n_tup_ins1", "tbl_n_tup_ins2"], "caption": "Ins", "title": "Number of rows inserted", "class": "table_obj_value"},'
          '{"id": ["tbl_n_tup_upd1", "tbl_n_tup_upd2"], "caption": "Upd", "title": "Number of rows updated (without HOT updated rows)", "class": "table_obj_value"},'
          '{"id": ["tbl_n_tup_del1", "tbl_n_tup_del2"], "caption": "Del", "title": "Number of rows deleted", "class": "table_obj_value"}'
     ']}'
    ']'
  '}]'::jsonb)
;

-- Functions section of a differential report
INSERT INTO report_struct (
  report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
  content, sect_struct)
VALUES
(2, 'func_time', 'funchdr', 100, 'Top functions by total time', 'Top functions by total time', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_functions",'
    '"filter": {"type": "exists", "field": "ord_time"},'
    '"ordering": "ord_time",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "funcname", "index": 1}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Function", "id": "funcname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Executions", "id": ["calls1", "calls2"], "title": "Number of times this function has been called", "class": "table_obj_value"},'
     '{"caption": "Time (s)", "title": "Function execution timing statistics", "columns": ['
          '{"caption": "Total", "id": ["total_time1", "total_time2"], "class": "table_obj_value", "title": "Time spent in this function and all other functions called by it"},'
          '{"caption": "Self", "id": ["self_time1", "self_time2"], "class": "table_obj_value", "title": "Time spent in this function itself, not including other functions called by it"},'
          '{"caption": "Mean", "id": ["m_time1", "m_time2"], "class": "table_obj_value", "title": "Mean total time per execution"},'
          '{"caption": "Mean self", "id": ["m_stime1", "m_stime2"], "class": "table_obj_value", "title": "Mean self time per execution"}'
     ']}'
    ']'
  '}]'::jsonb),
(2, 'func_calls', 'funchdr', 200, 'Top functions by executions', 'Top functions by executions', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_functions",'
    '"filter": {"type": "exists", "field": "ord_calls"},'
    '"ordering": "ord_calls",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "funcname", "index": 1}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Function", "id": "funcname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Executions", "id": ["calls1", "calls2"], "title": "Number of times this function has been called", "class": "table_obj_value"},'
     '{"caption": "Time (s)", "title": "Function execution timing statistics", "columns": ['
          '{"caption": "Total", "id": ["total_time1", "total_time2"], "class": "table_obj_value", "title": "Time spent in this function and all other functions called by it"},'
          '{"caption": "Self", "id": ["self_time1", "self_time2"], "class": "table_obj_value", "title": "Time spent in this function itself, not including other functions called by it"},'
          '{"caption": "Mean", "id": ["m_time1", "m_time2"], "class": "table_obj_value", "title": "Mean total time per execution"},'
          '{"caption": "Mean self", "id": ["m_stime1", "m_stime2"], "class": "table_obj_value", "title": "Mean self time per execution"}'
     ']}'
    ']'
  '}]'::jsonb),
(2, 'func_trg', 'funchdr', 300, 'Top trigger functions by total time', 'Top trigger functions by total time', 'trigger_function_stats', NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_functions",'
    '"filter": {"type": "exists", "field": "ord_trgtime"},'
    '"ordering": "ord_trgtime",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "funcname", "index": 1}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Function", "id": "funcname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Executions", "id": ["calls1", "calls2"], "title": "Number of times this function has been called", "class": "table_obj_value"},'
     '{"caption": "Time (s)", "title": "Function execution timing statistics", "columns": ['
          '{"caption": "Total", "id": ["total_time1", "total_time2"], "class": "table_obj_value", "title": "Time spent in this function and all other functions called by it"},'
          '{"caption": "Self", "id": ["self_time1", "self_time2"], "class": "table_obj_value", "title": "Time spent in this function itself, not including other functions called by it"},'
          '{"caption": "Mean", "id": ["m_time1", "m_time2"], "class": "table_obj_value", "title": "Mean total time per execution"},'
          '{"caption": "Mean self", "id": ["m_stime1", "m_stime2"], "class": "table_obj_value", "title": "Mean self time per execution"}'
     ']}'
    ']'
  '}]'::jsonb)
;

-- Vacuum section of a regular report
INSERT INTO report_struct (
  report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
  content, sect_struct)
VALUES
(2, 'vacops', 'vachdr', 100, 'Top tables by vacuum operations', 'Top tables by vacuum operations', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_vac_cnt"},'
    '"ordering": "ord_vac_cnt",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Vacuum count", "title": "Number of times vacuum operation was performed on the underlying table", "columns": ['
          '{"caption": "Vacuum", "id": ["vacuum_count1", "vacuum_count2"], "title": "Number of times this table has been manually vacuumed (not counting VACUUM FULL)", "class": "table_obj_value"},'
          '{"caption": "AutoVacuum", "id": ["autovacuum_count1", "autovacuum_count2"], "title": "Number of times this table has been vacuumed by the autovacuum daemon", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Vacuum time (s)", "title": "Time spent by vacuum operations on a table", "condition": "vacuum_time", "columns": ['
          '{"caption": "Vacuum", "id": ["total_vacuum_time1", "total_vacuum_time2"], "title": "Total time this table has been manually vacuumed, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"},'
          '{"caption": "AutoVacuum", "id": ["atotal_autovacuum_time1", "total_autovacuum_time2"], "title": "Total time this table has been vacuumed by the autovacuum daemon, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Ins", "id": ["n_tup_ins1", "n_tup_ins2"], "class": "table_obj_value", "title": "Number of rows inserted"},'
     '{"caption": "Upd", "id": ["n_tup_upd1", "n_tup_upd2"], "class": "table_obj_value", "title": "Number of rows updated (includes HOT updated rows)"},'
     '{"caption": "Del", "id": ["n_tup_del1", "n_tup_del2"], "class": "table_obj_value", "title": "Number of rows deleted"},'
     '{"caption": "Upd(HOT)", "id": ["n_tup_hot_upd1", "n_tup_hot_upd2"], "class": "table_obj_value", "title": "Number of rows HOT updated (i.e., with no separate index update required)"}'
    ']'
  '}]'::jsonb),
(2, 'anops', 'vachdr', 150, 'Top tables by analyze operations', 'Top tables by analyze operations', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_anl_cnt"},'
    '"ordering": "ord_anl_cnt",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Analyze count", "title": "Number of times vacuum operation was performed on the underlying table", "columns": ['
          '{"caption": "Analyze", "id": ["analyze_count1", "analyze_count2"], "title": "Number of times this table has been manually analyzed", "class": "table_obj_value"},'
          '{"caption": "AutoAnalyze", "id": ["autoanalyze_count1", "autoanalyze_count2"], "title": "Number of times this table has been analyzed by the autovacuum daemon", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Analyze time (s)", "title": "Time spent by analyze operations on a table", "condition": "analyze_time", "columns": ['
          '{"caption": "Analyze", "id": ["total_analyze_time1", "total_analyze_time2"], "title": "Total time this table has been manually analyzed, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"},'
          '{"caption": "AutoAnalyze", "id": ["total_autoanalyze_time1", "total_autoanalyze_time2"], "title": "Total time this table has been analyzed by the autovacuum daemon, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Ins", "id": ["n_tup_ins1", "n_tup_ins2"], "class": "table_obj_value", "title": "Number of rows inserted"},'
     '{"caption": "Upd", "id": ["n_tup_upd1", "n_tup_upd2"], "class": "table_obj_value", "title": "Number of rows updated (includes HOT updated rows)"},'
     '{"caption": "Del", "id": ["n_tup_del1", "n_tup_del2"], "class": "table_obj_value", "title": "Number of rows deleted"},'
     '{"caption": "Upd(HOT)", "id": ["n_tup_hot_upd1", "n_tup_hot_upd2"], "class": "table_obj_value", "title": "Number of rows HOT updated (i.e., with no separate index update required)"}'
    ']'
  '}]'::jsonb),
(2, 'vactime', 'vachdr', 200, 'Top tables by vacuum time spent', 'Top tables by vacuum time spent', 'vacuum_time', NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_vac_time"},'
    '"ordering": "ord_vac_time",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Vacuum time (s)", "title": "Time spent by vacuum operations on a table", "columns": ['
          '{"caption": "Vacuum", "id": ["total_vacuum_time1", "total_vacuum_time2"], "title": "Total time this table has been manually vacuumed, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"},'
          '{"caption": "AutoVacuum", "id": ["total_autovacuum_time1", "total_autovacuum_time2"], "title": "Total time this table has been vacuumed by the autovacuum daemon, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Vacuum count", "title": "Number of times vacuum operation was performed on the underlying table", "columns": ['
          '{"caption": "Vacuum", "id": ["vacuum_count1", "vacuum_count2"], "title": "Number of times this table has been manually vacuumed (not counting VACUUM FULL)", "class": "table_obj_value"},'
          '{"caption": "AutoVacuum", "id": ["autovacuum_count1", "autovacuum_count2"], "title": "Number of times this table has been vacuumed by the autovacuum daemon", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Ins", "id": ["n_tup_ins1", "n_tup_ins2"], "class": "table_obj_value", "title": "Number of rows inserted"},'
     '{"caption": "Upd", "id": ["n_tup_upd1", "n_tup_upd2"], "class": "table_obj_value", "title": "Number of rows updated (includes HOT updated rows)"},'
     '{"caption": "Del", "id": ["n_tup_del1", "n_tup_del2"], "class": "table_obj_value", "title": "Number of rows deleted"},'
     '{"caption": "Upd(HOT)", "id": ["n_tup_hot_upd1", "n_tup_hot_upd2"], "class": "table_obj_value", "title": "Number of rows HOT updated (i.e., with no separate index update required)"}'
    ']'
  '}]'::jsonb),
(2, 'antime', 'vachdr', 250, 'Top tables by analyze time spent', 'Top tables by analyze time spent', 'analyze_time', NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_tables",'
    '"filter": {"type": "exists", "field": "ord_anl_time"},'
    '"ordering": "ord_anl_time",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "relid", "dataset": "table_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "I", "id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "class": "interval"},'
     '{"caption": "Analyze time (s)", "title": "Time spent by analyze operations on a table", "columns": ['
          '{"caption": "Analyze", "id": ["total_analyze_time1", "total_analyze_time2"], "title": "Total time this table has been manually analyzed, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"},'
          '{"caption": "AutoAnalyze", "id": ["total_autoanalyze_time1", "total_autoanalyze_time2"], "title": "Total time this table has been analyzed by the autovacuum daemon, in seconds. (This includes the time spent sleeping due to cost-based delays.)", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Analyze count", "title": "Number of times vacuum operation was performed on the underlying table", "columns": ['
          '{"caption": "Analyze", "id": ["analyze_count1", "analyze_count2"], "title": "Number of times this table has been manually analyzed", "class": "table_obj_value"},'
          '{"caption": "AutoAnalyze", "id": ["autoanalyze_count1", "autoanalyze_count2"], "title": "Number of times this table has been analyzed by the autovacuum daemon", "class": "table_obj_value"}'
     ']},'
     '{"caption": "Ins", "id": ["n_tup_ins1", "n_tup_ins2"], "class": "table_obj_value", "title": "Number of rows inserted"},'
     '{"caption": "Upd", "id": ["n_tup_upd1", "n_tup_upd2"], "class": "table_obj_value", "title": "Number of rows updated (includes HOT updated rows)"},'
     '{"caption": "Del", "id": ["n_tup_del1", "n_tup_del2"], "class": "table_obj_value", "title": "Number of rows deleted"},'
     '{"caption": "Upd(HOT)", "id": ["n_tup_hot_upd1", "n_tup_hot_upd2"], "class": "table_obj_value", "title": "Number of rows HOT updated (i.e., with no separate index update required)"}'
    ']'
  '}]'::jsonb),
(2, 'ixvacest', 'vachdr', 300, 'Top indexes by estimated vacuum load', 'Top indexes by estimated vacuum load', NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "top_indexes",'
    '"filter": {"type": "exists", "field": "ord_vac"},'
    '"ordering": "ord_vac",'
    '"highlight": ['
      '{"id": "dbname", "index": 0},'
      '{"id": "tablespacename", "index": 1},'
      '{"id": "schemaname", "index": 1},'
      '{"id": "relname", "index": 1},'
      '{"id": "indexrelname", "index": 1}'
    '],'
    '"preview": ['
      '{"id": "indexrelid", "dataset": "index_storage_parameters"}'
    '],'
    '"limit": "topn",'
    '"columns": ['
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Tablespace", "id": "tablespacename", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Schema", "id": "schemaname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Table", "id": "relname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"caption": "Index", "id": "indexrelname", "class": "table_obj_name hdr", "rowspan": true},'
     '{"id": ["1", "2"], "title":["properties.timePeriod1", "properties.timePeriod2"], "caption": "I", "class": "interval"},'
     '{"id": ["vacuum_bytes_pretty1", "vacuum_bytes_pretty2"], "caption": "Vacuum bytes", "class": "table_obj_value", "title": "Estimated implicit vacuum load caused by table indexes"},'
     '{"caption": "Vacuum count", "title": "Number of times vacuum operation was performed on the underlying table", "columns": ['
          '{"caption": "Vacuum", "id": ["vacuum_count1", "vacuum_count2"], "title": "Number of times this table has been manually vacuumed (not counting VACUUM FULL)", "class": "table_obj_value"},'
          '{"caption": "AutoVacuum", "id": ["autovacuum_count1", "autovacuum_count2"], "title": "Number of times this table has been vacuumed by the autovacuum daemon", "class": "table_obj_value"}'
     ']},'
     '{"id": ["avg_indexrelsize_pretty1", "avg_indexrelsize_pretty2"], "caption": "IX size", "class": "table_obj_value", "title": "Average index size during report interval"},'
     '{"id": ["avg_relsize_pretty1", "avg_relsize_pretty2"], "caption": "Relsize", "class": "table_obj_value", "title": "Average relation size during report interval"}'
    ']'
  '}]'::jsonb)
;

-- Settings sections
INSERT INTO report_struct(
    report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
    content, sect_struct)
VALUES
(2, 'definedset', 'settings', 800, NULL, NULL, NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "settings",'
    '"filter": {"type": "exists", "field": "defined_val"},'
    '"columns": ['
     '{"caption": "Defined settings", "columns": ['
          '{"caption": "Setting", "id": "name", "class": "table_obj_value"},'
          '{"caption": "reset_val", "id": "reset_val", "class": "table_obj_value switch_bold"},'
          '{"caption": "Unit", "id": "unit", "class": "table_obj_value"},'
          '{"caption": "Source", "id": "source", "class": "table_obj_value"},'
          '{"caption": "Notes", "id": "notes", "class": "table_obj_value switch_bold"}'
     ']}'
    ']'
  '},'
  '{'
    '"type": "row_table",'
    '"source": "settings",'
    '"filter": {"type": "exists", "field": "default_val"},'
    '"columns": ['
     '{"caption": "Default settings", "columns": ['
          '{"caption": "Setting", "id": "name", "class": "table_obj_value"},'
          '{"caption": "reset_val", "id": "reset_val", "class": "table_obj_value switch_bold"},'
          '{"caption": "Unit", "id": "unit", "class": "table_obj_value"},'
          '{"caption": "Source", "id": "source", "class": "table_obj_value"},'
          '{"caption": "Notes", "id": "notes", "class": "table_obj_value switch_bold"}'
     ']}'
    ']'
  '}]'::jsonb)
;
-- Extension sections
INSERT INTO report_struct(
    report_id, sect_id, parent_sect_id, s_ord, toc_cap, tbl_cap, feature, function_name,
    content, sect_struct)
VALUES
(2, 'extension_versions', 'extensions', 900, NULL, NULL, NULL, NULL, NULL,
  '[{'
    '"type": "row_table",'
    '"source": "extension_versions",'
    '"ordering": "ord_ext",'
    '"columns": ['
     '{"caption": "Name", "id": "extname", "class": "table_obj_name", "title": "Name of the extension"},'
     '{"caption": "DB", "id": "dbname", "class": "table_obj_name", "title": "Name of the database"},'
     '{"caption": "First seen", "condition": "extension_versions_show_date_columns", "id": "first_seen", "class": "table_obj_value", "title": " The first appearance this extension version"},'
     '{"caption": "Last seen", "condition": "extension_versions_show_date_columns", "id": "last_seen", "class": "table_obj_value", "title": "The last appearance of the extension version"},'
     '{"caption": "Version", "id": "extversion", "class": "table_obj_value", "title": "Version name for the extension"}'
    ']'
  '}]'::jsonb)
;
